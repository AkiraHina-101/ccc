# Crank Meshing — package PSJ

## Chạy tool

1. Copy **nguyên thư mục này** sang máy đích, giữ nguyên cấu trúc `src/`.
2. Mở model input mới trong Jupiter, chạy **crank_messing.py** ở thư mục gốc bằng PSJ.
3. Chọn faces Pin/Journal, kiểm tra Radius/Width rồi bấm **Apply**.
4. **Renumber** là nút riêng; Auto renumber mặc định tắt. Thời gian từng bước in ra console.

Nếu PSJ không cung cấp `__file__`, sửa dòng **TOOL_FOLDER** gần đầu launcher
thành vị trí thư mục package trên máy đích, ví dụ:

```python
TOOL_FOLDER = r'D:/PSJ Tools/crank_messing'
```

Cũng có thể đặt biến môi trường `CRANK_MESSING_HOME` trỏ tới thư mục này.
Không chạy trực tiếp các module trong `src/`. Không cần cài Python ngoài;
tool dùng Python, JPT và pyjdg có sẵn trong Jupiter.
Thư mục package cần quyền ghi vì tool tự tạo `data/runs/` khi chạy.

## Thành phần

| Đường dẫn | Nội dung |
|---|---|
| crank_messing.py | Launcher PSJ, có xử lý trường hợp thiếu __file__ |
| src/crank_messing/ | Toàn bộ source runtime |
| src/core/revolve_tet10_psj.py | Core revolve giữ nguyên byte |
| PACKAGE-MANIFEST.json | Danh sách file, kích thước và SHA256 lúc đóng gói |

Package chỉ chứa launcher, source và hướng dẫn; không kèm model thử,
logs, checkpoint, archive, tests, MCP hay môi trường .venv. Không nén ZIP.
Tên namespace/file giữ đúng `crank_messing` như bản đang dùng.

## Luồng và phiên bản

Apply chạy 13 bước: đo CAD → surface crank chính → tạo Pin/Journal TET10
và RBE2 → dọn seed faces/edges → nối lưới/merge nodes/share faces →
volume crank TET10 → gộp Journal thành một part và Pin thành một part.
Mesh của Pin/Journal được giữ trong bước mesh crank.

Mặc định ngầm: 40 segments; 6 lớp W và 6 lớp radial; Journal W ratio
1:2:3:3:2:1, Pin chia đều; RBE2 ring thứ 2, đủ 6 DOF.

Runtime đã được thử trên **Jupiter 5.0.4**. **5.0.1 chưa được kiểm chứng runtime**.
Đây là bản đóng gói source hiện tại; lần đóng gói không chạy lại mesh native.
