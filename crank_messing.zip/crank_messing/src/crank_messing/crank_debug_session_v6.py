"""Minimal session owner: atomic checkpoints and native geometry measurement."""
import json
import os
import time
from pathlib import Path
from uuid import uuid4

def write_json(path, value, compact=False):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=None if compact else 2, ensure_ascii=False,
                              separators=(',', ':') if compact else None), encoding='utf-8')
    # Windows readers can briefly deny atomic rename while inspecting a report.
    for attempt in range(6):
        try:
            temp.replace(path)
            return
        except PermissionError as exc:
            if getattr(exc, 'winerror', None) not in (5, 32) or attempt == 5:
                raise
            time.sleep(.025 * 2**attempt)


def counts(jpt):
    return dict(parts=len(jpt.GetAllParts()), faces=len(jpt.GetAllFaces()),
        nodes=len(jpt.GetAllNodes()), elements=len(jpt.GetAllElems()),
        solids=len(jpt.GetElemsByKind(jpt.ElemKind.ELEMKIND_3D)),
        connections=len(jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION)))


class DebugSession:
    def __init__(self, jpt, root):
        self.jpt, self.root = jpt, Path(root)
        self.folder = self.root / 'data/runs' / ('debug_' + uuid4().hex)
        self.folder.mkdir(parents=True)
        self.state = dict(schema_version=2, pid=os.getpid(), events=[], steps={}, feedback=[])
        if hasattr(jpt,'GetActiveDocument'):
            self.state['document_id']=str(jpt.GetActiveDocument().docID)
        self.context = {}
        self.busy = False
        self.save()

    def save(self):
        write_json(self.folder / 'debug-session.json', self.state, compact=True)

    def measure(self):
        from .crank_faces import FaceGroups
        from .crank_geometry_v6 import measure_faces
        from Tools.Measure.Radius import Edge as MeasureRadius
        state = FaceGroups()
        for group in ('journal', 'pin'):
            state.capture(group, self.context.get('groups', {}).get(group, []))
        groups = state.validate()
        centers = self.context.setdefault('centers', {})
        available = {int(f.id) for f in self.jpt.GetAllFaces()}
        if not set(groups['journal']+groups['pin']).issubset(available):
            raise ValueError('Captured faces no longer exist')
        for group, ids in groups.items():
            for fid in ids:
                if fid in centers:
                    continue
                before = {int(n.id) for n in self.jpt.GetAllNodes()}
                command = 'MeshEditCreateNodeCylindCenter([6:%d], %d)' % (fid, max(before | {0})+1)
                self.state['pending_command'] = dict(step='measure', command=command)
                self.save()
                response = self.jpt.Exec(command)
                after = {int(n.id): n for n in self.jpt.GetAllNodes()}
                created = set(after)-before
                if len(created) != 1:
                    raise RuntimeError('Cylinder-center readback failed: %s new=%s' % (response, sorted(created)))
                nid = next(iter(created))
                n = after[nid]
                centers[fid] = dict(group=group, face_id=fid, node_id=nid,
                    xyz_m=[float(n.pos.x), float(n.pos.y), float(n.pos.z)])
                self.state['measured_centers'] = centers
                self.save()
        geometry = measure_faces(self.jpt, groups, centers,
            lambda e: MeasureRadius('%d:%d' % (e.typeID, e.id), iPrecision=12))
        self.context['geometry'] = geometry
        self.state['geometry'] = geometry
        return dict(geometry=geometry, scope='Measured geometry only; center nodes created, no mesh')
