"""Selection snapshots; independent from Jupiter and mesh implementation."""
class FaceGroups:
    def __init__(self):
        self.groups = {'journal': [], 'pin': []}

    def capture(self, group, ids):
        if group not in self.groups:
            raise ValueError('Unknown face group')
        ids = list(dict.fromkeys(int(value) for value in ids))
        if not ids or any(value <= 0 for value in ids):
            raise ValueError('Select at least one valid ' + group + ' face in the model')
        other = 'pin' if group == 'journal' else 'journal'
        overlap = set(ids) & set(self.groups[other])
        if overlap:
            raise ValueError('Faces already assigned to ' + other + ': ' + ', '.join(map(str, sorted(overlap))))
        self.groups[group] = ids
        return list(ids)

    def validate(self):
        for group in ('journal', 'pin'):
            if not self.groups[group]:
                raise ValueError('Capture ' + group + ' faces first')
        return {name: list(values) for name, values in self.groups.items()}
