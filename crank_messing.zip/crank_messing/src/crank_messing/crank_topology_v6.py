"""Explicit old-cylinder/connection removal planning; no model mutations here."""
import math
from collections import defaultdict


def snapshot(jpt, part_ids=None):
    parts = list(jpt.GetAllParts())
    if part_ids is not None:
        wanted = set(map(int, part_ids))
        parts = [p for p in parts if int(p.id) in wanted]
        if {int(p.id) for p in parts} != wanted:
            raise ValueError('Target part is missing')
    faces = {int(f.id): f for p in parts for f in p.faces}
    edges = {int(e.id): e for f in faces.values() for e in f.edges}
    nodes = {int(n.id): n for f in faces.values() for n in f.nodes}
    nodes.update({int(n.id): n for e in edges.values() for n in e.nodes})
    elems = {int(e.id): e for f in faces.values() for e in f.elems}
    return dict(parts=[dict(id=int(p.id), name=str(p.name), faces=[int(f.id) for f in p.faces]) for p in parts],
        faces=[dict(id=fid, edges=[int(e.id) for e in f.edges], nodes=[int(n.id) for n in f.nodes],
                    elems=[int(e.id) for e in f.elems]) for fid, f in faces.items()],
        edges=[dict(id=eid, nodes=[int(n.id) for n in e.nodes]) for eid, e in edges.items()],
        nodes={nid: [float(n.pos.x), float(n.pos.y), float(n.pos.z)] for nid, n in nodes.items()},
        elements={eid: [int(n.id) for n in e.nodes] for eid, e in elems.items()})


def indexed(data):
    return ({int(f['id']): f for f in data['faces']},
            {int(e['id']): e for e in data['edges']},
            {int(n): p for n, p in data['nodes'].items()},
            {int(e): n for e, n in data['elements'].items()})


def face_signature(face, nodes):
    return tuple(sorted(tuple(round(v, 10) for v in nodes[int(n)]) for n in face['nodes']))


def map_copied_faces(source, copied, selected):
    sf, _, sn, _ = indexed(source)
    cf, _, cn, _ = indexed(copied)
    lookup = defaultdict(list)
    for fid, face in cf.items():
        lookup[face_signature(face, cn)].append(fid)
    result = {}
    for fid in selected:
        matches = lookup.get(face_signature(sf[int(fid)], sn), [])
        if len(matches) != 1:
            raise ValueError('Copy mapping is ambiguous for face %d' % fid)
        result[int(fid)] = matches[0]
    return result


def ring_geometry(edge, nodes, axis, center, tolerance=1e-7):
    points = [nodes[int(n)] for n in edge['nodes']]
    if len(points) < 8:
        raise ValueError('Connection boundary has insufficient ring nodes')
    axial = [p[axis] for p in points]
    if max(axial)-min(axial) > tolerance:
        raise ValueError('Connection boundary is not a planar ring')
    transverse = [i for i in range(3) if i != axis]
    angles = sorted(set(round(math.atan2(p[transverse[1]]-center[transverse[1]],
                                       p[transverse[0]]-center[transverse[0]]), 10) for p in points))
    gaps = [b-a for a, b in zip(angles, angles[1:])] + [angles[0]+2*math.pi-angles[-1]]
    if max(gaps) >= math.pi/2:
        raise ValueError('Connection boundary is not a complete circular ring')
    radii = [math.hypot(p[transverse[0]]-center[transverse[0]],
                        p[transverse[1]]-center[transverse[1]]) for p in points]
    radius = sum(radii)/len(radii)
    if min(radii) <= 0 or max(radii)-min(radii) > radius*.02:
        raise ValueError('Connection boundary is not concentric with its cylinder')
    return dict(plane_m=sum(axial)/len(axial), radius_m=radius,
                radius_min_m=min(radii), radius_max_m=max(radii))


def removal_plan(data, geometry):
    """Accept only one short two-ring connection at each cylinder end.

    Identification combines shared-edge topology and complete-ring geometry.
    It never walks recursively into neighboring webs or deletes arbitrary small faces.
    """
    faces, edges, nodes, elems = indexed(data)
    adjacency = defaultdict(set)
    for fid, face in faces.items():
        for eid in face['edges']:
            adjacency[int(eid)].add(fid)
    cylinders = {int(r['face_id']) for r in geometry}
    if not cylinders or len(cylinders) != len(geometry):
        raise ValueError('Unique cylinder geometry records required')
    connections, used = [], set()
    for row in geometry:
        fid = int(row['face_id'])
        if fid not in faces or set(faces[fid]['edges']) != set(row['boundary_edge_ids']):
            raise ValueError('Cylinder topology changed after measurement')
        axis = 'XYZ'.index(row['axis'])
        center = row['center']['xyz_m']
        for eid in row['boundary_edge_ids']:
            neighbors = adjacency[eid]-{fid}
            if len(neighbors) != 1:
                raise ValueError('Expected one connection face per cylinder boundary')
            cid = neighbors.pop()
            face = faces[cid]
            if cid in cylinders or cid in used or len(face['edges']) != 2:
                raise ValueError('Connection face is ambiguous or unsupported')
            outer = next(e for e in face['edges'] if e != eid)
            retained = adjacency[outer]-{cid}
            if len(retained) != 1 or retained & cylinders:
                raise ValueError('Connection has no unique retained crankshaft neighbor')
            inner_ring = ring_geometry(edges[eid], nodes, axis, center)
            outer_ring = ring_geometry(edges[outer], nodes, axis, center)
            delta = outer_ring['plane_m']-inner_ring['plane_m']
            direction = inner_ring['plane_m']-center[axis]
            radius = row['radius_m']
            if delta*direction <= 0 or not 1e-7 < abs(delta) < radius*.15:
                raise ValueError('Adjacent face is not a short outward axial connection')
            if not radius*.8 < outer_ring['radius_m'] < radius*1.2:
                raise ValueError('Connection outer ring differs too much from cylinder radius')
            connections.append(dict(cylinder_face_id=fid, group=row['group'], face_id=cid,
                inner_edge_id=eid, outer_edge_id=outer, retained_face_id=next(iter(retained)),
                inner_ring=inner_ring, outer_ring=outer_ring,
                outer_node_ids=list(edges[outer]['nodes']), old_element_ids=list(face['elems'])))
            used.add(cid)
    delete = cylinders | used
    return dict(cylinder_face_ids=sorted(cylinders), connection_face_ids=sorted(used),
        delete_face_ids=sorted(delete), connections=connections,
        delete_element_ids=sorted({int(e) for fid in delete for e in faces[fid]['elems']}),
        retained_face_ids=sorted(set(faces)-delete),
        retained_boundary_node_ids=sorted({int(n) for c in connections for n in c['outer_node_ids']}))


def delete_old_faces(jpt, plan, progress):
    """Run explicit native deletion once and prove the scoped readback."""
    from Geometry.DeleteEntity import Face
    if progress.get('delete_started'):
        raise ValueError('Removal already attempted; inspect partial state before retrying')
    targets = plan['delete_face_ids']
    if not targets:
        raise ValueError('Explicit nonempty removal targets required')
    before_faces = {int(f.id) for f in jpt.GetAllFaces()}
    before_elems = {int(e.id) for e in jpt.GetAllElems()}
    if not set(targets).issubset(before_faces):
        raise ValueError('Removal targets are stale')
    progress['delete_started'] = True
    progress['delete_result'] = str(Face('[%s]' % ', '.join('6:%d' % fid for fid in targets),
                                       bIgnoreFaceOnSolidBody=False))
    after_faces = {int(f.id) for f in jpt.GetAllFaces()}
    after_elems = {int(e.id) for e in jpt.GetAllElems()}
    progress['removed_face_ids'] = sorted(before_faces-after_faces)
    progress['removed_element_ids'] = sorted(before_elems-after_elems)
    if before_faces-after_faces != set(targets) or after_faces-before_faces:
        raise RuntimeError('Native deletion did not remove exactly the planned faces')
    if set(plan['delete_element_ids']) & after_elems:
        raise RuntimeError('Deleted faces still have their old surface elements')
    after_nodes = {int(n.id) for n in jpt.GetAllNodes()}
    if not set(plan['retained_boundary_node_ids']).issubset(after_nodes):
        raise RuntimeError('Native deletion removed retained connection boundary nodes')
    jpt.ClearAllSelection()
    progress['delete_verified'] = True
    return progress
