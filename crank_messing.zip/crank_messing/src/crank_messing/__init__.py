"""Isolated clean review candidate; no native operations on import."""
import importlib
import sys

_RUNTIME = ('crank_connectivity', 'crank_revolve', 'crank_faces', 'crank_interface',
    'crank_geometry_v6', 'crank_parameters_v6', 'crank_topology_v6',
    'crank_insert_batch_v6', 'crank_seed_cleanup', 'crank_native_inserts', 'crank_bridge_quality', 'crank_sections_v6', 'crank_validation',
    'crank_debug_session_v6', 'crank_surface', 'crank_model_index', 'crank_volume', 'crank_part_groups', 'crank_prepare_v8', 'crank_mainflow_v8', 'crank_renumber', 'crank_gui_layout', 'crank_psj_v8')


def reload_runtime():
    """Refresh dependencies in order when Jupiter keeps Python modules cached."""
    importlib.invalidate_caches()
    for name in _RUNTIME:
        qualified = __name__ + '.' + name
        if qualified in sys.modules:
            importlib.reload(sys.modules[qualified])
        else:
            importlib.import_module(qualified)
    return sys.modules[__name__ + '.crank_psj_v8']
