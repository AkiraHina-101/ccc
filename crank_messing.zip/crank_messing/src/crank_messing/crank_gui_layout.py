"""Compact native JDG form and measured geometry tables."""
from .crank_parameters_v6 import DEFAULT_TARGETS

FORM_WIDTH=336
LABEL_WIDTH=80
INPUT_WIDTH=320
ROW_HEIGHT=22
TABLE_ROWS=2
TABLE_WIDTH=400
TABLE_HEIGHT=78
TABLE_LABEL_WIDTH=64
TABLE_FACE_WIDTH=52

def build_form(dlg,size_behavior):
    fixed=[]
    def row(parent,name):
        dlg.add_hlayout(parent,name=name,margin=[2,1,2,1])
        return name
    def text(parent,name,label,value):
        r=row(parent,name+'_row')
        dlg.add_label(r,name+'_label',text=label,width=LABEL_WIDTH,height=ROW_HEIGHT)
        dlg.add_textbox(r,name,text=str(value),width=INPUT_WIDTH,height=ROW_HEIGHT)
        fixed.extend((name+'_label',name))
    dlg.add_face_selector()
    dlg.add_groupbox('Window','face_inputs',text='Faces')
    for group in ('journal','pin'):
        r=row('face_inputs',group+'_faces_row')
        dlg.add_radiobutton(r,'pick_'+group,text=group.capitalize(),checked=int(group=='journal'),
            group=1,width=LABEL_WIDTH,height=ROW_HEIGHT)
        dlg.add_textbox(r,group+'_faces',text='',width=INPUT_WIDTH,height=ROW_HEIGHT)
        fixed.extend(('pick_'+group,group+'_faces'))
    for group in ('pin','journal'):
        dlg.add_groupbox('Window',group+'_geometry',text=group.capitalize()+' (mm)')
        dlg.add_table(group+'_geometry',name=group+'_dimensions',columns=[''],
            rows=TABLE_ROWS,width=TABLE_WIDTH,height=TABLE_HEIGHT,
            show_grid_line=True,show_row_number=False,show_col_header=True,menus=[])
        dlg.set_item_size_behavior(group+'_dimensions',size_behavior.horizontal)
    dlg.add_groupbox('Window','center_options',text='Center IDs')
    for group in ('journal','pin'):
        text('center_options',group+'_targets',group.capitalize()+' IDs',DEFAULT_TARGETS[group])
    r=row('center_options','renumber_row')
    dlg.add_label(r,'increment_label',text='Increment',width=LABEL_WIDTH,height=ROW_HEIGHT)
    dlg.add_textbox(r,'increment',text='1',width=96,height=ROW_HEIGHT)
    dlg.add_checkbox(r,'renumber',text='Auto renumber',checked=False,width=145,height=ROW_HEIGHT)
    fixed.extend(('renumber','increment_label','increment'))
    dlg.add_label('Window','status',text='Ready',width=FORM_WIDTH,height=20)
    r=row('Window','footer')
    dlg.add_space(r,name='footer_start',orientation='horizontal',size=0)
    dlg.add_button(r,'renumber_now',text='Renumber',width=80,height=30)
    dlg.add_button(r,'debug',text='Debug',width=80,height=30)
    dlg.add_button(r,'apply',text='Apply',width=80,height=30)
    dlg.add_space(r,name='footer_end',orientation='horizontal',size=0)
    fixed.extend(('renumber_now','debug','apply'))
    for name in fixed: dlg.set_item_size_behavior(name,size_behavior.fixed)
    return fixed


def dimension_series(records,groups=None):
    """Selected faces become stations ordered by center X, independently of axis."""
    result={}
    for group in ('pin','journal'):
        available={int(r['face_id']):r for r in records if r['group']==group}
        wanted=list(dict.fromkeys(int(n) for n in (groups[group] if groups is not None else available)))
        wanted.sort(key=lambda fid:(float(available[fid]['center']['xyz_m'][0]) if fid in available else float('inf'),fid))
        result[group]=[(fid,available.get(fid)) for fid in wanted]
    return result


def update_dimensions(dlg,records,groups=None):
    """Each face is one #n column; Radius and Width are the only data rows."""
    from pyjdg import TableColumnInfo,TableColumnInfoVector
    series=dimension_series(records,groups)
    for group in ('pin','journal'):
        name=group+'_dimensions'
        selected=series[group]
        columns=len(selected)+1
        current=dlg.get_total_column(name)
        if current<columns:
            for index in range(current,columns):
                # Native inserts a vector at one position in reverse order.
                # Single-column inserts preserve the visible #1...#n headers.
                extra=TableColumnInfoVector()
                extra.append(TableColumnInfo(name='#%d'%index,type='String'))
                dlg.insert_table_columns(name,extra,position=index)
        while current>columns:
            current-=1
            dlg.delete_table_column(name,current)
        dlg.set_table_column_width(name,0,TABLE_LABEL_WIDTH)
        for row,label in enumerate(('Radius','Width')):
            dlg.set_cell_value(name,row=row,col=0,value=label)
            dlg.set_table_cell_alignment(name,row,0,'Left')
        for column,(fid,record) in enumerate(selected,1):
            dlg.set_table_column_width(name,column,TABLE_FACE_WIDTH)
            for row,key in enumerate(('radius_m','width_m')):
                value='%.6g'%(record[key]*1000) if record is not None else '-'
                dlg.set_cell_value(name,row=row,col=column,value=value)
                dlg.set_table_cell_alignment(name,row,column,'Right')
        dlg.disable_item(name)
    return {group:[fid for fid,record in selected] for group,selected in series.items()}
