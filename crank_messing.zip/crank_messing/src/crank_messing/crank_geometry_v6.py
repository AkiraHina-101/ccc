"""Face-driven geometry/insert planning. No CSV, entered radii or entered widths.

This is the next v5 backend stage, NOT a completed remainder mesher.
"""
import math
import statistics
from copy import deepcopy
from .crank_faces import FaceGroups
from .crank_revolve import load_core


def measure_faces(jpt, groups, centers, radius_by_edge, tolerance_m=1e-7):
    """Read native arc radii and two planar circular boundaries per face.

    Explicitly reject unsupported topology instead of guessing from tessellation.
    Native node positions and Tools.Measure.Radius.Edge return SI metres.
    """
    state = FaceGroups()
    for name in ('journal', 'pin'):
        state.capture(name, groups[name])
    groups = state.validate()
    available = {int(face.id): face for face in jpt.GetAllFaces()}
    records = []
    for group in ('journal', 'pin'):
        for fid in groups[group]:
            if fid not in available or fid not in centers:
                raise ValueError('Face/center is missing: %d' % fid)
            face = available[fid]
            edges = list(face.edges)
            if len(edges) != 2:
                raise ValueError('Face %d: expected two circular boundaries; partitioned faces need a separate topology path' % fid)
            boundaries = []
            for edge in edges:
                points = [(float(n.pos.x), float(n.pos.y), float(n.pos.z)) for n in edge.nodes]
                if len(points) < 3 or not all(math.isfinite(v) for p in points for v in p):
                    raise ValueError('Face %d: insufficient/invalid boundary nodes' % fid)
                radius = float(radius_by_edge(edge))
                if not math.isfinite(radius) or radius <= 0:
                    raise ValueError('Face %d: native circular-edge radius measurement failed' % fid)
                boundaries.append(dict(edge_id=int(edge.id), points=points, radius_m=radius))
            candidates = []
            for axis in range(3):
                if all(max(p[axis] for p in b['points']) - min(p[axis] for p in b['points']) <= tolerance_m for b in boundaries):
                    planes = [statistics.median(p[axis] for p in b['points']) for b in boundaries]
                    if abs(planes[1] - planes[0]) > tolerance_m:
                        candidates.append((axis, sorted(planes)))
            if len(candidates) != 1:
                raise ValueError('Face %d: cannot determine a unique axis from circular boundary planes' % fid)
            axis, planes = candidates[0]
            radii = [b['radius_m'] for b in boundaries]
            if abs(radii[0] - radii[1]) > tolerance_m:
                raise ValueError('Face %d: boundary radii differ (not a constant-radius cylinder)' % fid)
            center = centers[fid]
            if center['group'] != group:
                raise ValueError('Face group/center mismatch')
            if abs(center['xyz_m'][axis] - sum(planes)/2) > tolerance_m:
                raise ValueError('Face %d: native center does not match boundary midpoint' % fid)
            records.append(dict(group=group, face_id=fid, center=center,
                axis='XYZ'[axis], radius_m=sum(radii)/2, width_m=planes[1]-planes[0],
                boundary_planes_m=planes, boundary_edge_ids=[b['edge_id'] for b in boundaries],
                evidence='native arc radius + planar circular-edge node coordinates'))
    if len({r['axis'] for r in records}) != 1:
        raise ValueError('Journal/Pin cylinder axes must be parallel')
    axis = 'XYZ'.index(records[0]['axis'])
    transverse = [i for i in range(3) if i != axis]
    journals = [r for r in records if r['group'] == 'journal']
    origin = journals[0]['center']['xyz_m']
    # Native cylinder-center has micrometre-level transverse fitting noise.
    if any(math.dist([r['center']['xyz_m'][i] for i in transverse],
                     [origin[i] for i in transverse]) > max(tolerance_m, 5e-6) for r in journals):
        raise ValueError('Journal faces do not share the crank axis')
    return sorted(records, key=lambda r: (r['group'] != 'journal', r['center']['xyz_m'][axis]))


def refresh_surface_boundaries(jpt, records, tolerance_m=1e-7):
    """Keep measured CAD dimensions; bind them to the new tessellated rings.

    Radius.Edge fits the remeshed polygon, so it no longer gives the exact CAD
    radius. Check the new rings against the original dimensions instead.
    """
    from .crank_topology_v6 import ring_geometry
    available = {int(f.id): f for f in jpt.GetAllFaces()}
    refreshed = deepcopy(records)
    for row in refreshed:
        face = available.get(row['face_id'])
        if face is None or len(list(face.edges)) != 2:
            raise ValueError('Surface mesh changed cylinder topology: %d' % row['face_id'])
        rings, edge_ids = [], []
        for edge in face.edges:
            nodes = {int(n.id): [float(n.pos.x), float(n.pos.y), float(n.pos.z)] for n in edge.nodes}
            ring = ring_geometry(dict(nodes=list(nodes)), nodes, 'XYZ'.index(row['axis']), row['center']['xyz_m'])
            if max(abs(ring[key]-row['radius_m']) for key in ('radius_min_m','radius_max_m')) > row['radius_m']*.005:
                raise ValueError('Surface boundary differs from measured cylinder: %d' % row['face_id'])
            rings.append(ring['plane_m']); edge_ids.append(int(edge.id))
        if any(abs(a-b)>tolerance_m for a,b in zip(sorted(rings),row['boundary_planes_m'])):
            raise ValueError('Surface mesh changed cylinder end planes: %d' % row['face_id'])
        row['boundary_edge_ids'] = edge_ids
        row['surface_boundary_evidence'] = 'Complete planar rings within 0.5% of original CAD radius; original end planes retained'
    return refreshed


def make_face_plan(records, layer_settings, doc_units_per_m=1000.0, sectors=32):
    """Only layers/ratios come from user settings; physical dimensions from faces."""
    core = load_core()
    scale = core.positive(doc_units_per_m, 'Document length scale')
    rows, totals, stations = [], 0, {'journal': 0, 'pin': 0}
    if not records:
        raise ValueError('Measure Journal/Pin faces first')
    for record in records:
        group = record['group']
        settings = layer_settings[group]
        width, radius = record['width_m']*scale, record['radius_m']*scale
        wl = core.levels(width, settings['width_layers'], settings['width_ratios'], 'Width')
        rl = core.levels(radius, settings['radial_layers'], settings['radial_ratios'], 'Radius')
        totals += 3*(len(wl)-1)*int(sectors)*(2*(len(rl)-1)-1)
        if totals > core.MAX_TETS:
            raise ValueError('Combined inserts exceed 250000 tetrahedra')
        stations[group] += 1
        params = dict(centers=str(record['center']['node_id']), xyz='', axis=record['axis'],
            width=str(width), radius=str(radius), nw=str(len(wl)-1), nr=str(len(rl)-1),
            wr=settings['width_ratios'], rr=settings['radial_ratios'], sectors=str(sectors),
            order=10, rbe=True, ring='1', dofs='123456', renumber=False, targets='',
            step='1', material='0', prefix='%s_%d' % (group.capitalize(), stations[group]))
        mesh = core.geometry(tuple(v*scale for v in record['center']['xyz_m']),
                             record['axis'], width, wl, rl, sectors, 10)
        rows.append(dict(group=group, station=stations[group], center=record['center'],
            geometry=record, params=params, stats=core.validate(mesh),
            effective_planes_mm=[(record['boundary_planes_m'][0]*scale + value)*1000/scale for value in wl],
            radial_levels_mm=[value*1000/scale for value in rl]))
    return rows
