"""User layer/RBE2/renumber settings; all physical dimensions come from faces."""
import re
from copy import deepcopy
from .crank_geometry_v6 import make_face_plan
from .crank_revolve import load_core

SEGMENTS = (32, 40)
DEFAULT_TARGETS = dict(journal='201-207 211-217 221-227 231-237',
                       pin='311-317 321-327 331-337 341-347')
FIXED_LAYERS = {group:dict(width_layers='6',radial_layers='6',
    width_ratios='1:2:3:3:2:1' if group=='journal' else '1:1:1:1:1:1',
    radial_ratios='1:1:1:1:1:1') for group in ('journal','pin')}


def clean_settings(values=None):
    """Crank product defaults fixed by the user; generic geometry core stays reusable."""
    settings=deepcopy(values or {})
    settings.update(layers=deepcopy(FIXED_LAYERS),rbe=True,ring=2,dofs='123456')
    settings['segments']=40
    settings.setdefault('renumber',False)
    settings.setdefault('targets',deepcopy(DEFAULT_TARGETS))
    settings.setdefault('increment','1')
    return settings


def expand_targets(text, increment):
    core = load_core()
    step = core.integer(increment, 'Renumber increment', 1, core.MAX_ID)
    ids, seen = [], set()
    for token in text.replace(',', ' ').split():
        match = re.fullmatch(r'(\d+)(?:-(\d+))?', token)
        if not match:
            raise ValueError('Target IDs: use ranges such as 201-207 211-217')
        first = core.integer(match[1], 'Target ID', 1, core.MAX_ID)
        last = core.integer(match[2] or match[1], 'Target ID', first, core.MAX_ID)
        if len(ids)+(last-first)//step+1 > 10000:
            raise ValueError('Target list exceeds 10000 IDs')
        for nid in range(first, last+1, step):
            if nid in seen:
                raise ValueError('Duplicate target ID %d' % nid)
            ids.append(nid)
            seen.add(nid)
    return ids


def configured_plan(geometry, settings, scale, segments=32, rbe=True, ring=1,
                    dofs='123456', renumber=True, targets=None, increment=1, existing_ids=()):
    core = load_core()
    segments = core.integer(segments, 'Segments', 3, 720)
    if segments not in SEGMENTS:
        raise ValueError('Segments must be 32 or 40')
    axis = 'XYZ'.index(geometry[0]['axis']) if geometry else 0
    geometry = sorted(geometry, key=lambda r: (r['group'] != 'journal', r['center']['xyz_m'][axis]))
    rows = make_face_plan(geometry, settings, scale, segments)
    if rbe and (not dofs or any(d not in '123456' for d in dofs) or len(set(dofs)) != len(dofs)):
        raise ValueError('RBE2 DOFs must be distinct digits 1..6')
    ring = core.integer(ring, 'RBE2 radial ring', 1, 1000)
    targets = DEFAULT_TARGETS if targets is None else targets
    assignments, usage = {}, {}
    for group in ('journal', 'pin'):
        selected = [r for r in rows if r['group'] == group]
        need = sum(int(r['params']['nw'])+1 for r in selected)
        ids = expand_targets(targets[group], increment) if renumber else []
        if renumber and len(ids) < need:
            raise ValueError('%s needs %d axial-center IDs; only %d supplied' % (group.capitalize(), need, len(ids)))
        usage[group] = dict(required=need, used=ids[:need], unused=ids[need:])
        offset = 0
        for row in selected:
            p = row['params']
            if rbe and ring > int(p['nr']):
                raise ValueError('%s radial ring %d exceeds %s R layers' % (group, ring, p['nr']))
            count = int(p['nw'])+1
            p.update(rbe=bool(rbe), ring=str(ring), dofs=dofs, renumber=bool(renumber),
                targets=' '.join(map(str, ids[offset:offset+count])), step='1',
                master_targets=ids[offset:offset+count] if renumber else [])
            assignments[row['center']['face_id']] = p['master_targets']
            offset += count
    used = [nid for group in usage.values() for nid in group['used']]
    if len(set(used)) != len(used):
        raise ValueError('Journal and Pin target lists overlap')
    collisions = sorted(set(used) & set(existing_ids))
    return rows, dict(groups=usage, assignments=assignments, collisions=collisions,
        import_ready=not collisions, ring=ring, segments=segments,
        numbering='Faces sorted along axis within each group; centers numbered from low to high axial plane')


def ordered_batch_targets(meshes, plan):
    """Adapt per-face center IDs to the core writer's global axial sorting."""
    if not any(row['params'].get('renumber') for row in plan):
        return []
    if len(meshes) != len(plan) or len({r['params']['axis'] for r in plan}) != 1:
        raise ValueError('One parallel-axis plan row per mesh required')
    axis = 'XYZ'.index(plan[0]['params']['axis'])
    ordered = []
    for index, (mesh, row) in enumerate(zip(meshes, plan)):
        ids = row['params'].get('master_targets', [])
        if len(ids) != mesh['nw']+1:
            raise ValueError('Every renumbered insert needs one target for each axial plane')
        for layer, nid in enumerate(ids):
            ordered.append((mesh['points'][layer*mesh['disk_nodes']][axis], index, layer, nid))
    targets = [item[3] for item in sorted(ordered)]
    if len(set(targets)) != len(targets):
        raise ValueError('Duplicate batch target IDs')
    return targets
