"""Live native handles and a lazy node-to-element index for center renumber."""
import hashlib


def digest(rows):
    total=0;count=0
    for row in rows:
        total^=int.from_bytes(hashlib.sha256(repr(row).encode('ascii')).digest(),'big');count+=1
    return (count,'%064x'%total)


def model_stamp(jpt):
    return (str(jpt.GetActiveDocument().docID),jpt.GetUndoCount(),jpt.GetRedoCount(),
        jpt.GetCountByType(jpt.DItemType.NODE),jpt.GetCountByType(jpt.DItemType.ELEM),
        tuple(sorted((int(p.key),int(p.id)) for p in jpt.GetAllParts())))


class ModelIndex:
    def __init__(self,jpt):
        self.jpt=jpt;self.elements={};self.rows={};self.solids={};self.adjacency={}
        self.node_handles={};self.points={};self.stamp=None;self.maximum=0
        for c in jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION):
            for n in c.masters:
                self.adjacency[int(n.id)]=set();self.node_handles[int(n.id)]=jpt.CastDItemToDNode(n)
            for n in c.slaves:self.node_handles[int(n.id)]=jpt.CastDItemToDNode(n)
        wanted=set(self.adjacency)
        for e in jpt.GetAllElems():
            eid=int(e.id);row=tuple(int(n.id) for n in e.nodes)
            self.elements[eid]=e;self.rows[eid]=row
            if e.kind==jpt.ElemKind.ELEMKIND_3D:self.solids[eid]=row
            for nid in wanted.intersection(row):self.adjacency[nid].add(eid)

    def finish(self,points):
        self.points=points;self.maximum=max(points,default=0);self.stamp=model_stamp(self.jpt)
        return self

    def current(self):
        return self.stamp==model_stamp(self.jpt)

    def free_ids(self,count,forbidden):
        from .crank_renumber import MAX_RENUMBER_ID
        candidate=self.maximum+1
        if candidate+count-1>MAX_RENUMBER_ID:candidate=1
        result=[]
        while len(result)<count and candidate<=MAX_RENUMBER_ID:
            if candidate not in self.points and candidate not in forbidden:result.append(candidate)
            candidate+=1
        if len(result)!=count:raise ValueError('Not enough free node IDs below 8 digits.')
        return result

    def related(self,node_ids):
        missing=set(node_ids)-set(self.adjacency)
        if missing:
            for nid in missing:self.adjacency[nid]=set()
            # Collision targets are rare; scan cached tuples, never native mesh again.
            for eid,row in self.rows.items():
                for nid in missing.intersection(row):self.adjacency[nid].add(eid)
        return {eid for nid in node_ids for eid in self.adjacency[nid]}

    def snapshot(self,node_ids,remap=None,element_ids=None):
        jpt=self.jpt;remap=remap or {};nodes=[]
        for nid in node_ids:
            source=remap.get(nid,nid);node=self.node_handles.get(source)
            if node is None:
                found=jpt.GetEntitiesByID(jpt.DItemType.NODE,nid)
                if len(found)!=1:raise RuntimeError('Renumber node lookup is missing or ambiguous')
                node=jpt.CastDItemToDNode(found[0]);self.node_handles[source]=node
            if int(node.id)!=nid:raise RuntimeError('Cached node handle differs from the requested ID')
            pos=node.pos;nodes.append((source,float(pos.x),float(pos.y),float(pos.z)))
        wanted=self.related(node_ids) if element_ids is None else set(element_ids)
        actual={}
        for eid in wanted:
            e=self.elements[eid]
            if int(e.id)!=eid:raise RuntimeError('Cached element handle is no longer valid')
            actual[eid]=tuple(int(n.id) for n in e.nodes)
        self.last_rows=actual
        connections=list(jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION))
        return dict(scope='native indexed affected-element readback + connections/counts',
            nodes=digest(nodes),elements=digest((eid,tuple(remap.get(n,n) for n in row)) for eid,row in actual.items()),
            element_ids=sorted(wanted),
            connections=digest((int(c.id),tuple(sorted(remap.get(int(n.id),int(n.id)) for n in c.masters)),
                tuple(sorted(remap.get(int(n.id),int(n.id)) for n in c.slaves))) for c in connections),
            global_counts=(jpt.GetCountByType(jpt.DItemType.NODE),jpt.GetCountByType(jpt.DItemType.ELEM),len(connections)),
            parts=sorted((int(p.key),int(p.id)) for p in jpt.GetAllParts()))

    def remap(self,changed):
        for table in (self.points,self.node_handles,self.adjacency):
            moved={new:table[old] for old,new in changed.items() if old in table}
            for old in changed:table.pop(old,None)
            table.update(moved)
        self.rows.update(self.last_rows)
        for eid,row in self.last_rows.items():
            if eid in self.solids:self.solids[eid]=row
        self.maximum=max(self.maximum,max(changed.values(),default=0))
        self.stamp=model_stamp(self.jpt)


def get_model_index(session):
    index=session.context.get('_model_index')
    if index is not None and index.current():return index,False
    from .crank_volume import node_positions
    index=ModelIndex(session.jpt).finish(node_positions(session.jpt))
    session.context['_model_index']=index
    return index,True
