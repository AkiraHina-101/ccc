"""Remove Circular's coincident meridian seed faces, retaining solid meshes."""
from collections import Counter, defaultdict


def internal_edge_ids(part):
    """Keep cap circles: remove an edge only if every segment is inside its faces."""
    face_counts, edge_faces = {}, defaultdict(list)
    for face in part.faces:
        counts = Counter()
        for elem in face.elems:
            nodes = [int(n.id) for n in elem.nodes]
            if len(nodes) == 6:
                counts.update(tuple(sorted((nodes[a], nodes[b]))) for a,b in ((0,1),(1,2),(2,0)))
        face_counts[int(face.id)] = counts
        for edge in face.edges:
            edge_faces[int(edge.id)].append(int(face.id))
    targets = []
    for edge in part.edges:
        segments = [tuple(sorted(int(n.id) for n in elem.nodes[:2]))
                    for elem in edge.elems if len(elem.nodes) in (2,3)]
        faces = edge_faces[int(edge.id)]
        if segments and faces and all(face_counts[fid][segment] == 2 for fid in faces for segment in segments):
            targets.append(int(edge.id))
    return targets


def seed_face_ids(part, row, points, scale):
    axis = 'XYZ'.index(row['params']['axis'])
    normal = (axis + 2) % 3
    plane = row['center']['xyz_m'][normal] * scale
    targets = []
    for face in part.faces:
        elems = list(face.elems)
        if not elems or not all(len(e.nodes) == 8 for e in elems):
            continue
        node_ids = {int(n.id) for elem in elems for n in elem.nodes}
        if any(n not in points or abs(points[n][normal] - plane) > 1e-8 for n in node_ids):
            raise RuntimeError('Unexpected Quad8 face outside the Circular seed plane.')
        targets.append(int(face.id))
    return targets


def remove_seed_faces(jpt, part, row, points, solids, scale):
    targets = seed_face_ids(part, row, points, scale)
    result = dict(face_ids=targets, removed_faces=0, edge_ids=[], removed_edges=0, verified=False)
    retained = {int(e.id): tuple(int(n.id) for n in e.nodes)
                for f in part.faces if int(f.id) not in targets for e in f.elems}
    if targets:
        # DeleteElement rejects solid-owned surface elements. DeleteFace with
        # keepSolid=0 removes the internal face and its mesh; scoped readback
        # proves existing solids/nodes and the retained TRI6 skin survive.
        result['response'] = str(jpt.Exec('DeleteFace(%s, 0)' % targets))
        faces = list(part.faces)
        if set(targets).intersection(int(f.id) for f in faces):
            raise RuntimeError('Circular seed face cleanup left a target face.')
        result['removed_faces'] = len(targets)
    edges = internal_edge_ids(part)
    result['edge_ids'] = edges
    if edges:
        boundary_ids = {int(e.id) for e in part.edges} - set(edges)
        result['edge_response'] = str(jpt.Exec('DeleteEdge(%s)' % edges))
        present = {int(e.id) for e in part.edges}
        if set(edges).intersection(present) or not boundary_ids.issubset(present):
            raise RuntimeError('Circular edge cleanup did not retain the required boundaries.')
        result['removed_edges'] = len(edges)
    if targets or edges:
        faces = list(part.faces)
        after_solids = {int(e.id): tuple(int(n.id) for n in e.nodes)
                        for e in part.elems if e.kind == jpt.ElemKind.ELEMKIND_3D}
        after_skin = {int(e.id): tuple(int(n.id) for n in e.nodes) for f in faces for e in f.elems}
        after_points = {}
        for node in part.nodes:
            pos = node.pos
            after_points[int(node.id)] = (float(pos.x)*scale, float(pos.y)*scale, float(pos.z)*scale)
        if solids != after_solids or retained != after_skin or points != after_points:
            raise RuntimeError('Circular seed face cleanup changed retained mesh or nodes.')
    result['verified'] = True
    return result
