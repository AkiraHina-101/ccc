"""Native face-group validation used by the clean workflow."""
from .crank_faces import FaceGroups

def validate_faces(jpt, groups):
    state = FaceGroups()
    for name in ('journal', 'pin'):
        if not groups.get(name): raise ValueError('Missing '+name.capitalize()+' faces')
        state.capture(name, groups[name])
    result = state.validate()
    available = {int(f.id) for f in jpt.GetAllFaces()}
    missing = set(result['journal']+result['pin'])-available
    if missing: raise ValueError('Faces no longer exist: '+str(sorted(missing)))
    return result
