"""One shared workflow, including crankshaft TET10 volume meshing."""
import time
import traceback
from copy import deepcopy
from .crank_debug_session_v6 import DebugSession, counts
from .crank_validation import validate_faces
from .crank_parameters_v6 import configured_plan, clean_settings
from .crank_topology_v6 import snapshot, removal_plan
from .crank_prepare_v8 import Preparation

FLOW = ('Validate faces', 'Measure geometry', 'Surface mesh crankshaft',
        'Plan layers / RBE2 / IDs', 'Remove old faces + chamfers',
        'Build Journal / Pin solids', 'Rebuild connections', 'Extract TET10 sections',
        'Merge interface nodes', 'Convert section shared faces',
        'Merge faces into crankshaft', 'Mesh crankshaft TET10', 'Group Journal / Pin parts')
PLAN_INDEX, REMOVE_INDEX = 3, 4



class FlowSession(DebugSession):
    def compact_result(self, result):
        if result is not None and result is self.state.get('main_plan'):
            return {'state_ref': 'main_plan'}
        for name, value in self.state.get('preparation', {}).items():
            if result is value:
                return {'state_ref': 'preparation.'+name, 'verified': bool(value.get('verified'))}
        return result

    def notify_stage(self, notify, status, label, event):
        try:
            notify(status, label)
        except Exception:
            event.setdefault('notification_errors', []).append(traceback.format_exc())

    def print_timing(self, text, event=None):
        try:
            print(text)
        except Exception:
            record = event if event is not None else self.state
            record.setdefault('timing_print_errors', []).append(traceback.format_exc())

    def run_stage(self, index, action, notify):
        if self.busy:
            raise ValueError('A step is already running')
        key, label = str(index+1), FLOW[index]
        status = self.state['steps'].get(key)
        # Validation and planning are read-only; corrected inputs may be retried.
        if status == 'RUNNING' or (status == 'FAILED' and index not in (0, PLAN_INDEX)):
            raise ValueError('Step already attempted; inspect the partial state before recovery')
        event = dict(step=key, label=label, status='RUNNING', started=time.time())
        self.state['events'].append(event)
        self.state['steps'][key] = 'RUNNING'
        self.busy = True
        started = time.monotonic()
        action_started = False
        self.print_timing('[CRANK-TIME] START Step %d/%d: %s' % (index+1,len(FLOW),label),event)
        try:
            self.save()
            self.notify_stage(notify, 'RUNNING', label, event)
            event['before'] = counts(self.jpt)
            self.save()
            action_started = True
            event['result'] = self.compact_result(action())
            event['after'] = counts(self.jpt)
            event['delta'] = {k: event['after'][k]-event['before'][k] for k in event['before']}
            event['status'] = self.state['steps'][key] = 'VERIFIED'
            self.notify_stage(notify, 'DONE', label, event)
            return event
        except Exception as exc:
            event.update(status='FAILED', action_started=action_started,
                         error=str(exc), traceback=traceback.format_exc())
            self.state['steps'][key] = 'FAILED' if action_started else 'READY'
            self.notify_stage(notify, 'ERROR', label, event)
            raise
        finally:
            self.busy = False
            event['seconds'] = time.monotonic()-started
            self.print_timing('[CRANK-TIME] %s Step %d/%d: %s | %.3f s' %
                  (event['status'],index+1,len(FLOW),label,event['seconds']),event)
            self.save()


class MainFlow:
    def __init__(self, session, notify=None):
        self.session, self.index = session, 0
        self.groups, self.settings = {}, None
        self.started = False
        self.notify = notify or (lambda status, label: print('[CRANK-FLOW]', status, label))
        session.progress_notify = lambda text: session.notify_stage(self.notify, 'RUNNING',
            FLOW[min(self.index, len(FLOW)-1)]+' / '+text, session.state['events'][-1])
        self.preparation = Preparation(session)
        session.state.setdefault('workflow_version',4)

    def configure(self, groups, settings):
        from .crank_surface import surface_settings
        settings = clean_settings(settings)
        settings['surface'] = surface_settings(settings.get('surface'))
        if self.session.state.get('preparation', {}).get('remainder_surface', {}).get('started') and settings['surface'] != surface_settings((self.settings or {}).get('surface')):
            raise ValueError('Surface mesh already started. Keep the surface settings for this run.')
        # Deleted face IDs remain the canonical captured inputs after removal.
        if self.started:
            if self.groups != groups:
                measured = self.session.state['steps'].get('2') in ('RUNNING', 'FAILED', 'VERIFIED')
                if self.index <= 1 and not measured and not self.session.context.get('geometry'):
                    groups = validate_faces(self.session.jpt, groups)
                else:
                    raise ValueError('Faces were already measured. Keep these groups for this run.')
            if self.settings != settings:
                deletion_attempted = self.session.state.get('preparation', {}).get('removal', {}).get('attempted')
                deletion_started = self.session.state['steps'].get(str(REMOVE_INDEX+1)) in ('RUNNING', 'FAILED', 'VERIFIED')
                if self.index > REMOVE_INDEX or deletion_attempted or deletion_started:
                    raise ValueError('Old faces were removed. Keep the settings used to build this model.')
                if self.index == REMOVE_INDEX:
                    self.index = PLAN_INDEX
                self.session.state.pop('main_plan', None)
        else:
            groups = validate_faces(self.session.jpt, groups)
        self.groups, self.settings = deepcopy(groups), deepcopy(settings)
        self.session.context['groups'] = self.groups
        self.session.context['surface_settings'] = surface_settings(settings.get('surface'))

    def plan(self):
        jpt, s = self.session.jpt, self.settings
        geometry = self.session.context['geometry']
        rows, ids = configured_plan(geometry, s['layers'],
            float(jpt.ConvertValueToDocUnit(1., jpt.UnitType.Unit_Length)),
            segments=s['segments'], rbe=s['rbe'], ring=s['ring'], dofs=s['dofs'],
            renumber=False, targets=s['targets'], increment=s['increment'],
            existing_ids={int(n.id) for n in jpt.GetAllNodes()})
        parts = list(jpt.GetAllParts())
        # CreateSharedFace and final part merge are global native operations.
        # Only a self-contained crankshaft model is supported by this version.
        if len(parts) != 1:
            raise ValueError('Preparation requires one source crankshaft part; unrelated parts are not supported')
        data = snapshot(jpt)
        self.session.state.update(source_snapshot=data, source_part_keys=[int(p.key) for p in parts],
            main_plan=dict(inserts=rows, numbering=ids, removal=removal_plan(data, geometry)))
        self.session.save()
        # Validate the expensive insert mesh before any old face is removed.
        from .crank_native_inserts import validate_native_plan
        validate_native_plan(rows,float(jpt.ConvertValueToDocUnit(1.,jpt.UnitType.Unit_Length)))
        return self.session.state['main_plan']

    def next(self):
        if self.index >= len(FLOW):
            if not self.session.state.get('numbering_complete',True):
                raise ValueError('Mesh complete. Finish center numbering with the Renumber button.')
            return dict(label='Full crankshaft TET10 complete', next='DONE: full TET10', complete=True)
        p = self.preparation
        actions = (lambda: dict(groups=validate_faces(self.session.jpt, self.groups)),
                   self.session.measure, p.surface_mesh, self.plan, p.remove, p.inserts, p.bridges,
                   p.sections, p.merge_nodes, p.shared, p.merge_parts, p.volume_mesh, p.group_inserts)
        current = self.index
        self.started = True
        event = self.session.run_stage(current, actions[current], self.notify)
        self.index += 1
        complete = self.index == len(FLOW)
        self.session.state.update(flow_index=self.index, preparation_complete=self.index>=11,
                                  volume_complete=self.index>=12, grouping_complete=complete)
        if complete:
            self.session.context.pop('_prepared_batch', None)
            self.session.state['numbering_complete']=not self.settings['renumber']
        self.session.save()
        if complete and self.settings['renumber']:
            from .crank_renumber import renumber_centers
            renumber_centers(self,self.settings['targets'],self.settings['increment'])
        return dict(step=current, label=FLOW[current], event=event, complete=complete,
                    next='DONE: full TET10' if complete else FLOW[self.index])

    def apply(self):
        result = None
        if self.index >= len(FLOW):
            return self.next()
        started = time.monotonic()
        try:
            while self.index < len(FLOW):
                result = self.next()
            return result
        finally:
            seconds = time.monotonic()-started
            self.session.state['last_apply_seconds'] = seconds
            self.session.print_timing('[CRANK-TIME] Apply %s | %.3f s total' %
                  ('COMPLETE' if self.index >= len(FLOW) and self.session.state.get('numbering_complete',True) else 'STOPPED',seconds))
            self.session.save()
