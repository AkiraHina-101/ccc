"""Explicit post-mesh center renumber, with normalized mesh/RBE2 readback."""
import hashlib
import time
from .crank_parameters_v6 import expand_targets
from .crank_native_inserts import native_transaction
MAX_RENUMBER_ID=9999999


def free_ids(occupied,count):
    candidate=max({n for n in occupied if n<=MAX_RENUMBER_ID}|{0})+1
    if candidate+count-1>MAX_RENUMBER_ID: candidate=1
    result=[]
    while len(result)<count and candidate<=MAX_RENUMBER_ID:
        if candidate not in occupied: result.append(candidate)
        candidate+=1
    if len(result)!=count: raise ValueError('Not enough free node IDs below 8 digits.')
    return result


def mesh_fingerprint(jpt, remap=None):
    remap=remap or {}
    def ids(nodes): return tuple(remap.get(int(n.id),int(n.id)) for n in nodes)
    def digest(rows):
        total,count=0,0
        for row in rows:
            total^=int.from_bytes(hashlib.sha256(repr(row).encode('ascii')).digest(),'big')
            count+=1
        return (count,'%064x'%total)
    return dict(nodes=digest((remap.get(int(n.id),int(n.id)),float(n.pos.x),float(n.pos.y),float(n.pos.z)) for n in jpt.GetAllNodes()),
        elements=digest((int(e.id),ids(e.nodes)) for e in jpt.GetAllElems()),
        connections=digest((int(c.id),tuple(sorted(ids(c.masters))),tuple(sorted(ids(c.slaves))))
            for c in jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION)),
        parts=sorted((int(p.key),int(p.id)) for p in jpt.GetAllParts()))


def affected_fingerprint(jpt,node_ids,remap=None,element_ids=None):
    """Bulk native readback includes corner AND midside node references.

    Dimension-specific association omits point elements in 5.0.4. Read the complete mesh
    once before rename; afterwards read that affected element set by stable IDs.
    Renumber changes node IDs only; counts, coordinates, connectivity and all
    RBE2 are checked. Independent acceptance still hashes the entire model.
    """
    remap=remap or {};elements={};nodes=[];wanted=set(node_ids)
    all_nodes=jpt.GetAllNodes();all_elements=jpt.GetAllElems()
    found=set()
    for node in all_nodes:
        if int(node.id) not in wanted: continue
        found.add(int(node.id))
        nodes.append((remap.get(int(node.id),int(node.id)),float(node.pos.x),float(node.pos.y),float(node.pos.z)))
    if found!=wanted or len(nodes)!=len(wanted): raise RuntimeError('Renumber node lookup is missing or ambiguous')
    allowed=None if element_ids is None else set(element_ids)
    for elem in all_elements:
        eid=int(elem.id)
        if allowed is not None and eid not in allowed: continue
        ids=tuple(int(n.id) for n in elem.nodes)
        if allowed is not None or wanted.intersection(ids):
            elements[eid]=tuple(remap.get(n,n) for n in ids)
    if allowed is not None and set(elements)!=allowed: raise RuntimeError('Renumber affected elements are missing')
    def digest(rows):
        total=0;count=0
        for row in rows:
            total^=int.from_bytes(hashlib.sha256(repr(row).encode('ascii')).digest(),'big');count+=1
        return (count,'%064x'%total)
    connections=list(jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION))
    return dict(scope='native bulk affected-element connectivity + all connections/global counts',
        nodes=digest(nodes),elements=digest(elements.items()),
        element_ids=sorted(elements),
        connections=digest((int(c.id),tuple(sorted(remap.get(int(n.id),int(n.id)) for n in c.masters)),
            tuple(sorted(remap.get(int(n.id),int(n.id)) for n in c.slaves))) for c in connections),
        global_counts=(len(all_nodes),len(all_elements),len(connections)),
        parts=sorted((int(p.key),int(p.id)) for p in jpt.GetAllParts()))


def center_mapping(rows, entries, targets, increment, existing_ids):
    assignments={}; ordered=[]
    for group in ('journal','pin'):
        sources=[int(entry['master']) for index,row in enumerate(rows) if row['group']==group
                 for entry in entries if entry['insert']==index and entry['status']=='verified']
        wanted=expand_targets(targets[group],increment)
        if any(n>MAX_RENUMBER_ID for n in wanted): raise ValueError('Renumber IDs must be below 8 digits (maximum 9999999).')
        if len(wanted)<len(sources): raise ValueError('%s needs %d center IDs.' % (group.capitalize(),len(sources)))
        ordered.extend(zip(sources,wanted[:len(sources)]))
    if not ordered or len({old for old,new in ordered})!=len(ordered):
        raise ValueError('Expected unique RBE2 center nodes from this run.')
    if len({new for old,new in ordered})!=len(ordered): raise ValueError('Journal and Pin target IDs overlap.')
    if any(old not in existing_ids for old,new in ordered): raise ValueError('Center nodes no longer exist in this model.')
    assignments.update(ordered)
    return assignments


def renumber_commands(pairs):
    """Group contiguous target IDs, with sources ordered by intended assigned IDs."""
    groups=[]
    for old,new in sorted(pairs,key=lambda pair:pair[1]):
        if groups and new==groups[-1][-1][1]+1: groups[-1].append((old,new))
        else: groups.append([(old,new)])
    return ['RenumberSpecify([%s], 0, 0, %d, 1, 1)' %
        (', '.join('10:%d'%old for old,new in group),group[0][1]) for group in groups]


def remap_insert_nodes(batch,changed):
    """Relocated target nodes may also be RBE2 slaves owned by an insert."""
    export=batch['export']
    export['node_ids']=[changed.get(n,n) for n in export['node_ids']]
    export['mapping']=[[changed.get(n,n) for n in row] for row in export['mapping']]
    for rigid in batch['rbe2_ids']:
        rigid['master']=changed.get(rigid['master'],rigid['master'])
        rigid['slaves']=[changed.get(n,n) for n in rigid['slaves']]


def renumber_centers(flow, targets, increment='1'):
    started=time.monotonic()
    session,p=flow.session,flow.preparation
    if session.busy: raise ValueError('A step is already running.')
    if not session.state.get('volume_complete'): raise ValueError('Complete crank meshing before renumbering centers.')
    if session.state.get('document_id') and str(session.jpt.GetActiveDocument().docID)!=session.state['document_id']:
        raise ValueError('Activate the model created by this run before renumbering.')
    history=p.progress.setdefault('manual_renumber',[])
    if history and history[-1].get('started') and not history[-1].get('verified'):
        raise ValueError('Renumber already attempted; inspect its checkpoint.')
    jpt=session.jpt
    batch=p.progress['batch']
    actual_connections=p.connection_connectivity()
    if any(actual_connections.get(entry['id'],((),()))[0]!=(int(entry['master']),)
           for entry in batch['rbe2_ids']):
        raise ValueError('RBE2 centers changed outside this run; inspect the model first.')
    masters={n for main,slaves in actual_connections.values() for n in main}
    mapping=center_mapping(session.state['main_plan']['inserts'],batch['rbe2_ids'],targets,increment,masters)
    center_changes=sum(old!=new for old,new in mapping.items())
    if not center_changes:
        session.state['numbering_complete']=True;session.save()
        return dict(count=0,verified=True)
    from .crank_model_index import get_model_index
    index,index_rebuilt=get_model_index(session)
    collisions=sorted(n for n in set(mapping.values()) if n in index.points and n not in mapping)
    relocations=dict(zip(collisions,index.free_ids(len(collisions),set(mapping.values()))))
    mapping.update(relocations)
    changed={old:new for old,new in mapping.items() if old!=new}
    if not changed:
        session.state['numbering_complete']=True
        session.save()
        return dict(count=0,verified=True)
    # Free targets need one native batch; collisions/swaps need an ID-index barrier.
    temporary={}
    if any(n in index.points for n in changed.values()):
        temporary=dict(zip(changed,index.free_ids(len(changed),set(mapping.values()))))
        phases=[renumber_commands(temporary.items()),
            renumber_commands((temporary[old],new) for old,new in changed.items())]
    else:
        phases=[renumber_commands(changed.items())]
    commands=[command for phase in phases for command in phase]
    before=index.snapshot(changed)
    entry=dict(started=True,targets=dict(targets),increment=str(increment),mapping=changed,
        temporary_mapping=temporary,relocated_node_ids=relocations,commands=[],before=before,
        transaction_count=len(phases),prepare_seconds=time.monotonic()-started,index_rebuilt=index_rebuilt)
    history.append(entry); session.busy=True
    try:
        session.save()
        entry['commands']=[dict(started=True,command=command) for command in commands]
        session.save()
        # ID lookup tables update at EndDatabaseTransaction; flush temporary
        # IDs before commands that address those new IDs.
        offset=0
        native_started=time.monotonic()
        for phase in phases:
            with native_transaction(jpt,'Crank center renumber'):
                for action in entry['commands'][offset:offset+len(phase)]:
                    action['response']=str(jpt.Exec(action['command']))
                    if action['response']=='0': raise RuntimeError('Native renumber command failed')
            offset+=len(phase)
        entry['native_seconds']=time.monotonic()-native_started
        read_started=time.monotonic()
        after=index.snapshot(changed.values(),{new:old for old,new in changed.items()},before['element_ids'])
        entry['readback_seconds']=time.monotonic()-read_started
        if before!=after: raise RuntimeError('Renumber mesh/RBE2 readback differs; inspect the saved model.')
        index.remap(changed)
        remap_insert_nodes(batch,changed)
        for row in session.state['main_plan']['inserts']:
            row['params']['master_targets']=[changed.get(n,n) for n in row['params'].get('master_targets',[])]
        # The completed flow uses native readback; discard cached pre-renumber patches.
        session.context.pop('patches',None)
        session.context.pop('_prepared_batch',None)
        interface=p.progress['remainder_tet10']['proof']['interface']
        interface['shared_node_ids']=[changed.get(n,n) for n in interface['shared_node_ids']]
        entry.update(verified=True,count=center_changes,relocated_count=len(relocations),after=after)
        session.state['numbering_complete']=True
        return entry
    except Exception as exc:
        session.context.pop('_model_index',None)
        entry['error']=str(exc); raise
    finally:
        entry['seconds']=time.monotonic()-started
        session.busy=False
        session.print_timing('[CRANK-TIME] Renumber %s | %.3f s' % ('VERIFIED' if entry.get('verified') else 'FAILED',entry['seconds']))
        session.save()
