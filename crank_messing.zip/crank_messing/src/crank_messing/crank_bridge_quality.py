"""Improve only annulus diagonals; preserve every boundary node and segment."""
import math


def triangle_min_angle(triangle,points):
    xyz=[points[n] for n in triangle[:3]]
    angles=[]
    for i in range(3):
        u=[xyz[(i+1)%3][k]-xyz[i][k] for k in range(3)]
        v=[xyz[(i+2)%3][k]-xyz[i][k] for k in range(3)]
        cross=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
        angles.append(math.degrees(math.atan2(math.sqrt(sum(x*x for x in cross)),sum(a*b for a,b in zip(u,v)))))
    return min(angles)


def quality_summary(triangles,points):
    values=sorted(triangle_min_angle(t,points) for t in triangles)
    return dict(triangles=len(values),minimum_angle_deg=values[0] if values else None,
                below_5_deg=sum(a<5 for a in values),below_10_deg=sum(a<10 for a in values),
                mean_minimum_angle_deg=sum(values)/len(values) if values else None)


def optimize_diagonals(triangles,inner_ids,points,axis):
    """Flip a convex strip quad only when its sorted pair of min angles improves.

    Test convexity in the ring plane and quality in 3D (axial offsets matter).
    Restrict replacement diagonals to cross-ring edges, so no ring chord cuts
    across the insert disk. Boundary segments, triangle count and IDs stay fixed.
    """
    faces=list(triangles); inner=set(inner_ids)
    transverse=[k for k in range(3) if k!='XYZ'.index(axis)]
    def orient(a,b,c):
        u,v=transverse; pa,pb,pc=points[a],points[b],points[c]
        return (pb[u]-pa[u])*(pc[v]-pa[v])-(pb[v]-pa[v])*(pc[u]-pa[u])
    def edge_rows():
        rows={}
        for i,t in enumerate(faces):
            for a,b in ((t[0],t[1]),(t[1],t[2]),(t[2],t[0])):
                rows.setdefault(tuple(sorted((a,b))),[]).append(i)
        return rows
    before=edge_rows(); boundary={e for e,rows in before.items() if len(rows)==1}
    scores=[triangle_min_angle(t,points) for t in faces]
    changed=True
    while changed:
        changed=False
        adjacency=edge_rows()
        for (a,b),rows in sorted(adjacency.items()):
            if len(rows)!=2: continue
            i,j=rows
            # Earlier flips in this pass may have removed this edge.
            if not {a,b}.issubset(faces[i]) or not {a,b}.issubset(faces[j]): continue
            c=next(n for n in faces[i] if n not in (a,b))
            d=next(n for n in faces[j] if n not in (a,b))
            if c==d or (c in inner)==(d in inner): continue
            diagonal=tuple(sorted((c,d)))
            if diagonal in adjacency: continue
            if orient(a,b,c)*orient(a,b,d)>=0 or orient(c,d,a)*orient(c,d,b)>=0: continue
            candidates=[(c,d,a),(d,c,b)]
            for k,old in enumerate((faces[i],faces[j])):
                if orient(*candidates[k])*orient(*old)<0:
                    x,y,z=candidates[k]; candidates[k]=(x,z,y)
            new=[triangle_min_angle(t,points) for t in candidates]
            old_pair=sorted((scores[i],scores[j])); new_pair=sorted(new)
            if not (new_pair[0]>old_pair[0]+1e-10 or
                    (abs(new_pair[0]-old_pair[0])<=1e-10 and new_pair[1]>old_pair[1]+1e-10)): continue
            faces[i],faces[j]=candidates; scores[i],scores[j]=new
            changed=True
            # Rebuild after a successful flip; do not use stale adjacency.
            break
    after=edge_rows()
    if {e for e,rows in after.items() if len(rows)==1}!=boundary or any(len(rows)>2 for rows in after.values()):
        raise ValueError('Bridge optimization changed its boundary or manifold topology')
    return faces
