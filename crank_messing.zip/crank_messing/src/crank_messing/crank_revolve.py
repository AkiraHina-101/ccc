"""Load the byte-preserved local core once; reload this module to invalidate it."""
import importlib.util
from functools import lru_cache
from pathlib import Path

CORE_PATH = Path(__file__).resolve().parents[1] / 'core/revolve_tet10_psj.py'

@lru_cache(maxsize=1)
def load_core():
    spec = importlib.util.spec_from_file_location('crank_messing_core', str(CORE_PATH))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
