"""Original crankshaft Tri3 surface meshing before insert/interface creation."""
import math
from .crank_sections_v6 import verify_closed_skin

SURFACE_DEFAULTS = dict(average_mm=3.,minimum_mm=1.,maximum_mm=5.,reduction=1.,
    grading=1.25,stretch=.1,quality=1,optimization=3,threads=18,max_angle_deg=45.,
    merge_angle_deg=30.,map_angle_deg=0.,curvature=False,merge_edges=False,
    merge_faces=False,bad_cad=False,close_holes=False,delete_chamfer=False,
    adjust_circle=True)


def surface_settings(values=None):
    settings=dict(SURFACE_DEFAULTS)
    if values: settings.update(values)
    for name in ('average_mm','minimum_mm','maximum_mm','reduction','grading','stretch',
                 'max_angle_deg','merge_angle_deg','map_angle_deg'):
        try: settings[name]=float(settings[name])
        except (ValueError,TypeError): raise ValueError('Surface '+name+' must be numeric')
        if not math.isfinite(settings[name]): raise ValueError('Surface '+name+' must be finite')
    avg,minimum,maximum=(settings[n] for n in ('average_mm','minimum_mm','maximum_mm'))
    if not (avg>0 and 0<minimum<=.7*avg and maximum>=1.4*avg):
        raise ValueError('Surface sizes require Average > 0, Minimum <= 0.7 x Average, Maximum >= 1.4 x Average')
    if settings['reduction']<=0 or settings['grading']<1 or not 0<=settings['stretch']<=.5:
        raise ValueError('Surface reduction > 0, grading >= 1 and stretch in 0..0.5 required')
    if not 15<=settings['max_angle_deg']<=180 or not 0<=settings['merge_angle_deg']<=180 or not 0<=settings['map_angle_deg']<=120:
        raise ValueError('Surface mesh angles are out of range')
    for name,limit in (('quality',2),('optimization',5),('threads',256)):
        value=settings[name]
        try: number=float(value)
        except (ValueError,TypeError): raise ValueError('Surface '+name+' must be an integer')
        if isinstance(value,bool) or not math.isfinite(number) or number!=int(number):
            raise ValueError('Surface '+name+' must be an integer')
        settings[name]=int(number)
        if not (1 if name=='threads' else 0)<=settings[name]<=limit:
            raise ValueError('Surface '+name+' is out of range')
    return settings


def native_parameters(settings):
    # Installed API mesh lengths are SI metres; angles are radians.
    return dict(dAvgElemSize=settings['average_mm']*.001,dMinElemSize=settings['minimum_mm']*.001,
        dMaxElemSize=settings['maximum_mm']*.001,dReductionFactor=settings['reduction'],
        dGeomAngle=math.radians(settings['max_angle_deg']),dGeomMinSize=settings['minimum_mm']*.001,
        dGradingFactor=settings['grading'],dMinStretchVal=settings['stretch'],
        iPerformanceMode=settings['quality'],iOptLevel=settings['optimization'],
        dAutoMergeTinyFacesAngle=math.radians(settings['merge_angle_deg']),
        dAutoMeshPatternMinElemAngle=math.radians(settings['map_angle_deg']),
        bOutputQuadMesh=False,bPureQuad=False,bCurvatureControl=bool(settings['curvature']),
        bAutoMergeEdges=bool(settings['merge_edges']),bAutoMergeFaces=bool(settings['merge_faces']),
        bBadInputModel=bool(settings['bad_cad']),bCloseGaps=bool(settings['close_holes']),
        bDeleteCircChamfer=bool(settings['delete_chamfer']))


def mesh_surface(p):
    """Mesh the original CAD crank before insert/shared-interface creation."""
    session,jpt=p.s,p.jpt
    if p.progress.get('remainder_surface',{}).get('started'):
        raise ValueError('Crank surface mesh already attempted; inspect its checkpoint.')
    settings=surface_settings(session.context.get('surface_settings'))
    parts=list(jpt.GetAllParts())
    if len(parts)!=1 or p.solid_connectivity():
        raise ValueError('Surface meshing requires one original crank part before creating inserts.')
    source=parts[0]
    captured={fid for group in session.context['groups'].values() for fid in group}
    from macroTypes import SURFACE_MESH
    from Meshing import SurfaceMeshing,SetMeshAttribute
    from Geometry import FCircVertexAdjust
    params=native_parameters(settings)
    entry=dict(started=True,settings=settings,parameters_si=params,source_key=int(source.key),
               source_id=int(source.id),actions={})
    p.progress['remainder_surface']=entry
    session.save()
    def call(name,action):
        entry['actions'][name]={'started':True}
        session.save()
        response=action()
        entry['actions'][name]['response']=str(response)
        session.save()
        if response is False:
            raise RuntimeError('Native '+name+' failed; inspect its checkpoint.')
    cursor='[3:%d]' % source.id
    mesh=SURFACE_MESH(**params)
    if settings['adjust_circle']: call('adjust_circle',lambda:FCircVertexAdjust(cursor))
    call('set_surface_parameters',lambda:SetMeshAttribute(crlParts=cursor,surfaceMesh=mesh))
    # No assembled inserts exist yet; local overrides are off so the profile is exact.
    call('surface_mesh',lambda:SurfaceMeshing(crlParts=cursor,surfaceMesh=mesh,bUseSetting=False,
        bFMesher=False,iThreadNum=settings['threads'],bRefData=True,bMeshColor=False))
    after_parts=list(jpt.GetAllParts())
    if len(after_parts)!=1 or int(after_parts[0].key)!=int(source.key) or p.solid_connectivity():
        raise RuntimeError('Original surface mesh changed part ownership or created solids.')
    if not captured.issubset({int(face.id) for face in jpt.GetAllFaces()}):
        raise RuntimeError('Surface meshing changed a captured Journal/Pin face ID.')
    # Boundary nodes/edges are now new; refresh geometry before taking the removal snapshot.
    from .crank_geometry_v6 import refresh_surface_boundaries
    geometry=refresh_surface_boundaries(jpt,session.context['geometry'])
    session.context['geometry']=session.state['geometry']=geometry
    source=after_parts[0]
    skin={int(e.id):tuple(int(n.id) for n in e.nodes) for face in source.faces for e in face.elems}
    if not skin or any(len(triangle)!=3 for triangle in skin.values()):
        raise RuntimeError('Original crank surface meshing did not produce a Tri3 skin.')
    closure=verify_closed_skin(list(skin.values()))
    entry.update(verified=True,surface_elements=len(skin),closure=closure,
                 geometry_refreshed=True,before_insert_creation=True)
    session.save()
    return entry
