"""Group completed inserts by their captured type, preserving native meshes."""
from .crank_native_inserts import native_transaction
from .crank_model_index import model_stamp


def group_inserts(preparation):
    p, session, jpt = preparation, preparation.s, preparation.jpt
    entry = p.progress.setdefault('insert_groups', {})
    if entry.get('started'):
        raise ValueError('Insert grouping already attempted; inspect the saved result.')
    if not p.progress.get('remainder_tet10', {}).get('verified'):
        raise ValueError('Complete crankshaft TET10 before grouping inserts.')
    batch = p.progress['batch']
    rows = session.state['main_plan']['inserts']
    keys = list(batch['part_keys'])
    if len(rows) != len(keys):
        raise RuntimeError('Insert ownership does not match the captured plan.')
    parts = {int(part.key): part for part in jpt.GetAllParts()}
    if set(parts) != set(keys) | set(session.state['source_part_keys']):
        raise RuntimeError('Insert grouping requires the retained crankshaft and this run\'s inserts.')
    if len({int(part.id) for part in parts.values()}) != len(parts):
        raise RuntimeError('Insert part IDs are ambiguous.')
    groups = {g: [parts[key] for row, key in zip(rows, keys) if row['group'] == g]
              for g in ('journal', 'pin')}
    if sum(map(len, groups.values())) != len(keys):
        raise RuntimeError('Unknown insert group in the captured plan.')
    before_elements, before_nodes = {}, {}
    for group, members in groups.items():
        before_elements[group] = {int(e.id): tuple(int(n.id) for n in e.nodes)
                                  for part in members for e in part.elems}
        for part in members:
            for node in part.nodes:
                pos = node.pos
                before_nodes[int(node.id)] = (float(pos.x), float(pos.y), float(pos.z))
    before_connections = p.connection_connectivity()
    shared_ids = {int(f.id) for f in p.shared_readback()}
    counts = (jpt.GetCountByType(jpt.DItemType.NODE), jpt.GetCountByType(jpt.DItemType.ELEM))
    point_ids = {int(e.id) for e in jpt.GetElemsByKind(jpt.ElemKind.ELEMKIND_0D)}
    index = session.context.get('_model_index')
    warm = index is not None and index.current()
    entry.update(started=True, original_part_keys=keys, groups={})
    session.save()
    if warm:
        index.stamp = None  # Partial native writes must never reuse a valid cache.
    from Geometry.MergeEntities import Parts
    expected_keys = set(parts)
    for group, members in groups.items():
        if not members:
            continue
        target = members[0]
        action = dict(started=True, source_keys=[int(part.key) for part in members],
                      command='Geometry.MergeEntities.Parts', remove_shared_face=False)
        entry['groups'][group] = action
        session.save()
        with native_transaction(jpt, 'Crank group '+group):
            if len(members) > 1:
                action['response'] = str(Parts(
                    crlParts='[%s]' % ', '.join('3:%d' % part.id for part in members),
                    dMergeTolerance=1e-10, bRemoveSharedFace=False))
            target.name = 'Journal' if group == 'journal' else 'Pin'
        expected_keys -= set(action['source_keys'][1:])
        current = {int(part.key): part for part in jpt.GetAllParts()}
        if set(current) != expected_keys:
            raise RuntimeError('Native grouping did not retain the intended part owner.')
        owner = current[action['source_keys'][0]]
        actual_elements = {int(e.id): e for e in owner.elems}
        actual_rows = {eid: tuple(int(n.id) for n in elem.nodes) for eid, elem in actual_elements.items()}
        # MergePart regenerates vertex marker elements (one node), while the
        # line/surface/solid mesh must retain every ID and node reference.
        retained_before = {eid: row for eid, row in before_elements[group].items() if len(row) != 1}
        retained_after = {eid: row for eid, row in actual_rows.items() if len(row) != 1}
        if retained_after != retained_before:
            raise RuntimeError('Insert grouping changed mesh IDs or connectivity.')
        action.update(verified=True, part_key=int(owner.key), part_id=int(owner.id), name=owner.name,
                      vertex_markers_before=len(before_elements[group])-len(retained_before),
                      vertex_markers_after=len(actual_rows)-len(retained_after))
        if warm:
            removed = set(before_elements[group]) - set(actual_rows)
            for eid in removed:
                index.elements.pop(eid, None)
                index.rows.pop(eid, None)
            for related in index.adjacency.values():
                related.difference_update(before_elements[group])
            for eid, row in actual_rows.items():
                for nid in set(row).intersection(index.adjacency):
                    index.adjacency[nid].add(eid)
            index.elements.update(actual_elements)
            index.rows.update(actual_rows)
        session.save()
    current = {int(part.key): part for part in jpt.GetAllParts()}
    # Shared sections also belong to the crankshaft: MergePart may rebuild
    # their vertex markers there. Fetch only 0D markers, never the full mesh.
    point_elements = {int(e.id): e for e in jpt.GetElemsByKind(jpt.ElemKind.ELEMKIND_0D)}
    expected_element_count = counts[1] - len(point_ids) + len(point_elements)
    if warm:
        for eid in point_ids:
            index.elements.pop(eid, None)
            index.rows.pop(eid, None)
        for related in index.adjacency.values():
            related.difference_update(point_ids)
        for eid, elem in point_elements.items():
            row = tuple(int(n.id) for n in elem.nodes)
            index.elements[eid] = elem
            index.rows[eid] = row
            for nid in set(row).intersection(index.adjacency):
                index.adjacency[nid].add(eid)
    owners = [entry['groups'][g]['part_key'] for g in ('journal', 'pin') if g in entry['groups']]
    after_nodes = {}
    for key in owners:
        for node in current[key].nodes:
            pos = node.pos
            after_nodes[int(node.id)] = (float(pos.x), float(pos.y), float(pos.z))
    if before_nodes != after_nodes or (counts[0], expected_element_count) != (
            jpt.GetCountByType(jpt.DItemType.NODE), jpt.GetCountByType(jpt.DItemType.ELEM)):
        raise RuntimeError('Insert grouping changed nodes or global mesh counts.')
    if before_connections != p.connection_connectivity() or shared_ids != {int(f.id) for f in p.shared_readback()}:
        raise RuntimeError('Insert grouping changed RBE2 or shared faces.')
    batch['original_part_keys'] = keys
    batch['part_keys'] = owners
    batch['part_ids'] = [int(current[key].id) for key in owners]
    for row, record in zip(rows, batch.get('parts', [])):
        owner = entry['groups'][row['group']]
        record.update(group_part_key=owner['part_key'], group_part_id=owner['part_id'])
    if warm:
        index.stamp = model_stamp(jpt)
    entry.update(verified=True, parts=len(current), nodes_preserved=True,
                 mesh_preserved=True, rbe2_preserved=True, shared_faces_preserved=True,
                 renumber_index_kept=warm)
    session.save()
    return entry
