"""Reference geometry/readback and the retained legacy BDF insert adapter.

Cache model ID sets once: do not rebuild all existing IDs per imported tetra.
Batch import/readback/RBE2 is native-verified; optional per-face renumber is
offline-verified. Current stage6 uses crank_native_inserts, not BDF import.
"""
import math
from pathlib import Path
from .crank_revolve import load_core
from .crank_connectivity import tet10_signature


def prepare_batch(plan, scale):
    core = load_core()
    scale = core.positive(scale, 'Document length scale')
    meshes = []
    for row in plan:
        p = row['params']
        width = core.positive(p['width'], 'Width')
        mesh = core.geometry(tuple(v*scale for v in row['center']['xyz_m']), p['axis'], width,
            core.levels(width, p['nw'], p['wr'], 'Width'),
            core.levels(p['radius'], p['nr'], p['rr'], 'Radius'), int(p['sectors']), 10)
        core.validate(mesh)
        meshes.append(mesh)
    if not meshes or sum(len(m['tets']) for m in meshes) > core.MAX_TETS:
        raise ValueError('Nonempty batch within combined tetra limit required')
    return meshes


def batch_key(plan,scale):
    names = ('axis', 'width', 'nw', 'wr', 'radius', 'nr', 'rr', 'sectors')
    return (float(scale), tuple((tuple(row['center']['xyz_m']),
                               tuple(str(row['params'][name]) for name in names)) for row in plan))


def prepared_batch(plan, scale, context):
    """Reuse validated native or reference geometry only for the same inputs."""
    key=batch_key(plan,scale)
    native=context.get('_native_meshes')
    if native is not None and native['key']==key: return native['meshes']
    cache = context.get('_prepared_batch')
    if cache is None or cache['key'] != key:
        cache = {'key': key, 'meshes': prepare_batch(plan, scale)}
        context['_prepared_batch'] = cache
    return cache['meshes']


def verify_import(meshes, result, actual_nodes, actual_solids, scale):
    """Linear readback; inputs are indexed once by the caller."""
    expected = sum(len(m['tets']) for m in meshes)
    if len(actual_solids) != expected or set(result['element_ids']) != set(actual_solids):
        raise RuntimeError('Batch solid count or IDs differ from the exported plan')
    for mesh, mapping in zip(meshes, result['mapping']):
        for nid, point in zip(mapping, mesh['points']):
            if nid not in actual_nodes:
                raise RuntimeError('Missing imported node %d' % nid)
            actual = actual_nodes[nid]
            for value, wanted in zip(actual, point):
                value *= scale
                if not math.isfinite(value) or abs(value-wanted) > 1e-10*max(1., abs(wanted)):
                    raise RuntimeError('Imported node coordinate differs: %d' % nid)
    cursor = iter(result['element_ids'])
    for mesh, mapping in zip(meshes, result['mapping']):
        for tet in mesh['tets']:
            eid = next(cursor)
            if len(actual_solids[eid]) != 10 or tet10_signature(actual_solids[eid]) != tet10_signature([mapping[n] for n in tet]):
                raise RuntimeError('Imported tetra connectivity differs: %d' % eid)
    return dict(nodes=sum(len(m['points']) for m in meshes), elements=expected)


def build_batch(jpt, plan, folder, progress, save_progress, mesh_context=None):
    """One import, explicit write-ahead checkpoints, native RBE2 only after readback.

    Refuse any retry after an import attempt. Recovery requires model inspection.
    save_progress receives the mutable progress before/after each native stage.
    """
    if progress.get('import_started'):
        raise ValueError('Batch import already attempted; inspect partial state before retrying')
    from Home.ImportMesh import NastranBdf
    core = load_core()
    scale = float(jpt.ConvertValueToDocUnit(1., jpt.UnitType.Unit_Length))
    meshes = prepare_batch(plan, scale) if mesh_context is None else prepared_batch(plan, scale, mesh_context)
    from .crank_parameters_v6 import ordered_batch_targets
    targets = ordered_batch_targets(meshes, plan)
    nodes = list(jpt.GetAllNodes())
    elems = list(jpt.GetAllElems())
    parts = list(jpt.GetAllParts())
    connections = list(jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION))
    props = list(jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_PROPERTY))
    node_ids = {int(n.id) for n in nodes}
    elem_ids = {int(e.id) for e in elems}
    part_ids = {int(p.id) for p in parts}
    connection_ids = {int(c.id) for c in connections}
    property_ids = {int(p.id) for p in props} | part_ids
    collisions = set(targets) & node_ids
    if collisions:
        raise ValueError('Target center IDs already exist: %s' % sorted(collisions))
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / 'inserts-solid-only.bdf'
    result = core.write_bdf(str(path), meshes, max(node_ids | set(targets) | {0})+1,
        max(elem_ids | connection_ids | {0})+1, max(property_ids | {0})+1,
        prefix='Crank_v6', rbe_ring=0, targets=targets, axis=plan[0]['params']['axis'])
    progress.update(stage='import', import_started=True, export=result, import_file=str(path),
                    source_part_ids=sorted(part_ids), scale=scale)
    save_progress(progress)
    progress['import_response'] = str(NastranBdf([str(path)], iImportType=2,
        bReadNameComment=True, iCreateDup1DElemAnswer=0))
    progress['stage'] = 'readback'
    save_progress(progress)
    new_solids = [e for e in jpt.GetElemsByKind(jpt.ElemKind.ELEMKIND_3D) if int(e.id) not in elem_ids]
    actual_solids = {int(e.id): [int(n.id) for n in e.nodes] for e in new_solids}
    wanted_nodes = set(result['node_ids'])
    actual_nodes = {int(n.id): (float(n.pos.x), float(n.pos.y), float(n.pos.z))
                    for n in jpt.GetAllNodes() if int(n.id) in wanted_nodes}
    progress['validation'] = verify_import(meshes, result, actual_nodes, actual_solids, scale)
    new_parts = [p for p in jpt.GetAllParts() if int(p.id) not in part_ids]
    if len(new_parts) != len(meshes):
        raise RuntimeError('Expected exactly one native part per insert')
    progress['part_ids'] = [int(p.id) for p in new_parts]
    progress['rbe2_ids'] = []
    progress['stage'] = 'rbe2'
    save_progress(progress)
    for index, (mesh, row, mapping) in enumerate(zip(meshes, plan, result['mapping'])):
        p = row['params']
        if not p.get('rbe', True):
            continue
        ring = core.integer(p['ring'], 'RBE2 ring', 1, mesh['nr'])
        for rigid in core.rigid_plan([mesh], [mapping], ring):
            # A started record persists an uncertain RBE2 call; never silently retry.
            entry = dict(insert=index, master=rigid['master'], status='started')
            progress['rbe2_ids'].append(entry)
            save_progress(progress)
            entry.update(id=core.native_rbe2(rigid['master'], rigid['slaves'], p['dofs'],
                'Crank_v6_P%d_L%d' % (index+1, rigid['layer']+1)), status='verified')
            save_progress(progress)
    progress.update(stage='inserts_verified', verified=True)
    save_progress(progress)
    return progress
