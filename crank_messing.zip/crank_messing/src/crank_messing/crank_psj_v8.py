# coding: utf-8
"""PSJ direct-script entry and importable JDG interface."""
if not globals().get('__package__'):
    import sys
    import importlib
    from pathlib import Path
    ROOT = (Path(__file__).resolve().parents[2] if '__file__' in globals() else
        Path('C:/Users/TechnoStar/Downloads/03-Developer/01-PSJ/06-CRANK-MESHING'))
    if str(ROOT/'src') not in sys.path: sys.path.insert(0, str(ROOT/'src'))
    import crank_messing
    importlib.reload(crank_messing).reload_runtime().main()
else:
    import sys
    from pathlib import Path
    ROOT = Path(__file__).resolve().parents[2]
    if str(ROOT/'src') not in sys.path: sys.path.insert(0, str(ROOT/'src'))
    from .crank_mainflow_v8 import FlowSession, MainFlow, FLOW
    from .crank_parameters_v6 import clean_settings
    from .crank_gui_layout import build_form, update_dimensions
    from .crank_surface import surface_settings


    def input_locks(flow):
        state = flow.session.state
        measured = state['steps'].get('2') in ('RUNNING', 'FAILED', 'VERIFIED')
        deletion = state['steps'].get('5') in ('RUNNING', 'FAILED', 'VERIFIED')
        attempted = state.get('preparation', {}).get('removal', {}).get('attempted')
        return (flow.index > 1 or measured or bool(flow.session.context.get('geometry')),
                flow.index >= 5 or deletion or bool(attempted))


    def completed_label(state):
        for event in reversed(state.get('events', [])):
            if event.get('status') == 'VERIFIED':
                return 'Completed: '+event['label']
        return 'Completed: -'


    def main(session=None, flow=None):
        import JPT
        from pyjdg import JDGCreator, size_behavior
        global _dialog, _session, _flow, _actions
        dlg = JDGCreator(title='Crank Meshing v8 clean | PSJ', resizable=True, validation=True)
        _dialog = dlg
        session = session or FlowSession(JPT, ROOT)
        _session = session
        flow = flow or MainFlow(session)
        _flow = flow
        active = ['journal']
        build_form(dlg,size_behavior)

        def message(text):
            dlg.set_item_text('status', ' '.join(str(text).split()))
        def dimensions():
            groups=flow.groups if flow.started else {g:[int(n) for n in dlg.get_item_text(g+'_faces').replace(',',' ').split() if n.isdigit()] for g in ('journal','pin')}
            return update_dimensions(dlg,session.context.get('geometry',[]),groups)
        def notify(status, label):
            message('%s | %d/%d: %s' % (status.title(), min(flow.index+1, len(FLOW)), len(FLOW), label))
            if status == 'DONE' and label in (FLOW[1],FLOW[2]): dimensions()
            sync()
        flow.notify = notify
        session.progress_notify = lambda text: session.notify_stage(notify, 'RUNNING',
            FLOW[min(flow.index, len(FLOW)-1)]+' / '+text, session.state['events'][-1])
        def guard(action):
            def handle(*args):
                try: action()
                except Exception as exc:
                    sync()
                    text = str(exc)
                    if 'already attempted' in text:
                        text = 'Stopped at step %d. Completed work is kept; see the run report.' % (flow.index+1)
                    message(text)
            return handle
        def pick(group):
            if session.busy or input_locks(flow)[0]: return
            active[0] = group
            for name in ('journal', 'pin'): dlg.set_radiobutton_state('pick_'+name, int(name == group))
            JPT.ClearAllSelection()
            message(group.capitalize())
        def selected(*args):
            if session.busy or input_locks(flow)[0]:
                return
            ids = list(dict.fromkeys(int(f.id) for f in JPT.GetSelectedFaces()))
            if ids:
                dlg.set_item_text(active[0]+'_faces', ' '.join(map(str, ids)))
                session.state['selection'] = {g: dlg.get_item_text(g+'_faces') for g in ('journal', 'pin')}
                session.save()
                dimensions()
        def read():
            groups = {g: [int(n) for n in dlg.get_item_text(g+'_faces').replace(',', ' ').split()] for g in ('journal', 'pin')}
            s = clean_settings(dict(renumber=dlg.isbutton_checked('renumber'), targets={g: dlg.get_item_text(g+'_targets') for g in ('journal', 'pin')},
                increment=dlg.get_item_text('increment'),
                surface=surface_settings((flow.settings or {}).get('surface'))))
            # ID fields remain editable for the manual button after completion.
            if flow.index>=len(FLOW):
                return
            flow.configure(groups, s)
        def debug():
            read()
            try:
                result = flow.next()
            finally:
                sync()
            message('Full crankshaft TET10 complete.' if result['complete']
                    else 'Ready | %d/%d: %s' % (flow.index+1,len(FLOW),result['next']))
        def apply():
            read()
            try:
                result = flow.apply()
            finally:
                sync()
            message('Full crankshaft TET10 complete.' if result['complete'] else result['label'])
        def renumber_now():
            from .crank_renumber import renumber_centers
            for name in ('renumber_now','debug','apply','journal_targets','pin_targets','increment'):
                dlg.disable_item(name)
            try:
                result=renumber_centers(flow,{g:dlg.get_item_text(g+'_targets') for g in ('journal','pin')},dlg.get_item_text('increment'))
            finally: sync()
            message('Renumbered %d center nodes.' % result['count'])

        def sync():
            faces_locked, settings_locked = input_locks(flow)
            busy = session.busy
            for group in ('journal', 'pin'):
                for name in ('pick_'+group, group+'_faces'):
                    (dlg.disable_item if busy or faces_locked else dlg.enable_item)(name)
            for name in ('renumber',):
                (dlg.disable_item if busy or settings_locked else dlg.enable_item)(name)
            for name in ('journal_targets', 'pin_targets', 'increment'):
                (dlg.disable_item if busy or (settings_locked and flow.index<len(FLOW)) else dlg.enable_item)(name)
            manual=session.state.get('preparation',{}).get('manual_renumber',[])
            uncertain=bool(manual and manual[-1].get('started') and not manual[-1].get('verified'))
            (dlg.enable_item if not busy and flow.index>=len(FLOW) and not uncertain else dlg.disable_item)('renumber_now')
            for name in ('debug', 'apply'):
                (dlg.disable_item if busy else dlg.enable_item)(name)

        _actions = dict(selected=selected, pick=pick, debug=debug, apply=apply,
                        sync=sync, renumber=renumber_now, dimensions=dimensions)
        for group in ('journal', 'pin'):
            dlg.on_command(name='pick_'+group, callfunc=guard(lambda g=group: pick(g)))
        dlg.on_selected(guard(selected))
        dlg.on_dlg_selector_changed(guard(selected))
        dlg.on_button_clicked('debug', guard(debug))
        dlg.on_button_clicked('apply', guard(apply))
        dlg.on_dlg_apply(guard(apply))
        dlg.on_button_clicked('renumber_now',guard(renumber_now))
        dlg.on_command(name='renumber',callfunc=guard(sync))
        for group in ('journal','pin'):
            dlg.on_command(name=group+'_faces',callfunc=guard(dimensions))
        dlg.generate_window()
        dimensions()
        sync()
        message('Ready | 1/%d: %s' % (len(FLOW), FLOW[0]))
        if flow.started and flow.settings:
            manual=session.state.get('preparation',{}).get('manual_renumber',[])
            numbering=manual[-1] if manual and manual[-1].get('verified') else flow.settings
            for g in ('journal', 'pin'):
                dlg.set_item_text(g+'_faces', ' '.join(map(str, flow.groups[g])))
                dlg.set_item_text(g+'_targets', numbering['targets'][g])
            dlg.set_checkbox_state('renumber', int(flow.settings['renumber']))
            dlg.set_item_text('increment', str(numbering['increment']))
            sync()
            label = FLOW[min(flow.index, len(FLOW)-1)]
            failed = session.state['steps'].get(str(flow.index+1)) == 'FAILED'
            complete = flow.index >= len(FLOW)
            message(('Done' if complete else 'Error' if failed else 'Ready')+' | %d/%d: ' % (min(flow.index+1, len(FLOW)), len(FLOW))+label)
        return dlg


    if __name__ == '__main__': main()
