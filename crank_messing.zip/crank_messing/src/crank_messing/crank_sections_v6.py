"""Section/connection topology from the new quadratic solids, independent of PSJ."""
import math
from collections import Counter
from .crank_interface import FACE_SLOTS
from .crank_bridge_quality import optimize_diagonals


def oriented_boundary(mesh, mapping):
    """Return outward TRI6 faces with the same corner/midside IDs as TET10."""
    entries = {}
    for tet in mesh['tets']:
        for slots in FACE_SLOTS:
            local = [tet[i] for i in slots]
            key = tuple(sorted(local[:3]))
            entries.setdefault(key, []).append((local, next(i for i in tet[:4] if i not in local[:3])))
    result = []
    points = mesh['points']
    for rows in entries.values():
        if len(rows) == 2:
            continue
        if len(rows) != 1:
            raise ValueError('Nonmanifold insert boundary')
        local, opposite = rows[0]
        a, b, c = [points[i] for i in local[:3]]
        u = [b[i]-a[i] for i in range(3)]
        v = [c[i]-a[i] for i in range(3)]
        normal = [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]
        if sum(normal[i]*(points[opposite][i]-a[i]) for i in range(3)) > 0:
            # TRI6 ordering: a,b,c,ab,bc,ca.
            local = [local[i] for i in (0, 2, 1, 5, 4, 3)]
        result.append(tuple(mapping[i] for i in local))
    return result


def section_patches(mesh, mapping, axis, scale):
    """Extract both full section disks and outer corner rings from insert boundary."""
    index = 'XYZ'.index(axis)
    points = {mapping[i]: tuple(v/scale for v in p) for i, p in enumerate(mesh['points'])}
    lo = min(p[index] for p in points.values())
    hi = max(p[index] for p in points.values())
    native=mesh.get('native_sections')
    boundary = oriented_boundary(mesh, mapping) if native is None else []
    sections = []
    for plane in (lo, hi):
        item=min(native,key=lambda sec:abs(sec['plane_m']-plane)) if native is not None else None
        faces = [tuple(mapping[n] for n in f) for f in item['faces']] if item is not None else [face for face in boundary if all(abs(points[n][index]-plane) < 1e-9 for n in face)]
        if not faces:
            raise ValueError('No complete quadratic section patch')
        edges = Counter(tuple(sorted((face[i], face[j]))) for face in faces for i, j in ((0, 1), (1, 2), (2, 0)))
        ring = {n for edge, count in edges.items() if count == 1 for n in edge}
        if len(ring) != mesh['ns'] or any(count > 2 for count in edges.values()):
            raise ValueError('Section disk has unexpected boundary topology')
        section=dict(plane_m=plane, faces=faces, ring_node_ids=sorted(ring))
        if item is not None: section['native_edge_ids']=item['native_edge_ids']
        sections.append(section)
    return sections, points


def bridge_rings(inner_ids, outer_ids, points, axis, center, optimize=True):
    """Angular strip followed by quality flips; reuse both rings' node IDs."""
    transverse = [i for i in range(3) if i != 'XYZ'.index(axis)]
    def ordered(ids):
        if len(set(ids)) != len(ids) or len(ids) < 3:
            raise ValueError('Expected distinct ring node IDs')
        rows = sorted((math.atan2(points[n][transverse[1]]-center[transverse[1]],
                                 points[n][transverse[0]]-center[transverse[0]]) % (2*math.pi), n) for n in ids)
        gaps = [b[0]-a[0] for a, b in zip(rows, rows[1:])] + [rows[0][0]+2*math.pi-rows[-1][0]]
        if min(gaps) < 1e-9 or max(gaps) >= math.pi:
            raise ValueError('Repeated angles or incomplete ring')
        return rows
    inner, outer = ordered(inner_ids), ordered(outer_ids)
    ni, no = len(inner), len(outer)
    i = j = 0
    faces = []
    while i < ni or j < no:
        ai = inner[(i+1) % ni][0] + (2*math.pi if i+1 >= ni else 0) if i < ni else math.inf
        ao = outer[(j+1) % no][0] + (2*math.pi if j+1 >= no else 0) if j < no else math.inf
        a, b = inner[i % ni][1], outer[j % no][1]
        if ai <= ao:
            faces.append((a, inner[(i+1) % ni][1], b))
            i += 1
        else:
            faces.append((a, outer[(j+1) % no][1], b))
            j += 1
    counts = Counter(tuple(sorted((f[i], f[j]))) for f in faces for i, j in ((0, 1), (1, 2), (2, 0)))
    expected = {tuple(sorted((r[k], r[(k+1) % len(r)]))) for r in
                ([n for _, n in inner], [n for _, n in outer]) for k in range(len(r))}
    if {edge for edge, count in counts.items() if count == 1} != expected or any(count > 2 for count in counts.values()):
        raise ValueError('Bridge is not a manifold annulus')
    for f in faces:
        a, b, c = [points[n] for n in f]
        u, v = ([b[k]-a[k] for k in range(3)], [c[k]-a[k] for k in range(3)])
        normal = [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]
        if sum(n*n for n in normal) <= 1e-28:
            raise ValueError('Degenerate connection triangle')
    return optimize_diagonals(faces,inner_ids,points,axis) if optimize else faces


def verify_closed_skin(triangles):
    """Topology check before volume meshing; geometry quality is checked separately."""
    keys = [tuple(sorted(t[:3])) for t in triangles]
    if len(set(keys)) != len(keys):
        raise ValueError('Duplicate surface triangles')
    counts = Counter(tuple(sorted((t[i], t[j]))) for t in triangles for i, j in ((0, 1), (1, 2), (2, 0)))
    if any(count != 2 for count in counts.values()):
        raise ValueError('Remainder skin is open or nonmanifold: %d invalid edges' % sum(c != 2 for c in counts.values()))
    return dict(triangles=len(triangles), edges=len(counts), closed=True)
