"""Create structured inserts and RBE2 inside Jupiter; no mesh import/export path."""
import json,math,time
from contextlib import contextmanager
from pathlib import Path
from .crank_revolve import load_core
from .crank_insert_batch_v6 import batch_key


@contextmanager
def native_transaction(jpt,name):
    """Public API batches undo and defers scene/status redraw; always unfreeze."""
    jpt.BeginDatabaseTransaction(name)
    try: yield
    finally: jpt.EndDatabaseTransaction()


def canonical_native_mesh(points,solids,row,scale):
    """Keep native topology, put lattice corners in the RBE2 layout order.

    Normalize only float roundoff in the verification copy. Never move native
    nodes. Core validation remains byte-preserved and exact on that copy.
    """
    core=load_core();p=row['params'];width=float(p['width']);radius=float(p['radius'])
    center=tuple(v*scale for v in row['center']['xyz_m'])
    wl=core.levels(width,p['nw'],p['wr'],'Width');rl=core.levels(radius,p['nr'],p['rr'],'Radius')
    reference=core.geometry(center,p['axis'],width,wl,rl,int(p['sectors']),4)
    corners={n for tet in solids.values() for n in tet[:4]}
    lookup={tuple(round(v,8) for v in points[n]):n for n in corners}
    if len(lookup)!=len(corners) or len(corners)<reference['corner_count']:
        raise RuntimeError('Native insert does not have the required structured corner lattice')
    mapping=[]
    for xyz in reference['points']:
        key=tuple(round(v,8) for v in xyz)
        if key not in lookup: raise RuntimeError('Native corner differs from the fixed layer/radius profile')
        mapping.append(lookup[key])
    interior=sorted(corners-set(mapping));axis='XYZ'.index(p['axis'])
    for nid in interior:
        xyz=points[nid]
        radial=math.sqrt(sum((xyz[k]-center[k])**2 for k in range(3) if k!=axis))
        if not center[axis]-width/2<xyz[axis]<center[axis]+width/2 or radial>=radius:
            raise RuntimeError('Native refinement changed an insert boundary')
    mapping.extend(interior)
    mapping.extend(sorted(set(points)-corners));indices={n:i for i,n in enumerate(mapping)}
    mesh=dict(reference,corner_count=len(corners),points=[tuple(points[n]) for n in mapping],
        tets=[tuple(indices[n] for n in tet) for tet in solids.values()],order=10)
    max_roundoff=0.
    for tet in mesh['tets']:
        for offset,(a,b) in enumerate(core.EDGES):
            expected=tuple(mesh['points'][tet[a]][d]/2+mesh['points'][tet[b]][d]/2 for d in range(3))
            mid=tet[4+offset]
            deviation=max(abs(mesh['points'][mid][d]-expected[d]) for d in range(3))
            max_roundoff=max(max_roundoff,deviation)
            if deviation>1e-9*max(1.,radius,width):
                raise RuntimeError('Native TET10 midside differs from its corner edge')
            mesh['points'][mid]=expected
    proof=core.validate(mesh);proof['midpoint_roundoff_doc_units']=max_roundoff
    proof['native_interior_refinement_nodes']=len(interior)
    expected_volume=int(p['sectors'])/2*radius*radius*math.sin(2*math.pi/int(p['sectors']))*width
    if abs(proof['volume']-expected_volume)>1e-9*expected_volume: raise RuntimeError('Native insert volume differs from the structured cylinder')
    return mesh,mapping,proof


def validate_native_plan(plan,scale):
    """Parameter-only preflight; actual native tetrahedra are checked after creation."""
    core=load_core();total=0
    for row in plan:
        p=row['params'];width=core.positive(p['width'],'Width');radius=core.positive(p['radius'],'Radius')
        core.levels(width,p['nw'],p['wr'],'Width');core.levels(radius,p['nr'],p['rr'],'Radius')
        if not all(math.isfinite(v) for v in row['center']['xyz_m']): raise ValueError('Finite insert center required')
        total+=3*int(p['nw'])*int(p['sectors'])*(2*int(p['nr'])-1)
    if not plan or total>core.MAX_TETS: raise ValueError('Insert plan exceeds the supported tetra limit')


def build_native_batch(jpt,plan,folder,progress,save_progress,context):
    if progress.get('import_started'): raise ValueError('Insert creation already attempted; inspect its checkpoint')
    from Geometry.Part import Cube
    from MeshEdit.CreateNode import Absolute
    from MeshCleanup.Manual2D import DeleteElement
    from HexModeling import Circular
    from Connections.RigidElements.RBE2 import OneToMany
    core=load_core();scale=float(jpt.ConvertValueToDocUnit(1.,jpt.UnitType.Unit_Length))
    path=Path(folder)/'inserts-native-meshes.json'
    progress.update(import_started=True,backend='native_circular_sweep',stage='native_inserts',
        scale=scale,native_mesh_file=str(path),parts=[],rbe2_ids=[])
    save_progress(progress)
    meshes=[];mappings=[];element_ids=[];part_keys=[];part_ids=[]
    before_connections={int(c.id) for c in jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION)}
    timings={'kernel':0.,'readback':0.,'checkpoint':0.}
    def call(name,func,record):
        start=time.monotonic();response=func();timings['kernel']+=time.monotonic()-start
        record.setdefault('actions',[]).append(dict(name=name,response=str(response)))
        if response is False or str(response)=='0': raise RuntimeError('Native '+name+' failed')
        return response
    jpt.BeginDatabaseTransaction('Crank native inserts and RBE2')
    try:
        for index,row in enumerate(plan):
            p=row['params'];axis='XYZ'.index(p['axis']);radial=(axis+1)%3;normal=(axis+2)%3
            width=float(p['width'])/scale;radius=float(p['radius'])/scale
            wl=core.levels(width,p['nw'],p['wr'],'Width');rl=core.levels(radius,p['nr'],p['rr'],'Radius')
            center=row['center']['xyz_m'];origin=list(center);origin[axis]-=width/2
            lengths=[0.,0.,0.];lengths[axis]=width;lengths[radial]=radius;lengths[normal]=min(width,radius)*.05
            prior={int(part.key) for part in jpt.GetAllParts()}
            record=dict(insert=index,started=True);progress['parts'].append(record)
            call('seed_holder',lambda:Cube(dlOrigin=origin,dlLength=lengths,ilAxialNodes=[2,2,2],
                strName='Crank_%s_%d_seed'%(row['group'],index+1)),record)
            holders=[part for part in jpt.GetAllParts() if int(part.key) not in prior]
            if len(holders)!=1: raise RuntimeError('Native seed holder was not created')
            holder=holders[0]
            face=next(f for f in holder.faces if len(f.nodes)>0 and all(abs((n.pos.x,n.pos.y,n.pos.z)[normal]-origin[normal])<1e-10 for n in f.nodes))
            face_key=int(face.key)
            existing={tuple(round(v,12) for v in (n.pos.x,n.pos.y,n.pos.z)):(int(n.id),int(n.key)) for n in face.nodes}
            next_id=int(jpt.GetMaxIDEntity(jpt.DItemType.NODE))+1
            grid=[];positions=[];new_ids=[];node_keys={nid:key for nid,key in existing.values()}
            for w in wl:
                for r in rl:
                    xyz=list(origin);xyz[axis]+=w;xyz[radial]+=r;key=tuple(round(v,12) for v in xyz)
                    if key in existing: grid.append(existing[key][0])
                    else:
                        grid.append(next_id);positions.append(xyz);new_ids.append(next_id);next_id+=1
            call('seed_nodes',lambda:Absolute(positions,new_ids),record)
            for nid in new_ids:
                found=jpt.GetEntitiesByID(jpt.DItemType.NODE,nid)
                if len(found)!=1: raise RuntimeError('New seed node lookup failed')
                node_keys[nid]=int(found[0].key)
            cursors='[%s]'%', '.join('%d:%d'%(e.typeID,e.id) for e in face.elems)
            call('clear_seed_triangles',lambda:DeleteElement(cursors),record)
            start=time.monotonic();nr=len(rl)-1;stride=nr+1
            for w in range(len(wl)-1):
                for r in range(nr):
                    ns=[grid[w*stride+r],grid[(w+1)*stride+r],grid[(w+1)*stride+r+1],grid[w*stride+r+1]]
                    response=jpt.Exec('CreateElement(1, %d, %s)'%(face_key,[node_keys[n] for n in ns]))
                    if str(response)=='0': raise RuntimeError('Native meridian quad failed')
            timings['kernel']+=time.monotonic()-start
            vector=[0.,0.,0.];vector[axis]=1.
            call('circular_sweep',lambda:Circular([face_key],dAngle=360,dTol=1e-10,iLayer=int(p['sectors']),
                vecAxisPt=center,vecAxisVect=vector,dBDeleteOriginalParts=1),record)
            new=[part for part in jpt.GetAllParts() if int(part.key) not in prior]
            if len(new)!=1: raise RuntimeError('Expected one swept insert part')
            part=new[0];target='[3:%d]'%part.id
            call('tet4',lambda:jpt.Exec('ElementConv_Solid(%s, 3)'%target),record)
            call('tet10',lambda:jpt.Exec('ElementConv_Solid(%s, 1)'%target),record)
            start=time.monotonic()
            solids={int(e.id):tuple(int(n.id) for n in e.nodes) for e in part.elems if e.kind==jpt.ElemKind.ELEMKIND_3D}
            if not solids or any(len(t)!=10 for t in solids.values()): raise RuntimeError('Native insert is not TET10')
            points={int(n.id):tuple(float(v)*scale for v in (n.pos.x,n.pos.y,n.pos.z)) for n in part.nodes}
            from .crank_seed_cleanup import remove_seed_faces
            record['seed_cleanup']=remove_seed_faces(jpt,part,row,points,solids,scale)
            mesh,mapping,proof=canonical_native_mesh(points,solids,row,scale)
            indices={n:i for i,n in enumerate(mapping)};corner_ids=set(mapping[:mesh['corner_count']])
            sections=[]
            from collections import Counter
            for f in part.faces:
                face_nodes=list(f.nodes)
                if not face_nodes: continue
                plane=float((face_nodes[0].pos.x,face_nodes[0].pos.y,face_nodes[0].pos.z)[axis])
                low=center[axis]-width/2;high=center[axis]+width/2
                if min(abs(plane-low),abs(plane-high))>1e-9 or any(abs((n.pos.x,n.pos.y,n.pos.z)[axis]-plane)>1e-9 for n in face_nodes): continue
                faces=[]
                for elem in f.elems:
                    ns=[indices[int(n.id)] for n in elem.nodes]
                    if len(ns)!=6: raise RuntimeError('Native section is not TRI6')
                    a,b,c=[mesh['points'][n] for n in ns[:3]]
                    u=[b[k]-a[k] for k in range(3)];v=[c[k]-a[k] for k in range(3)]
                    cross=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
                    if cross[axis]*(1 if abs(plane-high)<abs(plane-low) else -1)<0: ns=[ns[k] for k in (0,2,1,5,4,3)]
                    faces.append(ns)
                boundary=Counter(tuple(sorted((ns[i],ns[j]))) for ns in faces for i,j in ((0,1),(1,2),(2,0)))
                ring={mapping[n] for edge,count in boundary.items() if count==1 for n in edge}
                edge_ids=[];covered=set()
                for edge in f.edges:
                    nodes={int(n.id) for n in edge.nodes}&corner_ids
                    if nodes and nodes.issubset(ring): edge_ids.append(int(edge.id));covered.update(nodes)
                if len(ring)!=mesh['ns'] or covered!=ring: raise RuntimeError('Native section boundary edges are incomplete')
                sections.append(dict(plane_m=plane,faces=faces,native_edge_ids=edge_ids))
            if len(sections)!=2: raise RuntimeError('Expected two complete native section faces')
            mesh['native_sections']=sorted(sections,key=lambda sec:sec['plane_m'])
            meshes.append(mesh);mappings.append(mapping);element_ids.extend(solids)
            part_keys.append(int(part.key));part_ids.append(int(part.id))
            record.update(verified=True,part_key=int(part.key),part_id=int(part.id),validation=proof)
            timings['readback']+=time.monotonic()-start
        rigid_rows=[]
        for index,(mesh,mapping,row) in enumerate(zip(meshes,mappings,plan)):
            for rigid in core.rigid_plan([mesh],[mapping],int(row['params']['ring'])):
                entry=dict(insert=index,master=rigid['master'],slaves=rigid['slaves'],layer=rigid['layer'],status='started')
                progress['rbe2_ids'].append(entry);rigid_rows.append(entry)
                mask=sum(1<<(int(d)-1) for d in row['params']['dofs'])
                call('rbe2',lambda e=entry,m=mask:OneToMany(crlMasterTargets='[10:%d]'%e['master'],
                    crlSlaveTargets='[%s]'%', '.join('10:%d'%n for n in e['slaves']),iUlDOFs=m,
                    strName='Crank_P%d_L%d'%(index+1,e['layer']+1),iEnableCheckDulplicate=0),entry)
        native={tuple(int(n.id) for n in c.masters):c for c in jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION) if int(c.id) not in before_connections}
        if len(native)!=len(rigid_rows): raise RuntimeError('Native RBE2 count differs')
        for entry in rigid_rows:
            c=native.get((entry['master'],))
            if c is None or sorted(int(n.id) for n in c.slaves)!=sorted(entry['slaves']): raise RuntimeError('Native RBE2 ring differs')
            entry.update(id=int(c.id),status='verified')
    finally: jpt.EndDatabaseTransaction()
    context['_native_meshes']={'key':batch_key(plan,scale),'meshes':meshes}
    start=time.monotonic();path.write_text(json.dumps(meshes,separators=(',',':')),encoding='utf-8')
    progress.update(stage='inserts_verified',verified=True,part_keys=part_keys,part_ids=part_ids,
        export=dict(mapping=mappings,node_ids=[n for ns in mappings for n in ns],element_ids=element_ids,property_ids=[],file=None),
        validation=dict(nodes=sum(len(m['points']) for m in meshes),elements=sum(len(m['tets']) for m in meshes)),timings=timings)
    timings['checkpoint']=time.monotonic()-start;save_progress(progress)
    return progress
