"""Native remainder TET10 meshing with fixed interfaces and explicit readback."""
import math
import time
from .crank_connectivity import tri6_signature
from .crank_interface import boundary_faces, verify_boundary_interface
from .crank_sections_v6 import verify_closed_skin
from .crank_native_inserts import native_transaction
from .crank_model_index import ModelIndex


def verify_volume_mesh(tets, points, skin, insert_tets, shared_triangles, timings=None):
    timings={} if timings is None else timings
    started=time.monotonic()
    if not tets:
        raise RuntimeError('Remainder mesher created no solid elements.')
    boundaries = boundary_faces(tets)
    timings['boundary_faces']=time.monotonic()-started
    started=time.monotonic()
    expected = {tuple(sorted(triangle[:3])) for triangle in skin}
    if set(boundaries) != expected:
        raise RuntimeError('Remainder volume boundary differs from the retained skin: missing=%d extra=%d' %
                           (len(expected-set(boundaries)), len(set(boundaries)-expected)))
    for triangle in skin:
        if len(triangle) == 6:
            signature = tri6_signature(triangle)
            actual = tuple(sorted(((a,b),mid) for a,b,mid in boundaries[signature[0]]))
            if signature[1] != actual:
                raise RuntimeError('A quadratic skin face has different midside node IDs.')
    timings['skin_boundary']=time.monotonic()-started
    started=time.monotonic()
    volume, minimum = 0., float('inf')
    nonfinite={nid for nid,xyz in points.items() if not all(math.isfinite(v) for v in xyz)}
    for tet in tets:
        ax,ay,az=points[tet[0]];bx,by,bz=points[tet[1]]
        cx,cy,cz=points[tet[2]];dx,dy,dz=points[tet[3]]
        ux,uy,uz=bx-ax,by-ay,bz-az;vx,vy,vz=cx-ax,cy-ay,cz-az;wx,wy,wz=dx-ax,dy-ay,dz-az
        determinant=ux*(vy*wz-vz*wy)-uy*(vx*wz-vz*wx)+uz*(vx*wy-vy*wx)
        if not math.isfinite(determinant) or determinant <= 0:
            raise RuntimeError('Remainder contains a nonpositive corner tetrahedron.')
        minimum = min(minimum,determinant/6.)
        volume += determinant/6.
        if nonfinite and nonfinite.intersection(tet):
            raise RuntimeError('Remainder contains nonfinite node coordinates.')
    timings['corner_volume_finite']=time.monotonic()-started
    started=time.monotonic()
    interface = verify_boundary_interface(boundary_faces(insert_tets),boundaries,[tri[:3] for tri in shared_triangles])
    timings['shared_interface']=time.monotonic()-started
    return dict(elements=len(tets),boundary_triangles=len(boundaries),volume_m3=volume,
                minimum_corner_volume_m3=minimum,interface=interface)


def mesh_remainder(preparation):
    total_started=time.monotonic();timings={}
    def timed(name,action):
        started=time.monotonic()
        try:return action()
        finally:timings[name]=timings.get(name,0.)+time.monotonic()-started
    p,session,jpt = preparation, preparation.s, preparation.jpt
    prior = p.progress.get('remainder_tet10',{})
    if prior.get('started'):
        raise ValueError('Remainder mesh was already attempted; inspect its checkpoint.')
    if not p.progress.get('remainder_surface',{}).get('verified'):
        raise ValueError('Surface mesh the crankshaft before TET10 volume meshing.')
    if not p.progress.get('merge_parts',{}).get('verified'):
        raise ValueError('Attach and verify replacement surfaces before remainder meshing.')
    expected_parts = set(session.state['source_part_keys']) | set(p.progress['batch']['part_keys'])
    if {int(part.key) for part in jpt.GetAllParts()} != expected_parts:
        raise RuntimeError('Expected remainder and retained inserts only.')
    sources = [part for part in jpt.GetAllParts() if int(part.key) in session.state['source_part_keys']]
    if len(sources)!=1:
        raise RuntimeError('Expected one explicitly retained remainder part.')
    source = sources[0]
    parts_before = {int(part.key) for part in jpt.GetAllParts()}
    before = timed('before_solids',p.solid_connectivity)
    connections = p.connection_connectivity()
    skin = {int(e.id):tuple(int(n.id) for n in e.nodes) for face in source.faces for e in face.elems}
    verify_closed_skin(list(skin.values()))
    shared = [tuple(int(n.id) for n in e.nodes) for face in p.shared_readback() for e in face.elems]
    if not shared or any(len(t)!=6 for t in shared):
        raise RuntimeError('Expected retained TRI6 shared interfaces.')
    points_before = timed('before_nodes',lambda:node_positions(jpt))
    from Meshing import SolidMeshing
    options = dict(crlParts='[3:%d]' % source.id, bTet10=True, iRegion=0,
                   bInternalNodes=True,bSafeMode=True,bSurfaceNodes=False,bEdgeNodes=False,
                   bPreservation=True,bInternalMeshOnly=True)
    entry = dict(started=True,source_part_key=int(source.key),source_part_id=int(source.id),options=options,timings=timings)
    p.progress['remainder_tet10']=entry
    timed('checkpoint',session.save)
    def dispatch():
        with native_transaction(jpt,'Crank TET10 volume'):
            return SolidMeshing(**options)
    entry['response']=str(timed('native_meshing',dispatch))
    timed('checkpoint',session.save)
    index=timed('after_solids',lambda:ModelIndex(jpt))
    after=index.solids
    if any(after.get(eid)!=nodes for eid,nodes in before.items()):
        raise RuntimeError('Volume mesher changed an existing insert solid.')
    if connections!=p.connection_connectivity() or parts_before!={int(part.key) for part in jpt.GetAllParts()}:
        raise RuntimeError('Volume mesher changed parts or RBE2.')
    points = timed('after_nodes',lambda:node_positions(jpt))
    if any(points.get(nid)!=xyz for nid,xyz in points_before.items()):
        raise RuntimeError('Volume mesher moved or removed a retained node.')
    new = [nodes for eid,nodes in after.items() if eid not in before]
    proof = timed('volume_verification',lambda:verify_volume_mesh(new,points,list(skin.values()),list(before.values()),shared,timings))
    timed('insert_verification',lambda:p.verify_insert_geometry(allow_remainder=True,actual_nodes=points,actual_solids=after))
    entry.update(verified=True,proof=proof,total_tet10=len(after),rbe2=len(connections),
                 all_solid_elements_tet10=all(len(nodes)==10 for nodes in after.values()))
    if not entry['all_solid_elements_tet10']:
        raise RuntimeError('Some solid elements are not TET10.')
    session.context['_model_index']=index.finish(points)
    timed('checkpoint',session.save)
    timings['total_action']=time.monotonic()-total_started
    if hasattr(session,'print_timing'):
        session.print_timing('[CRANK-TIME] TET10 native %.3f s | readback %.3f s | checks %.3f s' %
            (timings['native_meshing'],sum(timings[k] for k in ('before_solids','before_nodes','after_solids','after_nodes')),
             timings['volume_verification']+timings['insert_verification']))
    return entry


def node_positions(jpt):
    result={}
    for node in jpt.GetAllNodes():
        pos=node.pos
        result[int(node.id)]=(float(pos.x),float(pos.y),float(pos.z))
    return result
