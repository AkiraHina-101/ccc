"""Strict TET10 interface validation for future fixed-boundary CAD fill."""
FACE_SLOTS = ((0, 1, 2, 4, 5, 6), (0, 1, 3, 4, 8, 7),
              (0, 2, 3, 6, 9, 7), (1, 2, 3, 5, 9, 8))
_MISSING=object()


def boundary_faces(tets):
    faces = {}
    for tet in tets:
        if len(tet) != 10 or len(set(tet)) != 10:
            raise ValueError('Expected valid TET10 connectivity')
        for slots in FACE_SLOTS:
            corners = tuple(sorted(tet[i] for i in slots[:3]))
            a, b, c = [tet[i] for i in slots[:3]]
            mids = tuple(sorted((min(u, v), max(u, v), tet[mid])
                                for (u, v), mid in zip(((a, b), (b, c), (a, c)), slots[3:])))
            previous=faces.get(corners,_MISSING)
            if previous is _MISSING:
                faces[corners]=mids
            elif previous is None:
                raise ValueError('Nonmanifold solid face')
            elif previous != mids:
                raise ValueError('Internal face has inconsistent quadratic midpoint nodes')
            else:
                # Keep a sentinel to reject a third incident tetra, release mids.
                faces[corners]=None
    return {corners:mids for corners,mids in faces.items() if mids is not None}


def verify_shared_interface(insert_tets, remainder_tets, required_corner_faces):
    """Verify whole expected triangular patches, not merely coincident nodes."""
    left, right = boundary_faces(insert_tets), boundary_faces(remainder_tets)
    return verify_boundary_interface(left,right,required_corner_faces)


def verify_boundary_interface(left,right,required_corner_faces):
    """Use already validated boundaries, preserving every quadratic edge check."""
    required = {tuple(sorted(face)) for face in required_corner_faces}
    if not required:
        raise ValueError('Explicit contact-face patches required; cannot infer contact from arbitrary common nodes')
    missing = required - (set(left) & set(right))
    if missing:
        raise ValueError('Solid interface is incomplete: %d required triangles do not share corner node IDs' % len(missing))
    if any(left[face] != right[face] for face in required):
        raise ValueError('Solid interface midside nodes differ; merging corner nodes alone is insufficient for TET10')
    return {'shared_triangles': len(required),
            'shared_node_ids': sorted({nid for face in required for nid in face + tuple(row[2] for row in left[face])})}
