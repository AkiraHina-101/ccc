"""Orientation-independent signatures retaining each midside's parent edge."""
def tri6_signature(nodes):
    if len(nodes) != 6: raise ValueError('A quadratic triangle is required')
    a,b,c,ab,bc,ca=nodes
    return tuple(sorted((a,b,c))),tuple(sorted((tuple(sorted(edge)),mid)
        for edge,mid in (((a,b),ab),((b,c),bc),((c,a),ca))))


def tet10_signature(nodes):
    if len(nodes) != 10: raise ValueError('A quadratic tetrahedron is required')
    a,b,c,d,ab,bc,ca,ad,bd,cd=nodes
    return tuple(sorted((a,b,c,d))),tuple(sorted((tuple(sorted(edge)),mid)
        for edge,mid in (((a,b),ab),((b,c),bc),((c,a),ca),((a,d),ad),((b,d),bd),((c,d),cd))))
