"""Run this Python file INSIDE PSJ/Jupiter to open the parameter dialog.

Pure Python geometry; no HyperMesh, numpy or external mesher required.
The TET4 topology is a port of ../revolve_tet4.tcl. TET10 uses straight
shared edge midpoints (no projection of midpoints to the ideal cylinder).
"""
import math
import os
import re
import tempfile
import time
from collections import Counter

MAX_TETS = 250000
MAX_ID = 2147483647
EDGES = ((0, 1), (1, 2), (2, 0), (0, 3), (1, 3), (2, 3))
DEFAULT_MASTER_IDS = '301-307 311-317 321-327 331-337'


def positive(value, label):
    value = float(value)
    if not math.isfinite(value) or not 0 < value < 1e100:
        raise ValueError(label + ': enter a finite positive number.')
    return value


def integer(value, label, lower, upper):
    if not re.fullmatch(r'[0-9]+', str(value).strip()):
        raise ValueError(label + ': enter an integer.')
    value = int(value)
    if not lower <= value <= upper:
        raise ValueError('{}: allowed range {}..{}.'.format(label, lower, upper))
    return value


def levels(total, count, ratios, label):
    total = positive(total, label)
    weights = ([positive(w.strip(), label + ' ratio') for w in ratios.strip().split(':')]
               if ratios.strip() else [1.0] * integer(count, label + ' layers', 1, 1000))
    if len(weights) > 1000:
        raise ValueError(label + ': at most 1000 layers.')
    scale = max(weights)
    weights = [w / scale for w in weights]
    denominator = math.fsum(weights)
    result = [0.0]
    acc = 0.0
    for w in weights:
        acc += w
        result.append(total * acc / denominator)
    result[-1] = total
    if any(b <= a for a, b in zip(result, result[1:])):
        raise ValueError(label + ': ratios create indistinguishable layers; reduce their range.')
    return result


def determinant(p, q, r, s):
    a = [q[i] - p[i] for i in range(3)]
    b = [r[i] - p[i] for i in range(3)]
    c = [s[i] - p[i] for i in range(3)]
    return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])


def geometry(center, axis, width, wl, rl, ns, order=10):
    if axis not in ('X', 'Y', 'Z') or order not in (4, 10):
        raise ValueError('Axis must be X/Y/Z; element order must be 4/10.')
    if len(center) != 3 or not all(math.isfinite(float(x)) for x in center):
        raise ValueError('Center must contain three finite coordinates.')
    ns = integer(ns, 'Circumference segments', 3, 720)
    nw, nr = len(wl) - 1, len(rl) - 1
    if 3*nw*ns*(2*nr-1) > MAX_TETS:
        raise ValueError('Mesh exceeds 250000 tetrahedra. Reduce layer/segment counts.')
    disk = [(0.0, 0.0)]
    for radius in rl[1:]:
        for j in range(ns):
            angle = 2*math.pi*j/ns
            disk.append((radius*math.cos(angle), radius*math.sin(angle)))
    triangles = []
    for j in range(ns):
        k = (j + 1) % ns
        triangles.append((0, 1+j, 1+k))
        for ring in range(1, nr):
            a, b = 1+(ring-1)*ns+j, 1+(ring-1)*ns+k
            c, d = 1+ring*ns+j, 1+ring*ns+k
            triangles.extend(((a, c, d), (a, d, b)))
    points = []
    for w in wl:
        axial = w - width/2.0
        for u, v in disk:
            delta = {'X': (axial, u, v), 'Y': (v, axial, u), 'Z': (u, v, axial)}[axis]
            points.append(tuple(float(center[i]) + delta[i] for i in range(3)))
    tets = []
    n = len(disk)
    for layer in range(nw):
        lo, hi = layer*n, (layer+1)*n
        for triangle in triangles:
            i, j, k = sorted(triangle)
            a, b, c, A, B, C = lo+i, lo+j, lo+k, hi+i, hi+j, hi+k
            for tet in ((a, b, c, C), (a, b, B, C), (a, A, B, C)):
                volume = determinant(*(points[x] for x in tet))
                if not math.isfinite(volume) or volume == 0:
                    raise ValueError('Degenerate mesh: check dimensions, coordinates and ratios.')
                if volume < 0:
                    tet = (tet[1], tet[0], tet[2], tet[3])
                tets.append(tet)
    corner_count = len(points)
    if order == 10:
        midpoints = {}
        quadratic = []
        for tet in tets:
            mids = []
            for i, j in EDGES:
                edge = tuple(sorted((tet[i], tet[j])))
                if edge not in midpoints:
                    midpoints[edge] = len(points)
                    points.append(tuple(points[edge[0]][d]/2 + points[edge[1]][d]/2 for d in range(3)))
                mids.append(midpoints[edge])
            quadratic.append(tet + tuple(mids))
        tets = quadratic
    return {'points': points, 'tets': tets, 'corner_count': corner_count,
            'disk_nodes': n, 'nw': nw, 'nr': nr, 'ns': ns, 'order': order}


def parse_ids(text):
    tokens = text.replace(',', ' ').split()
    if not tokens:
        return []
    return list(dict.fromkeys(integer(t, 'Center node ID', 1, MAX_ID) for t in tokens))


def target_ids(text, increment, count):
    step = integer(increment, 'Renumber increment', 1, MAX_ID)
    result = []
    for token in text.replace(',', ' ').split():
        match = re.fullmatch(r'([0-9]+)(?:-([0-9]+))?', token)
        if not match:
            raise ValueError('Target IDs: use IDs/ranges such as 301-307 311-317.')
        first = integer(match[1], 'Target ID', 1, MAX_ID)
        last = integer(match[2] or match[1], 'Target ID', first, MAX_ID)
        for value in range(first, last+1, step):
            if value in result:
                raise ValueError('Duplicate target node ID {}.'.format(value))
            result.append(value)
            if len(result) == count:
                return result
    if not result:
        raise ValueError('Enter target IDs for axial centers.')
    return result


def validate(mesh):
    """Check orientation, conformity and straight quadratic node placement."""
    points, tets = mesh['points'], mesh['tets']
    faces, mids = Counter(), {}
    volume = 0.0
    for tet in tets:
        six = determinant(*(points[i] for i in tet[:4]))
        if six <= 0 or not math.isfinite(six):
            raise ValueError('Nonpositive tetrahedron volume.')
        volume += six/6
        for slots in ((0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3)):
            faces[tuple(sorted(tet[i] for i in slots))] += 1
        if len(tet) == 10:
            for offset, (i, j) in enumerate(EDGES):
                edge = tuple(sorted((tet[i], tet[j])))
                mid = tet[4+offset]
                if edge in mids and mids[edge] != mid:
                    raise ValueError('Adjacent tetrahedra do not share midpoint nodes.')
                mids[edge] = mid
                expected = tuple(points[edge[0]][d]/2 + points[edge[1]][d]/2 for d in range(3))
                if points[mid] != expected:
                    raise ValueError('Incorrect TET10 midpoint.')
    if any(count not in (1, 2) for count in faces.values()):
        raise ValueError('Nonmanifold tetrahedral faces.')
    boundary = sum(count == 1 for count in faces.values())
    expected_boundary = 2*mesh['ns']*(2*mesh['nr']-1) + 2*mesh['nw']*mesh['ns']
    if boundary != expected_boundary:
        raise ValueError('Unexpected internal crack/boundary face count.')
    return {'nodes': len(points), 'elements': len(tets), 'boundary_faces': boundary, 'volume': volume}


def write_card(stream, name, fields):
    """Free-field Nastran: 8 data fields per line, explicit continuation marker."""
    fields = [str(x) for x in fields]
    while len(fields) > 8:
        stream.write(name + ',' + ','.join(fields[:8]) + ',+\n')
        fields, name = fields[8:], '+'
    stream.write(name + ',' + ','.join(fields) + '\n')


def write_bdf(path, meshes, node_start=1, elem_start=1, prop_start=1,
              prefix='RevolveTet', rbe_ring=0, dofs='123456', targets=(), axis='X', material_id=0,
              pattern_axis=None):
    nodes, elements, properties = [], [], []
    next_n, next_e = node_start, elem_start
    mapping, ordered = [], []
    for mesh in meshes:
        ids = list(range(next_n, next_n+len(mesh['points'])))
        next_n += len(ids)
        mapping.append(ids)
        for layer in range(mesh['nw']+1):
            index = layer*mesh['disk_nodes']
            ordered.append((mesh['points'][index]['XYZ'.index(pattern_axis or axis)], len(mapping)-1, index))
    for target, (_, part, index) in zip(targets, sorted(ordered)):
        mapping[part][index] = target
    if any(x > MAX_ID for ids in mapping for x in ids):
        raise ValueError('Node ID limit exceeded.')
    if any(rbe_ring > mesh['nr'] for mesh in meshes):
        raise ValueError('RBE2 ring exceeds radial layer count.')
    with open(path, 'w', encoding='ascii', newline='\n') as stream:
        stream.write('$ RevolveTet PSJ: mesh only; assign/verify material before analysis.\nBEGIN BULK\n')
        for part, (mesh, ids) in enumerate(zip(meshes, mapping)):
            pid = prop_start+part
            properties.append(pid)
            stream.write('$HMNAME COMP {} "{}_{}"\n'.format(pid, prefix, pid))
            write_card(stream, 'PSOLID', [pid, material_id or ''])
            for nid, point in zip(ids, mesh['points']):
                nodes.append(nid)
                write_card(stream, 'GRID', [nid, '', *('{:.16g}'.format(x) for x in point)])
            for tet in mesh['tets']:
                elements.append(next_e)
                write_card(stream, 'CTETRA', [next_e, pid, *(ids[i] for i in tet)])
                next_e += 1
        if rbe_ring:
            for mesh, ids in zip(meshes, mapping):
                for layer in range(mesh['nw']+1):
                    base = layer*mesh['disk_nodes']
                    first = base+1+(rbe_ring-1)*mesh['ns']
                    write_card(stream, 'RBE2', [next_e, ids[base], dofs, *ids[first:first+mesh['ns']]])
                    elements.append(next_e)
                    next_e += 1
        stream.write('ENDDATA\n')
    if max(elements + properties + [0]) > MAX_ID:
        raise ValueError('Element/property ID limit exceeded.')
    return {'node_ids': nodes, 'element_ids': elements, 'property_ids': properties,
            'mapping': mapping, 'file': path}


def rigid_plan(meshes, mapping, ring):
    plan = []
    for part_index, (mesh, ids) in enumerate(zip(meshes, mapping)):
        for layer in range(mesh['nw']+1):
            base = layer*mesh['disk_nodes']
            first = base+1+(ring-1)*mesh['ns']
            slaves = ids[first:first+mesh['ns']]
            master = ids[base]
            if master in slaves or len(set(slaves)) != mesh['ns']:
                raise ValueError('Invalid local RBE2 master/slave set.')
            plan.append(dict(master=master, slaves=slaves, part=part_index, layer=layer))
    return plan


def native_rbe2(master, slaves, dofs='123456', name='RevolveTet_RBE2', edit=None):
    """Bypass Jupiter 5.0.4's broken free-field RBE2 continuation importer."""
    import JPT
    master_cursor = '[10:{}]'.format(master)
    slave_cursor = '[' + ','.join('10:{}'.format(n) for n in slaves) + ']'
    mask = sum(1 << (int(d)-1) for d in dofs)
    edit_cursor = '{}:{}'.format(edit.typeID, edit.id) if edit is not None else '0:0'
    if len(set(slaves)) != len(slaves) or master in slaves:
        raise ValueError('Each RBE2 needs one master and distinct local slaves.')
    safe_name = re.sub(r'[^A-Za-z0-9_]', '_', name)
    before = {int(c.id) for c in JPT.GetAllByTableTypeID(JPT.DTableType.DTABLE_CONNECTION)}
    JPT.Exec('RBE2OneToMany(16,{},{},2,"{}",0:0,0,{},[0,0,0],0,{},1,0,0,0)'.format(
        master_cursor, slave_cursor, safe_name, mask, edit_cursor))
    connections = list(JPT.GetAllByTableTypeID(JPT.DTableType.DTABLE_CONNECTION))
    candidates = ([c for c in connections if int(c.id) == int(edit.id)] if edit is not None else
                  [c for c in connections if int(c.id) not in before])
    if len(candidates) != 1:
        raise RuntimeError('Native RBE2 creation/edit did not return exactly one connection.')
    connection = candidates[0]
    if [int(n.id) for n in connection.masters] != [master] or sorted(int(n.id) for n in connection.slaves) != sorted(slaves):
        raise RuntimeError('Native RBE2 master/slave readback mismatch.')
    return int(connection.id)


def generate_in_jupiter(params):
    import JPT
    from Home.ImportMesh import NastranBdf
    existing_nodes = list(JPT.GetAllNodes())
    existing_elems = list(JPT.GetAllElems())
    existing_parts = list(JPT.GetAllParts())
    existing_props = list(JPT.GetAllByTableTypeID(JPT.DTableType.DTABLE_PROPERTY))
    existing_connections = list(JPT.GetAllByTableTypeID(JPT.DTableType.DTABLE_CONNECTION))
    by_id = {int(n.id): n for n in existing_nodes}
    # DNode.pos uses macro SI metres; BDF and entered dimensions use document
    # units (typically mm). Convert selected center nodes before meshing.
    to_doc = float(JPT.ConvertValueToDocUnit(1.0, JPT.UnitType.Unit_Length))
    ids = parse_ids(params['centers'])
    if ids:
        missing = [x for x in ids if x not in by_id]
        if missing:
            raise ValueError('Center nodes do not exist: ' + str(missing))
        centers = [(by_id[x].pos.x*to_doc, by_id[x].pos.y*to_doc, by_id[x].pos.z*to_doc) for x in ids]
    else:
        centers = [tuple(float(x) for x in params['xyz'].replace(',', ' ').split())]
    width = positive(params['width'], 'Width')
    wl = levels(width, params['nw'], params['wr'], 'Width')
    rl = levels(params['radius'], params['nr'], params['rr'], 'Radius')
    ns = integer(params['sectors'], 'Circumference segments', 3, 720)
    order = int(params['order'])
    if 3*(len(wl)-1)*ns*(2*len(rl)-3)*len(centers) > MAX_TETS:
        raise ValueError('Combined mesh exceeds 250000 tetrahedra.')
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,39}', params['prefix']):
        raise ValueError('Part prefix: use a letter followed by letters, numbers or underscore (max 40).')
    ring = integer(params['ring'], 'RBE2 ring', 1, len(rl)-1) if params['rbe'] else 0
    if params['renumber'] and not ring:
        raise ValueError('Enable Create RBE2 before assigning master IDs.')
    dofs = params['dofs'].strip()
    if ring and (not dofs or any(x not in '123456' for x in dofs) or len(set(dofs)) != len(dofs)):
        raise ValueError('RBE2 DOFs: use distinct digits 1..6, e.g. 123456.')
    meshes = [geometry(c, params['axis'], width, wl, rl, ns, order) for c in centers]
    stats = [validate(mesh) for mesh in meshes]
    targets = target_ids(params['targets'], params['step'], len(wl)*len(centers)) if params['renumber'] else []
    if any(x in by_id for x in targets):
        raise ValueError('Renumber target IDs already exist in the model.')
    node_start = max([int(n.id) for n in existing_nodes] + targets + [0])+1
    elem_start = max([int(e.id) for e in existing_elems+existing_connections]+[0])+1
    prop_start = max([int(p.id) for p in existing_props+existing_parts]+[0])+1
    name_set = {str(p.name) for p in existing_parts}
    if any('{}_{}'.format(params['prefix'], prop_start+i) in name_set for i in range(len(meshes))):
        raise ValueError('Generated part name already exists; change the prefix.')
    material_id = integer(params.get('material', '0'), 'Material ID', 0, MAX_ID)
    if material_id:
        materials = JPT.GetAllByTableTypeID(JPT.DTableType.DTABLE_MATERIAL)
        if material_id not in {int(m.id) for m in materials}:
            raise ValueError('Material ID does not exist in the current model.')
    folder = tempfile.mkdtemp(prefix='RevolveTet_PSJ_')
    path = os.path.join(folder, 'revolve_tet{}.bdf'.format(order))
    result = write_bdf(path, meshes, node_start, elem_start, prop_start, params['prefix'],
                       ring, dofs, targets, params['axis'], material_id, params.get('pattern_axis'))
    import_path = path
    if ring:
        import_path = os.path.join(folder, 'solid_only.bdf')
        imported = write_bdf(import_path, meshes, node_start, elem_start, prop_start, params['prefix'],
                             0, dofs, targets, params['axis'], material_id, params.get('pattern_axis'))
        result['element_ids'] = imported['element_ids']
    result['import_file'] = import_path
    print('[RevolveTet] Validated {} parts, {} nodes, {} TET{}; BDF: {}'.format(
        len(meshes), sum(s['nodes'] for s in stats), sum(s['elements'] for s in stats), order, path))
    # The file is retained on failure to make import errors reviewable.
    # Installed Jupiter 5.0.4 calls its first parameter strlPaths, whereas
    # the exported documentation calls it strlFilePaths. Use positional input.
    response = NastranBdf([import_path], iImportType=2,
                         bReadNameComment=True, iCreateDup1DElemAnswer=0)
    new_parts = [p for p in JPT.GetAllParts() if int(p.id) not in {int(x.id) for x in existing_parts}]
    new_solids = [e for e in JPT.GetElemsByKind(JPT.ElemKind.ELEMKIND_3D)
                  if int(e.id) not in {int(x.id) for x in existing_elems}]
    expected = sum(len(m['tets']) for m in meshes)
    if len(new_parts) < len(meshes) or len(new_solids) != expected or any(len(e.nodes) != order for e in new_solids):
        raise RuntimeError('Import readback failed (response {}): {} new solids, expected {} TET{}. '
                           'Inspect newly imported parts before retrying. BDF: {}'.format(response, len(new_solids), expected, order, path))
    def readback_failure(message):
        raise RuntimeError(message + ' Inspect imported parts before retrying. BDF: ' + path)
    actual_nodes = {int(n.id): n for n in JPT.GetAllNodes()}
    for mesh, node_ids in zip(meshes, result['mapping']):
        for nid, point in zip(node_ids, mesh['points']):
            if nid not in actual_nodes:
                readback_failure('Imported node ID {} is missing.'.format(nid))
            n = actual_nodes[nid]
            for actual, wanted in zip((n.pos.x*to_doc, n.pos.y*to_doc, n.pos.z*to_doc), point):
                if abs(actual-wanted) > 1e-10*max(1.0, abs(wanted)):
                    readback_failure('Imported node {} coordinate mismatch: {} vs {}.'.format(nid, actual, wanted))
    actual_solids = {int(e.id): e for e in new_solids}
    eid = elem_start
    for mesh, node_ids in zip(meshes, result['mapping']):
        for tet in mesh['tets']:
            if eid not in actual_solids:
                readback_failure('Imported tetra ID {} is missing.'.format(eid))
            received = [int(n.id) for n in actual_solids[eid].nodes]
            if sorted(received) != sorted(node_ids[i] for i in tet):
                readback_failure('Imported tetra {} connectivity mismatch.'.format(eid))
            eid += 1
    all_new_elements = {int(e.id) for e in JPT.GetAllElems()} - {int(e.id) for e in existing_elems}
    if not set(result['element_ids']).issubset(all_new_elements):
        readback_failure('Imported solid/RBE2 element IDs are incomplete.')
    result['rbe2_ids'] = []
    if ring:
        for row in rigid_plan(meshes, result['mapping'], ring):
            result['rbe2_ids'].append(native_rbe2(row['master'], row['slaves'], dofs,
                '{}_P{}_L{}_M{}'.format(params['prefix'], row['part']+1, row['layer']+1, row['master'])))
    # Jupiter 5.0.4 ignores the HMNAME component comment and uses body_<PID>.
    # Rename only known newly imported part IDs, after mesh readback succeeds.
    for part in new_parts:
        if int(part.id) in result['property_ids']:
            name = '{}_{}'.format(params['prefix'], int(part.id))
            JPT.Exec('RenameItem("{}", 3:{})'.format(name, int(part.id)))
    new_parts = [p for p in JPT.GetAllParts() if int(p.id) not in {int(x.id) for x in existing_parts}]
    result['parts'] = [(int(p.id), str(p.name)) for p in new_parts]
    result['stats'] = stats
    return result


_dialog = None
_busy = False


def selected_center_ids():
    import JPT
    return list(dict.fromkeys(int(n.id) for n in JPT.GetSelectedNodes()))


def read_dialog_params(dlg):
    names = ('centers', 'xyz', 'prefix', 'width', 'nw', 'wr', 'radius', 'nr', 'rr',
             'sectors', 'material', 'ring', 'dofs', 'targets', 'step')
    values = {name: str(dlg.get_item_text(name)).strip() for name in names}
    def chosen_axis(prefix):
        checked = [a for a in 'XYZ' if dlg.isbutton_checked(prefix+a)]
        if len(checked) != 1:
            raise ValueError('Select exactly one ' + ('normal' if prefix == 'normal_' else 'pattern') + ' axis.')
        return checked[0]
    values['axis'] = chosen_axis('normal_')
    values['pattern_axis'] = chosen_axis('pattern_')
    order_index = int(dlg.get_combobox_sel('order'))
    values['order'] = 4 if order_index == 1 else 10
    values['rbe'] = bool(dlg.isbutton_checked('rbe'))
    values['renumber'] = bool(dlg.isbutton_checked('renumber'))
    ids = selected_center_ids()
    if ids:
        # Selection wins over stale IDs from a previous Apply. Preserve full
        # XYZ for every center; X values need not be equally spaced.
        values['centers'] = ' '.join(map(str, ids))
        dlg.set_item_text('centers', values['centers'])
    return values


def apply_dialog(dlg):
    """Native Apply and Create parts share this exact execution path."""
    global _busy
    if _busy:
        return None
    _busy = True
    dlg.disable_item('Create')
    dlg.disable_item('Preview')
    try:
        dlg.set_item_text('Status', 'Creating one solid part per selected center node...')
        started = time.time()
        result = generate_in_jupiter(read_dialog_params(dlg))
        message = 'Created {} solid part(s), {} tetrahedra in {:.2f}s.'.format(
            len(result['stats']), sum(s['elements'] for s in result['stats']), time.time()-started)
        dlg.set_item_text('Status', message)
        print('[RevolveTet] ' + message)
        return result
    except Exception as error:
        message = 'Create failed: ' + str(error)
        dlg.set_item_text('Status', message)
        print('[RevolveTet] ' + message)
        return None
    finally:
        _busy = False
        dlg.enable_item('Create')
        dlg.enable_item('Preview')


def show_dialog():
    from pyjdg import JDGCreator
    global _dialog
    if _dialog is not None:
        print('[RevolveTet] Parameter dialog already open.')
        return
    dlg = JDGCreator(title='Revolve TET | Mesh and RBE2', resizable=True)
    _dialog = dlg
    dlg.add_node_selector()
    dlg.add_label(name='Intro', text='Select center nodes, then Apply: one solid per node.', width=500, height=24, layout='Window')
    dlg.add_tabwnd(name='Tabs', width=510, height=260, layout='Window')
    dlg.add_tabwnd_page('Tabs', 'MeshPage', 'Mesh', 'vertical')
    dlg.add_tabwnd_page('Tabs', 'LinksPage', 'RBE2 / Master IDs', 'vertical')

    def row(name, parent):
        dlg.add_hlayout(name=name, margin=[2, 2, 2, 2], layout=parent)
        return name

    def entry(name, label, default, layout, label_width=78, width=125):
        dlg.add_label(name='label_'+name, text=label, width=label_width, layout=layout)
        dlg.add_textbox(name=name, text=str(default), width=width, layout=layout)

    entry('centers', 'Node IDs', '', row('CentersRow', 'MeshPage'), width=265)
    dlg.add_button(name='Pick', text='Use selection', width=95, layout='CentersRow')
    entry('xyz', 'Or XYZ', '0 0 0', row('XYZRow', 'MeshPage'), width=355)

    def axis_row(prefix, label, parent):
        layout = row(prefix+'row', parent)
        dlg.add_label(name=prefix+'label', text=label, width=78, layout=layout)
        def choose(axis):
            for a in 'XYZ':
                dlg.set_checkbox_state(prefix+a, a == axis)
        for a in 'XYZ':
            dlg.add_checkbox(name=prefix+a, text=a, checked=(a == 'X'), width=75, layout=layout)
            dlg.on_command(name=prefix+a, callfunc=lambda d, a=a: choose(a))

    axis_row('normal_', 'Normal', 'MeshPage')
    for left, label, default, right, right_label, right_default in [
        ('width', 'Width', '14.9', 'radius', 'Radius', '22.5'),
        ('nw', 'W layers', '6', 'nr', 'R layers', '6'),
        ('wr', 'W ratios', '', 'rr', 'R ratios', '')]:
        layout = row('Pair_'+left, 'MeshPage')
        entry(left, label, default, layout)
        entry(right, right_label, right_default, layout)
    layout = row('SegmentsRow', 'MeshPage')
    entry('sectors', 'Segments', '32', layout)
    dlg.add_label(name='OrderLabel', text='Element', width=78, layout=layout)
    dlg.add_combobox(name='order', options=['TET10', 'TET4'], width=125, layout=layout)
    dlg.add_label(name='RatiosHelp', text='Blank ratios = equal layers. Example: 1:2:1. Model units.', width=490, layout='MeshPage')

    dlg.add_checkbox(name='rbe', text='Create separate RBE2: one master per axial layer', checked=False, layout='LinksPage')
    layout = row('RigidRow', 'LinksPage')
    entry('ring', 'Ring', '1', layout)
    entry('dofs', 'DOFs', '123456', layout)
    axis_row('pattern_', 'Pattern', 'LinksPage')
    dlg.add_label(name='PatternHelp', text='Pattern axis sorts master IDs; normal axis orients the solid.', width=490, layout='LinksPage')
    dlg.add_checkbox(name='renumber', text='Renumber master nodes only', checked=False, layout='LinksPage')
    entry('targets', 'Master IDs', DEFAULT_MASTER_IDS, row('MasterIDsRow', 'LinksPage'), width=355)
    layout = row('IDOptionsRow', 'LinksPage')
    entry('step', 'ID step', '1', layout)
    entry('prefix', 'Part prefix', 'RevolveTet', layout)
    entry('material', 'Material ID', '0', row('MaterialRow', 'LinksPage'), width=125)

    dlg.add_label(name='Status', text='Ready. Select nodes and Apply. RBE2 options are in the second tab.', width=500, height=44, layout='Window')
    row('Actions', 'Window')
    dlg.add_button(name='Preview', text='Check mesh', width=140, height=28, layout='Actions')
    dlg.add_button(name='Create', text='Create parts', width=140, height=28, layout='Actions')

    def pick(_):
        ids = selected_center_ids()
        if ids:
            dlg.set_item_text('centers', ' '.join(map(str, ids)))
            dlg.set_item_text('Status', '{} center nodes selected.'.format(len(ids)))
        else:
            dlg.set_item_text('Status', 'Select mesh center nodes in Jupiter.')

    def preview(_):
        try:
            p = read_dialog_params(dlg)
            wl = levels(p['width'], p['nw'], p['wr'], 'Width')
            rl = levels(p['radius'], p['nr'], p['rr'], 'Radius')
            m = geometry((0, 0, 0), p['axis'], float(p['width']), wl, rl, p['sectors'], p['order'])
            stats = validate(m)
            count = len(parse_ids(p['centers'])) or 1
            if stats['elements']*count > MAX_TETS:
                raise ValueError('Combined mesh exceeds 250000 tetrahedra.')
            message = '{} solids, {} TET{}.'.format(count, count*stats['elements'], p['order'])
            if p['rbe']:
                masters = count*len(wl)
                assigned = len(target_ids(p['targets'], p['step'], masters)) if p['renumber'] else 0
                message += ' {} masters; {} given IDs, {} automatic.'.format(masters, assigned, masters-assigned)
            dlg.set_item_text('Status', message)
        except Exception as error:
            dlg.set_item_text('Status', 'Check failed: ' + str(error))

    dlg.on_button_clicked(name='Pick', callfunc=pick)
    dlg.on_button_clicked(name='Preview', callfunc=preview)
    dlg.on_button_clicked(name='Create', callfunc=lambda d: apply_dialog(dlg))
    dlg.on_dlg_apply(callfunc=lambda d: apply_dialog(dlg))
    dlg.on_dlg_ok(callfunc=lambda d: None)
    dlg.generate_window()
    dlg.set_combobox_sel('order', 0)


if __name__ == '__main__':
    show_dialog()
