# coding: utf-8
"""Run this file in Jupiter PSJ on a fresh input model."""
import importlib
import os
import sys
from pathlib import Path

# If PSJ does not supply __file__, set this to the folder containing this file.
TOOL_FOLDER = 'C:/Users/TechnoStar/Downloads/03-Developer/01-PSJ/06-CRANK-MESHING/dist/crank_messing'

def _tool_root():
    candidates = []
    if globals().get('__file__'):
        candidates.append(Path(__file__).resolve().parent)
    override = os.environ.get('CRANK_MESSING_HOME')
    if override:
        candidates.append(Path(override))
    if TOOL_FOLDER:
        candidates.append(Path(TOOL_FOLDER))
    candidates.append(Path.cwd())
    for folder in candidates:
        if ((folder/'src/crank_messing/__init__.py').is_file()
                and (folder/'src/core/revolve_tet10_psj.py').is_file()):
            return folder.resolve()
    raise RuntimeError('Crank Meshing: set TOOL_FOLDER in crank_messing.py '
                       'to the package folder containing src.')

ROOT = _tool_root()
SOURCE_DIR = str(ROOT/'src')
sys.path[:] = [SOURCE_DIR] + [item for item in sys.path if item != SOURCE_DIR]
# A previous PSJ session may have imported another copy of this tool.
existing = sys.modules.get('crank_messing')
expected = ROOT/'src/crank_messing/__init__.py'
if existing is not None and Path(getattr(existing, '__file__', '') or '.').resolve() != expected:
    for name in list(sys.modules):
        if name == 'crank_messing' or name.startswith('crank_messing.'):
            del sys.modules[name]
import crank_messing
importlib.reload(crank_messing).reload_runtime().main()
