# Multi-selection, rubber-band selection and one-history-step group operations.
namespace eval ::CAEDesigner {
    if {![info exists selection]} {variable selection {}}
    variable marquee {}; variable selection_drag {}
}
foreach method {show select render_selection} {
    catch {rename ::CAEDesigner::multi_base_$method {}}
    rename ::CAEDesigner::$method ::CAEDesigner::multi_base_$method
}
proc ::CAEDesigner::selection_set {ids {primary ""}} {
    set valid {}
    foreach id $ids {if {[dict exists $::CAEDesigner::nodes $id] && $id ni $valid} {lappend valid $id}}
    set ::CAEDesigner::selection $valid
    if {$primary ni $valid} {set primary [lindex $valid end]}
    set ::CAEDesigner::selected $primary
    multi_base_select $primary
    set count [llength $valid]
    if {$count > 1} {set ::CAEDesigner::status "$count controls selected. Drag to move together; Delete removes the selection; Undo restores it."}
}
proc ::CAEDesigner::select {id} {
    if {$id eq ""} {set ::CAEDesigner::selection {}} elseif {$id ni $::CAEDesigner::selection} {set ::CAEDesigner::selection [list $id]}
    multi_base_select $id
}
proc ::CAEDesigner::selection_roots {} {
    set result {}
    foreach id $::CAEDesigner::selection {
        if {![dict exists $::CAEDesigner::nodes $id]} {continue}
        set parent [dict get $::CAEDesigner::nodes $id parent]; set covered 0
        while {$parent ne "root"} {
            if {$parent in $::CAEDesigner::selection} {set covered 1; break}
            set parent [dict get $::CAEDesigner::nodes $parent parent]
        }
        if {!$covered} {lappend result $id}
    }
    return $result
}
proc ::CAEDesigner::node_press {id X Y {toggle 0}} {
    focus .cae_designer.center.canvas
    if {$toggle} {
        set ids $::CAEDesigner::selection; set i [lsearch -exact $ids $id]
        if {$i >= 0} {set ids [lreplace $ids $i $i]} else {lappend ids $id}
        selection_set $ids $id
        set ::CAEDesigner::drag {}; return
    }
    if {$id ni $::CAEDesigner::selection} {selection_set [list $id] $id} else {selection_set $::CAEDesigner::selection $id}
    checkpoint
    set initial {}
    foreach root [selection_roots] {dict set initial $root [dict get $::CAEDesigner::nodes $root]}
    set ::CAEDesigner::selection_drag [list $X $Y $initial]
    set ::CAEDesigner::drag [list group $X $Y]
}
proc ::CAEDesigner::group_delta {initial dx dy} {
    # Clamp a common delta; do not distort spacing at the form boundary.
    dict for {id n} $initial {
        set dx [expr {max(-[dict get $n x],min(2000-[dict get $n x],$dx))}]
        set dy [expr {max(-[dict get $n y],min(2000-[dict get $n y],$dy))}]
    }
    dict for {id n} $initial {
        dict set n x [expr {[dict get $n x]+$dx}]; dict set n y [expr {[dict get $n y]+$dy}]
        dict set ::CAEDesigner::nodes $id $n
        place configure [dict get $::CAEDesigner::paths $id] -x [dict get $n x] -y [dict get $n y]
    }
    select $::CAEDesigner::selected
}
proc ::CAEDesigner::node_motion {X Y} {
    if {[lindex $::CAEDesigner::drag 0] ne "group"} {return}
    lassign $::CAEDesigner::selection_drag sx sy initial
    group_delta $initial [snap [expr {$X-$sx}]] [snap [expr {$Y-$sy}]]
}
proc ::CAEDesigner::nudge {dx dy} {
    if {![llength $::CAEDesigner::selection]} {return}
    checkpoint; set initial {}
    foreach id [selection_roots] {dict set initial $id [dict get $::CAEDesigner::nodes $id]}
    group_delta $initial [expr {$dx*$::CAEDesigner::grid_size}] [expr {$dy*$::CAEDesigner::grid_size}]
}
proc ::CAEDesigner::widget_bind {p id} {
    bindtags $p [list $p .cae_designer all]
    bind $p <Button-1> [list ::CAEDesigner::node_press $id %X %Y]
    bind $p <Control-Button-1> [list ::CAEDesigner::node_press $id %X %Y 1]
    bind $p <B1-Motion> {::CAEDesigner::node_motion %X %Y}
    bind $p <ButtonRelease-1> {set ::CAEDesigner::drag {}}
    foreach child [winfo children $p] {widget_bind $child $id}
}
proc ::CAEDesigner::marquee_clear {} {
    set f .cae_designer.center.canvas.form
    foreach edge {n s w e} {catch {destroy $f.marquee_$edge}}
}
proc ::CAEDesigner::surface_begin {X Y {append 0}} {
    set b .cae_designer.center.canvas.form.body
    set x [expr {$X-[winfo rootx $b]}]; set y [expr {$Y-[winfo rooty $b]}]
    focus .cae_designer.center.canvas
    if {$::CAEDesigner::tool ne "pointer"} {add $::CAEDesigner::tool $x $y; set ::CAEDesigner::tool pointer; return}
    set previous {}; if {$append} {set previous $::CAEDesigner::selection}
    selection_set $previous
    set ::CAEDesigner::marquee [list $x $y $previous]
    set f .cae_designer.center.canvas.form
    marquee_clear
    foreach edge {n s w e} {frame $f.marquee_$edge -background #2166a5}
}
proc ::CAEDesigner::surface_motion {X Y} {
    if {![llength $::CAEDesigner::marquee]} {return}
    lassign $::CAEDesigner::marquee sx sy previous
    set b .cae_designer.center.canvas.form.body
    set x [expr {$X-[winfo rootx $b]}]; set y [expr {$Y-[winfo rooty $b]}]
    set l [expr {min($sx,$x)}]; set t [expr {min($sy,$y)}]; set r [expr {max($sx,$x)}]; set bottom [expr {max($sy,$y)}]
    set ids $previous
    dict for {id n} $::CAEDesigner::nodes {
        lassign [absolute $id] ax ay
        if {$ax >= $l && $ay >= $t && $ax+[dict get $n width] <= $r && $ay+[dict get $n height] <= $bottom} {if {$id ni $ids} {lappend ids $id}}
    }
    selection_set $ids
    set f .cae_designer.center.canvas.form
    incr l 1; incr r 1; incr t 31; incr bottom 31
    place $f.marquee_n -x $l -y $t -width [expr {max(1,$r-$l)}] -height 1
    place $f.marquee_s -x $l -y $bottom -width [expr {max(1,$r-$l)}] -height 1
    place $f.marquee_w -x $l -y $t -width 1 -height [expr {max(1,$bottom-$t)}]
    place $f.marquee_e -x $r -y $t -width 1 -height [expr {max(1,$bottom-$t)}]
    foreach edge {n s w e} {raise $f.marquee_$edge}
}
proc ::CAEDesigner::surface_end {X Y} {
    surface_motion $X $Y
    set ::CAEDesigner::marquee {}; marquee_clear
}
proc ::CAEDesigner::render_selection {} {
    set filtered {}
    foreach id $::CAEDesigner::selection {if {[dict exists $::CAEDesigner::nodes $id]} {lappend filtered $id}}
    set ::CAEDesigner::selection $filtered
    multi_base_render_selection
    set f .cae_designer.center.canvas.form
    foreach child [winfo children $f] {if {[string match "$f.multi_*" $child]} {destroy $child}}
    foreach id $filtered {
        if {$id eq $::CAEDesigner::selected} {continue}
        lassign [absolute $id] x y; incr x 1; incr y 31
        set n [dict get $::CAEDesigner::nodes $id]; set w [dict get $n width]; set h [dict get $n height]
        foreach edge {n s w e} {frame $f.multi_${id}_$edge -background #2166a5}
        place $f.multi_${id}_n -x $x -y $y -width $w -height 1
        place $f.multi_${id}_s -x $x -y [expr {$y+$h}] -width $w -height 1
        place $f.multi_${id}_w -x $x -y $y -width 1 -height $h
        place $f.multi_${id}_e -x [expr {$x+$w}] -y $y -width 1 -height $h
    }
}
proc ::CAEDesigner::object_select {} {
    set ids {}
    foreach index [.cae_designer.left.objectbox.objects curselection] {lappend ids [lindex $::CAEDesigner::object_ids $index]}
    selection_set $ids
}
proc ::CAEDesigner::remove {} {
    set ids $::CAEDesigner::selection
    if {![llength $ids] && $::CAEDesigner::selected ne ""} {set ids [list $::CAEDesigner::selected]}
    if {![llength $ids]} {return}
    checkpoint
    for {set i 0} {$i < [llength $ids]} {incr i} {
        dict for {id n} $::CAEDesigner::nodes {if {[dict get $n parent] eq [lindex $ids $i] && $id ni $ids} {lappend ids $id}}
    }
    foreach id $ids {dict unset ::CAEDesigner::nodes $id}
    set ::CAEDesigner::selection {}; set ::CAEDesigner::selected ""; render
    set ::CAEDesigner::status "Deleted [llength $ids] controls. Undo restores the group."
}
proc ::CAEDesigner::delete_key {widget} {
    if {$widget eq ".cae_designer.center.canvas" || $widget eq ".cae_designer.left.objectbox.objects" || [string match .cae_designer.center.canvas.form.* $widget]} {remove; return -code break}
}
proc ::CAEDesigner::show {} {
    if {[winfo exists .cae_designer]} {raise .cae_designer; return}
    multi_base_show
    .cae_designer.left.objectbox.objects configure -selectmode extended
    bind .cae_designer <Delete> {::CAEDesigner::delete_key %W}
    foreach target {.cae_designer.center.canvas .cae_designer.left.objectbox.objects} {
        bind $target <Control-a> {::CAEDesigner::selection_set [dict keys $::CAEDesigner::nodes]; break}
        foreach {key dx dy} {Left -1 0 Right 1 0 Up 0 -1 Down 0 1} {bind $target <Key-$key> [list ::CAEDesigner::nudge $dx $dy]}
    }
    .cae_designer.toolbox.hint configure -text "Tool: click or drag onto the form.\nPointer: drag blank form to select a group.\nCtrl-click adds/removes; Delete removes."
    # render recreates the background canvas, so bind it through grid_draw too.
    selection_surface_bind
}
proc ::CAEDesigner::selection_surface_bind {} {
    set g .cae_designer.center.canvas.form.body.designgrid
    if {![winfo exists $g]} {return}
    bind $g <Button-1> {::CAEDesigner::surface_begin %X %Y}
    bind $g <Control-Button-1> {::CAEDesigner::surface_begin %X %Y 1}
    bind $g <B1-Motion> {::CAEDesigner::surface_motion %X %Y}
    bind $g <ButtonRelease-1> {::CAEDesigner::surface_end %X %Y}
}
catch {rename ::CAEDesigner::multi_base_grid_draw {}}
rename ::CAEDesigner::grid_draw ::CAEDesigner::multi_base_grid_draw
proc ::CAEDesigner::grid_draw {} {multi_base_grid_draw; selection_surface_bind}
