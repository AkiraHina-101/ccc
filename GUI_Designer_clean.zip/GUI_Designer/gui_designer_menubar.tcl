# Native application menus reuse the existing action commands.
catch {rename ::CAEDesigner::menubar_base_show {}}
rename ::CAEDesigner::show ::CAEDesigner::menubar_base_show
proc ::CAEDesigner::show {} {menubar_base_show; install_menubar}
proc ::CAEDesigner::menu_action {role} {
    set button .cae_designer.top.$role
    if {[winfo exists $button]} {$button invoke}
}
proc ::CAEDesigner::menu_edit_state {} {
    set m .cae_designer.menubar.edit
    foreach {index values} {0 undo 1 redo} {
        set state disabled
        if {[llength [set ::CAEDesigner::$values]]} {set state normal}
        $m entryconfigure $index -state $state
    }
    set state disabled
    if {$::CAEDesigner::selected ne ""} {set state normal}
    $m entryconfigure 3 -state $state
}
proc ::CAEDesigner::install_menubar {} {
    if {![winfo exists .cae_designer]} {return}
    set m .cae_designer.menubar
    if {[winfo exists $m]} {return}
    menu $m -tearoff 0
    .cae_designer configure -menu $m
    foreach {name caption} {file File edit Edit view View help Help} {
        menu $m.$name -tearoff 0
        $m add cascade -label $caption -underline 0 -menu $m.$name
    }
    foreach {role caption shortcut} {new {New Form} {Ctrl+N} load {Open...} {Ctrl+O} save {Save Design...} {Ctrl+S} export {Save Tcl Copy...} {Ctrl+Shift+S}} {
        $m.file add command -label $caption -accelerator $shortcut -command [list ::CAEDesigner::menu_action $role]
    }
    $m.file add separator
    $m.file add command -label "CAE Sample" -command [list ::CAEDesigner::menu_action sample]
    $m.file add separator
    $m.file add command -label Close -command ::CAEDesigner::close
    $m.edit add command -label Undo -accelerator Ctrl+Z -command [list ::CAEDesigner::menu_action undo]
    $m.edit add command -label Redo -accelerator Ctrl+Y -command [list ::CAEDesigner::menu_action redo]
    $m.edit add separator
    $m.edit add command -label "Delete Selected Controls" -accelerator Delete -command ::CAEDesigner::remove
    $m.edit add command -label "Select All Controls" -command {::CAEDesigner::selection_set [dict keys $::CAEDesigner::nodes]}
    $m.edit configure -postcommand ::CAEDesigner::menu_edit_state
    $m.view add command -label "Preview Form" -accelerator F5 -command [list ::CAEDesigner::menu_action preview]
    $m.view add command -label "Component Preview" -command {::CAEDesigner::safe ::CAEDesigner::full_preview}
    $m.view add command -label "Focus Form / Show Panels" -command ::CAEDesigner::focus_form
    $m.view add command -label Toolbox -command [.cae_designer.center.hint.tools cget -command]
    $m.help add command -label "About Icons" -command ::CAEDesigner::icon_credits
    foreach {key role} {Control-n new Control-o load Control-s save Control-Shift-S export Control-z undo Control-y redo F5 preview} {
        bind .cae_designer <$key> "::CAEDesigner::menu_action $role; break"
    }
    # Keep the original widgets as command owners for compatibility, but hide them.
    foreach role {new sample undo redo save load preview export} {grid remove .cae_designer.top.$role}
    grid remove .cae_designer.top.titlelabel .cae_designer.top.title
    grid columnconfigure .cae_designer.top 9 -weight 0
    .cae_designer.top.titlelabel configure -text "Form title"
    grid .cae_designer.top.titlelabel -row 0 -column 0 -sticky w -padx {0 8}
    grid .cae_designer.top.title -row 0 -column 1 -sticky w
    .cae_designer.top.title configure -width 32
}
