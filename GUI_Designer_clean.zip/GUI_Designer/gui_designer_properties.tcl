# Native typed property editors; configure remains the acceptance oracle.
foreach method {show properties_refresh} {
    catch {rename ::CAEDesigner::typed_base_$method {}}
    rename ::CAEDesigner::$method ::CAEDesigner::typed_base_$method
}
proc ::CAEDesigner::show {} {
    typed_base_show
    set fields .cae_designer.right.tabs.layout.fields
    foreach key {x y width height} {
        set slot [grid info $fields.e$key]; destroy $fields.e$key
        set minimum 0; if {$key eq "width"} {set minimum 20}; if {$key eq "height"} {set minimum 10}
        spinbox $fields.e$key -from $minimum -to 2000 -increment $::CAEDesigner::grid_size -width 12 -textvariable ::CAEDesigner::props($key) -command {::CAEDesigner::safe ::CAEDesigner::apply}
        eval [list grid $fields.e$key] $slot
        bind $fields.e$key <Return> {::CAEDesigner::safe ::CAEDesigner::apply}
    }
    set slot [grid info $fields.eparent]; destroy $fields.eparent
    ttk::combobox $fields.eparent -textvariable ::CAEDesigner::props(parent) -state readonly -width 15
    eval [list grid $fields.eparent] $slot
    bind $fields.eparent <<ComboboxSelected>> {::CAEDesigner::safe ::CAEDesigner::apply}
    set layout .cae_designer.right.tabs.layout
    ttk::frame $layout.sizebuttons
    foreach {key caption delta} {width {Width -} -1 width {Width +} 1 height {Height -} -1 height {Height +} 1} {
        set suffix minus; if {$delta > 0} {set suffix plus}
        ttk::button $layout.sizebuttons.$key$suffix -text $caption -command [list ::CAEDesigner::safe [list ::CAEDesigner::geometry_adjust $key $delta]]
        grid $layout.sizebuttons.$key$suffix -row [expr {$key eq "height"}] -column [expr {$delta > 0}] -sticky ew -padx 2 -pady 2
    }
    grid columnconfigure $layout.sizebuttons 0 -weight 1; grid columnconfigure $layout.sizebuttons 1 -weight 1
    pack $layout.sizebuttons -before $layout.apply -fill x -pady 4
    set window .cae_designer.right.tabs.window
    foreach key {width height form_x form_y} {
        destroy $window.e$key
        set minimum 0; if {$key in {width height}} {set minimum 100}
        spinbox $window.e$key -from $minimum -to 2000 -increment $::CAEDesigner::grid_size -width 12 -textvariable ::CAEDesigner::$key -command {::CAEDesigner::safe ::CAEDesigner::form_apply}
        pack $window.e$key -after $window.l$key -fill x -pady {2 10}
        bind $window.e$key <Return> {::CAEDesigner::safe ::CAEDesigner::form_apply}
    }
    .cae_designer.right.tabs.widget.help configure -text "Select a native option. Available values use a selector; numbers use arrows. Apply updates the live control."
    properties_refresh
}
proc ::CAEDesigner::geometry_adjust {key direction} {
    if {$::CAEDesigner::selected eq ""} {return}
    set minimum 20; if {$key eq "height"} {set minimum 10}
    set ::CAEDesigner::props($key) [expr {max($minimum,min(2000,$::CAEDesigner::props($key)+$direction*$::CAEDesigner::grid_size))}]
    apply
}
proc ::CAEDesigner::properties_refresh {} {
    typed_base_properties_refresh
    set combo .cae_designer.right.tabs.layout.fields.eparent
    if {[winfo exists $combo] && [winfo class $combo] eq "TCombobox"} {
        set parents root
        dict for {id n} $::CAEDesigner::nodes {
            if {$id ne $::CAEDesigner::selected && [dict get $n type] in {frame labelframe}} {lappend parents $id}
        }
        $combo configure -values $parents
        set state readonly
        if {$::CAEDesigner::selected ne "" && [dict exists $::CAEDesigner::nodes $::CAEDesigner::selected originalpath]} {set state disabled; $combo configure -values [list $::CAEDesigner::props(parent)]}
        $combo configure -state $state
    }
    set options .cae_designer.right.tabs.widget.optionbox.options
    if {![winfo exists $options]} {return}
    set old $::CAEDesigner::option_name
    set all [$options get 0 end]; set i [lsearch -exact $all $old]
    if {$i < 0 && [llength $all]} {set i 0}
    if {$i >= 0} {$options selection set $i; property_pick} else {
        set ::CAEDesigner::option_name ""; set ::CAEDesigner::option_value ""
    }
}
proc ::CAEDesigner::property_pick {} {
    set list .cae_designer.right.tabs.widget.optionbox.options
    set index [$list curselection]; if {![llength $index] || $::CAEDesigner::selected eq ""} {return}
    set name [$list get [lindex $index 0]]
    set p [dict get $::CAEDesigner::paths $::CAEDesigner::selected]
    set ::CAEDesigner::option_name $name; set ::CAEDesigner::option_value [$p cget $name]
    set widget .cae_designer.right.tabs.widget
    catch {destroy $widget.optionvalue}; catch {destroy $widget.choosecolor}
    set choices {}
    switch -- $name {
        -anchor {set choices {n ne e se s sw w nw center}}
        -justify {set choices {left center right}}
        -relief - -activerelief - -sliderrelief {set choices {flat raised sunken groove ridge solid}}
        -orient {set choices {horizontal vertical}}
        -compound {set choices {none top bottom left right center image text}}
        -state {set choices {normal disabled readonly active}}
        -mode {set choices {determinate indeterminate}}
        -selectmode {set choices {single browse multiple extended}; if {[winfo class $p] eq "Treeview"} {set choices {none browse extended}}}
        -wrap {set choices {none char word}}
        -font {set choices [lsort [font names]]}
        -cursor {set choices {{} arrow hand2 crosshair fleur watch xterm sizing}}
        -takefocus - -exportselection - -showvalue - -jump - -indicatoron - -undo - -autoseparators - -setgrid - -opaqueresize {set choices {0 1}}
    }
    if {[llength $choices]} {
        # Probe an unmapped matching constructor, never transiently modify the user's control.
        set probe .cae_designer.property_probe; catch {destroy $probe}
        set node [dict get $::CAEDesigner::nodes $::CAEDesigner::selected]; dict set node options {}
        if {![catch {uplevel #0 [factory $probe $node]}]} {
            set supported {}
            foreach value $choices {if {![catch {$probe configure $name $value}]} {lappend supported $value}}
            set choices $supported
            if {[lsearch -exact $choices $::CAEDesigner::option_value] < 0 && ![catch {$probe configure $name $::CAEDesigner::option_value}]} {lappend choices $::CAEDesigner::option_value}
        }
        catch {destroy $probe}
        ttk::combobox $widget.optionvalue -values $choices -state readonly -textvariable ::CAEDesigner::option_value
    } elseif {$name in {-width -height -length -padding -padx -pady -borderwidth -highlightthickness -wraplength -insertwidth -selectborderwidth -from -to -increment -value -maximum -resolution -digits -tickinterval -sliderlength -repeatdelay -repeatinterval -insertontime -insertofftime -spacing1 -spacing2 -spacing3} && ([string is double -strict $::CAEDesigner::option_value] || $::CAEDesigner::option_value eq "")} {
        set minimum 0; if {$name in {-from -to -value}} {set minimum -100000}
        spinbox $widget.optionvalue -from $minimum -to 100000 -increment 1 -textvariable ::CAEDesigner::option_value
    } else {ttk::entry $widget.optionvalue -textvariable ::CAEDesigner::option_value}
    pack $widget.optionvalue -before $widget.optionapply -fill x -pady 6
    if {[string match *background $name] || [string match *foreground $name] || $name in {-selectcolor -troughcolor -insertbackground -highlightcolor}} {
        ttk::button $widget.choosecolor -text "Choose Color..." -command ::CAEDesigner::choose_color
        pack $widget.choosecolor -before $widget.optionapply -fill x -pady 3
    }
    bind $widget.optionvalue <Return> {::CAEDesigner::safe ::CAEDesigner::property_apply}
}
proc ::CAEDesigner::choose_color {} {
    set args [list -parent .cae_designer -title "Widget Color"]
    if {![catch {winfo rgb .cae_designer $::CAEDesigner::option_value}]} {lappend args -initialcolor $::CAEDesigner::option_value}
    set color [eval tk_chooseColor $args]
    if {$color ne ""} {set ::CAEDesigner::option_value $color; safe ::CAEDesigner::property_apply}
}
