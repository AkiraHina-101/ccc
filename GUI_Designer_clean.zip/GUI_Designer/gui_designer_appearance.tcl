# Native preview viewport and quick appearance controls.
namespace eval ::CAEDesigner {variable appearance; variable color_target -background}
foreach method {show browse_preview full_preview properties_refresh factory} {
    catch {rename ::CAEDesigner::appearance_base_$method {}}
    rename ::CAEDesigner::$method ::CAEDesigner::appearance_base_$method
}
proc ::CAEDesigner::show {} {
    if {[winfo exists .cae_designer]} {wm deiconify .cae_designer; raise .cae_designer; return}
    appearance_base_show
    set r .cae_designer.left.reference.right
    pack forget $r.sample
    ttk::frame $r.viewport
    canvas $r.viewport.c -width 300 -height 230 -highlightthickness 0 -background #f0f0f0
    ttk::scrollbar $r.viewport.v -orient vertical -command [list $r.viewport.c yview]
    ttk::scrollbar $r.viewport.h -orient horizontal -command [list $r.viewport.c xview]
    $r.viewport.c configure -yscrollcommand [list $r.viewport.v set] -xscrollcommand [list $r.viewport.h set]
    grid $r.viewport.c -row 0 -column 0 -sticky nsew
    grid $r.viewport.v -row 0 -column 1 -sticky ns
    grid $r.viewport.h -row 1 -column 0 -sticky ew
    grid columnconfigure $r.viewport 0 -weight 1
    grid rowconfigure $r.viewport 0 -weight 1
    pack $r.viewport -fill x -pady 4
    pack propagate $r.sample 1
    $r.sample configure -width 0 -height 0
    $r.viewport.c create window 0 0 -anchor nw -window $r.sample -tags content
    bind $r.sample <Configure> {::CAEDesigner::preview_extent}
    set a .cae_designer.right.tabs.appearance
    ttk::frame $a -padding 8
    .cae_designer.right.tabs add $a -text Appearance
    ttk::label $a.help -text "Select a control. Changes apply immediately. Ttk colors use a private style; native themes may override its appearance." -wraplength 270
    pack $a.help -fill x -pady {0 8}
    ttk::combobox $a.target -state readonly -values {-background -foreground -activebackground -activeforeground -highlightbackground -highlightcolor} -textvariable ::CAEDesigner::color_target
    pack $a.target -fill x
    bind $a.target <<ComboboxSelected>> {::CAEDesigner::appearance_refresh}
    ttk::frame $a.palette
    set i 0
    foreach color {#f0f0f0 #ffffff #d9d9d9 #808080 #303030 #000000 #2166a5 #58a6d6 #287a3d #d9a329 #c84343 #7855a6} {
        button $a.palette.c$i -background $color -activebackground $color -width 3 -relief raised -borderwidth 2 -takefocus 1
        # Resolve the selected target at click time.
        $a.palette.c$i configure -command "::CAEDesigner::safe \[list ::CAEDesigner::appearance_apply \$::CAEDesigner::color_target $color\]"
        bind $a.palette.c$i <FocusIn> [list set ::CAEDesigner::appearance(status) "Color: $color (Space to apply)"]
        bind $a.palette.c$i <Enter> [list set ::CAEDesigner::appearance(status) "Color: $color"]
        grid $a.palette.c$i -row [expr {$i/6}] -column [expr {$i%6}] -padx 2 -pady 3 -sticky ew
        incr i
    }
    pack $a.palette -fill x -pady 6
    ttk::button $a.choose -text "Choose Color..." -command ::CAEDesigner::appearance_choose
    pack $a.choose -fill x -pady 4
    ttk::label $a.reliefLabel -text "Border relief"
    ttk::combobox $a.relief -state readonly -values {flat raised sunken groove ridge solid} -textvariable ::CAEDesigner::appearance(relief)
    bind $a.relief <<ComboboxSelected>> {::CAEDesigner::safe [list ::CAEDesigner::appearance_apply -relief $::CAEDesigner::appearance(relief)]}
    ttk::label $a.widthLabel -text "Border width (px)"
    spinbox $a.width -from 0 -to 20 -width 8 -textvariable ::CAEDesigner::appearance(borderwidth) -command {::CAEDesigner::safe [list ::CAEDesigner::appearance_apply -borderwidth $::CAEDesigner::appearance(borderwidth)]}
    bind $a.width <Return> {::CAEDesigner::safe [list ::CAEDesigner::appearance_apply -borderwidth $::CAEDesigner::appearance(borderwidth)]}
    pack $a.reliefLabel $a.relief $a.widthLabel $a.width -fill x -pady 4
    ttk::label $a.value -textvariable ::CAEDesigner::appearance(status) -wraplength 270
    pack $a.value -fill x -pady 6
    browse_preview
    appearance_refresh
}
proc ::CAEDesigner::preview_extent {} {
    set r .cae_designer.left.reference.right
    if {![winfo exists $r.viewport.c]} {return}
    set w [expr {max(300,[winfo reqwidth $r.sample])}]
    set h [expr {max(230,[winfo reqheight $r.sample])}]
    $r.viewport.c itemconfigure content -width $w -height $h
    $r.viewport.c configure -scrollregion [list 0 0 $w $h]
}
proc ::CAEDesigner::browse_preview {} {
    appearance_base_browse_preview
    set indices [.cae_designer.left.palettebox.palette curselection]
    if {[llength $indices]} {
        set row [lindex $::CAEDesigner::browser_rows [lindex $indices 0]]
        if {[lindex $row 1] eq "toplevel"} {
            set p .cae_designer.left.reference.right.sample
            foreach child [winfo children $p] {destroy $child}
            ttk::label $p.explanation -text "toplevel creates an independent native window.\nIts title bar and border belong to Windows." -wraplength 280
            ttk::button $p.open -text "Open Native Window" -command ::CAEDesigner::native_window_preview
            pack $p.explanation $p.open -fill x -padx 12 -pady 10
        }
    }
    preview_extent
    set c .cae_designer.left.reference.right.viewport.c
    if {[winfo exists $c]} {$c xview moveto 0; $c yview moveto 0}
}
proc ::CAEDesigner::native_window_preview {} {
    catch {destroy .cae_native_window_preview}
    toplevel .cae_native_window_preview
    wm title .cae_native_window_preview "Tk Toplevel Preview"
    wm geometry .cae_native_window_preview 360x180
    ttk::label .cae_native_window_preview.label -text "Native Tk toplevel — independent window" -padding 16
    ttk::button .cae_native_window_preview.close -text Close -command {destroy .cae_native_window_preview}
    pack .cae_native_window_preview.label -fill x
    pack .cae_native_window_preview.close -side bottom -pady 16
}
proc ::CAEDesigner::full_preview {} {
    set indices [.cae_designer.left.palettebox.palette curselection]
    if {[llength $indices] && [lindex [lindex $::CAEDesigner::browser_rows [lindex $indices 0]] 1] eq "toplevel"} {native_window_preview; return}
    appearance_base_full_preview
}
proc ::CAEDesigner::properties_refresh {} {appearance_base_properties_refresh; appearance_refresh}
proc ::CAEDesigner::appearance_refresh {} {
    set a .cae_designer.right.tabs.appearance
    if {![winfo exists $a]} {return}
    set id $::CAEDesigner::selected
    set ::CAEDesigner::appearance(status) "Select a control to edit its colors and border."
    set ::CAEDesigner::appearance(relief) flat
    set ::CAEDesigner::appearance(borderwidth) 0
    set p ""
    if {$id ne "" && [dict exists $::CAEDesigner::paths $id]} {set p [dict get $::CAEDesigner::paths $id]}
    foreach {option widget} {-relief relief -borderwidth width} {
        set state disabled
        if {$p ne "" && ![catch {$p cget $option} value]} {set ::CAEDesigner::appearance([string range $option 1 end]) $value; set state normal}
        if {$widget eq "relief" && $state eq "normal"} {set state readonly}
        $a.$widget configure -state $state
    }
    set supported 0
    if {$p ne ""} {
        if {![catch {$p cget $::CAEDesigner::color_target} value]} {set supported 1; set ::CAEDesigner::appearance(status) "$::CAEDesigner::color_target: $value"} elseif {$::CAEDesigner::color_target in {-background -foreground} && ![catch {$p cget -style}]} {set supported 1; set ::CAEDesigner::appearance(status) "Ttk private style; rendering follows the active theme."}
    }
    set state disabled; if {$supported} {set state normal}
    foreach b [winfo children $a.palette] {$b configure -state $state}
    $a.choose configure -state $state
}
proc ::CAEDesigner::appearance_apply {option value} {
    set id $::CAEDesigner::selected
    if {$id eq ""} {return}
    set p [dict get $::CAEDesigner::paths $id]
    if {![catch {$p cget $option}]} {
        set ::CAEDesigner::option_name $option; set ::CAEDesigner::option_value $value
        property_apply
    } elseif {$option in {-background -foreground} && ![catch {$p cget -style}]} {
        winfo rgb $p $value
        checkpoint
        dict set ::CAEDesigner::nodes $id quickstyle $option $value
        render
    } else {error "This native control does not support $option."}
    appearance_refresh
}
proc ::CAEDesigner::appearance_choose {} {
    set color [tk_chooseColor -parent .cae_designer -title "Control Color"]
    if {$color ne ""} {safe [list ::CAEDesigner::appearance_apply $::CAEDesigner::color_target $color]}
}
proc ::CAEDesigner::style_code {p n} {
    if {![dict exists $n quickstyle]} {return ""}
    set base ""
    if {[dict exists $n options -style]} {set base [dict get $n options -style]}
    if {$base eq ""} {
        set type [dict get $n type]
        set base T[string toupper [string index $type 0]][string range $type 1 end]
        if {$type eq "labelframe"} {set base TLabelframe}
        if {$type eq "treeview"} {set base Treeview}
    }
    set style CAEQuick.[string map {. _ : _} $p].$base
    set cmd [list ttk::style configure $style]
    dict for {key value} [dict get $n quickstyle] {lappend cmd $key $value}
    return "$cmd\n[list $p configure -style $style]\n"
}
proc ::CAEDesigner::factory {p n} {return "[appearance_base_factory $p $n][style_code $p $n]"}
