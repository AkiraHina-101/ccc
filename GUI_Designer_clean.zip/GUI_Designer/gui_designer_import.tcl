# Existing Tcl UI import. The child interpreter owns source variables/procedures.
# Only bounded UI aliases reach the host. Application callbacks are never run.
namespace eval ::CAEDesigner {
    if {![info exists imported]} {variable imported {}}
    variable import_session {}; variable import_last_report {}
    if {![info exists import_counter]} {variable import_counter 0}
}
foreach method {show load save export new sample factory render properties_refresh} {
    catch {rename ::CAEDesigner::import_base_$method {}}
    rename ::CAEDesigner::$method ::CAEDesigner::import_base_$method
}
proc ::CAEDesigner::import_block {ip message} {
    dict lappend ::CAEDesigner::import_session blocked $message
    error "Tcl UI import blocked: $message"
}
proc ::CAEDesigner::import_map {path} {
    if {![dict exists $::CAEDesigner::import_session paths $path]} {error "Unknown imported window: $path"}
    return [dict get $::CAEDesigner::import_session paths $path]
}
proc ::CAEDesigner::import_value {ip name} {
    if {[catch {interp eval $ip [list set $name]} value]} {return ""}
    return $value
}
proc ::CAEDesigner::import_options {ip path args} {
    if {[llength $args] % 2} {error "Expected option/value pairs for $path"}
    set result {}
    foreach {key value} $args {
        if {![regexp {^-[a-zA-Z]+$} $key]} {error "Invalid option $key"}
        dict set ::CAEDesigner::import_session explicit $path $key $value
        if {$key in {-command -validatecommand -invalidcommand -postcommand -xscrollcommand -yscrollcommand -menu -image -class -container -variable -textvariable}} {
            if {$key eq "-image" && $value ne ""} {import_block $ip "Unsupported resource $key on $path"}
            if {$key eq "-menu" && $value ne ""} {dict set ::CAEDesigner::import_session menus $path $value}
            if {$key eq "-textvariable"} {
                set text [import_value $ip $value]
                dict set ::CAEDesigner::import_session sampletext $path $text
                set type [dict get $::CAEDesigner::import_session constructors $path]
                if {[namespace tail $type] in {label button checkbutton radiobutton labelframe menubutton message}} {lappend result -text $text}
            }
            continue
        }
        if {$key eq "-style"} {set value CAEImported.$value}
        lappend result $key $value
    }
    return $result
}
proc ::CAEDesigner::import_constructor {ip api path args} {
    if {![regexp {^\.[a-zA-Z0-9_.]+$} $path] || [string length $path] > 250} {import_block $ip "Unsupported widget path"}
    if {[dict size [dict get $::CAEDesigner::import_session constructors]] >= 200} {import_block $ip "Maximum 200 imported components"}
    dict set ::CAEDesigner::import_session constructors $path $api
    if {$api eq "toplevel"} {
        if {[dict get $::CAEDesigner::import_session root] ne ""} {import_block $ip "Only one top-level form is supported"}
        set mapped .cae_import_capture_[incr ::CAEDesigner::import_counter]
        dict set ::CAEDesigner::import_session root $path
        set caller [interp eval $ip {info level 0}]
        if {[llength $caller] && [llength [interp eval $ip [list info procs [lindex $caller 0]]]]} {
            dict set ::CAEDesigner::import_session showproc [lindex $caller 0]
        }
        toplevel $mapped
        wm withdraw $mapped
        catch {wm attributes $mapped -alpha 0.0}
    } else {
        # Tk hierarchy uses the final dot, not filesystem hierarchy.
        set parent [string range $path 0 [expr {[string last . $path]-1}]]
        set mapped [import_map $parent].[string range $path [expr {[string last . $path]+1}] end]
        set filtered [import_options $ip $path {*}$args]
        uplevel #0 [list $api $mapped {*}$filtered]
        # No imported bind script, variable trace or class click can run in host.
        bindtags $mapped [list $mapped]
        if {[dict exists $::CAEDesigner::import_session sampletext $path] && [namespace tail $api] in {entry spinbox combobox}} {
            set value [dict get $::CAEDesigner::import_session sampletext $path]
            if {[namespace tail $api] eq "combobox"} {$mapped set $value} else {$mapped insert 0 $value}
        }
        if {[namespace tail $api] in {checkbutton radiobutton} && [dict exists $::CAEDesigner::import_session explicit $path -variable]} {
            set variable [dict get $::CAEDesigner::import_session explicit $path -variable]
            set expected 1
            foreach key {-onvalue -value} {if {[dict exists $::CAEDesigner::import_session explicit $path $key]} {set expected [dict get $::CAEDesigner::import_session explicit $path $key]}}
            set checked [expr {[import_value $ip $variable] eq $expected}]
            dict set ::CAEDesigner::import_session checked $path $checked
            if {[string match *ttk::* $api]} {
                $mapped state {!alternate !selected}
                if {$checked} {$mapped state selected}
            } elseif {$checked} {$mapped select} else {$mapped deselect}
        }
    }
    dict set ::CAEDesigner::import_session paths $path $mapped
    interp alias $ip $path {} ::CAEDesigner::import_widget $ip $path
    return $path
}
proc ::CAEDesigner::import_widget {ip path operation args} {
    set mapped [import_map $path]
    switch $operation {
        configure - config {
            if {![llength $args]} {return [$mapped configure]}
            if {[llength $args] == 1} {return [$mapped configure {*}$args]}
            set filtered [import_options $ip $path {*}$args]
            if {[llength $filtered]} {$mapped configure {*}$filtered}
            return
        }
        cget {
            set key [lindex $args 0]
            if {$key in {-command -variable -textvariable -menu -image} && [dict exists $::CAEDesigner::import_session explicit $path $key]} {return [dict get $::CAEDesigner::import_session explicit $path $key]}
            return [$mapped cget {*}$args]
        }
        create - itemconfigure - itemconfig - coords - move - raise - lower - bbox - find - type - heading - column - tag - children - exists - item - see - index - size - add {
            set type [namespace tail [dict get $::CAEDesigner::import_session constructors $path]]
            if {$type ni {canvas treeview menu text}} {import_block $ip "Unsupported content operation $path $operation"}
            if {$operation eq "create" && [lindex $args 0] in {window image}} {import_block $ip "Canvas external resources are not supported"}
            if {$operation eq "tag" && [lindex $args 0] eq "bind"} {import_block $ip "Tag callback execution is disabled"}
            set filtered {}; set skip 0
            foreach arg $args {
                if {$skip} {set skip 0; continue}
                if {$arg eq "-command"} {set skip 1; continue}
                lappend filtered $arg
            }
            set result [$mapped $operation {*}$filtered]
            if {$operation in {create itemconfigure itemconfig coords move heading column tag add}} {import_content $path [list $operation {*}$filtered]}
            return $result
        }
        get - set - insert - delete - state - instate - current - selection - xview - yview {
            if {$operation eq "instate" && [llength $args] > 1} {import_block $ip "Instate callback execution is disabled"}
            set result [$mapped $operation {*}$args]
            if {$operation in {insert delete} && [namespace tail [dict get $::CAEDesigner::import_session constructors $path]] in {treeview canvas}} {import_content $path [list $operation {*}$args]}
            return $result
        }
        default {import_block $ip "Unsupported widget operation $path $operation"}
    }
}
proc ::CAEDesigner::import_content {path operation} {
    set current {}
    if {[dict exists $::CAEDesigner::import_session content $path]} {set current [dict get $::CAEDesigner::import_session content $path]}
    if {[llength $current] >= 2000} {error "Maximum 2000 drawing/table operations."}
    lappend current $operation
    dict set ::CAEDesigner::import_session content $path $current
}
proc ::CAEDesigner::import_geometry {ip command args} {
    set translated {}
    foreach arg $args {
        if {[string match .* $arg]} {lappend translated [import_map $arg]} else {lappend translated $arg}
    }
    # A geometry query can expose only this isolated hierarchy.
    return [uplevel #0 [list $command {*}$translated]]
}
proc ::CAEDesigner::import_wm {ip operation path args} {
    set mapped [import_map $path]
    switch $operation {
        title - minsize - maxsize - resizable {return [wm $operation $mapped {*}$args]}
        geometry {
            if {[llength $args] && ![regexp {^([0-9]{1,4}x[0-9]{1,4})?([+-][0-9]+[+-][0-9]+)?$} [lindex $args 0]]} {import_block $ip "Unsupported window geometry"}
            if {[llength $args] && [regexp {^[0-9]+x[0-9]+} [lindex $args 0]]} {dict set ::CAEDesigner::import_session windowgeometry [lindex $args 0]}
            return [wm geometry $mapped {*}$args]
        }
        attributes - protocol - withdraw - deiconify {return ""}
        default {import_block $ip "Unsupported wm operation $operation"}
    }
}
proc ::CAEDesigner::import_winfo {ip operation path args} {
    if {$operation eq "exists" && ![dict exists $::CAEDesigner::import_session paths $path]} {return 0}
    if {$operation ni {exists width height reqwidth reqheight x y class screenwidth screenheight ismapped pointerxy}} {import_block $ip "Unsupported winfo operation $operation"}
    return [winfo $operation [import_map $path] {*}$args]
}
proc ::CAEDesigner::import_destroy {ip args} {
    foreach path $args {if {[dict exists $::CAEDesigner::import_session paths $path]} {destroy [import_map $path]}}
}
proc ::CAEDesigner::import_package {ip operation args} {
    if {$operation eq "require" && [lindex $args 0] in {Tk Tcl}} {return [info patchlevel]}
    if {$operation eq "require" && [lindex $args 0] eq "twapi"} {
        # Optional monitor positioning falls back to Tk's native screen bounds.
        dict lappend ::CAEDesigner::import_session messages {Optional twapi monitor positioning omitted; Tk fallback retained.}
        error "Optional desktop monitor helper is not loaded in the import child"
    }
    import_block $ip "Unsupported package operation: $operation $args"
}
proc ::CAEDesigner::import_unknown {ip command args} {import_block $ip "Unsupported command: $command"}
proc ::CAEDesigner::import_bind {ip args} {
    dict lappend ::CAEDesigner::import_session bindings $args
    return ""
}
proc ::CAEDesigner::import_puts {ip args} {
    if {[llength $args] > 3} {import_block $ip "Unsupported puts arguments"}
    dict lappend ::CAEDesigner::import_session messages [string range [lindex $args end] 0 2047]
    return ""
}
proc ::CAEDesigner::import_update {ip args} {
    if {$args ne "idletasks"} {import_block $ip "Only geometry idle updates are supported"}
    update idletasks
}
proc ::CAEDesigner::import_hm_info {ip args} {
    if {![llength [info commands ::hm_info]] || $args ni {{-appinfo VERSION} {-appinfo DISPLAYVERSION}}} {import_block $ip "Only native HyperMesh version readback is allowed"}
    return [::hm_info {*}$args]
}
proc ::CAEDesigner::import_style {ip operation args} {
    if {$operation ni {configure map lookup}} {import_block $ip "Unsupported style operation $operation"}
    set name [lindex $args 0]; set owned CAEImported.$name
    if {$operation eq "lookup"} {return [ttk::style lookup $name {*}[lrange $args 1 end]]}
    dict lappend ::CAEDesigner::import_session styles [list ttk::style $operation $owned {*}[lrange $args 1 end]]
    return [ttk::style $operation $owned {*}[lrange $args 1 end]]
}
proc ::CAEDesigner::import_confined {ip path} {
    set normalized [file normalize $path]
    set base [dict get $::CAEDesigner::import_session allowedroot]
    if {![string equal -nocase $normalized $base] && ![string match -nocase "$base/*" $normalized]} {import_block $ip "File read outside the selected tool project: $normalized"}
    return $normalized
}
proc ::CAEDesigner::import_file {ip operation args} {
    if {$operation in {dirname join normalize tail rootname extension split pathtype separator}} {return [file $operation {*}$args]}
    if {$operation in {exists isfile isdirectory size}} {
        set path [import_confined $ip [lindex $args 0]]
        return [file $operation $path]
    }
    import_block $ip "File operation disabled: $operation"
}
proc ::CAEDesigner::import_source {ip args} {
    if {[llength $args] == 1} {set encoding utf-8; set path [lindex $args 0]} elseif {[llength $args] == 3 && [lindex $args 0] eq "-encoding"} {
        set encoding [lindex $args 1]; set path [lindex $args 2]
    } else {import_block $ip "Unsupported source arguments"}
    set path [import_confined $ip $path]
    if {[file extension $path] ne ".tcl" || [file size $path] > 4194304} {import_block $ip "Source must be a bounded local Tcl dependency"}
    if {![dict exists $::CAEDesigner::import_session depdata $path]} {
        if {[dict size [dict get $::CAEDesigner::import_session depdata]] >= 64} {import_block $ip "Maximum 64 Tcl dependencies"}
        set f [open $path rb]; set bytes [read $f]; ::close $f
        dict set ::CAEDesigner::import_session depdata $path $bytes
    }
    dict lappend ::CAEDesigner::import_session dependencies $path
    # Hidden source preserves [info script] and lexical caller scope in the child.
    return [interp invokehidden $ip source -encoding $encoding $path]
}
proc ::CAEDesigner::capture_tcl {path} {
    set sourcepath [file normalize $path]
    if {[file size $path] > 4194304} {error "Tcl file exceeds 4 MB."}
    set f [open $path rb]; set bytes [read $f]; ::close $f
    set source [encoding convertfrom utf-8 $bytes]
    if {[encoding convertto utf-8 $source] ne $bytes} {error "Tcl import currently requires UTF-8 text."}
    set ip [interp create -safe]
    set allowedroot [file dirname $sourcepath]
    # A mapped project's own Tcl libraries are allowed; other projects are not.
    if {[regexp {^(.*\/01_CAE_TOOLS/projects/[^/]+)(/.*)?$} $sourcepath all projectroot]} {set allowedroot $projectroot}
    set ::CAEDesigner::import_session [dict create paths {} constructors {} explicit {} blocked {} bindings {} root "" showproc "" allowedroot $allowedroot dependencies {} depdata {} styles {} menus {} messages {}]
    set code [catch {
        foreach command {after vwait update interp package unknown puts} {catch {interp hide $ip $command}}
        foreach api {toplevel label button entry spinbox frame labelframe checkbutton radiobutton listbox text canvas message scrollbar scale menubutton menu ttk::label ttk::button ttk::entry ttk::frame ttk::labelframe ttk::checkbutton ttk::radiobutton ttk::combobox ttk::spinbox ttk::separator ttk::progressbar ttk::scale ttk::scrollbar ttk::sizegrip ttk::treeview} {
            if {$api eq "ttk::spinbox" && ![llength [info commands ::ttk::spinbox]]} {continue}
            interp alias $ip $api {} ::CAEDesigner::import_constructor $ip $api
        }
        foreach command {pack grid place} {interp alias $ip $command {} ::CAEDesigner::import_geometry $ip $command}
        foreach {command handler} {wm import_wm winfo import_winfo destroy import_destroy package import_package unknown import_unknown bind import_bind file import_file source import_source puts import_puts update import_update hm_info import_hm_info ttk::style import_style} {interp alias $ip $command {} ::CAEDesigner::$handler $ip}
        interp limit $ip command -value 300000
        interp limit $ip time -seconds [expr {[clock seconds]+5}] -milliseconds 0
        import_source $ip $sourcepath
        if {[llength [dict get $::CAEDesigner::import_session blocked]]} {error [join [dict get $::CAEDesigner::import_session blocked] "; "]}
        set root [dict get $::CAEDesigner::import_session root]
        if {$root eq ""} {error "No supported form was constructed. The Tcl file must open one form when loaded."}
        # Traces and a saved patch may change a default after construction.
        dict for {path api} [dict get $::CAEDesigner::import_session constructors] {
            if {![dict exists $::CAEDesigner::import_session explicit $path -textvariable]} {continue}
            set value [import_value $ip [dict get $::CAEDesigner::import_session explicit $path -textvariable]]
            set p [import_map $path]; set type [namespace tail $api]
            if {$type in {entry spinbox combobox}} {
                set state [$p cget -state]; $p configure -state normal
                if {$type eq "combobox"} {$p set $value} else {$p delete 0 end; $p insert 0 $value}
                $p configure -state $state
            } elseif {$type in {label button checkbutton radiobutton labelframe menubutton message}} {$p configure -text $value}
        }
        update idletasks
        set capture [import_map $root]
        lassign [wm minsize $capture] minw minh
        set w [expr {max(100,$minw,[winfo reqwidth $capture])}]; set h [expr {max(100,$minh,[winfo reqheight $capture])}]
        if {[dict exists $::CAEDesigner::import_session windowgeometry]} {regexp {^([0-9]+)x([0-9]+)} [dict get $::CAEDesigner::import_session windowgeometry] ignored w h}
        if {$w > 2000 || $h > 2000} {error "Imported form exceeds 2000 pixels."}
        wm geometry $capture ${w}x${h}+10000+10000
        wm deiconify $capture
        # Windows mapping/configure events must settle before reading child sizes.
        update
        update idletasks
        set w [winfo width $capture]; set h [winfo height $capture]
        set paths [dict create $root root]; set nodes {}; set serial 0; set original {}
        dict for {path api} [dict get $::CAEDesigner::import_session constructors] {
            if {$path eq $root} {continue}
            if {$api eq "menu"} {continue}
            set p [import_map $path]; set type [namespace tail $api]
            if {$type ni $::CAEDesigner::types} {error "Unsupported control type: $api"}
            set parent [string range $path 0 [expr {[string last . $path]-1}]]
            set id w[incr serial]; dict set paths $path $id
            set text ""; catch {set text [$p cget -text]}
            if {$type in {entry spinbox combobox}} {set text [$p get]}
            if {$type eq "text"} {set text [$p get 1.0 end-1c]}
            set values {}; catch {set values [$p cget -values]}
            if {$type eq "listbox"} {set values [$p get 0 end]}
            set options {}
            if {[dict exists $::CAEDesigner::import_session explicit $path]} {
                dict for {key value} [dict get $::CAEDesigner::import_session explicit $path] {
                    if {$key in {-command -variable -textvariable -validatecommand -invalidcommand -postcommand -xscrollcommand -yscrollcommand -menu -image -class -container -text -values}} {continue}
                    dict set options $key $value
                }
            }
            set exportapi $api; if {[string match ttk::* $api]} {set exportapi ::$api}
            set n [dict create type $type text $text values $values x [winfo x $p] y [winfo y $p] width [winfo width $p] height [winfo height $p] parent [dict get $paths $parent] options $options exportapi $exportapi originalpath $path]
            dict set n originalparent [dict get $n parent]
            dict set n source-manager [winfo manager $p]
            set events {}
            foreach event [dict get $::CAEDesigner::import_session bindings] {
                if {[llength $event] >= 3 && [lindex $event 0] eq $path} {lappend events $event}
            }
            dict set n source-bindings $events
            dict set n x [expr {[winfo rootx $p]-[winfo rootx [import_map $parent]]}]
            dict set n y [expr {[winfo rooty $p]-[winfo rooty [import_map $parent]]}]
            if {[dict exists $n options -style]} {dict set n options -style CAEImported.[dict get $n options -style]}
            if {[dict exists $::CAEDesigner::import_session content $path]} {dict set n content [dict get $::CAEDesigner::import_session content $path]}
            foreach key {-textvariable -variable -command} {
                if {[dict exists $::CAEDesigner::import_session explicit $path $key]} {dict set n source$key [dict get $::CAEDesigner::import_session explicit $path $key]}
            }
            if {[string match ttk::* $api]} {dict set n sample_state [$p state]}
            if {[dict exists $::CAEDesigner::import_session checked $path]} {dict set n sample_selected [dict get $::CAEDesigner::import_session checked $path]}
            dict set nodes $id $n; dict set original $path $n
        }
        validate $nodes
        set report [dict create path $sourcepath root $root showproc [dict get $::CAEDesigner::import_session showproc] widgets [dict size $nodes] bindings [llength [dict get $::CAEDesigner::import_session bindings]] dependencies [dict get $::CAEDesigner::import_session dependencies] blocked {} width $w height $h]
        set result [dict create nodes $nodes serial $serial title [wm title $capture] width $w height $h context [dict create path $sourcepath bytes $bytes root $root showproc [dict get $::CAEDesigner::import_session showproc] original $original styles [dict get $::CAEDesigner::import_session styles] dependencies [dict get $::CAEDesigner::import_session dependencies] depdata [dict get $::CAEDesigner::import_session depdata]] report $report]
    } message options]
    set captureRoot [dict get $::CAEDesigner::import_session root]
    if {$captureRoot ne "" && [dict exists $::CAEDesigner::import_session paths $captureRoot]} {
        set owned [import_map $captureRoot]
        catch {destroy $owned}
        # Altair's wrapped Tk controls can retain private command aliases.
        foreach command [info commands ${owned}.*] {catch {rename $command {}}}
    }
    interp delete $ip
    set ::CAEDesigner::import_last_report [dict create result $code message $message blocked [dict get $::CAEDesigner::import_session blocked]]
    if {$code} {return -options $options $message}
    return $result
}
proc ::CAEDesigner::open_tcl {path} {
    # Capture succeeds before replacing any current document.
    set document [capture_tcl $path]
    foreach key {nodes serial title width height} {set ::CAEDesigner::$key [dict get $document $key]}
    set ::CAEDesigner::imported [dict get $document context]
    set ::CAEDesigner::import_last_report [dict get $document report]
    set ::CAEDesigner::undo {}; set ::CAEDesigner::redo {}; set ::CAEDesigner::selected ""; set ::CAEDesigner::dirty 0
    if {[info exists ::CAEDesigner::selection]} {set ::CAEDesigner::selection {}}
    set ::CAEDesigner::form_x 24; set ::CAEDesigner::form_y 24
    if {[winfo exists .cae_designer.center.documents]} {
        .cae_designer.center.documents select .cae_designer.center.documents.design
        .cae_designer.left.pages select .cae_designer.left.pages.objects
        grid .cae_designer.left; grid .cae_designer.right
        grid columnconfigure .cae_designer 0 -minsize 340
        grid columnconfigure .cae_designer 2 -minsize 320
        .cae_designer.center.hint.focusform configure -text "Focus Form"
    }
    render
    fit_form
    set ::CAEDesigner::status "Opened Tcl: [file tail $path] — [dict size $::CAEDesigner::nodes] editable controls. Callbacks preserved; Save Tcl Copy uses fixed positions."
    return $::CAEDesigner::import_last_report
}
proc ::CAEDesigner::factory {p n} {
    if {[dict exists $n originalpath] && [dict get $n type] in {treeview canvas}} {
        set command [list [dict get $n exportapi] $p]
        dict for {key value} [dict get $n options] {lappend command $key $value}
        set code "$command\n"
        if {[dict exists $n content]} {foreach operation [dict get $n content] {append code [list $p {*}$operation] "\n"}}
    } else {set code [import_base_factory $p $n]}
    if {[dict exists $n sample_state] && [string match ::ttk::* [dict get $n exportapi]]} {
        append code [list $p state {!selected !alternate !disabled}] "\n" [list $p state [dict get $n sample_state]] "\n"
    } elseif {[dict exists $n sample_selected] && [dict get $n type] in {checkbutton radiobutton}} {
        set action deselect; if {[dict get $n sample_selected]} {set action select}
        append code [list $p $action] "\n"
    }
    return $code
}
proc ::CAEDesigner::patched_tcl {} {
    if {$::CAEDesigner::imported eq ""} {error "Open a Tcl file first."}
    validate $::CAEDesigner::nodes
    set context $::CAEDesigner::imported; set root [dict get $context root]
    set body [list wm title $root $::CAEDesigner::title]
    append body "\n" [list wm geometry $root ${::CAEDesigner::width}x${::CAEDesigner::height}] "\n"
    if {[dict exists $context styles]} {foreach style [dict get $context styles] {append body $style "\n"}}
    set paths [dict create root $root]; set retained {}
    foreach id [ordered $::CAEDesigner::nodes] {
        set n [dict get $::CAEDesigner::nodes $id]
        if {[dict exists $n originalpath]} {set p [dict get $n originalpath]; lappend retained $p} else {set p [dict get $paths [dict get $n parent]].designer_$id}
        dict set paths $id $p
    }
    dict for {p n} [dict get $context original] {if {$p ni $retained} {append body [list catch [list destroy $p]] "\n"}}
    foreach id [ordered $::CAEDesigner::nodes] {
        set n [dict get $::CAEDesigner::nodes $id]; set p [dict get $paths $id]
        if {![dict exists $n originalpath]} {
            append body [import_base_factory $p $n]
        } else {
            set old [dict get $context original $p]
            if {[dict get $n parent] ne [dict get $old parent]} {error "Imported control $p cannot change its original parent."}
            # Emit only changed options; original actions and variables stay intact.
            set changed {}
            foreach key {text values} {
                if {[dict get $n $key] eq [dict get $old $key]} {continue}
                if {$key eq "text" && [dict exists $old source-textvariable]} {
                    set variable [dict get $old source-textvariable]
                    if {![string match ::* $variable]} {error "Only fully qualified textvariable defaults can be saved: $p"}
                    append body [list set $variable [dict get $n text]] "\n"
                    continue
                }
                if {$key eq "text" && [dict get $n type] in {entry spinbox combobox text}} {
                    switch [dict get $n type] {
                        combobox {append body [list $p set [dict get $n text]] "\n"}
                        text {append body [list $p delete 1.0 end] "\n" [list $p insert 1.0 [dict get $n text]] "\n"}
                        default {append body [list $p delete 0 end] "\n" [list $p insert 0 [dict get $n text]] "\n"}
                    }
                    continue
                }
                if {$key eq "values" && [dict get $n type] eq "listbox"} {append body [list $p delete 0 end] "\n" [list $p insert end {*}[dict get $n values]] "\n"; continue}
                if {$key eq "values" && [dict get $n type] ne "combobox"} {continue}
                lappend changed -$key [dict get $n $key]
            }
            if {[dict exists $n options]} {
                dict for {key value} [dict get $n options] {
                    if {![dict exists $old options $key] || $value ne [dict get $old options $key]} {lappend changed $key $value}
                }
            }
            if {[llength $changed]} {append body [list $p configure {*}$changed] "\n"}
        }
        if {[llength [info commands ::CAEDesigner::style_code]]} {append body [style_code $p $n]}
        append body [list pack forget $p] "\n" [list grid forget $p] "\n"
        append body [list place $p -in [dict get $paths [dict get $n parent]] -x [dict get $n x] -y [dict get $n y] -width [dict get $n width] -height [dict get $n height] -bordermode outside] "\n"
    }
    set patchNamespace ::CAEDesignerSaved[clock clicks]
    set patch "\n# BEGIN CAE DESIGNER UI PATCH — original source above is preserved.\n"
    append patch "# Fixed pixel layout; original application callbacks are retained.\n" [list namespace eval $patchNamespace {}] "\n"
    append patch [list proc ${patchNamespace}::apply {} $body] "\n"
    set showproc [dict get $context showproc]
    if {$showproc ne ""} {
        set originalShow [namespace qualifiers $showproc]::__caeDesignerOriginalShow[clock clicks]
        append patch [list rename $showproc $originalShow] "\n"
        set wrapped "set result \[uplevel 1 \[list $originalShow {*}\$args\]\]\n${patchNamespace}::apply\nreturn \$result"
        append patch [list proc $showproc args $wrapped] "\n"
    }
    append patch "${patchNamespace}::apply\n# END CAE DESIGNER UI PATCH\n"
    return "[dict get $context bytes][encoding convertto utf-8 $patch]"
}
proc ::CAEDesigner::save_tcl_copy {{path ""}} {
    set data [patched_tcl]
    if {$path eq ""} {set path [tk_getSaveFile -parent .cae_designer -initialfile "[file rootname [file tail [dict get $::CAEDesigner::imported path]]]_designed.tcl" -defaultextension .tcl -filetypes {{{Tcl script} {.tcl}}}]}
    if {$path eq ""} {return}
    if {[string equal -nocase [file normalize $path] [dict get $::CAEDesigner::imported path]]} {error "Choose a new Tcl filename. The original file is protected."}
    # Stage dependency destinations before writing anything; never replace them.
    set copies {}; set base [file dirname [dict get $::CAEDesigner::imported path]]
    if {[dict exists $::CAEDesigner::imported depdata]} {
        dict for {dependency bytes} [dict get $::CAEDesigner::imported depdata] {
            if {$dependency eq [dict get $::CAEDesigner::imported path]} {continue}
            if {![string match -nocase "$base/*" $dependency]} {error "This tool uses libraries outside its entry folder. Export requires a project-folder copy."}
            set relative [string range $dependency [expr {[string length $base]+1}] end]
            set destination [file join [file dirname $path] $relative]
            if {[file exists $destination]} {
                set f [open $destination rb]; set existing [read $f]; ::close $f
                if {$existing ne $bytes} {error "Dependency already exists with different content: $destination"}
            } else {dict set copies $destination $bytes}
        }
    }
    dict for {destination bytes} $copies {file mkdir [file dirname $destination]; set f [open $destination wb]; puts -nonewline $f $bytes; ::close $f}
    set f [open $path wb]; puts -nonewline $f $data; ::close $f
    set ::CAEDesigner::dirty 0; set ::CAEDesigner::status "Saved Tcl copy: $path — original callbacks preserved."
    return $path
}
proc ::CAEDesigner::load {{path ""}} {
    if {$path eq ""} {
        if {![discard_ok]} {return}
        set path [tk_getOpenFile -parent .cae_designer -filetypes {{{Tcl / CAE Design} {.tcl .caedesign}} {{Tcl script} {.tcl}} {{CAE Design} {.caedesign}}}]
    }
    if {$path eq ""} {return}
    if {[string equal -nocase [file extension $path] .tcl]} {return [open_tcl $path]}
    set f [open $path r]; fconfigure $f -encoding utf-8; set data [read $f]; ::close $f
    if {[dict exists $data imported]} {
        import_base_load $path
        set ::CAEDesigner::imported [dict get $data imported]
    } else {import_base_load $path; set ::CAEDesigner::imported {}}
}
proc ::CAEDesigner::save {{path ""}} {
    if {$::CAEDesigner::imported eq ""} {return [import_base_save $path]}
    if {$path eq ""} {set path [tk_getSaveFile -parent .cae_designer -defaultextension .caedesign -filetypes {{{CAE Design} {.caedesign}}}]}
    if {$path eq ""} {return}
    validate $::CAEDesigner::nodes
    write_file $path [dict create format CAEDesigner1 title $::CAEDesigner::title width $::CAEDesigner::width height $::CAEDesigner::height nodes $::CAEDesigner::nodes imported $::CAEDesigner::imported]
    set ::CAEDesigner::dirty 0; set ::CAEDesigner::status "Saved editable design: $path"
}
proc ::CAEDesigner::export {} {
    if {$::CAEDesigner::imported ne ""} {return [save_tcl_copy]}
    import_base_export
}
proc ::CAEDesigner::new {} {
    if {![discard_ok]} {return}
    set ::CAEDesigner::dirty 0
    import_base_new
}
proc ::CAEDesigner::sample {} {
    if {![discard_ok]} {return}
    set ::CAEDesigner::dirty 0
    import_base_sample
}
proc ::CAEDesigner::show {} {
    import_base_show
    .cae_designer.top.load configure -text Open -command {::CAEDesigner::safe ::CAEDesigner::load}
    .cae_designer.top.export configure -text "Save Tcl Copy"
    set tabs .cae_designer.right.tabs
    ttk::frame $tabs.source -padding 8
    $tabs add $tabs.source -text Source
    ttk::label $tabs.source.hint -text "Original widget and bindings. Actions are preserved and never run in the Designer." -wraplength 260
    pack $tabs.source.hint -fill x -pady {0 8}
    text $tabs.source.details -width 28 -height 18 -wrap word -state disabled
    pack $tabs.source.details -fill both -expand 1
    properties_refresh
    ttk::button .cae_designer.center.hint.focusform -text "Focus Form" -command ::CAEDesigner::focus_form
    pack .cae_designer.center.hint.focusform -side left -padx {6 0}
}
proc ::CAEDesigner::focus_form {} {
    if {[winfo ismapped .cae_designer.left]} {
        grid remove .cae_designer.left; grid remove .cae_designer.right
        grid columnconfigure .cae_designer 0 -minsize 0; grid columnconfigure .cae_designer 2 -minsize 0
        .cae_designer.center.hint.focusform configure -text "Show Panels"
    } else {
        grid .cae_designer.left; grid .cae_designer.right
        grid columnconfigure .cae_designer 0 -minsize 340; grid columnconfigure .cae_designer 2 -minsize 320
        .cae_designer.center.hint.focusform configure -text "Focus Form"
    }
    fit_form
}
proc ::CAEDesigner::fit_form {} {
    if {![winfo exists .cae_designer.center.canvas]} {return}
    update idletasks
    set c .cae_designer.center.canvas
    # A wide imported form needs the canvas space occupied by the side panels.
    # Keep native control sizes; hide panels rather than scale the form.
    set available [expr {[winfo screenwidth .cae_designer]-40}]
    set required [expr {[winfo width .cae_designer]-[winfo width $c]+$::CAEDesigner::width+$::CAEDesigner::form_x+40}]
    if {$required > $available && [winfo ismapped .cae_designer.left]} {
        grid remove .cae_designer.left; grid remove .cae_designer.right
        grid columnconfigure .cae_designer 0 -minsize 0; grid columnconfigure .cae_designer 2 -minsize 0
        .cae_designer.center.hint.focusform configure -text "Show Panels"
        update idletasks
    }
    # Keep native pixels at 1:1; grow the editor, never shrink the controls.
    set needw [expr {[winfo width .cae_designer]-[winfo width $c]+$::CAEDesigner::width+$::CAEDesigner::form_x+40}]
    set needh [expr {[winfo height .cae_designer]-[winfo height $c]+$::CAEDesigner::height+$::CAEDesigner::form_y+72}]
    set w [expr {min([winfo screenwidth .cae_designer]-40,max(1180,$needw,[winfo width .cae_designer]))}]
    set h [expr {min([winfo screenheight .cae_designer]-100,max(760,$needh,[winfo height .cae_designer]))}]
    wm geometry .cae_designer ${w}x${h}
    $c xview moveto 0; $c yview moveto 0
    update idletasks
}
proc ::CAEDesigner::render {} {
    import_base_render
    set list .cae_designer.left.objectbox.objects
    if {![winfo exists $list]} {return}
    $list delete 0 end
    foreach id $::CAEDesigner::object_ids {
        set n [dict get $::CAEDesigner::nodes $id]; set label "$id | [dict get $n type]"
        if {[dict exists $n originalpath]} {append label " | [file tail [string map {. /} [dict get $n originalpath]]]"}
        $list insert end $label
    }
}
proc ::CAEDesigner::properties_refresh {} {
    import_base_properties_refresh
    set p .cae_designer.right.tabs.source.details
    if {![winfo exists $p]} {return}
    set details "This is a new control.\nApplication callbacks are added in Tcl."
    set id $::CAEDesigner::selected
    if {$id ne "" && [dict exists $::CAEDesigner::nodes $id originalpath]} {
        set n [dict get $::CAEDesigner::nodes $id]
        set details "Widget: [dict get $n originalpath]\nConstructor: [dict get $n exportapi]\n"
        foreach {key caption} {source-textvariable {Text variable} source-variable Variable source-command Callback} {
            if {[dict exists $n $key]} {append details "\n${caption}: [dict get $n $key]\n"}
        }
        append details "\nSave Tcl Copy preserves the original code and applies fixed pixel positions."
    }
    $p configure -state normal; $p delete 1.0 end; $p insert 1.0 $details; $p configure -state disabled
}
