# Explicit macro entry: test suppression must never suppress a user launch.
if {[llength [info commands ::CAEDesigner::show]] && [winfo exists .cae_designer]} {
    wm deiconify .cae_designer
    raise .cae_designer
    return
}
set ::CAE_Designer_LaunchHome [file dirname [info script]]
namespace eval ::CAEDesigner {variable no_autoshow}
set ::CAE_Designer_LaunchHadFlag [info exists ::CAEDesigner::no_autoshow]
if {$::CAE_Designer_LaunchHadFlag} {set ::CAE_Designer_LaunchOldFlag $::CAEDesigner::no_autoshow}
set ::CAEDesigner::no_autoshow 1
set ::CAE_Designer_LaunchCode [catch {
    source -encoding utf-8 [file join $::CAE_Designer_LaunchHome gui_designer.tcl]
    ::CAEDesigner::show
    wm deiconify .cae_designer
    raise .cae_designer
} ::CAE_Designer_LaunchResult]
if {$::CAE_Designer_LaunchHadFlag} {
    set ::CAEDesigner::no_autoshow $::CAE_Designer_LaunchOldFlag
    unset ::CAE_Designer_LaunchOldFlag
} else {unset ::CAEDesigner::no_autoshow}
if {$::CAE_Designer_LaunchCode} {error $::CAE_Designer_LaunchResult}
