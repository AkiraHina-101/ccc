source -encoding utf-8 [file join [file dirname [info script]] .. TK_Gallery runtime_paths.tcl]
# Installed Altair 2022.3 imagery; vendor assets are referenced, not redistributed.
namespace eval ::CAEDesigner {
    variable icon_home [::CAERuntimePaths::hw_root]
    variable icon_sources {}
}
foreach method {show property_pick} {
    catch {rename ::CAEDesigner::icon_base_$method {}}
    rename ::CAEDesigner::$method ::CAEDesigner::icon_base_$method
}
proc ::CAEDesigner::icon {role} {
    set devroles [dict create sample Window preview Preview export Tcl apply Tick color Colorpicker tools Pallet pointer select label Label entry Entry combobox Combobox listbox Listbox checkbutton Checkbutton radiobutton Radiobutton button Button labelframe Labelframe notebook Notebook spinbox Spinbox scrollbar Scrollbar width horizontal height vertical]
    if {[dict exists $devroles $role]} {
        set key [dict get $devroles $role]
        if {![info exists ::hwtk::devtool::_images($key)]} {
            uplevel #0 [list source [file join $::CAEDesigner::icon_home tcl hwtk devtools images.tcl]]
        }
        dict set ::CAEDesigner::icon_sources $role "Altair HWTK DevTools: $key"
        return $::hwtk::devtool::_images($key)
    }
    set name ::CAEDesignerIcon_$role
    if {$name ni [image names]} {
        set files [dict create new {tcl/hwt/images/new16.gif} undo {tcl/hwt/images/undoGeneral-16.gif} redo {tcl/procNexus/plugins/AutomateDebugger/images/redo-24.gif} save {tcl/texteditor/images/fileGeneralSave-16.png} load {tcl/texteditor/images/fileGeneralOpen-16.png} add {images/add-16.png} delete {images/delete-16.png} search {tcl/texteditor/images/searchGeneral-16.png}]
        set path [file join $::CAEDesigner::icon_home [dict get $files $role]]
        image create photo $name -file $path
        dict set ::CAEDesigner::icon_sources $role $path
    }
    return $name
}
proc ::CAEDesigner::icon_apply {widget role {compound left}} {
    if {[winfo exists $widget]} {$widget configure -image [icon $role] -compound $compound}
}
proc ::CAEDesigner::show {} {
    icon_base_show
    # Keep every toolbar action visible at the supported minimum window size.
    set top .cae_designer.top
    foreach child [winfo children $top] {pack forget $child}
    set column 0
    foreach {role caption} {new {New Form} sample Sample undo Undo redo Redo save Save load Open preview Preview export {Export Tcl}} {
        $top.$role configure -text $caption -padding {8 5}
        icon_apply $top.$role $role
        grid $top.$role -row 0 -column $column -sticky ew -padx 3 -pady 2
        incr column
    }
    grid $top.titlelabel -row 0 -column 8 -padx {12 4}
    grid $top.title -row 0 -column 9 -sticky ew
    grid columnconfigure $top 9 -weight 1
    $top.title configure -width 18
    icon_apply .cae_designer.left.actions.add add
    icon_apply .cae_designer.left.actions.full preview
    icon_apply .cae_designer.right.tabs.layout.apply apply
    icon_apply .cae_designer.right.tabs.layout.delete delete
    icon_apply .cae_designer.right.tabs.widget.optionapply apply
    icon_apply .cae_designer.right.tabs.window.apply apply
    icon_apply .cae_designer.center.hint.tools tools
    foreach {role kind} {width width height height} {
        foreach suffix {minus plus} {icon_apply .cae_designer.right.tabs.layout.sizebuttons.$kind$suffix $role}
    }
    set toolbox .cae_designer.toolbox
    set i 0
    foreach type {pointer label entry combobox listbox checkbutton radiobutton button labelframe notebook spinbox scrollbar} {
        $toolbox.t$i configure -padding {8 8} -width 13
        icon_apply $toolbox.t$i $type top
        incr i
    }
    if {![winfo exists $toolbox.credits]} {ttk::button $toolbox.credits -text "About icons" -command ::CAEDesigner::icon_credits}
    grid $toolbox.credits -row 5 -columnspan 3 -sticky ew -padx 6 -pady {0 6}
    property_pick
}
proc ::CAEDesigner::property_pick {} {
    icon_base_property_pick
    icon_apply .cae_designer.right.tabs.widget.choosecolor color
}
proc ::CAEDesigner::icon_credits {} {
    tk_messageBox -parent .cae_designer -type ok -icon info -title "About icons" -message "This Designer references icons from your installed Altair 2022.3.\n\nToolbox: HWTK DevTools control icons.\nToolbar: Altair desktop action icons.\n\nAltair vendor artwork remains in its original installation.\nEditor icons are not included in exported Tcl forms."
}
