# Shared compact workspace. Source navigation never evaluates displayed Tcl.
namespace eval ::CAEDesigner {
    variable connection_rows {}
    variable code_cache ""
    variable property_sections
}
foreach method {show properties_refresh property_pick} {
    catch {rename ::CAEDesigner::workspace_base_$method {}}
    rename ::CAEDesigner::$method ::CAEDesigner::workspace_base_$method
}
proc ::CAEDesigner::section_toggle {name} {
    set ::CAEDesigner::property_sections($name) [expr {!$::CAEDesigner::property_sections($name)}]
    workspace_sections
}
proc ::CAEDesigner::workspace_sections {} {
    set host .cae_designer.right.tabs.compact.viewport.content
    if {![winfo exists $host]} {return}
    foreach {name pane caption} {general layout {General / Position} appearance appearance Appearance advanced widget {Advanced Tk options} window window {Form geometry}} {
        set allowed [expr {$name eq "window" ? $::CAEDesigner::selected eq "" : $::CAEDesigner::selected ne ""}]
        pack forget $host.$name
        pack forget .cae_designer.right.tabs.$pane
        if {!$allowed} {continue}
        pack $host.$name -fill x -pady {3 0}
        set marker +; if {$::CAEDesigner::property_sections($name)} {set marker -}
        $host.$name configure -text "$marker  $caption"
        if {$::CAEDesigner::property_sections($name)} {
            pack .cae_designer.right.tabs.$pane -in $host -fill x -after $host.$name
            raise .cae_designer.right.tabs.$pane
        }
    }
    after idle ::CAEDesigner::workspace_extent
}
proc ::CAEDesigner::workspace_extent {} {
    set c .cae_designer.right.tabs.compact.viewport
    if {[winfo exists $c]} {$c configure -scrollregion [$c bbox all]}
}
proc ::CAEDesigner::show {} {
    workspace_base_show
    if {[winfo exists .cae_designer.toolbox]} {destroy .cae_designer.toolbox}
    pack forget .cae_designer.center.hint.tools
    set menu .cae_designer.menubar.view
    for {set i [$menu index end]} {$i >= 0} {incr i -1} {
        if {[$menu type $i] eq "command" && [$menu entrycget $i -label] eq "Toolbox"} {$menu delete $i}
    }
    set ::CAEDesigner::tool pointer
    set tabs .cae_designer.right.tabs
    if {[winfo exists $tabs.compact]} {return}
    set left .cae_designer.left
    ttk::notebook $left.pages
    foreach page {components objects} {
        ttk::frame $left.pages.$page
        $left.pages add $left.pages.$page -text [string totitle $page]
        grid columnconfigure $left.pages.$page 0 -weight 1
    }
    foreach child {label filters families palettebox actions reference mode objectlabel objectbox} {
        set pane components
        if {$child in {objectlabel objectbox}} {set pane objects}
        set slot [grid info $left.$child]
        dict set slot -in $left.pages.$pane
        if {$pane eq "objects"} {dict set slot -row [expr {$child eq "objectlabel" ? 0 : 1}]}
        eval [list grid $left.$child] $slot
    }
    grid rowconfigure $left.pages.components 3 -weight 1
    grid rowconfigure $left.pages.objects 1 -weight 1
    grid rowconfigure $left 3 -weight 0
    grid rowconfigure $left 8 -weight 0
    grid rowconfigure $left 0 -weight 1
    grid $left.pages -row 0 -column 0 -sticky nsew
    foreach pane [$tabs tabs] {$tabs forget $pane}
    ttk::frame $tabs.compact
    $tabs add $tabs.compact -text Properties
    canvas $tabs.compact.viewport -highlightthickness 0 -width 300 -background #f0f0f0 -yscrollcommand [list $tabs.compact.scroll set]
    ttk::scrollbar $tabs.compact.scroll -command [list $tabs.compact.viewport yview]
    pack $tabs.compact.scroll -side right -fill y
    pack $tabs.compact.viewport -fill both -expand 1
    set host $tabs.compact.viewport.content
    ttk::frame $host
    $tabs.compact.viewport create window 0 0 -window $host -anchor nw -tags content
    bind $tabs.compact.viewport <Configure> [list $tabs.compact.viewport itemconfigure content -width %w]
    bind $host <Configure> ::CAEDesigner::workspace_extent
    foreach name {general appearance advanced window} {
        set ::CAEDesigner::property_sections($name) [expr {$name in {general window}}]
        ttk::button $host.$name -command [list ::CAEDesigner::section_toggle $name]
    }
    set layout $tabs.layout
    foreach item {help sizebuttons apply delete} {pack forget $layout.$item}
    foreach key {text values x y width height} {
        bind $layout.fields.e$key <Return> {::CAEDesigner::safe ::CAEDesigner::apply}
        bind $layout.fields.e$key <FocusOut> {if {$::CAEDesigner::selected ne ""} {::CAEDesigner::safe ::CAEDesigner::apply}}
    }
    $layout.fields.lx configure -text Left
    $layout.fields.ly configure -text Top
    $tabs.widget.optionbox.options configure -height 7
    pack forget $tabs.widget.help $tabs.widget.optionapply
    pack forget $tabs.appearance.help
    foreach key {width height form_x form_y} {
        bind $tabs.window.e$key <FocusOut> {::CAEDesigner::safe ::CAEDesigner::form_apply}
    }
    pack forget $tabs.window.apply
    # Keep stable native widget paths; place the existing canvas into Design.
    set center .cae_designer.center
    ttk::notebook $center.documents
    ttk::frame $center.documents.design
    ttk::frame $center.documents.code
    $center.documents add $center.documents.design -text Design
    $center.documents add $center.documents.code -text Code
    grid $center.documents -row 2 -column 0 -columnspan 2 -sticky nsew
    grid forget $center.canvas $center.x $center.y
    grid $center.canvas -in $center.documents.design -row 0 -column 0 -sticky nsew
    grid $center.y -in $center.documents.design -row 0 -column 1 -sticky ns
    grid $center.x -in $center.documents.design -row 1 -column 0 -sticky ew
    grid columnconfigure $center.documents.design 0 -weight 1
    grid rowconfigure $center.documents.design 0 -weight 1
    set p $center.documents.code
    ttk::label $p.title -text "Original source / generated form · Read only"
    grid $p.title -row 0 -column 0 -columnspan 2 -sticky ew
    text $p.text -font TkFixedFont -wrap none -state disabled -undo 0 -yscrollcommand [list $p.y set] -xscrollcommand [list $p.x set]
    ttk::scrollbar $p.y -command [list $p.text yview]
    ttk::scrollbar $p.x -orient horizontal -command [list $p.text xview]
    grid $p.text -row 1 -column 0 -sticky nsew
    grid $p.y -row 1 -column 1 -sticky ns
    grid $p.x -row 2 -column 0 -sticky ew
    grid columnconfigure $p 0 -weight 1; grid rowconfigure $p 1 -weight 1
    code_style $p.text
    set ::CAEDesigner::code_cache ""
    ttk::labelframe $center.connections -text Connections -padding 4
    listbox $center.connections.list -height 4 -exportselection 0 -yscrollcommand [list $center.connections.y set]
    ttk::scrollbar $center.connections.y -command [list $center.connections.list yview]
    pack $center.connections.y -side right -fill y
    pack $center.connections.list -fill both -expand 1
    grid $center.connections -row 3 -column 0 -columnspan 2 -sticky ew -pady {6 0}
    bind $center.connections.list <Double-Button-1> ::CAEDesigner::connection_open
    bind $center.connections.list <Return> ::CAEDesigner::connection_open
    bind $center.documents <<NotebookTabChanged>> {::CAEDesigner::code_refresh; ::CAEDesigner::workspace_stack}
    bind $left.pages <<NotebookTabChanged>> ::CAEDesigner::workspace_stack
    bind $center.canvas.form.title <ButtonRelease-1> {::CAEDesigner::form_release}
    bind $center.canvas.form.grip <ButtonRelease-1> {::CAEDesigner::form_release}
    properties_refresh
    workspace_stack
}
proc ::CAEDesigner::workspace_stack {} {
    # -in changes the geometry master, not the native parent/stacking order.
    # Legacy siblings must sit above the new notebooks that contain them.
    foreach child {label filters families palettebox actions reference mode objectlabel objectbox} {
        set p .cae_designer.left.$child
        if {[winfo exists $p]} {raise $p}
    }
    foreach child {canvas x y} {
        set p .cae_designer.center.$child
        if {[winfo exists $p]} {raise $p}
    }
}
proc ::CAEDesigner::property_pick {} {
    # Existing typed editors use this button as their pack insertion anchor.
    set anchor .cae_designer.right.tabs.widget.optionapply
    if {[winfo exists $anchor]} {pack $anchor -fill x}
    workspace_base_property_pick
    if {[winfo exists .cae_designer.right.tabs.compact]} {pack forget $anchor}
    set p .cae_designer.right.tabs.widget.optionvalue
    if {[winfo exists $p]} {
        bind $p <<ComboboxSelected>> {::CAEDesigner::safe ::CAEDesigner::property_apply}
        if {[winfo class $p] eq "Spinbox"} {$p configure -command {::CAEDesigner::safe ::CAEDesigner::property_apply}}
    }
}
proc ::CAEDesigner::source_text {} {
    if {[info exists ::CAEDesigner::imported] && $::CAEDesigner::imported ne ""} {
        return [encoding convertfrom utf-8 [dict get $::CAEDesigner::imported bytes]]
    }
    return [generate .cae_form 0]
}
# Literal occurrences are navigation evidence, not semantic data-flow proof.
proc ::CAEDesigner::source_hits {source needle} {
    set result {}; if {$needle eq ""} {return $result}
    set number 0
    foreach line [split $source \n] {
        incr number
        if {[string first $needle $line] >= 0} {lappend result [list $number [string trim $line]]}
        if {[llength $result] >= 50} {break}
    }
    return $result
}
proc ::CAEDesigner::connection_data {source node} {
    set rows {}
    if {[dict exists $node source-manager]} {lappend rows [list "Original layout: [dict get $node source-manager]; Tcl copy uses fixed place geometry." 0]}
    if {[dict exists $node source-bindings]} {
        foreach event [dict get $node source-bindings] {lappend rows [list "Event: [lindex $event 1] -> [lindex $event 2]" 0]}
    }
    if {[dict exists $node originalpath]} {
        set path [dict get $node originalpath]
        foreach hit [source_hits $source $path] {
            lassign $hit line text
            lappend rows [list "Widget reference · line $line: $text" $line]
        }
        if {![llength $rows]} {lappend rows [list "Definition: Unresolved (dynamic widget path)" 0]}
    }
    foreach {key caption} {source-textvariable {Input variable} source-variable {Value variable} source-command Action} {
        if {![dict exists $node $key]} {continue}
        set value [dict get $node $key]
        lappend rows [list "$caption: $value" 0]
        foreach hit [source_hits $source $value] {
            lassign $hit line text
            lappend rows [list "Literal reference · line $line: $text" $line]
        }
        if {$key eq "source-command" && ![catch {llength $value}] && [llength $value]} {
            set command [lindex $value 0]; set number 0
            foreach text [split $source \n] {
                incr number
                if {[regexp {^\s*proc\s+(\S+)} $text -> name] && [string trim $name \{\}] eq $command} {
                    lappend rows [list "Procedure · line $number: $command" $number]
                }
            }
        }
    }
    lappend rows [list "Reads / event flow: Unresolved; references are literal matches." 0]
    return $rows
}
proc ::CAEDesigner::code_refresh {} {
    set p .cae_designer.center.documents.code.text
    if {![winfo exists $p]} {return}
    set source [source_text]
    if {$source ne $::CAEDesigner::code_cache} {
        set ::CAEDesigner::code_cache $source
        $p configure -state normal; $p delete 1.0 end; $p insert 1.0 $source; $p configure -state disabled
        code_highlight $p $source
    }
    set mode "Generated form · Read only"
    if {[info exists ::CAEDesigner::imported] && $::CAEDesigner::imported ne ""} {set mode "Original source · [dict get $::CAEDesigner::imported path] · Read only"}
    .cae_designer.center.documents.code.title configure -text $mode
}
proc ::CAEDesigner::properties_refresh {} {
    workspace_base_properties_refresh
    if {![winfo exists .cae_designer.center.connections.list]} {return}
    workspace_sections
    code_refresh
    set rows [list [list "Form selected. Select a control to inspect its connections." 0]]
    set id $::CAEDesigner::selected
    if {$id ne "" && [dict exists $::CAEDesigner::nodes $id]} {
        set n [dict get $::CAEDesigner::nodes $id]
        if {![dict exists $n originalpath] && (![info exists ::CAEDesigner::imported] || $::CAEDesigner::imported eq "")} {
            set paths [dict create root .cae_form]
            foreach nid [ordered $::CAEDesigner::nodes] {
                dict set paths $nid [dict get $paths [dict get $::CAEDesigner::nodes $nid parent]].$nid
            }
            dict set n originalpath [dict get $paths $id]
        }
        set rows [connection_data $::CAEDesigner::code_cache $n]
    }
    set ::CAEDesigner::connection_rows $rows
    set list .cae_designer.center.connections.list
    $list delete 0 end
    foreach row $rows {$list insert end [lindex $row 0]}
    set p .cae_designer.center.documents.code.text
    $p tag remove linked 1.0 end
    foreach row $rows {set line [lindex $row 1]; if {$line > 0} {$p tag add linked $line.0 "$line.end"}}
}
proc ::CAEDesigner::connection_open {} {
    set index [.cae_designer.center.connections.list curselection]
    if {![llength $index]} {return}
    set line [lindex [lindex $::CAEDesigner::connection_rows [lindex $index 0]] 1]
    if {$line <= 0} {return}
    .cae_designer.center.documents select .cae_designer.center.documents.code
    .cae_designer.center.documents.code.text see $line.0
    focus .cae_designer.center.documents.code.text
}
proc ::CAEDesigner::form_release {} {
    set ::CAEDesigner::form_drag {}
    grid_draw
    properties_refresh
}
proc ::CAEDesigner::form_press {mode X Y} {
    checkpoint
    set ::CAEDesigner::form_drag [list $mode $X $Y $::CAEDesigner::form_x $::CAEDesigner::form_y $::CAEDesigner::width $::CAEDesigner::height]
}
proc ::CAEDesigner::fit_form {} {
    # Preserve navigation/properties. Oversized forms use the canvas scrollbars.
    set c .cae_designer.center.canvas
    if {![winfo exists $c]} {return}
    update idletasks
    $c xview moveto 0; $c yview moveto 0
}
