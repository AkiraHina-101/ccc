# Native Tcl 8.5 designer; the design document is data, never executable Tcl.
namespace eval ::CAEDesigner {
    if {![info exists nodes]} {
    variable nodes {}; variable serial 0; variable selected ""; variable undo {}; variable redo {}
    variable dirty 0; variable status "Browse a component, then drag it onto the form or click Add to Form."
    variable drag {}; variable title "CAE Form"; variable width 760; variable height 500
    }
    variable types {button label entry combobox spinbox checkbutton radiobutton labelframe frame progressbar scale separator}
    variable labels {Button Label Entry Combobox Spinbox Checkbutton Radiobutton Labelframe Frame Progressbar Scale Separator}
    variable props
    # Node-only history from an older module cannot restore source context safely.
    foreach historyName {undo redo} {
        if {[llength [set $historyName]] && ![dict exists [lindex [set $historyName] end] nodes]} {set $historyName {}}
    }
}
proc ::CAEDesigner::document_snapshot {} {
    set snapshot {}
    foreach key {nodes imported title width height form_x form_y} {
        if {[info exists ::CAEDesigner::$key]} {dict set snapshot $key [set ::CAEDesigner::$key]}
    }
    return $snapshot
}
proc ::CAEDesigner::document_restore {snapshot} {
    dict for {key value} $snapshot {set ::CAEDesigner::$key $value}
}
proc ::CAEDesigner::checkpoint {} {
    variable undo; variable redo; variable nodes; variable dirty
    lappend undo [document_snapshot]; if {[llength $undo] > 100} {set undo [lrange $undo end-99 end]}
    set redo {}; set dirty 1
}
proc ::CAEDesigner::history {direction} {
    variable undo; variable redo; variable nodes; variable selected; variable dirty
    if {$direction eq "undo" && [llength $undo]} {
        lappend redo [document_snapshot]; document_restore [lindex $undo end]; set undo [lrange $undo 0 end-1]
    } elseif {$direction eq "redo" && [llength $redo]} {
        lappend undo [document_snapshot]; document_restore [lindex $redo end]; set redo [lrange $redo 0 end-1]
    } else {return}
    set selected ""; set dirty 1; render
}
proc ::CAEDesigner::absolute {id} {
    variable nodes
    set n [dict get $nodes $id]; set x [dict get $n x]; set y [dict get $n y]
    set parent [dict get $n parent]
    if {$parent ne "root"} {lassign [absolute $parent] px py; incr x $px; incr y $py}
    return [list $x $y]
}
proc ::CAEDesigner::validate {data} {
    variable types
    if {[dict size $data] > 200} {error "Maximum 200 components."}
    dict for {id n} $data {
        if {![regexp {^w[0-9]+$} $id]} {error "Invalid component ID."}
        foreach field {type text values x y width height parent} {if {![dict exists $n $field]} {error "Missing property $field."}}
        if {[dict get $n type] ni $types} {error "Unsupported widget type."}
        if {[catch {llength [dict get $n values]}]} {error "Values must be a valid Tcl list (e.g. Steel Aluminum)."}
        foreach key {x y width height} {
            set v [dict get $n $key]
            if {![string is integer -strict $v] || $v < 0 || $v > 2000} {error "$key must be an integer from 0 to 2000."}
        }
        if {[dict exists $n originalpath]} {
            if {[dict get $n width] < 1 || [dict get $n height] < 1} {error "Imported controls must have positive dimensions."}
            if {[dict exists $n originalparent] && [dict get $n parent] ne [dict get $n originalparent]} {error "Imported controls must retain their original parent to preserve Tcl bindings."}
        } elseif {[dict get $n width] < 20 || [dict get $n height] < 10} {error "Minimum size: 20 × 10."}
        set seen [list $id]; set parent [dict get $n parent]
        while {$parent ne "root"} {
            if {$parent in $seen || ![dict exists $data $parent]} {error "Invalid parent or cyclic hierarchy."}
            if {[dict get $data $parent type] ni {frame labelframe}} {error "Parent must be a frame."}
            lappend seen $parent; set parent [dict get $data $parent parent]
        }
    }
    return $data
}
proc ::CAEDesigner::add {type x y {parent root}} {
    variable nodes; variable serial; variable selected
    set w 140; set h 30; set text $type
    switch $type {
        button {set text "Run Mesh"}
        label {set text "Size (mm)"}
        entry {set text "Bracket_A"}
        combobox {set text Steel}
        spinbox {set text 2.5}
        checkbutton {set text "Show labels"}
        radiobutton {set text TRIA3}
        frame - labelframe {set text "Mesh Settings"; set w 300; set h 180}
        progressbar {set w 220; set h 24}
        scale {set w 220}
        separator {set w 240; set h 10}
    }
    incr serial; set id w$serial
    set n [dict create type $type text $text values {Steel Aluminum Titanium} x [expr {max(0,int($x))}] y [expr {max(0,int($y))}] width $w height $h parent $parent]
    set data $nodes; dict set data $id $n; validate $data
    checkpoint; set nodes $data; set selected $id; render; return $id
}
proc ::CAEDesigner::select {id} {
    variable selected; variable nodes; variable props
    set selected $id
    if {$id ne "" && [dict exists $nodes $id]} {
        set n [dict get $nodes $id]
        foreach key {type text values x y width height parent} {set props($key) [dict get $n $key]}
        set props(id) $id
    } else {foreach key {id type text values x y width height parent} {set props($key) ""}}
    if {[winfo exists .cae_designer]} {render_selection}
}
proc ::CAEDesigner::render_selection {} {
    variable selected; variable nodes
    set c .cae_designer.center.canvas; $c delete selection
    if {$selected eq "" || ![dict exists $nodes $selected]} {return}
    set n [dict get $nodes $selected]; lassign [absolute $selected] x y
    set right [expr {$x+[dict get $n width]}]; set bottom [expr {$y+[dict get $n height]}]
    $c create rectangle $x $y $right $bottom -outline #2166a5 -width 2 -tags selection
    $c create rectangle [expr {$right-7}] [expr {$bottom-7}] $right $bottom -fill #2166a5 -tags {selection resize}
}
proc ::CAEDesigner::render {} {
    variable nodes; variable selected; variable width; variable height
    if {![winfo exists .cae_designer]} {return}
    set c .cae_designer.center.canvas; $c delete all
    $c configure -scrollregion [list 0 0 $width $height]
    for {set x 0} {$x <= $width} {incr x 20} {$c create line $x 0 $x $height -fill #edf0f3 -tags grid}
    for {set y 0} {$y <= $height} {incr y 20} {$c create line 0 $y $width $y -fill #edf0f3 -tags grid}
    .cae_designer.left.objectbox.objects delete 0 end
    dict for {id n} $nodes {
        set type [dict get $n type]; lassign [absolute $id] x y
        set w [dict get $n width]; set h [dict get $n height]
        set fill #f2f3f4; if {$type in {frame labelframe}} {set fill ""}
        $c create rectangle $x $y [expr {$x+$w}] [expr {$y+$h}] -fill $fill -outline #88939e -tags [list object $id]
        set text [dict get $n text]
        switch $type {
            combobox {append text "  ▾"}
            checkbutton {set text "☐ $text"}
            radiobutton {set text "○ $text"}
            progressbar {set text "████░░ 65%"}
            scale {set text "────●────"}
            separator {set text "────────────────"}
        }
        $c create text [expr {$x+8}] [expr {$y+min($h/2,15)}] -anchor w -width [expr {max(10,$w-16)}] -text $text -tags [list object $id]
        .cae_designer.left.objectbox.objects insert end "$id — $type"
    }
    select $selected
}
proc ::CAEDesigner::pick {x y} {
    set c .cae_designer.center.canvas
    set items [$c find overlapping $x $y $x $y]
    foreach item [lreverse $items] {
        foreach tag [$c gettags $item] {if {[regexp {^w[0-9]+$} $tag]} {return $tag}}
    }
    return ""
}
proc ::CAEDesigner::press {x y} {
    variable selected; variable drag; variable nodes
    set c .cae_designer.center.canvas; set x [$c canvasx $x]; set y [$c canvasy $y]
    if {$selected ne "" && [dict exists $nodes $selected]} {
        set n [dict get $nodes $selected]; lassign [absolute $selected] ax ay
        set rx [expr {$ax+[dict get $n width]}]; set ry [expr {$ay+[dict get $n height]}]
        if {abs($x-$rx) <= 8 && abs($y-$ry) <= 8} {checkpoint; set drag [list resize $x $y $n]; return}
    }
    set id [pick $x $y]; select $id
    if {$id ne ""} {checkpoint; set drag [list move $x $y [dict get $nodes $id]]} else {set drag {}}
}
proc ::CAEDesigner::motion {x y} {
    variable selected; variable drag; variable nodes
    if {![llength $drag] || $selected eq ""} {return}
    lassign $drag mode sx sy n
    set c .cae_designer.center.canvas
    set dx [expr {int([$c canvasx $x]-$sx)}]; set dy [expr {int([$c canvasy $y]-$sy)}]
    if {$mode eq "move"} {
        dict set n x [expr {max(0,min(2000,[dict get $n x]+$dx))}]
        dict set n y [expr {max(0,min(2000,[dict get $n y]+$dy))}]
    } else {
        dict set n width [expr {max(20,min(2000,[dict get $n width]+$dx))}]
        dict set n height [expr {max(10,min(2000,[dict get $n height]+$dy))}]
    }
    dict set nodes $selected $n; render
}
proc ::CAEDesigner::apply {} {
    variable selected; variable props; variable nodes
    if {$selected eq ""} {return}
    set n [dict get $nodes $selected]
    if {[dict exists $n originalpath] && $props(parent) ne [dict get $n parent]} {
        set props(parent) [dict get $n parent]
        set ::CAEDesigner::status "Imported controls keep their original parent. Edit position and size within that parent."
        return
    }
    foreach key {text values x y width height parent} {dict set n $key $props($key)}
    if {$n eq [dict get $nodes $selected]} {return}
    set data $nodes; dict set data $selected $n
    if {[catch {validate $data} result]} {set ::CAEDesigner::status $result; return}
    checkpoint; set nodes $data; render; set ::CAEDesigner::status "Properties applied."
}
proc ::CAEDesigner::remove {} {
    variable nodes; variable selected
    if {$selected eq ""} {return}
    checkpoint; set ids [list $selected]
    for {set i 0} {$i < [llength $ids]} {incr i} {
        dict for {id n} $nodes {if {[dict get $n parent] eq [lindex $ids $i]} {lappend ids $id}}
    }
    foreach id $ids {dict unset nodes $id}; set selected ""; render
}
proc ::CAEDesigner::palette_add {{x 30} {y 30}} {
    set chosen [.cae_designer.left.palettebox.palette curselection]
    if {![llength $chosen]} {set ::CAEDesigner::status "Select a component in the browser first."; return}
    add [lindex $::CAEDesigner::types [lindex $chosen 0]] $x $y
}
proc ::CAEDesigner::palette_drop {X Y} {
    set c .cae_designer.center.canvas
    if {$X < [winfo rootx $c] || $Y < [winfo rooty $c] || $X > [winfo rootx $c]+[winfo width $c] || $Y > [winfo rooty $c]+[winfo height $c]} {return}
    palette_add [$c canvasx [expr {$X-[winfo rootx $c]}]] [$c canvasy [expr {$Y-[winfo rooty $c]}]]
}
proc ::CAEDesigner::ordered {data {parent root}} {
    set ids {}
    dict for {id n} $data {
        if {[dict get $n parent] eq $parent} {lappend ids $id; set ids [concat $ids [ordered $data $id]]}
    }
    return $ids
}
proc ::CAEDesigner::generate {{window .cae_generated}} {
    variable nodes; variable title; variable width; variable height
    validate $nodes
    foreach v [list $width $height] {if {![string is integer -strict $v] || $v < 100 || $v > 2000} {error "Form size must be between 100 and 2000 pixels."}}
    set code "# Generated by CAE Tk Designer. Add CAE callbacks separately.\npackage require Tk\n"
    append code [list catch [list destroy $window]] "\n" [list toplevel $window] "\n"
    append code [list wm title $window $title] "\n" [list wm geometry $window ${width}x${height}] "\n"
    set paths [dict create root $window]
    foreach id [ordered $nodes] {
        set n [dict get $nodes $id]; set type [dict get $n type]
        set p [dict get $paths [dict get $n parent]].$id; dict set paths $id $p
        set command [list ::ttk::$type $p]
        if {$type eq "spinbox"} {set command [list spinbox $p]}
        switch $type {
            button - label - checkbutton - radiobutton - labelframe {lappend command -text [dict get $n text]}
            combobox {lappend command -values [dict get $n values] -state readonly}
            spinbox {lappend command -from 0 -to 1000 -increment 0.5}
            progressbar {lappend command -value 65}
            scale {lappend command -from 0 -to 100 -orient horizontal}
        }
        if {$type eq "radiobutton"} {lappend command -variable ${window}_radio -value $id}
        append code $command "\n"
        if {$type in {entry spinbox}} {append code [list $p delete 0 end] "\n" [list $p insert 0 [dict get $n text]] "\n"}
        if {$type eq "combobox"} {append code [list $p set [dict get $n text]] "\n"}
        append code [list place $p -x [dict get $n x] -y [dict get $n y] -width [dict get $n width] -height [dict get $n height]] "\n"
    }
    return $code
}
proc ::CAEDesigner::preview {} {
    if {[catch {uplevel #0 [generate .cae_designer_preview]} result]} {set ::CAEDesigner::status "Preview error: $result"}
}
proc ::CAEDesigner::write_file {path content} {
    set f [open $path w]; fconfigure $f -encoding utf-8; puts $f $content; ::close $f
}
proc ::CAEDesigner::save {{path ""}} {
    if {$path eq ""} {set path [tk_getSaveFile -parent .cae_designer -defaultextension .caedesign -filetypes {{{CAE Design} {.caedesign}}}]}
    if {$path eq ""} {return}
    validate $::CAEDesigner::nodes
    form_apply
    write_file $path [dict create format CAEDesigner1 title $::CAEDesigner::title width $::CAEDesigner::width height $::CAEDesigner::height nodes $::CAEDesigner::nodes]
    set ::CAEDesigner::dirty 0; set ::CAEDesigner::status "Saved: $path"
}
proc ::CAEDesigner::load {{path ""}} {
    if {$path eq ""} {if {![discard_ok]} {return}; set path [tk_getOpenFile -parent .cae_designer -filetypes {{{CAE Design} {.caedesign}}}]}
    if {$path eq ""} {return}
    if {[file size $path] > 1048576} {error "Design file exceeds 1 MB."}
    set f [open $path r]; fconfigure $f -encoding utf-8; set data [read $f]; ::close $f
    if {[dict get $data format] ne "CAEDesigner1"} {error "Unsupported design file format."}
    set ns [dict get $data nodes]
    if {[dict exists $data imported original]} {
        dict for {id n} $ns {
            if {[dict exists $n originalpath] && [dict exists $data imported original [dict get $n originalpath]]} {
                dict set ns $id originalparent [dict get $data imported original [dict get $n originalpath] parent]
            }
        }
    }
    validate $ns
    foreach key {width height} {set v [dict get $data $key]; if {![string is integer -strict $v] || $v < 100 || $v > 2000} {error "Invalid form dimensions."}}
    checkpoint; set ::CAEDesigner::nodes $ns
    set ::CAEDesigner::imported {}
    if {[dict exists $data imported]} {set ::CAEDesigner::imported [dict get $data imported]}
    foreach key {title width height} {set ::CAEDesigner::$key [dict get $data $key]}
    dict for {id n} $ns {set ::CAEDesigner::serial [expr {max($::CAEDesigner::serial,[string range $id 1 end])}]}
    set ::CAEDesigner::selected ""; set ::CAEDesigner::dirty 0; render
}
proc ::CAEDesigner::export {} {
    set path [tk_getSaveFile -parent .cae_designer -defaultextension .tcl -filetypes {{{Tcl script} {.tcl}}}]
    if {$path ne ""} {write_file $path [generate]; set ::CAEDesigner::status "Tcl exported: $path"}
}
proc ::CAEDesigner::discard_ok {} {
    if {!$::CAEDesigner::dirty} {return 1}
    return [expr {[tk_messageBox -parent .cae_designer -type yesno -icon question -message "Unsaved design. Discard changes?"] eq "yes"}]
}
proc ::CAEDesigner::close {} {
    if {![discard_ok]} {return}
    catch {destroy .cae_designer_preview}; destroy .cae_designer
}
proc ::CAEDesigner::safe {command} {if {[catch {uplevel #0 $command} result]} {set ::CAEDesigner::status "Error: $result"}}
proc ::CAEDesigner::object_select {} {
    set index [.cae_designer.left.objectbox.objects curselection]
    if {[llength $index]} {select [lindex [dict keys $::CAEDesigner::nodes] [lindex $index 0]]}
}
proc ::CAEDesigner::new {} {
    if {![discard_ok]} {return}
    checkpoint; set ::CAEDesigner::imported {}; set ::CAEDesigner::nodes {}; set ::CAEDesigner::selected ""; render
}
proc ::CAEDesigner::sample {} {
    if {![discard_ok]} {return}
    checkpoint; set ::CAEDesigner::imported {}; set ::CAEDesigner::nodes {}; set ::CAEDesigner::selected ""
    set group [add labelframe 20 20]
    dict set ::CAEDesigner::nodes $group width 420
    set label [add label 15 35 $group]
    add spinbox 175 35 $group
    set material [add label 15 80 $group]; dict set ::CAEDesigner::nodes $material text "Material"
    add combobox 175 80 $group
    add checkbutton 15 125 $group
    add button 20 220
    add progressbar 185 223
    render
}
proc ::CAEDesigner::show {} {
    package require Tk
    if {[llength [info commands hm_info]] && ![string match "2022.3.*" [hm_info -appinfo DISPLAYVERSION]]} {error "Designer requires HyperMesh 2022.3."}
    if {[winfo exists .cae_designer]} {raise .cae_designer; return}
    toplevel .cae_designer; wm title .cae_designer "CAE Tk Designer — Drag and Drop Designer"
    wm geometry .cae_designer 1200x800; wm minsize .cae_designer 1000 650
    wm protocol .cae_designer WM_DELETE_WINDOW ::CAEDesigner::close
    ttk::frame .cae_designer.top -padding 8; pack .cae_designer.top -fill x
    foreach {id label command} {new {New Form} new sample {CAE Sample} sample undo Undo {history undo} redo Redo {history redo} save {Save Design} save load {Open Design} load preview {Preview} preview export {Export Tcl} export} {
        ttk::button .cae_designer.top.$id -text $label -command [list ::CAEDesigner::safe "::CAEDesigner::$command"]
        pack .cae_designer.top.$id -side left -padx 4
    }
    ttk::label .cae_designer.top.titlelabel -text "Form title:"; ttk::entry .cae_designer.top.title -textvariable ::CAEDesigner::title -width 22
    pack .cae_designer.top.titlelabel .cae_designer.top.title -side left -padx 4
    bind .cae_designer.top.title <KeyRelease> {set ::CAEDesigner::dirty 1}
    ttk::label .cae_designer.status -textvariable ::CAEDesigner::status -padding 8 -wraplength 1150
    pack .cae_designer.status -side bottom -fill x
    foreach side {left right center} {ttk::frame .cae_designer.$side -padding 8}
    pack .cae_designer.left -side left -fill y; pack .cae_designer.right -side right -fill y; pack .cae_designer.center -fill both -expand 1
    ttk::label .cae_designer.left.label -text "Widget Tk/Ttk"; pack .cae_designer.left.label -anchor w
    listbox .cae_designer.left.palettebox.palette -height 12 -width 22 -exportselection 0
    foreach label $::CAEDesigner::labels {.cae_designer.left.palettebox.palette insert end $label}
    pack .cae_designer.left.palettebox.palette -fill x -pady 6
    ttk::button .cae_designer.left.add -text "Add to Form" -command {::CAEDesigner::safe ::CAEDesigner::palette_add}; pack .cae_designer.left.add -fill x
    bind .cae_designer.left.palettebox.palette <Double-Button-1> {::CAEDesigner::safe ::CAEDesigner::palette_add}
    bind .cae_designer.left.palettebox.palette <ButtonRelease-1> {::CAEDesigner::safe [list ::CAEDesigner::palette_drop %X %Y]}
    ttk::label .cae_designer.left.objectlabel -text "Objects"; pack .cae_designer.left.objectlabel -anchor w -pady {14 4}
    listbox .cae_designer.left.objectbox.objects -height 8 -width 22 -exportselection 0 -yscrollcommand {.cae_designer.left.scroll set}
    ttk::scrollbar .cae_designer.left.scroll -command {.cae_designer.left.objectbox.objects yview}
    pack .cae_designer.left.scroll -side right -fill y; pack .cae_designer.left.objectbox.objects -fill both -expand 1
    bind .cae_designer.left.objectbox.objects <<ListboxSelect>> ::CAEDesigner::object_select
    ttk::label .cae_designer.center.hint -text "Live form • Drag components to move • Drag blue handle to resize\nParent: enter a frame ID (e.g. w1), or root" -wraplength 650
    pack .cae_designer.center.hint -anchor w -pady 5
    canvas .cae_designer.center.canvas -background white -highlightthickness 1 -takefocus 1 -xscrollcommand {.cae_designer.center.x set} -yscrollcommand {.cae_designer.center.y set}
    ttk::scrollbar .cae_designer.center.x -orient horizontal -command {.cae_designer.center.canvas xview}
    ttk::scrollbar .cae_designer.center.y -command {.cae_designer.center.canvas yview}
    pack .cae_designer.center.x -side bottom -fill x; pack .cae_designer.center.y -side right -fill y; pack .cae_designer.center.canvas -fill both -expand 1
    bind .cae_designer.center.canvas <Button-1> {::CAEDesigner::press %x %y}
    bind .cae_designer.center.canvas <B1-Motion> {::CAEDesigner::motion %x %y}
    bind .cae_designer.center.canvas <ButtonRelease-1> {set ::CAEDesigner::drag {}}
    bind .cae_designer.center.canvas <Delete> ::CAEDesigner::remove
    bind .cae_designer.center.canvas <Double-Button-1> {::CAEDesigner::palette_add %x %y}
    ttk::label .cae_designer.right.label -text "Properties"; pack .cae_designer.right.label -anchor w
    ttk::frame .cae_designer.right.fields; pack .cae_designer.right.fields -fill x -pady 6
    set row 0
    foreach {key label} {id ID type {API type} text {Text / Value} values {Values (Tcl list)} parent {Parent (ID / root)} x X y Y width {Width (px)} height {Height (px)}} {
        ttk::label .cae_designer.right.fields.l$key -text $label
        ttk::entry .cae_designer.right.fields.e$key -textvariable ::CAEDesigner::props($key) -width 16
        if {$key in {id type}} {.cae_designer.right.fields.e$key configure -state readonly}
        grid .cae_designer.right.fields.l$key -row $row -column 0 -sticky w -pady 3 -padx {0 6}
        grid .cae_designer.right.fields.e$key -row $row -column 1 -sticky ew -pady 3
        incr row
    }
    ttk::button .cae_designer.right.apply -text "Apply Properties" -command ::CAEDesigner::apply
    ttk::button .cae_designer.right.delete -text "Delete Component / Group" -command ::CAEDesigner::remove
    pack .cae_designer.right.apply .cae_designer.right.delete -fill x -pady 6
    ttk::label .cae_designer.right.help -text "X/Y are relative to the parent.\nDeleting a frame deletes its children.\nAdd CAE callbacks after export." -wraplength 200
    pack .cae_designer.right.help -anchor w -pady 8
    foreach {key label} {width {Form width (100–2000 px)} height {Form height (100–2000 px)}} {
        ttk::label .cae_designer.right.forml$key -text $label
        ttk::entry .cae_designer.right.form$key -textvariable ::CAEDesigner::$key -width 12
        pack .cae_designer.right.forml$key .cae_designer.right.form$key -anchor w -pady 2
        bind .cae_designer.right.form$key <KeyRelease> {set ::CAEDesigner::dirty 1}
    }
    ttk::button .cae_designer.right.formapply -text "Apply Form Size" -command {::CAEDesigner::safe ::CAEDesigner::form_apply}
    pack .cae_designer.right.formapply -anchor w -pady 4
    render
}
proc ::CAEDesigner::form_apply {} {
    foreach v [list $::CAEDesigner::width $::CAEDesigner::height] {if {![string is integer -strict $v] || $v < 100 || $v > 2000} {error "Form size must be between 100 and 2000 pixels."}}
    render
}
