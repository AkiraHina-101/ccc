# Designer v2: full gallery browser, shared live/export factory, independent Properties.
namespace eval ::CAEDesigner {
    variable home [file dirname [info script]]
    variable query ""; variable family All; variable catalog_rows {}; variable browser_rows {}
    variable form_x 30; variable form_y 30; variable form_drag {}; variable option_name ""; variable option_value ""
    variable paths {}; variable preview_status "Browse a component to see its preview."
    variable types {button label entry combobox spinbox checkbutton radiobutton labelframe frame progressbar scale separator canvas text listbox treeview notebook panedwindow menubutton scrollbar message sizegrip}
}
# Reuse gallery functions in an isolated namespace/path adapter. No gallery window is opened.
proc ::CAEDesigner::load_catalog {} {
    variable home; variable catalog_rows
    set old 0; if {[info exists ::CAEGallery::no_autoshow]} {set old $::CAEGallery::no_autoshow}
    namespace eval ::CAEGallery {variable no_autoshow 1}
    if {![llength [info commands ::CAEGallery::catalog]]} {source [file join $home .. TK_Gallery gui_gallery.tcl]}
    set ::CAEGallery::no_autoshow $old
    set catalog_rows [::CAEGallery::catalog]
    namespace eval ::CAEDesignerReference {variable base [::CAERuntimePaths::tcl_root]; variable serial 0; variable shown {}; variable status ""}
    foreach command [info procs ::CAEGallery::*] {
        set name [namespace tail $command]
        if {$name in {show close filter clear explain_vi}} {continue}
        set args {}
        foreach arg [info args $command] {
            if {[info default $command $arg default]} {lappend args [list $arg $default]} else {lappend args $arg}
        }
        set body [string map {::CAEGallery ::CAEDesignerReference .cae_gallery .cae_designer.left.reference} [info body $command]]
        proc ::CAEDesignerReference::$name $args $body
    }
    proc ::CAEDesignerReference::note {text} {
        set ::CAEDesigner::preview_status "$::CAEDesignerReference::preview_mode"
        .cae_designer.left.reference.right.options configure -state normal
        .cae_designer.left.reference.right.options delete 1.0 end
        .cae_designer.left.reference.right.options insert end $text
        .cae_designer.left.reference.right.options configure -state disabled
    }
    proc ::CAEDesignerReference::menu_pick {button label} {
        if {$button ne "" && [winfo exists $button]} {$button configure -text "$label  \u25be"}
        set ::CAEDesigner::preview_status "Demo selection: $label"
    }
    proc ::CAEDesignerReference::menu_items {path family {button ""}} {
        set i 0
        foreach label {{Inspect Component} {Check Mesh Quality} {Export Report} {Mesh Settings}} {
            set cmd [list ::CAEDesignerReference::menu_pick $button $label]
            if {$family eq "HWTK"} {$path item action[incr i] -caption $label -command $cmd} else {$path add command -label $label -command $cmd}
        }
    }
    # Primary button already demonstrates its native constructor; variants live in Gallery.
    proc ::CAEDesignerReference::button_variants {p} {}
}
proc ::CAEDesigner::adapter {row} {
    lassign $row family api desc; set tail [string tolower [namespace tail $api]]
    set type frame; set mode "Functional adapter (Tk/Ttk)"
    if {$family in {Tk Ttk} && $tail in $::CAEDesigner::types} {set type $tail; set mode Native}
    if {$mode ne "Native"} {
        foreach {pattern target} {
            {labelframe|groupbox} labelframe {notebook|tabcontrol|widgettour} notebook
            {tree|table|grid|propertysheet|selectlist} treeview {menu} menubutton
            {check|radio|bool|statebutton} checkbutton {progress} progressbar
            {combo} combobox {entry|spin|real|^str$|file|choose} entry
            {button} button {list|iconbox} listbox {log|text|message|document|html} text
            {clock|calendar|canvas|image|icon|thumbnail} canvas {scale|slider} scale
            {pane|split} panedwindow {label|status|tooltip} label
        } {if {[regexp $pattern $tail]} {set type $target; break}}
    }
    set constructor ::ttk::$type
    if {$type in {canvas text listbox message spinbox}} {set constructor $type}
    if {$family eq "Tk" && $mode eq "Native"} {set constructor $type}
    if {$type eq "spinbox"} {set constructor spinbox; if {$family ne "Tk"} {set mode "Tk spinbox adapter (Tk 8.5)"}}
    return [list $type $constructor $mode]
}
proc ::CAEDesigner::browse_filter {} {
    variable browser_rows; variable catalog_rows; variable query; variable family
    set browser_rows {}; .cae_designer.left.palettebox.palette delete 0 end
    foreach row $catalog_rows {
        lassign $row f api desc
        if {$family ne "All" && $family ne $f} {continue}
        if {$query ne "" && [string first [string tolower $query] [string tolower "$f $api $desc"]] < 0} {continue}
        lappend browser_rows $row; .cae_designer.left.palettebox.palette insert end "$f | $api"
    }
    set ::CAEDesigner::preview_status "[llength $browser_rows] / [llength $catalog_rows] components"
    set ::CAEDesigner::result_count "[llength $browser_rows] / [llength $catalog_rows]"
    if {[llength $browser_rows]} {.cae_designer.left.palettebox.palette selection set 0; browse_preview} else {
        ::CAEDesignerReference::resetpreview
        set ::CAEDesigner::preview_status "No matches. Clear the search or choose All families."
    }
}
proc ::CAEDesigner::english_preview {p} {
    foreach w [winfo children $p] {english_preview $w}
    if {![catch {$p cget -text} text]} {
        set text [string map {{Chọn thao tác} {Choose Action} {Bấm mũi tên để xổ menu; chọn mục để đổi tên nút.} {Click the arrow and choose an action.} {Các kiểu nút} {Button variants}} $text]
        catch {$p configure -text $text}
    }
}
proc ::CAEDesigner::browse_preview {} {
    variable browser_rows
    set index [.cae_designer.left.palettebox.palette curselection]; if {![llength $index]} {return}
    set row [lindex $browser_rows [lindex $index 0]]
    set ::CAEDesignerReference::shown [list $row]
    .cae_designer.left.reference.left.list delete 0 end
    .cae_designer.left.reference.left.list insert end [lindex $row 1]
    .cae_designer.left.reference.left.list selection set 0
    if {[catch {::CAEDesignerReference::preview} result]} {set ::CAEDesigner::preview_status "Preview failed: $result"}
    english_preview .cae_designer.left.reference.right.sample
    lassign [adapter $row] type constructor mode
    set ::CAEDesigner::preview_status "Source: [lindex $row 1]\nExport: $constructor — $mode"
}
proc ::CAEDesigner::palette_add {{x 30} {y 30}} {
    set index [.cae_designer.left.palettebox.palette curselection]
    if {![llength $index]} {set ::CAEDesigner::status "Select a component first."; return}
    set row [lindex $::CAEDesigner::browser_rows [lindex $index 0]]
    lassign [adapter $row] type constructor mode
    set id [add $type $x $y]
    dict set ::CAEDesigner::nodes $id sourceapi [lindex $row 1]
    dict set ::CAEDesigner::nodes $id exportapi $constructor
    dict set ::CAEDesigner::nodes $id options {}
    if {$type in {canvas text listbox treeview notebook panedwindow}} {
        dict set ::CAEDesigner::nodes $id width 300
        dict set ::CAEDesigner::nodes $id height 160
    }
    render; set ::CAEDesigner::status "Added [lindex $row 1] — export uses $constructor ($mode)."
}
# New factory is the single source for live stage, detached preview and exported Tcl.
proc ::CAEDesigner::factory {p n} {
    set type [dict get $n type]; set text [dict get $n text]
    set api ::ttk::$type
    if {$type in {canvas text listbox message spinbox}} {set api $type}
    if {[dict exists $n exportapi]} {set api [dict get $n exportapi]}
    set allowed [list ::ttk::$type $type]
    if {$api ni $allowed} {error "Invalid export constructor: $api"}
    set cmd [list $api $p]
    switch $type {
        button - label - checkbutton - radiobutton - labelframe - menubutton - message {lappend cmd -text $text}
        combobox {lappend cmd -values [dict get $n values] -state readonly}
        spinbox {lappend cmd -from 0 -to 1000 -increment 0.5}
        progressbar {lappend cmd -value 65}
        scale {lappend cmd -from 0 -to 100 -orient horizontal}
        scrollbar {lappend cmd -orient horizontal}
    }
    if {[dict exists $n options]} {
        dict for {key value} [dict get $n options] {
            if {![regexp {^-[a-zA-Z]+$} $key] || $key in {-command -variable -textvariable -validatecommand -invalidcommand -postcommand -xscrollcommand -yscrollcommand -menu -image -class -container}} {error "Unsupported external/action property: $key"}
            lappend cmd $key $value
        }
    }
    set code "$cmd\n"
    switch $type {
        entry - spinbox {append code [list $p delete 0 end] "\n" [list $p insert 0 $text] "\n"}
        combobox {append code [list $p set $text] "\n"}
        text {append code [list $p insert end $text] "\n"}
        listbox {append code [list $p insert end {*}[dict get $n values]] "\n"}
        notebook {
            foreach {tab title} {one Mesh two Results} {
                append code [list ttk::frame $p.$tab] "\n" [list $p add $p.$tab -text $title] "\n"
                append code [list ttk::label $p.$tab.label -text "$title — demo content"] "\n" [list pack $p.$tab.label -padx 12 -pady 12] "\n"
            }
        }
        treeview {
            append code [list $p configure -columns {id value} -show {tree headings}] "\n"
            foreach {column title} {#0 Component id ID value Value} {append code [list $p heading $column -text $title] "\n"}
            append code [list $p insert {} end -text Bracket_A -values {101 2.5}] "\n" [list $p insert {} end -text Cover_B -values {102 4.0}] "\n"
        }
        canvas {append code [list $p create rectangle 10 10 100 50 -fill #dde9f2 -outline #345a76] "\n" [list $p create text 55 30 -text Demo] "\n"}
        panedwindow {
            foreach part {a b} {append code [list ttk::frame $p.$part] "\n" [list $p add $p.$part] "\n" [list ttk::label $p.$part.label -text "Pane $part"] "\n" [list pack $p.$part.label -padx 8 -pady 8] "\n"}
        }
        menubutton {
            append code [list menu $p.dropdown -tearoff 0] "\n"
            foreach label {Inspect MeshQuality ExportReport} {append code [list $p.dropdown add command -label $label] "\n"}
            append code [list $p configure -menu $p.dropdown] "\n"
        }
        scrollbar {append code [list $p set 0.2 0.65] "\n"}
    }
    return $code
}
proc ::CAEDesigner::generate {{window .cae_generated} {embedded 0}} {
    variable nodes; variable title; variable width; variable height
    validate $nodes
    foreach value [list $width $height] {if {![string is integer -strict $value] || $value < 100 || $value > 2000} {error "Form size must be 100–2000 pixels."}}
    set code "# CAE Designer export. Add application callbacks separately.\npackage require Tk\n"
    append code [list catch [list destroy $window]] "\n"
    if {$embedded} {append code [list ttk::frame $window -width $width -height $height] "\n"} else {
        append code [list toplevel $window] "\n" [list wm title $window $title] "\n" [list wm geometry $window ${width}x${height}] "\n"
    }
    set paths [dict create root $window]
    foreach id [ordered $nodes] {
        set n [dict get $nodes $id]; set p [dict get $paths [dict get $n parent]].$id; dict set paths $id $p
        append code [factory $p $n]
        set placement [list place $p -x [dict get $n x] -y [dict get $n y] -width [dict get $n width] -height [dict get $n height]]
        if {[dict exists $n originalpath]} {lappend placement -bordermode outside}
        append code $placement "\n"
    }
    return $code
}
proc ::CAEDesigner::widget_bind {p id} {
    bindtags $p [list $p .cae_designer all]
    bind $p <Button-1> [list ::CAEDesigner::node_press $id %X %Y]
    bind $p <B1-Motion> {::CAEDesigner::node_motion %X %Y}
    bind $p <ButtonRelease-1> {set ::CAEDesigner::drag {}}
    foreach child [winfo children $p] {widget_bind $child $id}
}
proc ::CAEDesigner::node_press {id X Y} {
    select $id; checkpoint
    set ::CAEDesigner::drag [list native $X $Y [dict get $::CAEDesigner::nodes $id]]
}
proc ::CAEDesigner::node_motion {X Y} {
    if {![llength $::CAEDesigner::drag]} {return}
    lassign $::CAEDesigner::drag mode sx sy n
    dict set n x [expr {max(0,min(2000,[dict get $n x]+$X-$sx))}]
    dict set n y [expr {max(0,min(2000,[dict get $n y]+$Y-$sy))}]
    dict set ::CAEDesigner::nodes $::CAEDesigner::selected $n
    # Update geometry without destroying the widget holding the pointer grab.
    set p [dict get $::CAEDesigner::paths $::CAEDesigner::selected]
    place configure $p -x [dict get $n x] -y [dict get $n y]
    select $::CAEDesigner::selected
}
proc ::CAEDesigner::render {} {
    if {![winfo exists .cae_designer.center.canvas]} {return}
    set c .cae_designer.center.canvas
    if {![winfo exists $c.form]} {return}
    set code [generate $c.form.body 1]
    uplevel #0 $code
    place $c.form.body -x 1 -y 31 -width $::CAEDesigner::width -height $::CAEDesigner::height
    $c.form.title configure -text "$::CAEDesigner::title — $::CAEDesigner::width × $::CAEDesigner::height"
    $c itemconfigure form -width [expr {$::CAEDesigner::width+2}] -height [expr {$::CAEDesigner::height+32}]
    $c coords form $::CAEDesigner::form_x $::CAEDesigner::form_y
    raise $c.form.grip
    $c configure -scrollregion [list 0 0 [expr {max(1000,$::CAEDesigner::form_x+$::CAEDesigner::width+100)}] [expr {max(800,$::CAEDesigner::form_y+$::CAEDesigner::height+100)}]]
    set ::CAEDesigner::paths [dict create root $c.form.body]
    .cae_designer.left.objectbox.objects delete 0 end
    foreach id [ordered $::CAEDesigner::nodes] {
        set n [dict get $::CAEDesigner::nodes $id]
        set p [dict get $::CAEDesigner::paths [dict get $n parent]].$id
        dict set ::CAEDesigner::paths $id $p
        widget_bind $p $id
        .cae_designer.left.objectbox.objects insert end "$id | [dict get $n type]"
    }
    set ::CAEDesigner::object_ids [ordered $::CAEDesigner::nodes]
    select $::CAEDesigner::selected
}
proc ::CAEDesigner::object_select {} {
    set index [.cae_designer.left.objectbox.objects curselection]
    if {[llength $index]} {select [lindex $::CAEDesigner::object_ids [lindex $index 0]]}
}
proc ::CAEDesigner::render_selection {} {
    catch {destroy .cae_designer.center.canvas.form.handle}
    set id $::CAEDesigner::selected
    if {$id eq "" || ![dict exists $::CAEDesigner::nodes $id]} {properties_refresh; return}
    lassign [absolute $id] x y; set n [dict get $::CAEDesigner::nodes $id]
    set h .cae_designer.center.canvas.form.handle
    frame $h -background #2166a5 -cursor sizing -width 10 -height 10
    place $h -x [expr {$x+[dict get $n width]-8}] -y [expr {$y+[dict get $n height]+23}] -width 10 -height 10
    bind $h <Button-1> {::CAEDesigner::resize_press %X %Y}
    bind $h <B1-Motion> {::CAEDesigner::resize_motion %X %Y}
    bind $h <ButtonRelease-1> {set ::CAEDesigner::drag {}}
    properties_refresh
}
proc ::CAEDesigner::resize_press {X Y} {checkpoint; set ::CAEDesigner::drag [list size $X $Y [dict get $::CAEDesigner::nodes $::CAEDesigner::selected]]}
proc ::CAEDesigner::resize_motion {X Y} {
    lassign $::CAEDesigner::drag mode sx sy n
    if {$mode ne "size"} {return}
    dict set n width [expr {max(20,min(2000,[dict get $n width]+$X-$sx))}]
    dict set n height [expr {max(10,min(2000,[dict get $n height]+$Y-$sy))}]
    dict set ::CAEDesigner::nodes $::CAEDesigner::selected $n
    place configure [dict get $::CAEDesigner::paths $::CAEDesigner::selected] -width [dict get $n width] -height [dict get $n height]
    set h .cae_designer.center.canvas.form.handle
    lassign [absolute $::CAEDesigner::selected] x y
    place configure $h -x [expr {$x+[dict get $n width]-8}] -y [expr {$y+[dict get $n height]+23}]
}
proc ::CAEDesigner::form_press {mode X Y} {set ::CAEDesigner::form_drag [list $mode $X $Y $::CAEDesigner::form_x $::CAEDesigner::form_y $::CAEDesigner::width $::CAEDesigner::height]}
proc ::CAEDesigner::form_motion {X Y} {
    lassign $::CAEDesigner::form_drag mode sx sy x y w h
    if {$mode eq "move"} {set ::CAEDesigner::form_x [expr {max(0,$x+$X-$sx)}]; set ::CAEDesigner::form_y [expr {max(0,$y+$Y-$sy)}]} else {
        set ::CAEDesigner::width [expr {max(100,min(2000,$w+$X-$sx))}]; set ::CAEDesigner::height [expr {max(100,min(2000,$h+$Y-$sy))}]; set ::CAEDesigner::dirty 1
    }
    render
}
proc ::CAEDesigner::properties_refresh {} {
    if {![winfo exists .cae_designer.right.tabs.widget.optionbox.options]} {return}
    .cae_designer.right.tabs.widget.optionbox.options delete 0 end
    set id $::CAEDesigner::selected
    if {$id eq "" || ![dict exists $::CAEDesigner::paths $id]} {return}
    set p [dict get $::CAEDesigner::paths $id]
    foreach option [$p configure] {
        set name [lindex $option 0]
        if {$name in {-command -variable -textvariable -validatecommand -invalidcommand -postcommand -xscrollcommand -yscrollcommand -menu -image -class -container}} {continue}
        .cae_designer.right.tabs.widget.optionbox.options insert end $name
    }
}
proc ::CAEDesigner::property_pick {} {
    set i [.cae_designer.right.tabs.widget.optionbox.options curselection]
    if {![llength $i]} {return}
    set ::CAEDesigner::option_name [.cae_designer.right.tabs.widget.optionbox.options get [lindex $i 0]]
    set p [dict get $::CAEDesigner::paths $::CAEDesigner::selected]
    set ::CAEDesigner::option_value [$p cget $::CAEDesigner::option_name]
}
proc ::CAEDesigner::property_apply {} {
    set id $::CAEDesigner::selected; if {$id eq "" || $::CAEDesigner::option_name eq ""} {return}
    set p [dict get $::CAEDesigner::paths $id]
    # Native configure is the property oracle, before persisting the change.
    $p configure $::CAEDesigner::option_name $::CAEDesigner::option_value
    checkpoint
    dict set ::CAEDesigner::nodes $id options $::CAEDesigner::option_name $::CAEDesigner::option_value
    if {$::CAEDesigner::option_name eq "-text"} {dict set ::CAEDesigner::nodes $id text $::CAEDesigner::option_value; set ::CAEDesigner::props(text) $::CAEDesigner::option_value}
    set ::CAEDesigner::status "Property applied: $::CAEDesigner::option_name"
}
proc ::CAEDesigner::close {} {
    if {![discard_ok]} {return}
    ::CAEDesignerReference::cleanup .cae_designer.left.reference
    if {[winfo exists .cae_browser_preview]} {::CAEDesignerLargeReference::cleanup .cae_browser_preview; destroy .cae_browser_preview}
    catch {destroy .cae_designer_preview}; destroy .cae_designer
}
proc ::CAEDesigner::rebuild {} {
    if {[winfo exists .cae_designer]} {::CAEDesignerReference::cleanup .cae_designer.left.reference; destroy .cae_designer}
    show
}
proc ::CAEDesigner::palette_drop {X Y} {
    set b .cae_designer.center.canvas.form.body
    if {$X >= [winfo rootx $b] && $Y >= [winfo rooty $b] && $X < [winfo rootx $b]+[winfo width $b] && $Y < [winfo rooty $b]+[winfo height $b]} {palette_add [expr {$X-[winfo rootx $b]}] [expr {$Y-[winfo rooty $b]}]}
}
proc ::CAEDesigner::show {} {
    package require Tk
    if {[llength [info commands hm_info]] && ![string match "2022.3.*" [hm_info -appinfo DISPLAYVERSION]]} {error "Designer requires HyperMesh 2022.3."}
    if {[winfo exists .cae_designer]} {raise .cae_designer; return}
    load_catalog
    if {"CAEDesignerHeading" ni [font names]} {font create CAEDesignerHeading {*}[font actual TkDefaultFont] -weight bold}
    ttk::style configure CAEDesigner.Heading.TLabel -font CAEDesignerHeading -foreground #2166a5
    toplevel .cae_designer
    wm title .cae_designer "CAE GUI Designer — Components / Live Form / Properties"
    wm geometry .cae_designer 1440x900; wm minsize .cae_designer 1180 760
    wm protocol .cae_designer WM_DELETE_WINDOW ::CAEDesigner::close
    grid columnconfigure .cae_designer 0 -minsize 340
    grid columnconfigure .cae_designer 1 -weight 1 -minsize 460
    grid columnconfigure .cae_designer 2 -minsize 320
    grid rowconfigure .cae_designer 1 -weight 1
    ttk::frame .cae_designer.top -padding {8 8}
    grid .cae_designer.top -row 0 -column 0 -columnspan 3 -sticky ew
    foreach {id label command} {new {New Form} new sample {CAE Sample} sample undo Undo {history undo} redo Redo {history redo} save {Save Design} save load {Open Design} load preview Preview preview export {Export Tcl} export} {
        ttk::button .cae_designer.top.$id -text $label -command [list ::CAEDesigner::safe "::CAEDesigner::$command"]
        pack .cae_designer.top.$id -side left -padx 3
    }
    ttk::label .cae_designer.top.titlelabel -text "Form title:"
    ttk::entry .cae_designer.top.title -textvariable ::CAEDesigner::title -width 22
    pack .cae_designer.top.titlelabel .cae_designer.top.title -side left -padx 4
    bind .cae_designer.top.title <KeyRelease> {set ::CAEDesigner::dirty 1}
    ttk::label .cae_designer.status -textvariable ::CAEDesigner::status -padding 8 -wraplength 1200
    grid .cae_designer.status -row 2 -column 0 -columnspan 3 -sticky ew
    foreach {side column} {left 0 center 1 right 2} {
        ttk::frame .cae_designer.$side -padding 8
        grid .cae_designer.$side -row 1 -column $column -sticky nsew
    }
    # Every list/control is a real descendant of its geometry container.
    grid columnconfigure .cae_designer.left 0 -weight 1
    grid rowconfigure .cae_designer.left 3 -weight 3
    grid rowconfigure .cae_designer.left 8 -weight 1
    ttk::label .cae_designer.left.label -text "COMPONENTS · TK GALLERY" -style CAEDesigner.Heading.TLabel
    grid .cae_designer.left.label -row 0 -sticky w -pady {0 8}
    ttk::frame .cae_designer.left.filters
    ttk::entry .cae_designer.left.filters.search -textvariable ::CAEDesigner::query -width 24
    ttk::button .cae_designer.left.filters.clear -text Clear -command {set ::CAEDesigner::query ""; set ::CAEDesigner::family All; ::CAEDesigner::browse_filter}
    grid columnconfigure .cae_designer.left.filters 0 -weight 1
    grid .cae_designer.left.filters.search -row 0 -column 0 -sticky ew
    grid .cae_designer.left.filters.clear -row 0 -column 1 -padx {5 0}
    grid .cae_designer.left.filters -row 1 -sticky ew -pady {0 6}
    ttk::frame .cae_designer.left.families
    ttk::label .cae_designer.left.families.label -text Library
    ttk::combobox .cae_designer.left.families.family -textvariable ::CAEDesigner::family -state readonly -values {All Tk Ttk HWTK Editor HWT MetaWidget Dialog Altair Infrastructure} -width 18
    ttk::label .cae_designer.left.families.count -textvariable ::CAEDesigner::result_count
    pack .cae_designer.left.families.label .cae_designer.left.families.family .cae_designer.left.families.count -side left -padx 3
    grid .cae_designer.left.families -row 2 -sticky ew -pady {0 6}
    bind .cae_designer.left.filters.search <KeyRelease> ::CAEDesigner::browse_filter
    bind .cae_designer.left.families.family <<ComboboxSelected>> ::CAEDesigner::browse_filter
    ttk::frame .cae_designer.left.palettebox
    listbox .cae_designer.left.palettebox.palette -width 36 -height 9 -exportselection 0 -background white -foreground #263746 -selectbackground #2166a5 -selectforeground white -yscrollcommand {.cae_designer.left.palettebox.scroll set}
    ttk::scrollbar .cae_designer.left.palettebox.scroll -command {.cae_designer.left.palettebox.palette yview}
    grid columnconfigure .cae_designer.left.palettebox 0 -weight 1
    grid rowconfigure .cae_designer.left.palettebox 0 -weight 1
    grid .cae_designer.left.palettebox.palette -row 0 -column 0 -sticky nsew
    grid .cae_designer.left.palettebox.scroll -row 0 -column 1 -sticky ns
    grid .cae_designer.left.palettebox -row 3 -sticky nsew
    bind .cae_designer.left.palettebox.palette <<ListboxSelect>> {::CAEDesigner::safe ::CAEDesigner::browse_preview}
    bind .cae_designer.left.palettebox.palette <Double-Button-1> {::CAEDesigner::safe ::CAEDesigner::palette_add}
    bind .cae_designer.left.palettebox.palette <ButtonRelease-1> {::CAEDesigner::safe [list ::CAEDesigner::palette_drop %X %Y]}
    ttk::frame .cae_designer.left.actions
    ttk::button .cae_designer.left.actions.add -text "Add to Form" -command {::CAEDesigner::safe ::CAEDesigner::palette_add}
    ttk::button .cae_designer.left.actions.full -text "Full Preview" -command {::CAEDesigner::safe ::CAEDesigner::full_preview}
    pack .cae_designer.left.actions.add .cae_designer.left.actions.full -side left -expand 1 -fill x -padx 2
    grid .cae_designer.left.actions -row 4 -sticky ew -pady 6
    ttk::frame .cae_designer.left.reference
    ttk::frame .cae_designer.left.reference.left
    listbox .cae_designer.left.reference.left.list -exportselection 0
    ttk::frame .cae_designer.left.reference.right
    ttk::entry .cae_designer.left.reference.right.api -state readonly
    ttk::labelframe .cae_designer.left.reference.right.sample -text "Browse Preview" -height 200 -width 320
    text .cae_designer.left.reference.right.options -state disabled -height 3
    pack .cae_designer.left.reference.right -fill x
    pack .cae_designer.left.reference.right.api -fill x
    pack .cae_designer.left.reference.right.sample -fill x -pady 4
    pack propagate .cae_designer.left.reference.right.sample 0
    grid .cae_designer.left.reference -row 5 -sticky ew
    ttk::label .cae_designer.left.mode -textvariable ::CAEDesigner::preview_status -wraplength 315
    grid .cae_designer.left.mode -row 6 -sticky ew -pady {2 8}
    ttk::label .cae_designer.left.objectlabel -text "FORM OBJECTS" -style CAEDesigner.Heading.TLabel
    grid .cae_designer.left.objectlabel -row 7 -sticky w -pady {0 4}
    ttk::frame .cae_designer.left.objectbox
    listbox .cae_designer.left.objectbox.objects -width 36 -height 5 -exportselection 0 -yscrollcommand {.cae_designer.left.objectbox.scroll set}
    ttk::scrollbar .cae_designer.left.objectbox.scroll -command {.cae_designer.left.objectbox.objects yview}
    grid columnconfigure .cae_designer.left.objectbox 0 -weight 1; grid rowconfigure .cae_designer.left.objectbox 0 -weight 1
    grid .cae_designer.left.objectbox.objects -row 0 -column 0 -sticky nsew
    grid .cae_designer.left.objectbox.scroll -row 0 -column 1 -sticky ns
    grid .cae_designer.left.objectbox -row 8 -sticky nsew
    bind .cae_designer.left.objectbox.objects <<ListboxSelect>> ::CAEDesigner::object_select
    # Live form workspace.
    grid columnconfigure .cae_designer.center 0 -weight 1; grid rowconfigure .cae_designer.center 2 -weight 1
    ttk::label .cae_designer.center.label -text "LIVE FORM · 1:1 CLIENT AREA" -style CAEDesigner.Heading.TLabel
    grid .cae_designer.center.label -row 0 -column 0 -sticky w -pady {0 8}
    ttk::label .cae_designer.center.hint -text "Drag the window title bar or a component.\nDrag a blue corner handle to resize. Preview opens the exported window." -wraplength 500
    grid .cae_designer.center.hint -row 1 -column 0 -sticky w -pady {0 8}
    set c .cae_designer.center.canvas
    canvas $c -background #edf0f3 -highlightthickness 0 -takefocus 1 -xscrollcommand {.cae_designer.center.x set} -yscrollcommand {.cae_designer.center.y set}
    ttk::scrollbar .cae_designer.center.x -orient horizontal -command [list $c xview]
    ttk::scrollbar .cae_designer.center.y -command [list $c yview]
    grid $c -row 2 -column 0 -sticky nsew
    grid .cae_designer.center.y -row 2 -column 1 -sticky ns
    grid .cae_designer.center.x -row 3 -column 0 -sticky ew
    frame $c.form -background #88939e
    label $c.form.title -background #dbe7f1 -anchor w -padx 10 -cursor fleur
    place $c.form.title -x 1 -y 1 -height 30 -relwidth 1
    frame $c.form.grip -background #2166a5 -cursor sizing
    place $c.form.grip -relx 1 -rely 1 -anchor se -width 12 -height 12
    $c create window $::CAEDesigner::form_x $::CAEDesigner::form_y -anchor nw -window $c.form -tags form
    bind $c.form.title <Button-1> {::CAEDesigner::form_press move %X %Y}
    bind $c.form.title <B1-Motion> {::CAEDesigner::safe [list ::CAEDesigner::form_motion %X %Y]}
    bind $c.form.grip <Button-1> {::CAEDesigner::form_press size %X %Y}
    bind $c.form.grip <B1-Motion> {::CAEDesigner::safe [list ::CAEDesigner::form_motion %X %Y]}
    bind $c <Button-1> {::CAEDesigner::select ""}
    bind $c <Delete> ::CAEDesigner::remove
    # All property controls live inside the actual notebook tab that owns them.
    grid columnconfigure .cae_designer.right 0 -weight 1; grid rowconfigure .cae_designer.right 1 -weight 1
    ttk::label .cae_designer.right.label -text PROPERTIES -style CAEDesigner.Heading.TLabel
    grid .cae_designer.right.label -row 0 -sticky w -pady {0 8}
    ttk::notebook .cae_designer.right.tabs
    grid .cae_designer.right.tabs -row 1 -sticky nsew
    foreach {tab title} {layout Layout widget Widget window Window} {
        ttk::frame .cae_designer.right.tabs.$tab -padding 10
        .cae_designer.right.tabs add .cae_designer.right.tabs.$tab -text $title
    }
    set layout .cae_designer.right.tabs.layout
    ttk::label $layout.help -text "Select an object on the form or in Form Objects.\nCoordinates are relative to its parent." -wraplength 280
    pack $layout.help -fill x -pady {0 10}
    ttk::frame $layout.fields
    pack $layout.fields -fill x
    grid columnconfigure $layout.fields 1 -weight 1
    set row 0
    foreach {key label} {id ID type Type text {Text / Value} values {Values (Tcl list)} parent {Parent ID / root} x X y Y width {Width (px)} height {Height (px)}} {
        ttk::label $layout.fields.l$key -text $label
        ttk::entry $layout.fields.e$key -textvariable ::CAEDesigner::props($key) -width 17
        if {$key in {id type}} {$layout.fields.e$key configure -state readonly}
        grid $layout.fields.l$key -row $row -column 0 -sticky w -pady 5 -padx {0 8}
        grid $layout.fields.e$key -row $row -column 1 -sticky ew -pady 5
        incr row
    }
    ttk::button $layout.apply -text "Apply Layout" -command {::CAEDesigner::safe ::CAEDesigner::apply}
    ttk::button $layout.delete -text "Delete Component / Group" -command ::CAEDesigner::remove
    pack $layout.apply $layout.delete -fill x -pady 8
    set widget .cae_designer.right.tabs.widget
    ttk::label $widget.help -text "Select a supported native property, then edit its value." -wraplength 280
    pack $widget.help -fill x -pady {0 8}
    ttk::frame $widget.optionbox
    listbox $widget.optionbox.options -height 14 -width 30 -exportselection 0 -yscrollcommand [list $widget.optionbox.scroll set]
    ttk::scrollbar $widget.optionbox.scroll -command [list $widget.optionbox.options yview]
    grid columnconfigure $widget.optionbox 0 -weight 1; grid rowconfigure $widget.optionbox 0 -weight 1
    grid $widget.optionbox.options -row 0 -column 0 -sticky nsew
    grid $widget.optionbox.scroll -row 0 -column 1 -sticky ns
    pack $widget.optionbox -fill both -expand 1
    ttk::label $widget.optionname -textvariable ::CAEDesigner::option_name
    ttk::entry $widget.optionvalue -textvariable ::CAEDesigner::option_value -width 28
    ttk::button $widget.optionapply -text "Apply Widget Property" -command {::CAEDesigner::safe ::CAEDesigner::property_apply}
    pack $widget.optionname $widget.optionvalue $widget.optionapply -fill x -pady 6
    bind $widget.optionbox.options <<ListboxSelect>> {::CAEDesigner::safe ::CAEDesigner::property_pick}
    set window .cae_designer.right.tabs.window
    foreach {key label} {width {Client width (px)} height {Client height (px)} form_x {Workspace X} form_y {Workspace Y}} {
        ttk::label $window.l$key -text $label
        ttk::entry $window.e$key -textvariable ::CAEDesigner::$key -width 20
        pack $window.l$key $window.e$key -anchor w -fill x -pady 4
    }
    ttk::button $window.apply -text "Apply Window Geometry" -command {::CAEDesigner::safe ::CAEDesigner::form_apply}
    pack $window.apply -fill x -pady 12
    browse_filter
    render
}
proc ::CAEDesigner::full_preview {} {
    set index [.cae_designer.left.palettebox.palette curselection]; if {![llength $index]} {return}
    set row [lindex $::CAEDesigner::browser_rows [lindex $index 0]]
    if {[winfo exists .cae_browser_preview]} {::CAEDesignerLargeReference::cleanup .cae_browser_preview; destroy .cae_browser_preview}
    namespace eval ::CAEDesignerLargeReference {variable base [::CAERuntimePaths::tcl_root]; variable serial 0; variable status ""; variable shown {}}
    foreach command [info procs ::CAEDesignerReference::*] {
        set args {}
        foreach arg [info args $command] {if {[info default $command $arg default]} {lappend args [list $arg $default]} else {lappend args $arg}}
        proc ::CAEDesignerLargeReference::[namespace tail $command] $args [string map {::CAEDesignerReference ::CAEDesignerLargeReference .cae_designer.left.reference .cae_browser_preview} [info body $command]]
    }
    toplevel .cae_browser_preview; wm title .cae_browser_preview "Component Preview — [lindex $row 1]"; wm geometry .cae_browser_preview 820x640
    wm protocol .cae_browser_preview WM_DELETE_WINDOW {::CAEDesignerLargeReference::cleanup .cae_browser_preview; destroy .cae_browser_preview}
    ttk::frame .cae_browser_preview.left; listbox .cae_browser_preview.left.list -exportselection 0
    ttk::frame .cae_browser_preview.right -padding 12; pack .cae_browser_preview.right -fill both -expand 1
    ttk::entry .cae_browser_preview.right.api -state readonly; pack .cae_browser_preview.right.api -fill x
    ttk::labelframe .cae_browser_preview.right.sample -text "Full Component Preview"; pack .cae_browser_preview.right.sample -fill both -expand 1 -pady 10
    text .cae_browser_preview.right.options -height 8 -state disabled; pack .cae_browser_preview.right.options -fill x
    set ::CAEDesignerLargeReference::shown [list $row]
    .cae_browser_preview.left.list insert end [lindex $row 1]; .cae_browser_preview.left.list selection set 0
    ::CAEDesignerLargeReference::preview
    english_preview .cae_browser_preview.right.sample
}

