# Read-only Tcl source presentation; no source evaluation or document mutation.
proc ::CAEDesigner::code_style {p} {
    set family Consolas
    foreach candidate {{Cascadia Code} {Cascadia Mono} Consolas {Courier New}} {
        if {[lsearch -nocase -exact [font families] $candidate] >= 0} {set family $candidate; break}
    }
    if {"CAEDesigner.Code" ni [font names]} {font create CAEDesigner.Code}
    font configure CAEDesigner.Code -family $family -size 11
    $p configure -font CAEDesigner.Code -background #1f1f1f -foreground #d4d4d4 -insertbackground #ffffff -selectbackground #264f78 -selectforeground #ffffff -padx 12 -pady 10 -spacing1 1 -spacing3 1 -tabs {32 64 96 128 160 192 224 256} -borderwidth 0
    foreach {tag color} {keyword #c586c0 command #569cd6 variable #9cdcfe number #b5cea8 string #ce9178 option #dcdcaa comment #7fa56d} {
        $p tag configure syntax_$tag -foreground $color
    }
    $p tag configure linked -background #2d3b4b
}
proc ::CAEDesigner::code_tag_matches {p tag text pattern offset} {
    foreach span [regexp -all -inline -indices -- $pattern $text] {
        lassign $span a b
        $p tag add syntax_$tag "1.0 + [expr {$offset+$a}] chars" "1.0 + [expr {$offset+$b+1}] chars"
    }
}
proc ::CAEDesigner::code_highlight {p source} {
    foreach tag {keyword command variable number string option comment} {$p tag remove syntax_$tag 1.0 end}
    # Lightweight lexical coloring, intentionally not a semantic Tcl parser.
    set offset 0
    foreach line [split $source \n] {
        code_tag_matches $p number $line {\m[0-9]+(?:\.[0-9]+)?\M} $offset
        code_tag_matches $p option $line {-[[:alpha:]][[:alnum:]_-]*} $offset
        code_tag_matches $p command $line {(?:::)?[[:alpha:]_][[:alnum:]_]*(?:::[[:alnum:]_]+)+|\m(?:button|entry|label|frame|labelframe|checkbutton|radiobutton|combobox|spinbox|canvas|text|listbox|menu|toplevel|pack|grid|place|wm|winfo|bind|configure|cget|source|destroy|puts|format|expr|list|dict|lindex|llength|append|lappend|incr|after)\M} $offset
        code_tag_matches $p keyword $line {\m(?:proc|namespace|variable|set|if|elseif|else|foreach|for|while|switch|return|break|continue|catch|try|global|upvar|uplevel|package|error|rename)\M} $offset
        code_tag_matches $p string $line {"(?:[^"\\]|\\.)*"} $offset
        code_tag_matches $p variable $line {\$(?:\{[^\}]+\}|(?:::)?[[:alnum:]_:]+(?:\([^)]*\))?)} $offset
        if {[regexp -indices {^\s*#.*$} $line span]} {
            lassign $span a b
            $p tag add syntax_comment "1.0 + [expr {$offset+$a}] chars" "1.0 + [expr {$offset+$b+1}] chars"
        }
        incr offset [expr {[string length $line]+1}]
    }
    foreach tag {number option command keyword string variable comment} {$p tag raise syntax_$tag}
    $p tag raise linked
}
