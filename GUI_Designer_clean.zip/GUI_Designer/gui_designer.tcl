# ASCII entrypoint so HyperMesh's default Windows source encoding is safe.
source -encoding utf-8 [file join [file dirname [info script]] gui_designer_core.tcl]
source -encoding utf-8 [file join [file dirname [info script]] gui_designer_v2.tcl]
source -encoding utf-8 [file join [file dirname [info script]] gui_designer_grid.tcl]
source -encoding utf-8 [file join [file dirname [info script]] gui_designer_properties.tcl]
source -encoding utf-8 [file join [file dirname [info script]] gui_designer_icons.tcl]
source -encoding utf-8 [file join [file dirname [info script]] gui_designer_import.tcl]
source -encoding utf-8 [file join [file dirname [info script]] gui_designer_selection.tcl]
source -encoding utf-8 [file join [file dirname [info script]] gui_designer_appearance.tcl]
source -encoding utf-8 [file join [file dirname [info script]] gui_designer_menubar.tcl]
source -encoding utf-8 [file join [file dirname [info script]] gui_designer_workspace.tcl]
source -encoding utf-8 [file join [file dirname [info script]] gui_designer_code_theme.tcl]
if {![info exists ::CAEDesigner::no_autoshow] || !$::CAEDesigner::no_autoshow} {::CAEDesigner::show}
