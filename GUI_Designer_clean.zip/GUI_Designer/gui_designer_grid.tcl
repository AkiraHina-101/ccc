# VBA-style design affordances. Editor-only; never emitted by generate.
namespace eval ::CAEDesigner {
    foreach {name value} {grid_size 8 snap_grid 1 show_grid 1 tool pointer} {
        if {![info exists $name]} {set $name $value}
    }
}
foreach method {show render add} {
    catch {rename ::CAEDesigner::grid_base_$method {}}
    rename ::CAEDesigner::$method ::CAEDesigner::grid_base_$method
}
proc ::CAEDesigner::snap {value} {
    if {!$::CAEDesigner::snap_grid} {return [expr {int($value)}]}
    set step $::CAEDesigner::grid_size
    return [expr {int(round(double($value)/$step))*$step}]
}
proc ::CAEDesigner::grid_changed {} {
    if {![string is integer -strict $::CAEDesigner::grid_size] || $::CAEDesigner::grid_size < 4 || $::CAEDesigner::grid_size > 32} {
        set ::CAEDesigner::grid_size 8
        set ::CAEDesigner::status "Grid spacing must be 4-32 pixels."
    }
    grid_draw
}
proc ::CAEDesigner::grid_draw {} {
    set b .cae_designer.center.canvas.form.body
    if {![winfo exists $b]} {return}
    if {![winfo exists $b.designgrid]} {
        canvas $b.designgrid -background #f0f0f0 -highlightthickness 0
        place $b.designgrid -x 0 -y 0 -relwidth 1 -relheight 1
        bind $b.designgrid <Button-1> {::CAEDesigner::surface_press %x %y}
    }
    set g $b.designgrid; $g delete all
    if {$::CAEDesigner::show_grid} {
        set step $::CAEDesigner::grid_size
        for {set y $step} {$y < $::CAEDesigner::height} {incr y $step} {
            for {set x $step} {$x < $::CAEDesigner::width} {incr x $step} {
                $g create rectangle $x $y $x $y -outline #969696 -tags dot
            }
        }
    }
    lower $g
}
proc ::CAEDesigner::add {type x y {parent root}} {
    set id [grid_base_add $type [snap $x] [snap $y] $parent]
    set data $::CAEDesigner::nodes
    foreach key {width height} {
        set minimum 20; if {$key eq "height"} {set minimum 10}
        if {$::CAEDesigner::snap_grid} {set minimum [expr {int(ceil(double($minimum)/$::CAEDesigner::grid_size))*$::CAEDesigner::grid_size}]}
        dict set data $id $key [expr {max($minimum,[snap [dict get $data $id $key]])}]
    }
    validate $data
    set ::CAEDesigner::nodes $data
    render; return $id
}
proc ::CAEDesigner::surface_press {x y} {
    if {$::CAEDesigner::tool eq "pointer"} {select ""; return}
    add $::CAEDesigner::tool $x $y
    set ::CAEDesigner::tool pointer
}
proc ::CAEDesigner::render {} {grid_base_render; grid_draw}
proc ::CAEDesigner::show {} {
    grid_base_show
    set bar .cae_designer.center.hint
    destroy $bar; ttk::frame $bar
    ttk::checkbutton $bar.dots -text "Show Grid" -variable ::CAEDesigner::show_grid -command ::CAEDesigner::grid_changed
    ttk::checkbutton $bar.snap -text "Snap to Grid" -variable ::CAEDesigner::snap_grid
    ttk::label $bar.label -text "Grid (px)"
    spinbox $bar.step -from 4 -to 32 -increment 4 -width 3 -textvariable ::CAEDesigner::grid_size -command ::CAEDesigner::grid_changed
    bind $bar.step <Return> ::CAEDesigner::grid_changed
    bind $bar.step <FocusOut> ::CAEDesigner::grid_changed
    pack $bar.dots $bar.snap $bar.label $bar.step -side left -padx {0 6}
    grid $bar -row 1 -column 0 -sticky w -pady {0 8}
    .cae_designer.center.label configure -text "USERFORM DESIGNER · 1:1 CLIENT AREA"
    set toolbox .cae_designer.toolbox
    if {![winfo exists $toolbox]} {
        toplevel $toolbox; wm title $toolbox "Toolbox"; wm resizable $toolbox 0 0
        wm transient $toolbox .cae_designer
        wm protocol $toolbox WM_DELETE_WINDOW [list wm withdraw $toolbox]
        set i 0
        foreach {type caption} {pointer "Pointer" label "Label" entry "TextBox" combobox "ComboBox" listbox "ListBox" checkbutton "CheckBox" radiobutton "OptionButton" button "CommandButton" labelframe "Frame" notebook "MultiPage" spinbox "SpinButton" scrollbar "ScrollBar"} {
            ttk::radiobutton $toolbox.t$i -text $caption -value $type -variable ::CAEDesigner::tool -style Toolbutton
            grid $toolbox.t$i -row [expr {$i/3}] -column [expr {$i%3}] -sticky ew -padx 2 -pady 2
            bind $toolbox.t$i <ButtonRelease-1> [list ::CAEDesigner::tool_drop $type %X %Y]
            incr i
        }
        ttk::label $toolbox.hint -text "Select a tool, then click the dotted form.\nOr drag a tool onto the form."
        grid $toolbox.hint -row 4 -columnspan 3 -padx 6 -pady 6
        wm geometry $toolbox +[expr {[winfo rootx .cae_designer]+20}]+[expr {[winfo rooty .cae_designer]+140}]
    }
    ttk::button $bar.tools -text Toolbox -command {wm deiconify .cae_designer.toolbox; raise .cae_designer.toolbox}
    pack $bar.tools -side left
    grid_draw
}
proc ::CAEDesigner::tool_drop {type X Y} {
    set b .cae_designer.center.canvas.form.body
    if {$type eq "pointer" || ![winfo exists $b]} {return}
    if {$X >= [winfo rootx $b] && $Y >= [winfo rooty $b] && $X < [winfo rootx $b]+[winfo width $b] && $Y < [winfo rooty $b]+[winfo height $b]} {
        add $type [expr {$X-[winfo rootx $b]}] [expr {$Y-[winfo rooty $b]}]
        set ::CAEDesigner::tool pointer
    }
}
proc ::CAEDesigner::render_selection {} {
    set f .cae_designer.center.canvas.form
    catch {destroy $f.handle}
    foreach w [winfo children $f] {if {[string match "$f.sel_*" $w]} {destroy $w}}
    set id $::CAEDesigner::selected
    if {$id eq "" || ![dict exists $::CAEDesigner::nodes $id]} {properties_refresh; return}
    foreach side {n s e w} {frame $f.sel_line_$side -background #404040}
    foreach {edge cursor} {nw top_left_corner n top_side ne top_right_corner e right_side se bottom_right_corner s bottom_side sw bottom_left_corner w left_side} {
        frame $f.sel_$edge -background white -highlightbackground #404040 -highlightthickness 1 -cursor $cursor
        bind $f.sel_$edge <Button-1> [list ::CAEDesigner::resize_press %X %Y $edge]
        bind $f.sel_$edge <B1-Motion> {::CAEDesigner::resize_motion %X %Y}
        bind $f.sel_$edge <ButtonRelease-1> {set ::CAEDesigner::drag {}; ::CAEDesigner::select $::CAEDesigner::selected}
    }
    selection_place; properties_refresh
}
proc ::CAEDesigner::selection_place {} {
    set id $::CAEDesigner::selected; set f .cae_designer.center.canvas.form
    if {$id eq "" || ![dict exists $::CAEDesigner::nodes $id]} {return}
    lassign [absolute $id] x y; incr x 1; incr y 31
    set n [dict get $::CAEDesigner::nodes $id]; set w [dict get $n width]; set h [dict get $n height]
    foreach {edge rx ry} {nw 0 0 n .5 0 ne 1 0 e 1 .5 se 1 1 s .5 1 sw 0 1 w 0 .5} {
        place $f.sel_$edge -x [expr {int($x+$rx*$w-4)}] -y [expr {int($y+$ry*$h-4)}] -width 8 -height 8
    }
    place $f.sel_line_n -x $x -y $y -width $w -height 1
    place $f.sel_line_s -x $x -y [expr {$y+$h}] -width $w -height 1
    place $f.sel_line_w -x $x -y $y -width 1 -height $h
    place $f.sel_line_e -x [expr {$x+$w}] -y $y -width 1 -height $h
    foreach edge {nw n ne e se s sw w} {raise $f.sel_$edge}
}
proc ::CAEDesigner::node_motion {X Y} {
    if {![llength $::CAEDesigner::drag]} {return}
    lassign $::CAEDesigner::drag mode sx sy n
    foreach {key delta} [list x [expr {$X-$sx}] y [expr {$Y-$sy}]] {
        dict set n $key [expr {max(0,min(2000,[snap [expr {[dict get $n $key]+$delta}]]))}]
    }
    dict set ::CAEDesigner::nodes $::CAEDesigner::selected $n
    place configure [dict get $::CAEDesigner::paths $::CAEDesigner::selected] -x [dict get $n x] -y [dict get $n y]
    select $::CAEDesigner::selected
}
proc ::CAEDesigner::resize_press {X Y {edge se}} {
    checkpoint; set ::CAEDesigner::drag [list size $X $Y [dict get $::CAEDesigner::nodes $::CAEDesigner::selected] $edge]
}
proc ::CAEDesigner::resize_motion {X Y} {
    if {![llength $::CAEDesigner::drag]} {return}
    lassign $::CAEDesigner::drag mode sx sy n edge
    if {$mode ne "size"} {return}
    set x [dict get $n x]; set y [dict get $n y]; set r [expr {$x+[dict get $n width]}]; set b [expr {$y+[dict get $n height]}]
    if {[string match *w* $edge]} {set x [expr {max(0,min($r-24,[snap [expr {$x+$X-$sx}]]))}]}
    if {[string match *e* $edge]} {set r [expr {min(2000,max($x+24,[snap [expr {$r+$X-$sx}]]))}]}
    if {[string match *n* $edge]} {set y [expr {max(0,min($b-16,[snap [expr {$y+$Y-$sy}]]))}]}
    if {[string match *s* $edge]} {set b [expr {min(2000,max($y+16,[snap [expr {$b+$Y-$sy}]]))}]}
    foreach {key value} [list x $x y $y width [expr {$r-$x}] height [expr {$b-$y}]] {dict set n $key $value; set ::CAEDesigner::props($key) $value}
    dict set ::CAEDesigner::nodes $::CAEDesigner::selected $n
    place configure [dict get $::CAEDesigner::paths $::CAEDesigner::selected] -x $x -y $y -width [dict get $n width] -height [dict get $n height]
    selection_place
}
proc ::CAEDesigner::form_motion {X Y} {
    if {![llength $::CAEDesigner::form_drag]} {return}
    lassign $::CAEDesigner::form_drag mode sx sy x y w h
    if {$mode eq "move"} {
        set ::CAEDesigner::form_x [expr {max(0,$x+$X-$sx)}]
        set ::CAEDesigner::form_y [expr {max(0,$y+$Y-$sy)}]
    } else {
        set ::CAEDesigner::width [expr {max(104,min(2000,[snap [expr {$w+$X-$sx}]]))}]
        set ::CAEDesigner::height [expr {max(104,min(2000,[snap [expr {$h+$Y-$sy}]]))}]
        set ::CAEDesigner::dirty 1
    }
    # Moving/resizing the shell must preserve its existing native controls.
    set ::CAEDesigner::dirty 1
    set c .cae_designer.center.canvas
    $c coords form $::CAEDesigner::form_x $::CAEDesigner::form_y
    if {$mode ne "move"} {
        place configure $c.form.body -width $::CAEDesigner::width -height $::CAEDesigner::height
        $c itemconfigure form -width [expr {$::CAEDesigner::width+2}] -height [expr {$::CAEDesigner::height+32}]
        $c.form.title configure -text "$::CAEDesigner::title — $::CAEDesigner::width × $::CAEDesigner::height"
    }
    $c configure -scrollregion [list 0 0 [expr {max(1000,$::CAEDesigner::form_x+$::CAEDesigner::width+100)}] [expr {max(800,$::CAEDesigner::form_y+$::CAEDesigner::height+100)}]]
}
