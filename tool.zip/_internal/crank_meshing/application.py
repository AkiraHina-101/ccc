"""Application for Crank Meshing."""
import traceback
from pathlib import Path
from crank_meshing.workflow import FlowSession, MainFlow, FLOW, VOLUME_INDEX
from crank_meshing.shaft_parameters import clean_settings
from crank_meshing.ui.dialog_layout import build_form, TITLE
from crank_meshing.mesh.surface_meshing import surface_settings
from crank_meshing.ui.parameter_table import StationEditor
from crank_meshing.ui.psj_table_controls import NativeGridCells
from crank_meshing.ui.crank_preview import TablePreview

class DialogCallbacks:
    def __init__(self, dialog, session):
        self.dialog, self.session = dialog, session
        self.running = self.closed = False
        self.depth = 0
        self.handlers = []
        self.cleanups = []
        self.sync = lambda: None
        self.message = lambda text: None

    def record(self, error):
        # Error reporting must never throw back into a native GUI callback.
        try:
            self.session.state.setdefault('gui_errors', []).append(
                dict(error=str(error), traceback=traceback.format_exc()))
            self.session.save()
        except BaseException:
            pass

    def refresh(self):
        if not self.closed:
            try:
                self.sync()
            except BaseException as exc:
                self.record(exc)

    def wrap(self, action, exclusive=False, sync_after=True):
        def handle(*args):
            if self.closed or self.depth or self.running or self.session.busy:
                return
            self.depth += 1
            if exclusive:
                self.running = True
            try:
                if exclusive:
                    self.sync()
                return action()
            except BaseException as exc:
                self.record(exc)
                if not self.closed:
                    try:
                        self.message(str(exc))
                    except BaseException as render_error:
                        self.record(render_error)
            finally:
                self.running = False
                if sync_after:self.refresh()
                self.depth -= 1
        # Hold callbacks explicitly until the native dialog is retired.
        self.handlers.append(handle)
        return handle

    def deferred(self, message, action):
        """Enqueue native completion even inside a guarded callback.

        The caller must register after generate_window. No model/UI reads on
        the native notification stack; the existing JDG queue owns delivery.
        """
        pending=[False]
        guarded=self.wrap(action,sync_after=False)
        def delivered(*args):
            pending[0]=False
            return guarded()
        self.handlers.append(delivered)
        self.dialog.register_message(message,delivered)
        def enqueue(*args):
            if self.closed or pending[0]:return
            pending[0]=True
            try:self.dialog.post_message(message,0)
            except BaseException as exc:
                pending[0]=False;self.record(exc)
        self.handlers.append(enqueue)
        return enqueue

    def on_close(self, *args):
        if self.closed:return
        self.closed = True
        cleanups,self.cleanups=self.cleanups,[]
        for cleanup in cleanups:
            try:cleanup()
            except BaseException as exc:self.record(exc)
        if self.running or self.session.busy:
            self.session.context['_stop_requested'] = True

    def retire(self):
        if self.running or self.session.busy:
            return False
        if not self.closed:
            self.on_close()
            try:
                self.dialog.close()
            except BaseException as exc:
                self.record(exc)
        return True


ROOT = Path(__file__).resolve().parents[2]


def input_locks(flow):
    state = flow.session.state
    measured = state['steps'].get('2') in ('RUNNING', 'FAILED', 'VERIFIED')
    deletion = state['steps'].get('5') in ('RUNNING', 'FAILED', 'VERIFIED')
    attempted = state.get('preparation', {}).get('removal', {}).get('attempted')
    aligned=bool(state.get('alignment',{}).get('started'))
    return (flow.index > 1 or measured or bool(flow.session.context.get('geometry')),
            flow.index >= 5 or deletion or bool(attempted) or aligned)


def completed_label(state):
    for event in reversed(state.get('events', [])):
        if event.get('status') == 'VERIFIED':
            return 'Completed: '+event['label']
    return 'Completed: -'


def confirm_crank_volume(jpt):
    answer = jpt.MessageBoxPSJ(
        'The crankshaft surface mesh (2D) is ready.\n'
        'Create TET10 solid mesh for the crankshaft now?\n\n'
        'Journal/Pin parts have already been grouped.\n'
        'Yes: mesh the crankshaft only, preserving the grouped inserts.\n'
        'Other model parts will not be meshed.\n'
        'No: stop at 2D; keep the Journal/Pin solids and RBE2.\n'
        'Use Apply or Next step later to continue.',
        jpt.MsgBoxType.MB_INFORMATION_YESNO)
    return str(answer).strip().upper() == 'YES'


def flow_status(result, flow):
    if result.get('paused'):
        return 'Stopped at 2D | Crankshaft surface ready. Apply / Next step to continue.'
    if result['complete']:
        return 'Full crankshaft TET10 complete.'
    return 'Ready | %d/%d: %s' % (flow.index+1, len(FLOW), result['next'])


def main(session=None, flow=None, package_root=None, data_folder=None):
    import JPT
    import pyjdg
    from pyjdg import JDGCreator, size_behavior
    global _dialog, _session, _flow, _actions, _callbacks
    previous = globals().get('_callbacks')
    if previous is not None and not previous.retire():
        return previous.dialog
    host = str(JPT.GetProgramPath())
    runtime_paths = dict(jupiter_home=host, macro=str(Path(host) / 'macro'),
                         pyjdg=str(pyjdg.__file__))
    print('[CRANK-RUNTIME] Host: ' + host)
    print('[CRANK-RUNTIME] Python commands: ' + runtime_paths['macro'])
    print('[CRANK-RUNTIME] GUI module: ' + runtime_paths['pyjdg'])
    dlg = JDGCreator(title=TITLE, resizable=False, validation=True,
        include_apply=False,include_ok=False,include_cancel=False)
    _dialog = dlg
    data_root = Path(data_folder) if data_folder else ROOT
    if session is None:
        from crank_meshing.run_state import migrate_drafts
        package_root = Path(package_root) if package_root else ROOT
        migrate_drafts(data_root, (package_root, package_root.parent))
    session = session or FlowSession(JPT, data_root)
    session.state['runtime_paths'] = runtime_paths
    owner = DialogCallbacks(dlg, session)
    _callbacks = owner
    _session = session
    flow = flow or MainFlow(session)
    flow.confirm_volume = lambda: confirm_crank_volume(JPT)
    _flow = flow
    active = ['journal']
    editor = StationEditor(dlg,session,flow,lambda text:message(text))
    preview = TablePreview(dlg,editor,session.folder)
    owner.cleanups.extend((editor.before_close,preview.close))
    build_form(dlg,size_behavior,preview.image)

    def message(text):
        if owner.closed: return
        dlg.set_item_text('status', ' '.join(str(text).split()))
    def dimensions():
        if owner.closed: return
        return editor.refresh_selection()
    def notify(status, label):
        if owner.closed: return
        message('%s | %d/%d: %s' % (status.title(), min(flow.index+1, len(FLOW)), len(FLOW), label))
        if status == 'DONE' and label in (FLOW[1],FLOW[2]): dimensions()
        sync()
    flow.notify = notify
    session.progress_notify = lambda text: session.notify_stage(notify, 'RUNNING',
        FLOW[min(flow.index, len(FLOW)-1)]+' / '+text, session.state['events'][-1])
    guard = owner.wrap
    def pick(group):
        if session.busy or input_locks(flow)[0]: return
        # Restore the group's own native selection in the same guarded
        # callback. Never carry Journal highlights into the Pin picker.
        ids=[int(n) for n in dlg.get_item_text(group+'_faces').replace(',', ' ').split()]
        active[0] = group
        for g in ('journal','pin'):dlg.set_radiobutton_state(g+'_pick',g==group)
        JPT.ClearAllSelection()
        if ids:
            JPT.SelectArrayCursor('['+', '.join('%d:%d'%(int(JPT.DItemType.FACE),n) for n in ids)+']')
        message('Faces | '+group.capitalize())
    def selected(*args):
        if session.busy or input_locks(flow)[0]:
            return
        ids = list(dict.fromkeys(int(f.id) for f in JPT.GetSelectedFaces()))
        dlg.set_item_text(active[0]+'_faces', ' '.join(map(str, ids)))
        session.state['selection'] = {g: dlg.get_item_text(g+'_faces') for g in ('journal', 'pin')}
        session.save()
        dimensions()
    def read():
        groups = {g: [int(n) for n in dlg.get_item_text(g+'_faces').replace(',', ' ').split()] for g in ('journal', 'pin')}
        s = clean_settings(dict(renumber=False, targets={g: dlg.get_item_text(g+'_targets') for g in ('journal', 'pin')},
            increment=dlg.get_item_text('increment'),
            station_inputs=editor.read(),
            alignment=preview.alignment_request(),
            surface=surface_settings((flow.settings or {}).get('surface'))))
        if session.state.get('alignment',{}).get('started'):
            s['station_inputs']=flow.settings.get('station_inputs')
        # ID fields remain editable for the manual button after completion.
        if flow.index>=len(FLOW):
            return
        flow.configure(groups, s)
    def debug():
        read()
        try:
            result = flow.next()
        finally:
            sync()
        message(flow_status(result, flow))
    def apply():
        read()
        try:
            result = flow.apply()
        finally:
            sync()
        message(flow_status(result, flow))
    def renumber_now():
        from crank_meshing.node_renumbering import renumber_centers
        for name in ('renumber_now','debug','apply','journal_targets','pin_targets','increment'):
            dlg.disable_item(name)
        try:
            result=renumber_centers(flow,{g:dlg.get_item_text(g+'_targets') for g in ('journal','pin')},dlg.get_item_text('increment'))
        finally: sync()
        message('Renumbered %d center nodes.' % result['count'])
    def close():
        owner.on_close()
        dlg.close()

    def sync():
        if owner.closed: return
        faces_locked, settings_locked = input_locks(flow)
        busy = session.busy or owner.running
        for group in ('journal', 'pin'):
            for name in (group+'_faces',group+'_pick'):
                (dlg.disable_item if busy or faces_locked else dlg.enable_item)(name)
        editor.sync(busy or settings_locked)
        preview.sync(busy)
        (dlg.disable_item if busy else dlg.enable_item)('table_view')
        (dlg.disable_item if busy else dlg.enable_item)('close')
        for name in ('journal_targets', 'pin_targets', 'increment'):
            (dlg.disable_item if busy or (settings_locked and flow.index<len(FLOW)) else dlg.enable_item)(name)
        manual=session.state.get('preparation',{}).get('manual_renumber',[])
        uncertain=bool(manual and manual[-1].get('started') and not manual[-1].get('verified'))
        (dlg.enable_item if not busy and flow.index>=len(FLOW) and not uncertain else dlg.disable_item)('renumber_now')
        for name in ('debug', 'apply'):
            (dlg.disable_item if busy or not editor.valid else dlg.enable_item)(name)

    _actions = dict(selected=selected, pick=pick, debug=debug, apply=apply,
                    sync=sync, renumber=renumber_now, dimensions=dimensions, editor=editor,
                    active_group=lambda:active[0],preview=preview)
    owner.sync, owner.message = sync, message
    editor.connect(guard)
    preview.connect(guard)
    dlg.on_selected(guard(selected))
    dlg.on_dlg_selector_changed(guard(selected))
    dlg.on_button_clicked('debug', guard(debug, exclusive=True))
    dlg.on_button_clicked('apply', guard(apply, exclusive=True))
    # The form has one custom Apply button; do not register a second Apply route.
    dlg.on_button_clicked('renumber_now',guard(renumber_now, exclusive=True))
    dlg.on_button_clicked('close',guard(close))
    dlg.on_dlg_cancel(owner.on_close)
    for group in ('journal','pin'):
        dlg.on_button_clicked(group+'_pick',guard(lambda g=group:pick(g)))
        dlg.on_command(name=group+'_faces',callfunc=guard(lambda g=group:(pick(g),dimensions())))
    dlg.generate_window()
    editor.native=NativeGridCells(TITLE,dlg)
    guard(lambda:editor.restore() or dimensions())()
    guard(lambda:pick('journal'))()
    sync()
    message('Ready | 1/%d: %s' % (len(FLOW), FLOW[0]))
    if flow.started and flow.settings:
        manual=session.state.get('preparation',{}).get('manual_renumber',[])
        numbering=manual[-1] if manual and manual[-1].get('verified') else flow.settings
        for g in ('journal', 'pin'):
            dlg.set_item_text(g+'_faces', ' '.join(map(str, flow.groups[g])))
            dlg.set_item_text(g+'_targets', numbering['targets'][g])
        guard(dimensions)()
        dlg.set_item_text('increment', str(numbering['increment']))
        sync()
        label = FLOW[min(flow.index, len(FLOW)-1)]
        failed = session.state['steps'].get(str(flow.index+1)) == 'FAILED'
        complete = flow.index >= len(FLOW)
        if session.state.get('volume_paused_2d') and flow.index==VOLUME_INDEX:
            message('Stopped at 2D | Crankshaft surface ready. Apply / Next step to continue.')
        else:
            message(('Done' if complete else 'Error' if failed else 'Ready')+' | %d/%d: ' % (min(flow.index+1, len(FLOW)), len(FLOW))+label)
    editor.connect_psj_commit(owner)
    return dlg
