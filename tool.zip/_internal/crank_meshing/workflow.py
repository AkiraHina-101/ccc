"""Workflow for Crank Meshing."""
import time
import traceback
from copy import deepcopy
from crank_meshing.run_state import DebugSession, counts
from crank_meshing.model_parts import validate_faces
from crank_meshing.shaft_parameters import configured_plan, clean_settings
from crank_meshing.model_parts import snapshot, removal_plan
from crank_meshing.mesh.mesh_preparation import Preparation
from crank_meshing.shaft_parameters import effective_geometry, validate_clearance

FLOW = ('Validate faces', 'Align shaft / measure geometry', 'Surface mesh crankshaft',
        'Plan layers / RBE2 / IDs', 'Remove old faces + chamfers',
        'Build Journal / Pin solids', 'Rebuild connections', 'Extract TET10 sections',
        'Merge interface nodes', 'Convert section shared faces',
        'Merge faces into crankshaft', 'Group Journal / Pin parts', 'Mesh crankshaft TET10')
PLAN_INDEX, REMOVE_INDEX = 3, 4
VOLUME_INDEX = 12
STEP_IDS = ('validate', 'align', 'surface', 'plan', 'remove', 'inserts', 'bridges',
            'sections', 'merge_nodes', 'shared', 'attach', 'group', 'volume')
WORKFLOW_VERSION = 6



class FlowSession(DebugSession):
    def compact_result(self, result):
        if result is not None and result is self.state.get('main_plan'):
            return {'state_ref': 'main_plan'}
        for name, value in self.state.get('preparation', {}).items():
            if result is value:
                return {'state_ref': 'preparation.'+name, 'verified': bool(value.get('verified'))}
        return result

    def notify_stage(self, notify, status, label, event):
        try:
            notify(status, label)
        except Exception:
            event.setdefault('notification_errors', []).append(traceback.format_exc())

    def print_timing(self, text, event=None):
        try:
            print(text)
        except Exception:
            record = event if event is not None else self.state
            record.setdefault('timing_print_errors', []).append(traceback.format_exc())

    def run_stage(self, index, action, notify):
        if self.busy:
            raise ValueError('A step is already running')
        key, label = str(index+1), FLOW[index]
        status = self.state['steps'].get(key)
        # Validation and planning are read-only; corrected inputs may be retried.
        if status == 'RUNNING' or (status == 'FAILED' and index not in (0, PLAN_INDEX)):
            raise ValueError('Step already attempted; inspect the partial state before recovery')
        event = dict(step=key, label=label, status='RUNNING', started=time.time())
        self.state['events'].append(event)
        self.state['steps'][key] = 'RUNNING'
        self.busy = True
        started = time.monotonic()
        action_started = False
        self.print_timing('[CRANK-TIME] START Step %d/%d: %s' % (index+1,len(FLOW),label),event)
        try:
            self.save()
            self.notify_stage(notify, 'RUNNING', label, event)
            event['before'] = counts(self.jpt)
            self.save()
            action_started = True
            event['result'] = self.compact_result(action())
            event['after'] = counts(self.jpt)
            event['delta'] = {k: event['after'][k]-event['before'][k] for k in event['before']}
            event['status'] = self.state['steps'][key] = 'VERIFIED'
            self.notify_stage(notify, 'DONE', label, event)
            return event
        except Exception as exc:
            event.update(status='FAILED', action_started=action_started,
                         error=str(exc), traceback=traceback.format_exc())
            self.state['steps'][key] = 'FAILED' if action_started else 'READY'
            self.notify_stage(notify, 'ERROR', label, event)
            raise
        finally:
            self.busy = False
            event['seconds'] = time.monotonic()-started
            self.print_timing('[CRANK-TIME] %s Step %d/%d: %s | %.3f s' %
                  (event['status'],index+1,len(FLOW),label,event['seconds']),event)
            self.save()


class MainFlow:
    def __init__(self, session, notify=None, confirm_volume=None):
        self.session, self.index = session, 0
        self.groups, self.settings = {}, None
        self.started = False
        # The interactive form supplies a native PSJ question. Script callers
        # keep their existing explicit full-run behavior unless they supply one.
        self.confirm_volume = confirm_volume
        self._volume_prompt_open = False
        self.notify = notify or (lambda status, label: print('[CRANK-FLOW]', status, label))
        session.progress_notify = lambda text: session.notify_stage(self.notify, 'RUNNING',
            FLOW[min(self.index, len(FLOW)-1)]+' / '+text, session.state['events'][-1])
        previous_version = session.state.get('workflow_version')
        if previous_version is not None and previous_version != WORKFLOW_VERSION:
            raise ValueError('Workflow changed. Start a new run on a fresh input model; do not resume old checkpoints.')
        session.state['workflow_version'] = WORKFLOW_VERSION
        self.preparation = Preparation(session)

    def stage_complete(self, name):
        return self.session.state['steps'].get(str(STEP_IDS.index(name) + 1)) == 'VERIFIED'

    def configure(self, groups, settings):
        self.session.require_document()
        from crank_meshing.mesh.surface_meshing import surface_settings
        settings = clean_settings(settings)
        settings['surface'] = surface_settings(settings.get('surface'))
        if self.session.state.get('alignment',{}).get('started') and self.settings is not None:
            if any(settings.get(k)!=self.settings.get(k) for k in ('alignment','station_inputs')):
                raise ValueError('The model was aligned. Keep the station values and orientation for this run.')
        if self.session.state.get('preparation', {}).get('remainder_surface', {}).get('started') and settings['surface'] != surface_settings((self.settings or {}).get('surface')):
            raise ValueError('Surface mesh already started. Keep the surface settings for this run.')
        # Deleted face IDs remain the canonical captured inputs after removal.
        if self.started:
            if self.groups != groups:
                measured = self.session.state['steps'].get('2') in ('RUNNING', 'FAILED', 'VERIFIED')
                if self.index <= 1 and not measured and not self.session.context.get('geometry'):
                    groups = validate_faces(self.session.jpt, groups)
                else:
                    raise ValueError('Faces were already measured. Keep these groups for this run.')
            if self.settings != settings:
                deletion_attempted = self.session.state.get('preparation', {}).get('removal', {}).get('attempted')
                deletion_started = self.session.state['steps'].get(str(REMOVE_INDEX+1)) in ('RUNNING', 'FAILED', 'VERIFIED')
                if self.index > REMOVE_INDEX or deletion_attempted or deletion_started:
                    raise ValueError('Old faces were removed. Keep the settings used to build this model.')
                if self.index == REMOVE_INDEX:
                    self.index = PLAN_INDEX
                self.session.state.pop('main_plan', None)
        else:
            groups = validate_faces(self.session.jpt, groups)
        self.groups, self.settings = deepcopy(groups), deepcopy(settings)
        self.session.context['groups'] = self.groups
        self.session.context['surface_settings'] = surface_settings(settings.get('surface'))

    def plan(self):
        jpt, s = self.session.jpt, self.settings
        geometry = self.session.context['geometry']
        op = self.session.operation
        effective = op('plan.station_inputs', lambda: deepcopy(self.session.context['aligned_effective'])
            if self.session.context.get('aligned_effective') is not None else effective_geometry(geometry,s.get('station_inputs')))
        scale = op('plan.document_units', lambda: float(jpt.ConvertValueToDocUnit(1., jpt.UnitType.Unit_Length)))
        rows, ids = op('plan.insert_parameters', lambda: configured_plan(effective, s['layers'], scale,
            segments=s['segments'], rbe=s['rbe'], ring=s['ring'], dofs=s['dofs'],
            renumber=False, targets=s['targets'], increment=s['increment'],
            existing_ids=()))
        parts = op('plan.source_parts', lambda: list(jpt.GetAllParts()))
        from crank_meshing.model_parts import capture_sources
        parts,crank=capture_sources(self.session,self.groups)
        data = op('plan.topology_snapshot', lambda: snapshot(jpt,[int(crank.id)]))
        removal = op('plan.removal_scope', lambda: removal_plan(data, geometry))
        op('plan.insert_clearance', lambda: validate_clearance(effective, removal))
        self.session.state.update(source_snapshot=data, source_part_keys=[int(p.key) for p in parts],
            effective_geometry=effective,
            main_plan=dict(inserts=rows, numbering=ids,
                removal=removal))
        self.session.save()
        # Validate the expensive insert mesh before any old face is removed.
        from crank_meshing.mesh.journal_pin_solids import validate_native_plan
        op('plan.native_preflight', lambda: validate_native_plan(rows,scale))
        return self.session.state['main_plan']

    def measure(self):
        if self.settings.get('alignment') is not None:
            from crank_meshing.shaft_alignment import apply_native
            if self.session.state.get('alignment',{}).get('started'):
                raise ValueError('Alignment was already attempted; inspect this run before recovery')
            apply_native(self.session,self.groups,self.settings.get('station_inputs'),self.settings['alignment'])
        result=self.session.measure()
        effective=self.session.context.get('aligned_effective')
        if effective is not None:
            centers={r['face_id']:r['center']['node_id'] for r in self.session.context['geometry']}
            for row in effective:row['center']['node_id']=centers[row['face_id']]
            self.session.state['alignment']['effective_geometry']=deepcopy(effective)
        return result

    def next(self):
        self.session.require_document()
        if self.session.busy or self._volume_prompt_open:
            raise ValueError('A step is already running')
        if self.index >= len(FLOW):
            if not self.session.state.get('numbering_complete',True):
                raise ValueError('Mesh complete. Finish center numbering with the Renumber button.')
            return dict(label='Full crankshaft TET10 complete', next='DONE: full TET10', complete=True)
        if self.index == VOLUME_INDEX and self.confirm_volume is not None:
            # Do not ask or replay after a native volume attempt failed.
            status = self.session.state['steps'].get(str(VOLUME_INDEX+1))
            if status not in ('RUNNING', 'FAILED'):
                self._volume_prompt_open = True
                waiting = time.monotonic()
                try:
                    approved = self.confirm_volume() is True
                finally:
                    self._volume_prompt_open = False
                    prompt_seconds = time.monotonic()-waiting
                # A modal question pumps host messages: recheck document/close
                # before allowing any mutation after the answer.
                self.session.require_document()
                self.session.state.setdefault('volume_decisions', []).append(
                    dict(time=time.time(), after_step=VOLUME_INDEX, create_tet10=approved, seconds=prompt_seconds))
                self.session.state['volume_paused_2d'] = not approved
                if not approved:
                    self.session.state.update(flow_index=self.index,
                        preparation_complete=self.stage_complete('attach'), volume_complete=False,
                        grouping_complete=self.stage_complete('group'))
                self.session.save()
                if not approved:
                    return dict(step=None, label='Stopped at 2D: crankshaft surface ready',
                        next=FLOW[VOLUME_INDEX], complete=False, paused=True, surface_only=True)
        p = self.preparation
        actions = (lambda: dict(groups=validate_faces(self.session.jpt, self.groups)),
                   self.measure, p.surface_mesh, self.plan, p.remove, p.inserts, p.bridges,
                   p.sections, p.merge_nodes, p.shared, p.merge_parts, p.group_inserts, p.volume_mesh)
        current = self.index
        self.started = True
        event = self.session.run_stage(current, actions[current], self.notify)
        self.index += 1
        complete = self.index == len(FLOW)
        self.session.state.update(flow_index=self.index, preparation_complete=self.stage_complete('attach'),
                                  volume_complete=self.stage_complete('volume'),
                                  grouping_complete=self.stage_complete('group'))
        if current == VOLUME_INDEX:
            self.session.state['volume_paused_2d'] = False
        if complete:
            self.session.context.pop('_prepared_batch', None)
            self.session.state['numbering_complete']=not self.settings['renumber']
        self.session.save()
        if complete and self.settings['renumber']:
            from crank_meshing.node_renumbering import renumber_centers
            renumber_centers(self,self.settings['targets'],self.settings['increment'])
        return dict(step=current, label=FLOW[current], event=event, complete=complete,
                    next='DONE: full TET10' if complete else FLOW[self.index])

    def apply(self):
        result = None
        if self.index >= len(FLOW):
            return self.next()
        started = time.monotonic()
        wait_before = sum(d.get('seconds',0.) for d in self.session.state.get('volume_decisions',[]))
        try:
            while self.index < len(FLOW):
                result = self.next()
                if result.get('paused'):
                    break
            return result
        finally:
            waited = sum(d.get('seconds',0.) for d in self.session.state.get('volume_decisions',[]))-wait_before
            seconds = max(0.,time.monotonic()-started-waited)
            self.session.state['last_apply_seconds'] = seconds
            self.session.state['last_apply_prompt_seconds'] = waited
            if waited:
                self.session.print_timing('[CRANK-TIME] Volume confirmation | %.3f s user wait' % waited)
            self.session.print_timing('[CRANK-TIME] Apply %s | %.3f s total' %
                  ('COMPLETE' if self.index >= len(FLOW) and self.session.state.get('numbering_complete',True) else 'STOPPED',seconds))
            self.session.save()
