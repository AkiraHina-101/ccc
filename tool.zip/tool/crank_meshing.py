# coding: utf-8
"""Run this file using Python/PSJ in Jupiter; do not run internal modules."""

# The tool folder is detected from the running script; no PC-specific path.
# Jupiter installation folder. Blank uses the Jupiter that is running.
# Example for 5.0.1: r'C:/Program Files/TechnoStar/Jupiter_5.0.1'
JUPITER_HOME = ''
# Optional settings/log location. Blank uses LOCALAPPDATA/CrankMeshing.
DATA_FOLDER = ''

import importlib
import os
import sys
from pathlib import Path


def _tool_root():
    candidates = []
    override = os.environ.get('CRANK_MESHING_HOME')
    if override:
        candidates.append(Path(override).expanduser())
    if globals().get('__file__'):
        candidates.append(Path(__file__).resolve().parent)
    # PSJ may omit __file__ but preserve the filename in the compiled code.
    frame = sys._getframe()
    try:
        while frame is not None:
            filename = frame.f_code.co_filename
            if filename and not filename.startswith('<'):
                script = Path(filename)
                if script.name.lower() == 'crank_meshing.py':
                    candidates.append(script.resolve().parent)
            frame = frame.f_back
    finally:
        del frame
    for filename in getattr(sys, 'argv', ()):
        if filename and Path(filename).name.lower() == 'crank_meshing.py':
            candidates.append(Path(filename).resolve().parent)
    candidates.append(Path.cwd())
    for folder in candidates:
        if (folder / '_internal/crank_meshing/__init__.py').is_file():
            return folder.resolve()
    raise RuntimeError('Crank Meshing: the host supplied no usable script location. '
                       'Run crank_meshing.py as a Python file, keeping _internal beside it. '
                       'For text-only exec use runpy.run_path with the script filename.')


def _data_root():
    override = os.environ.get('CRANK_MESHING_DATA') or DATA_FOLDER
    if override:
        path = Path(override).expanduser()
        return (ROOT / path).resolve() if not path.is_absolute() else path.resolve()
    local = os.environ.get('LOCALAPPDATA')
    return Path(local) / 'CrankMeshing' if local else ROOT


def _configure_jupiter():
    """Select wrappers from the requested installation, never mix native hosts."""
    if not JUPITER_HOME:
        return None
    import JPT
    installation = Path(JUPITER_HOME).expanduser().resolve()
    macro = installation / 'macro'
    if not macro.is_dir():
        raise RuntimeError('JUPITER_HOME must be a full Jupiter installation containing macro/: '
                           + str(installation))
    host = Path(JPT.GetProgramPath()).resolve()
    if installation != host:
        raise RuntimeError('JUPITER_HOME selects ' + str(installation) +
                           ', but this process is running ' + str(host) +
                           '. Open the selected Jupiter version and run this script there.')
    # Existing extension modules cannot be switched to another C++ runtime.
    names = ('pyjdg', 'macro_defs', 'macroTypes', 'Meshing', 'Geometry',
             'MeshEdit', 'Connections', 'Tools', 'Home', 'FileMenu')
    for name in names:
        origin = getattr(sys.modules.get(name), '__file__', None)
        if origin and not Path(origin).resolve().is_relative_to(installation):
            raise RuntimeError(name + ' is already loaded from ' + str(origin) +
                               '. Restart the selected Jupiter to clear mixed installation modules.')
    selected = [SOURCE_DIR, str(macro)]
    if (installation / 'DLLs').is_dir():
        selected.append(str(installation / 'DLLs'))
    sys.path[:] = selected + [item for item in sys.path if item not in selected]
    print('[CRANK-RUNTIME] Configured Jupiter: ' + str(installation))
    print('[CRANK-RUNTIME] Python commands: ' + str(macro))
    return installation


ROOT = _tool_root()
SOURCE_DIR = str(ROOT / '_internal')
sys.path[:] = [SOURCE_DIR] + [item for item in sys.path if item != SOURCE_DIR]
CAN_LAUNCH = True
# Retire either a previous copy or the pre-1.3 package before replacing modules.
for package_name, ui_name in (('crank_messing', 'crank_psj_v8'),
                              ('crank_meshing', 'application')):
    existing = sys.modules.get(package_name)
    if existing is None:
        continue
    expected = ROOT / '_internal/crank_meshing/__init__.py'
    if package_name == 'crank_meshing' and Path(getattr(existing, '__file__', '') or '.').resolve() == expected:
        continue
    previous_ui = sys.modules.get(package_name + '.' + ui_name)
    owner = getattr(previous_ui, '_callbacks', None)
    if owner is not None:
        CAN_LAUNCH = owner.retire()
    elif getattr(getattr(previous_ui, '_session', None), 'busy', False):
        CAN_LAUNCH = False
    elif getattr(previous_ui, '_dialog', None) is not None:
        previous_ui._dialog.close()
    if not CAN_LAUNCH:
        break
    for name in list(sys.modules):
        if name == package_name or name.startswith(package_name + '.'):
            del sys.modules[name]

if CAN_LAUNCH:
    _configure_jupiter()
    import crank_meshing
    importlib.reload(crank_meshing).reload_runtime().main(package_root=ROOT, data_folder=_data_root())
else:
    print('Crank is running; the current dialog and source are kept.')
