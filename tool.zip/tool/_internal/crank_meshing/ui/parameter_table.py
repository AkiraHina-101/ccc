"""Parameter table for Crank Meshing."""
from copy import deepcopy
from contextlib import nullcontext
from crank_meshing.ui.dialog_layout import FIELDS, cad_cell, format_cell, dimension_series, update_dimensions
from crank_meshing.shaft_parameters import effective_geometry
from crank_meshing.run_state import TableDrafts

class StationEditor:
    def __init__(self,dlg,session,flow,message):
        self.dlg,self.session,self.flow,self.message=dlg,session,flow,message
        self.records=[];self.signature=None;self.selection_error=None
        self.values=deepcopy(session.state.get('table_drafts',{}))
        if not self.values and (flow.settings or {}).get('station_inputs',{}):
            source=flow.settings['station_inputs']
            if source.get('mode')=='manual':self.values=deepcopy(source.get('values',{}))
        self.view='modify';self.valid=True;self.locked=False
        self.native=None
        self.on_change=lambda:None
        self.drafts=session.context.get('table_draft_store')
        if self.drafts is None and hasattr(session,'root'):self.drafts=TableDrafts(session.root)
        self.drafts_ready=False
        self.preview_options={}
        self.aligned=False
        self.display_records=[]
        self.defaults={}
        self.final_coordinates=True
        self.legacy_draft=session.state.get('table_coordinate_frame')!='final'
        for group in ('journal','pin'):self.values.setdefault(group,{})

    def groups(self):
        if self.flow.started:return self.flow.groups
        return {g:list(dict.fromkeys(int(v) for v in self.dlg.get_item_text(g+'_faces').replace(',',' ').split())) for g in ('journal','pin')}

    def can_edit(self,group,row,col):
        count=len([r for r in self.records if r['group']==group])
        return self.view=='modify' and not self.locked and 0<=row<len(FIELDS) and 1<=col<=count

    def pull(self,commit=True):
        if self.view!='modify' or self.locked:return
        if self.native and commit:self.native.commit()
        changed=False
        for group,rows in dimension_series(self.records).items():
            for column,(fid,record) in enumerate(rows,1):
                values=self.values[group].setdefault(str(fid),{})
                for row,field in enumerate(FIELDS):
                    if not self.can_edit(group,row,column):continue
                    value=self.dlg.get_cell_value(group+'_dimensions',row,column)
                    if values.get(field)!=value:values[field]=value;changed=True
        if changed:
            self.session.state['table_drafts']=deepcopy(self.values)
            self.session.save()
            self.persist()
        return changed

    def refresh_selection(self,pull=True):
        if pull:self.pull()
        self.selection_error=None
        try:
            groups=self.groups();signature=tuple((g,tuple(sorted(groups[g]))) for g in ('journal','pin'))
            measured=self.session.context.get('geometry')
            aligned=self.session.context.get('aligned_effective')
            if measured and aligned is not None and not self.aligned:
                # Display the actual execution frame after native alignment.
                for record in aligned:
                    values=self.values[record['group']].setdefault(str(record['face_id']),{})
                    for k,field in enumerate(('x','y','z')):values[field]=format_cell(record['center']['xyz_m'][k]*1000)
                self.aligned=True
            if measured:
                self.records=measured
                if self.aligned:self.display_records=measured
            elif signature!=self.signature:
                self.session.require_document()
                if set(groups['journal'])&set(groups['pin']):raise ValueError('A face cannot belong to both Journal and Pin')
                from Tools.Measure.Radius import Edge
                from crank_meshing.cad_geometry import preview_faces
                self.records=preview_faces(self.session.jpt,groups,lambda e:Edge('%d:%d'%(e.typeID,e.id),iPrecision=12)) if any(groups.values()) else []
                self.session.context['cad_preview']=deepcopy(self.records)
            self.signature=signature
            for group in ('journal','pin'):
                wanted={str(fid) for fid in groups[group]}
                self.values[group]={fid:values for fid,values in self.values[group].items() if fid in wanted}
                self.defaults={key:value for key,value in self.defaults.items() if key[0]!=group or key[1] in wanted}
            for record in self.records:
                values=self.values[record['group']].setdefault(str(record['face_id']),{})
                key=(record['group'],str(record['face_id']))
                if key not in self.defaults and not values:
                    self.defaults[key]={field:format_cell(cad_cell(record,field)) for field in FIELDS}
                for field in FIELDS:values.setdefault(field,format_cell(cad_cell(record,field)))
            self.session.state['table_drafts']=deepcopy(self.values)
            self.drafts_ready=self.drafts_ready or bool(self.records)
            self.render()
            self.persist()
        except (ValueError,KeyError) as exc:
            self.selection_error=str(exc);self.valid=False;self.message('Inputs: '+str(exc))

    def render(self,notify=True):
        with self.native.batch() if self.native else nullcontext():
            options=dict(values=self.values,editable=self.view=='modify',locked=self.locked)
            if self.native:options['set_widths']=False
            update_dimensions(self.dlg,self.records,self.groups(),**options)
            if self.native:self.native.apply(self)
        self.validate()
        if notify:self.on_change()

    def inputs(self):
        return dict(mode='manual',coordinate_frame='final',values=deepcopy(self.values)) if self.view=='modify' else None

    def set_coordinate_frame(self,baseline):
        """Follow aligned CAD defaults while retaining each literal user edit.

        Upgrade old drafts by replacing only cells still equal to raw CAD.
        Explicit edits (including invalid text) remain exactly as entered.
        """
        raw={(r['group'],str(r['face_id'])):r for r in self.records}
        changed=False
        new_defaults={}
        for record in baseline:
            key=(record['group'],str(record['face_id']))
            values=self.values[key[0]].setdefault(key[1],{})
            new_defaults[key]={field:format_cell(cad_cell(record,field)) for field in FIELDS}
            previous=self.defaults.get(key)
            if previous is None:
                previous={field:format_cell(cad_cell(raw[key],field)) for field in FIELDS} if self.legacy_draft else new_defaults[key]
            for field,value in new_defaults[key].items():
                if field not in values or values[field]==previous[field]:
                    if values.get(field)!=value:values[field]=value;changed=True
        self.defaults=new_defaults
        self.display_records=baseline
        self.legacy_draft=False
        self.session.state['table_coordinate_frame']='final'
        if changed:
            self.session.state['table_drafts']=deepcopy(self.values)
            self.session.save()
            self.render(notify=False)
        return changed

    def validate(self):
        was_valid=self.valid
        try:
            if self.selection_error:raise ValueError(self.selection_error)
            effective_geometry(self.display_records or self.records,self.inputs())
            self.valid=True
            if not was_valid:self.message('CAD | original coordinates, read only' if self.view=='cad' else 'Modify | final XYZ, white cells editable')
        except ValueError as exc:
            self.valid=False;self.message('Inputs: '+str(exc))

    def change_view(self):
        self.pull()
        self.view='cad' if self.dlg.get_combobox_sel('table_view')==1 else 'modify'
        self.render()
        self.persist()
        if self.valid:self.message('CAD | original coordinates, read only' if self.view=='cad' else 'Modify | final XYZ, white cells editable')

    def changed(self):
        self.pull();self.validate()
        self.on_change()

    def committed(self):
        # BCG owns the edit's lifetime. A queued notification may arrive after
        # another cell has begun editing; do not close that newer editor.
        changed=self.pull(commit=False)
        self.validate()
        if self.native and not changed:
            self._restoring_labels=True
            try:self.native.restore_display_values()
            finally:self._restoring_labels=False
        if changed:
            self.on_change()
            for name in ('apply','debug'):
                (self.dlg.enable_item if self.valid else self.dlg.disable_item)(name)

    def preview_records(self):
        inputs=self.inputs()
        if self.selection_error:raise ValueError(self.selection_error)
        effective=effective_geometry((self.display_records or self.records) if self.view=='modify' else self.records,inputs)
        by_id={(r['group'],r['face_id']):r for r in effective}
        return [by_id[g,fid] for g,rows in dimension_series(self.records).items() for fid,_ in rows]

    def persist(self):
        # Keep the pre-Apply user draft keyed to the original CAD. Execution
        # transforms the disposable model; it must not overwrite that draft.
        if self.drafts is not None and self.drafts_ready and not self.session.state.get('alignment',{}).get('started'):
            options=dict(self.preview_options,coordinate_frame='final')
            self.drafts.save(self.records,self.values,self.view,options)

    def restore(self):
        if self.drafts is None or self.flow.started:return False
        saved=self.drafts.read()
        if not saved or not any(saved.get('groups',{}).values()):return False
        try:
            self.session.require_document()
            from Tools.Measure.Radius import Edge
            from crank_meshing.cad_geometry import preview_faces
            groups={g:list(map(int,saved['groups'][g])) for g in ('journal','pin')}
            records=preview_faces(self.session.jpt,groups,lambda e:Edge('%d:%d'%(e.typeID,e.id),iPrecision=12))
            if not self.drafts.matches(saved,records):return False
        except (ValueError,KeyError,TypeError,RuntimeError):return False
        self.records=records;self.signature=tuple((g,tuple(sorted(groups[g]))) for g in ('journal','pin'))
        self.values=deepcopy(saved['values']);self.drafts_ready=True
        self.preview_options=deepcopy(saved.get('preview') or {})
        self.legacy_draft=self.preview_options.get('coordinate_frame')!='final'
        for group in ('journal','pin'):self.values.setdefault(group,{})
        self.view='cad' if saved.get('view')=='cad' else 'modify'
        for g in ('journal','pin'):self.dlg.set_item_text(g+'_faces',' '.join(map(str,groups[g])))
        self.dlg.set_combobox_sel('table_view',1 if self.view=='cad' else 0)
        self.refresh_selection(pull=False)
        return True

    def before_close(self):
        try:self.pull()
        finally:self.persist()

    def read(self):
        self.pull();self.refresh_selection()
        if not self.valid:raise ValueError('Check the table values before continuing')
        return self.inputs()

    def sync(self,locked):
        if self.locked!=locked:
            if locked:self.pull()
            self.locked=locked
            self.render()

    def connect_psj_commit(self,owner):
        # The vendor grid emits ENDINPLACEEDIT after it has stored the final
        # value. Queue the read so it runs outside the native notification
        # stack. Other controls call pull(), which ends the active PSJ edit.
        self._end_edit_handler=owner.deferred('Crank.TableCommit',self.committed)
        def ended(*args):
            try:
                if not getattr(self,'_restoring_labels',False):
                    self._end_edit_handler()
            except BaseException as exc:owner.record(exc)
        self._native_end_edit_handler=ended
        self.dlg.register_message('BCGM_GRID_ITEM_ENDINPLACEEDIT',ended)

    def connect(self,guard):
        self.dlg.on_combobox_sel('table_view',guard(self.change_view))
        for group in ('journal','pin'):
            def selected(g=group):
                if self.native:
                    cells=self.dlg.get_table_sel_cell(g+'_dimensions')
                    count=sum(r['group']==g for r in self.records)
                    if any(cell.col_number>count for cell in cells):
                        self.native.reject_padding(g)
                        return
                # Parameter edits must not re-arm the viewport face selector:
                # SelectArrayCursor can steal focus from the new native edit.
                # Journal/Pin radio buttons own face-picking explicitly.
            self.dlg.on_table_sel_changed(group+'_dimensions',guard(selected,sync_after=False))
            self.dlg.on_table_button_clicked(group+'_dimensions',guard(selected,sync_after=False))
            self.dlg.on_command(group+'_dimensions',guard(
                lambda:self._end_edit_handler() if hasattr(self,'_end_edit_handler') else None,sync_after=False))
