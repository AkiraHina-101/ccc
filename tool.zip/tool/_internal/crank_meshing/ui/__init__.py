"""Jupiter dialog, parameter tables and crank preview."""



