"""Dialog layout for Crank Meshing."""
from crank_meshing.shaft_parameters import DEFAULT_TARGETS
from crank_meshing import __version__

TITLE='Crank Meshing | ver.' + __version__
FORM_WIDTH=440
LABEL_WIDTH=80
INPUT_WIDTH=434
ROW_HEIGHT=22
TABLE_ROWS=5
TABLE_WIDTH=440
TABLE_HEIGHT=138 # Native header26px + five22px rows + border/scroll threshold.
PREVIEW_HEIGHT=285
TABLE_LABEL_WIDTH=42
TABLE_FACE_WIDTH=62
TABLE_MIN_STATIONS=5
FIELDS=('radius','width','x','y','z')
LABELS=('Radius','Width','X','Y','Z')
EDIT_COLOR=0xFFFFFF
LOCK_COLOR=0xF2F2F2
HEADER_COLOR=0xFFEBDD


def build_form(dlg,size_behavior,preview_image=None):
    fixed=[]
    def row(parent,name):
        dlg.add_hlayout(parent,name=name,margin=[2,1,2,1])
        return name
    def text(parent,name,label,value):
        r=row(parent,name+'_row')
        dlg.add_label(r,name+'_label',text=label,width=LABEL_WIDTH,height=ROW_HEIGHT)
        dlg.add_textbox(r,name,text=str(value),width=INPUT_WIDTH,height=ROW_HEIGHT)
        fixed.extend((name+'_label',name))
    dlg.add_face_selector()
    dlg.add_groupbox('Window','face_inputs',text='Faces')
    for group in ('journal','pin'):
        name=group+'_faces';r=row('face_inputs',name+'_row')
        dlg.add_radiobutton(r,group+'_pick',id=6101 if group=='journal' else 6102,
            text=group.capitalize(),checked=group=='journal',width=LABEL_WIDTH,height=ROW_HEIGHT)
        dlg.add_textbox(r,name,text='',width=INPUT_WIDTH,height=ROW_HEIGHT)
        fixed.extend((group+'_pick',name))
    r=row('face_inputs','table_view_row')
    dlg.add_label(r,'table_view_label',text='Parameter view',width=LABEL_WIDTH,height=ROW_HEIGHT)
    dlg.add_combobox(r,'table_view',options=['Modify','CAD'],index=0,width=76,height=ROW_HEIGHT)
    dlg.add_label(r,'table_order',text='mm',width=24,height=ROW_HEIGHT)
    fixed.extend(('table_view_label','table_view','table_order'))
    for group in ('journal','pin'):
        dlg.add_groupbox('Window',group+'_geometry',text=group.capitalize()+' (mm)')
        dlg.add_table(group+'_geometry',name=group+'_dimensions',columns=['']+['#%d'%n for n in range(1,6)],
            rows=TABLE_ROWS,width=TABLE_WIDTH,height=TABLE_HEIGHT,
            show_grid_line=True,show_row_number=False,show_col_header=True,menus=[])
        dlg.set_item_size_behavior(group+'_dimensions',size_behavior.horizontal)
    if preview_image is not None:
        dlg.add_groupbox('Window','crank_preview',text='Preview (XZ)')
        dlg.set_groupbox_collapsed('crank_preview',True)
        r=row('crank_preview','preview_controls')
        dlg.add_label(r,'preview_zero_label',text='Reference pin',width=76,height=ROW_HEIGHT)
        dlg.add_combobox(r,'preview_zero',options=['CAD'],index=0,width=52,height=ROW_HEIGHT)
        dlg.add_space(r,name='preview_parameter_gap',orientation='horizontal',size=18)
        dlg.add_label(r,'preview_rotation_label',text='Angle to +Z',width=70,height=ROW_HEIGHT)
        dlg.add_textbox(r,'preview_rotation',text='0',width=64,height=ROW_HEIGHT)
        dlg.add_label(r,'preview_angle_unit',text='deg',width=18,height=ROW_HEIGHT)
        dlg.add_imagectrl('crank_preview','crank_preview_image',image_file=str(preview_image),
                          width=TABLE_WIDTH,height=PREVIEW_HEIGHT)
        fixed.extend(('preview_zero_label','preview_zero','preview_angle_unit','preview_rotation_label','preview_rotation',
                      'crank_preview_image'))
    dlg.add_groupbox('Window','center_options',text='Renumber')
    dlg.set_groupbox_collapsed('center_options',True)
    for group in ('journal','pin'):
        text('center_options',group+'_targets',group.capitalize()+' IDs',DEFAULT_TARGETS[group])
    r=row('center_options','renumber_row')
    dlg.add_label(r,'increment_label',text='Increment',width=LABEL_WIDTH,height=ROW_HEIGHT)
    dlg.add_textbox(r,'increment',text='1',width=96,height=ROW_HEIGHT)
    fixed.extend(('increment_label','increment'))
    dlg.add_label('Window','status',text='Ready',width=FORM_WIDTH,height=20)
    r=row('Window','footer')
    dlg.add_space(r,name='footer_start',orientation='horizontal',size=0)
    for name,label in (('apply','Apply'),('debug','Next step'),('renumber_now','Renumber'),('close','Close')):
        dlg.add_button(r,name,text=label,width=90,height=30)
        fixed.append(name)
    dlg.add_space(r,name='footer_end',orientation='horizontal',size=0)
    for name in fixed:dlg.set_item_size_behavior(name,size_behavior.fixed)
    return fixed


def dimension_series(records,groups=None):
    result={}
    for group in ('pin','journal'):
        available={int(r['face_id']):r for r in records if r['group']==group}
        wanted=list(dict.fromkeys(int(n) for n in (groups[group] if groups is not None else available)))
        direction=next(iter(available.values())).get('axis_vector',[1.,0.,0.]) if available else [1.,0.,0.]
        wanted.sort(key=lambda fid:(sum(float(a)*b for a,b in zip(available[fid]['center']['xyz_m'],direction)) if fid in available else float('inf'),fid))
        result[group]=[(fid,available.get(fid)) for fid in wanted]
    return result


def cad_cell(record,field):
    if field in ('radius','width'):return record[field+'_m']*1000
    return record['center']['xyz_m']['xyz'.index(field)]*1000


def format_cell(value):
    return ('%.6f'%(0. if abs(value)<.5e-6 else value)).rstrip('0').rstrip('.')


def update_dimensions(dlg,records,groups=None,values=None,editable=False,locked=False,set_widths=True):
    """Native tables retain five blank station columns and scroll beyond five."""
    from pyjdg import TableColumnInfo,TableColumnInfoVector,TableCellID
    series=dimension_series(records,groups)
    for group in ('pin','journal'):
        name=group+'_dimensions';selected=series[group]
        columns=max(TABLE_MIN_STATIONS,len(selected))+1
        current=dlg.get_total_column(name)
        if current<columns:
            for index in range(current,columns):
                extra=TableColumnInfoVector()
                extra.append(TableColumnInfo(name='#%d'%index,type='String'))
                dlg.insert_table_columns(name,extra,position=index)
        while current>columns:
            current-=1;dlg.delete_table_column(name,current)
        dlg.enable_item(name)
        for column in range(columns):
            if set_widths:dlg.set_table_column_width(name,column,TABLE_LABEL_WIDTH if column==0 else TABLE_FACE_WIDTH)
            record=selected[column-1][1] if 0<column<=len(selected) else None
            for row,(field,label) in enumerate(zip(FIELDS,LABELS)):
                value=label if column==0 else ''
                if record is not None:
                    value=format_cell(cad_cell(record,field))
                    if editable and values is not None:
                        value=values.get(group,{}).get(str(record['face_id']),{}).get(field,value)
                can_edit=bool(editable and not locked and record is not None)
                dlg.clear_table_cell(name,row,column)
                dlg.set_cell_value(name,row,column,str(value))
                dlg.set_table_cell_alignment(name,row,column,'Center' if column==0 else 'Right')
                cell=TableCellID(row,column)
                dlg.set_table_cell_fill_color(name,cell,HEADER_COLOR if column==0 else EDIT_COLOR if can_edit else LOCK_COLOR)
                dlg.set_table_cell_text_color(name,cell,0x000000 if can_edit else 0x505050)
    return {g:[fid for fid,_ in rows] for g,rows in series.items()}
