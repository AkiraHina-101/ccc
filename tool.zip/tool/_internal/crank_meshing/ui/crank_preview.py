"""Crank preview for Crank Meshing."""
import ctypes as c
from ctypes import wintypes as w
import math
from pathlib import Path
from crank_meshing.ui import preview_drawing as drawing
from crank_meshing.shaft_alignment import aligned_frame, shaft_frame, pin_phase, transform_records, rotation_frame, execution_geometry

class PreviewWindow:
    def __init__(self):
        self.u=c.WinDLL('user32',use_last_error=True);self.g=c.WinDLL('gdi32')
        self.hwnd=self.image_hwnd=self.bitmap=None
        self.u.CreateWindowExW.argtypes=[w.DWORD,w.LPCWSTR,w.LPCWSTR,w.DWORD,c.c_int,c.c_int,c.c_int,c.c_int,w.HWND,w.HMENU,w.HINSTANCE,c.c_void_p]
        self.u.CreateWindowExW.restype=w.HWND
        self.u.LoadImageW.argtypes=[w.HINSTANCE,w.LPCWSTR,w.UINT,c.c_int,c.c_int,w.UINT];self.u.LoadImageW.restype=w.HANDLE
        self.u.SendMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM];self.u.SendMessageW.restype=c.c_ssize_t
        self.u.IsWindow.argtypes=[w.HWND];self.u.IsWindow.restype=w.BOOL
        self.u.DestroyWindow.argtypes=[w.HWND]
        self.u.AdjustWindowRectEx.argtypes=[c.POINTER(w.RECT),w.DWORD,w.BOOL,w.DWORD]
        self.u.SystemParametersInfoW.argtypes=[w.UINT,w.UINT,c.c_void_p,w.UINT]
        self.u.RedrawWindow.argtypes=[w.HWND,c.c_void_p,c.c_void_p,w.UINT]
        self.g.DeleteObject.argtypes=[w.HANDLE]

    @property
    def is_open(self):return bool(self.hwnd and self.u.IsWindow(self.hwnd))

    def size(self):
        work=w.RECT();self.u.SystemParametersInfoW(0x30,0,c.byref(work),0)
        scale=min(1.,max(100,work.right-work.left-60)/1000.,max(100,work.bottom-work.top-100)/560.)
        return round(1000*scale),round(560*scale)

    def open(self,owner,path,size):
        self.close();width,height=size
        rect=w.RECT(0,0,width,height);style=0x12C80000;exstyle=0x80
        self.u.AdjustWindowRectEx(c.byref(rect),style,False,exstyle)
        # Built-in STATIC window procedure handles its own Close. It cannot
        # dispatch JDG's global cancel route or close the Crank dialog.
        self.hwnd=self.u.CreateWindowExW(exstyle,'STATIC','Crank Preview | Full size',style,
            80,60,rect.right-rect.left,rect.bottom-rect.top,owner,None,None,None)
        if not self.hwnd:raise c.WinError(c.get_last_error())
        self.image_hwnd=self.u.CreateWindowExW(0,'STATIC','',0x5000020E,0,0,width,height,self.hwnd,None,None,None)
        if not self.image_hwnd:
            self.close();raise RuntimeError('Cannot create native preview image')
        self.update(path)

    def update(self,path):
        if not self.is_open:
            self.close();return
        bitmap=self.u.LoadImageW(None,str(path),0,0,0,0x2010)
        if not bitmap:raise c.WinError(c.get_last_error())
        self.u.SendMessageW(self.image_hwnd,0x0172,0,int(bitmap))
        old,self.bitmap=self.bitmap,bitmap
        if old:self.g.DeleteObject(old)
        # Keep the container's background from painting over the child bitmap,
        # and finish native paint before an immediate PrintWindow capture.
        self.u.RedrawWindow(self.hwnd,None,None,0x185)

    def close(self):
        if self.is_open:self.u.DestroyWindow(self.hwnd)
        self.hwnd=self.image_hwnd=None
        if self.bitmap:self.g.DeleteObject(self.bitmap);self.bitmap=None




def reference_phase(cad,records,zero_face):
    frame=shaft_frame(cad,records) if any(r['group']=='journal' for r in cad) else rotation_frame(0.)
    return pin_phase(records,zero_face,frame)


def target_rotation(cad,records,zero_face,angle):
    """Displayed pin angle is measured from +Z towards +Y, not a CAD rotation."""
    angle=drawing.number(angle,'Pin angle')
    if zero_face is None:return angle
    return (reference_phase(cad,records,zero_face)-angle+180.)%360.-180.


def table_plan(records, rotation=0., reference=None):
    """Preserve table XYZ exactly at zero view rotation, including Journal Y/Z."""
    rotation=drawing.number(rotation,'View rotation')%360.
    groups={'journal':[],'pin':[]};rectangles=[]
    pins=[r for r in records if r['group']=='pin'];base=0.
    if reference is not None:
        if not 0<=reference<len(pins):raise ValueError('Select an existing zero pin')
        yy,zz=pins[reference]['center']['xyz_m'][1:]
        if math.hypot(yy,zz)<1e-15:raise ValueError('Zero pin lies on X; choose another pin or CAD')
        base=math.degrees(math.atan2(yy,zz))
    applied=rotation-base;angle=math.radians(applied);sn,cs=math.sin(angle),math.cos(angle)
    for record in records:
        group=record['group'];rows=groups[group]
        x,y,z=[float(v)*1000 for v in record['center']['xyz_m']]
        radius=float(record['radius_m'])*1000;width=float(record['width_m'])*1000
        for key,value in (('X',x),('Y',y),('Z',z),('radius',radius),('width',width)):
            drawing.number(value,key,key in ('radius','width'))
        throw=math.hypot(y,z);phase=math.degrees(math.atan2(y,z))%360.
        # View-only rotation about X; never normalize onto a selected zero pin.
        yy,zz=(y,z) if applied==0 else (y*cs+z*sn,z*cs-y*sn)
        if group=='pin' and reference==len(rows) and rotation==0:yy,zz=0.,throw
        row=dict(x=x,radius=radius,width=width,throw=throw,phase=phase,
                 y=yy,z=zz,face_id=record['face_id'])
        rows.append(row)
        rect=dict(row,name=('J' if group=='journal' else 'P')+str(len(rows)),
            group='J' if group=='journal' else 'P',angle=(phase+applied)%360.,
            xmin=x-width/2,xmax=x+width/2,zmin=zz-radius,zmax=zz+radius)
        if not all(math.isfinite(rect[k]) for k in ('xmin','xmax','zmin','zmax')):
            raise ValueError('Preview dimensions exceed the supported numeric range')
        rectangles.append(rect)
    return dict(journals=groups['journal'],pins=groups['pin'],rectangles=rectangles,
                rotation=rotation,reference=reference if reference is not None else 0,
                zero_pin=reference,orientation_label='TABLE XYZ' if reference is None else 'ZERO P%d'%(reference+1))


class TablePreview:
    def __init__(self,dlg,editor,folder):
        self.dlg,self.editor=dlg,editor
        self.folder=Path(folder)/'preview';self.folder.mkdir(parents=True,exist_ok=True)
        self.revision=0;self.signature=None;self.last_error=None
        self.full=None
        self.pin_ids=();self.zero_face=None
        self.view_restored=False
        self.execution_seen=False
        self.plan=table_plan([]);self.report=None
        self.image=self.folder/'view0.png'
        drawing.render_table_preview(self.plan,self.image)

    def refresh(self):
        final_coordinates=getattr(self.editor,'final_coordinates',False)
        # Restore orientation before parsing or migrating an old table draft.
        records=self.editor.records if final_coordinates else self.editor.preview_records()
        d=self.dlg
        if records and not self.view_restored:
            options=getattr(self.editor,'preview_options',{})
            self.zero_face=options.get('zero_face')
            if options:
                angle=options.get('rotation','0')
                if options.get('angle_mode')=='cad-phase' and self.zero_face is not None:
                    cad=getattr(self.editor,'records',records)
                    angle=(reference_phase(cad,records,self.zero_face)-float(angle)+180.)%360.-180.
                d.set_item_text('preview_rotation',str(angle))
            self.view_restored=True
        self.sync_zero_options(records)
        reference=self.pin_ids.index(self.zero_face) if self.zero_face in self.pin_ids else None
        cad=getattr(self.editor,'records',records)
        aligned=getattr(self.editor,'aligned',False)
        if aligned:
            order=[(r['group'],r['face_id']) for r in records]
            execution=self.editor.session.state.get('effective_geometry',self.editor.session.context.get('aligned_effective',records))
            byid={(r['group'],r['face_id']):r for r in execution}
            records=[byid[key] for key in order]
        if aligned and not self.execution_seen:
            if self.zero_face is None:d.set_item_text('preview_rotation','0')
            elif 'alignment' not in self.plan:
                current=(reference_phase(cad,records,self.zero_face)+180.)%360.-180.
                d.set_item_text('preview_rotation','0' if abs(current)<1e-9 else '%.9g'%current)
            self.execution_seen=True
        angle=drawing.number(d.get_item_text('preview_rotation'),'Pin angle')
        applied=target_rotation(cad,cad if final_coordinates and not aligned else records,self.zero_face,angle)
        if final_coordinates and not aligned:
            options=dict(zero_face=self.zero_face,angle=applied)
            has_journals=any(r['group']=='journal' for r in cad)
            if has_journals:frame,baseline,_=execution_geometry(cad,None,options)
            else:
                frame=rotation_frame(applied)
                baseline=transform_records(cad,frame,preserve_order=True)
            self.editor.set_coordinate_frame(baseline)
            if has_journals:frame,baseline,records=execution_geometry(cad,self.editor.inputs(),options)
            else:records=self.editor.preview_records() if self.editor.view=='modify' else baseline
            byid={(r['group'],r['face_id']):r for r in records}
            from crank_meshing.ui.dialog_layout import dimension_series
            records=[byid[g,fid] for g,rows in dimension_series(cad).items() for fid,_ in rows]
            plan=table_plan(records)
            if has_journals:plan['alignment']=frame
        elif any(r['group']=='journal' for r in cad) and not aligned:
            frame=aligned_frame(cad,records,self.zero_face,applied)
            plan=table_plan(transform_records(records,frame,preserve_order=True))
            plan['alignment']=frame
        elif aligned:plan=table_plan(transform_records(records,rotation_frame(applied),preserve_order=True))
        else:plan=table_plan(records,angle if reference is not None else -angle,reference)
        plan.update(rotation=angle,rotation_applied=applied,zero_pin=reference,
            orientation_label='CENTERED CAD' if reference is None else 'ZERO P%d'%(reference+1))
        dims=grid=True
        from crank_meshing.ui.dialog_layout import TABLE_WIDTH, PREVIEW_HEIGHT
        size=self.output_size(TABLE_WIDTH,PREVIEW_HEIGHT)
        signature=repr((plan,dims,grid,size))
        if signature==self.signature:
            self.last_error=None
            return self.plan
        target=self.folder/('view%d.png'%((self.revision+1)%2))
        report=drawing.render_table_preview(plan,target,dims,grid,output_size=size)
        d.set_image_file('crank_preview_image',str(target))
        self.plan,self.report,self.image=plan,report,target
        self.signature=signature;self.revision+=1;self.last_error=None
        if hasattr(self.editor,'preview_options'):
            self.editor.preview_options=dict(zero_face=self.zero_face,rotation=d.get_item_text('preview_rotation'),angle_mode='pin-target',
                **(dict(coordinate_frame='final') if final_coordinates else {}))
            self.editor.persist()
        self.update_full()
        return plan

    def sync_zero_options(self,records):
        ids=tuple(r['face_id'] for r in records if r['group']=='pin')
        if ids==self.pin_ids:return
        self.pin_ids=ids
        if self.zero_face not in ids:self.zero_face=None
        if not hasattr(self.dlg,'clear_combobox'):return
        self.dlg.clear_combobox('preview_zero');self.dlg.add_combobox_option('preview_zero','CAD')
        for i in range(len(ids)):self.dlg.add_combobox_option('preview_zero','P%d'%(i+1))
        self.dlg.set_combobox_sel('preview_zero',ids.index(self.zero_face)+1 if self.zero_face in ids else 0)

    def update(self):
        try:return self.refresh()
        except ValueError as exc:
            self.last_error=str(exc)
            # Never leave an apparently current image showing stale values.
            self.editor.message('Preview paused: '+str(exc))

    def connect(self,guard):
        self.editor.on_change=self.update
        def refresh():
            self.editor.pull();self.editor.validate()
            return self.update()
        for name in ('preview_rotation',):
            self.dlg.on_command(name,guard(refresh))
        self.dlg.on_combobox_sel('preview_zero',guard(self.select_zero))

    def select_zero(self):
        self.editor.pull()
        index=self.dlg.get_combobox_sel('preview_zero')-1
        self.zero_face=self.pin_ids[index] if 0<=index<len(self.pin_ids) else None
        self.dlg.set_item_text('preview_rotation','0')
        self.editor.validate();self.update()

    def rotate(self):
        from crank_meshing.shaft_alignment import rotate_completed
        self.editor.pull();self.refresh()
        result=rotate_completed(self.editor.flow,self.plan['rotation_applied'])
        if self.zero_face is None:self.dlg.set_item_text('preview_rotation','0')
        self.editor.aligned=False
        self.editor.refresh_selection(pull=False)
        self.editor.message('Rotated %.6g deg | %.3f s | mesh preserved'%(result['angle'],result['seconds']))
        return result

    def alignment_request(self):
        if self.editor.flow.settings and self.editor.session.state.get('alignment',{}).get('started'):
            return self.editor.flow.settings['alignment']
        self.refresh()
        return dict(zero_face=self.zero_face,angle=self.plan['rotation_applied'])

    def update_full(self):
        if self.full is not None and self.full.is_open:
            path=self.folder/'full.bmp'
            drawing.render_table_preview(self.plan,path,True,True,output_size=self.full.size())
            self.full.update(path)

    def show_full(self):
        self.editor.pull();self.editor.validate();self.refresh()
        if self.full is None:self.full=PreviewWindow()
        path=self.folder/'full.bmp';size=self.full.size()
        drawing.render_table_preview(self.plan,path,True,True,output_size=size)
        self.full.open(self.editor.native.window,path,size)

    def close(self):
        if self.full is not None:self.full.close()

    def output_size(self,width,height):
        native=getattr(self.editor,'native',None)
        if native is None or not native.handles:return (round(width*1.25),round(height*1.25))
        scale=native.u.GetDpiForWindow(native.handles['journal'])/96.
        return (max(1,round(width*scale)),max(1,round(height*scale)))

    def sync(self,busy):
        state=self.editor.session.state
        orientation_locked=bool(state.get('alignment',{}).get('started')) and not state.get('volume_complete')
        for name in ('preview_zero','preview_rotation'):
            (self.dlg.disable_item if busy or orientation_locked else self.dlg.enable_item)(name)
