"""Psj table controls for Crank Meshing."""
import ctypes as c
from ctypes import wintypes as w
import hashlib, os
from contextlib import contextmanager
from pathlib import Path

# Build-specific native grid profile. Installation selection is in the launcher.
VERIFIED_JUPITER = '5.0.4'
PYJDG_HASH='79de6481dac701784432f8ad15eb282a62788cd5662f42ab6cd830bef5d2e971'
MFC_LIBRARY = 'mfc140u.dll'
BCG_LIBRARY = 'BCGCBPRO3100u140.dll'
MFC_FROM_HANDLE_ORDINAL = 4726
MFC_IS_KIND_OF_ORDINAL = 7928


class NativeGridCells:
    def __init__(self,title,dlg):
        import pyjdg
        if c.sizeof(c.c_void_p)!=8 or hashlib.sha256(Path(pyjdg.__file__).read_bytes()).hexdigest()!=PYJDG_HASH:
            raise RuntimeError('Native table profile is verified for Jupiter ' + VERIFIED_JUPITER +
                               '; loaded pyjdg: ' + str(pyjdg.__file__) +
                               '. Adapt ui/psj_table_controls.py for this build before using native grid calls.')
        self.title,self.dlg=title,dlg
        self.u=c.WinDLL('user32');k=c.WinDLL('kernel32')
        k.GetModuleHandleW.argtypes=[w.LPCWSTR];k.GetModuleHandleW.restype=w.HMODULE
        k.GetProcAddress.argtypes=[w.HMODULE,c.c_void_p];k.GetProcAddress.restype=c.c_void_p
        m=k.GetModuleHandleW(MFC_LIBRARY)
        if not m:raise RuntimeError('Jupiter MFC module is unavailable')
        a,b=k.GetProcAddress(m,MFC_FROM_HANDLE_ORDINAL),k.GetProcAddress(m,MFC_IS_KIND_OF_ORDINAL)
        if not a or not b:raise RuntimeError('Jupiter MFC imports are unavailable')
        self.from_handle=c.WINFUNCTYPE(c.c_void_p,w.HWND)(a)
        self.is_kind=c.WINFUNCTYPE(c.c_int,c.c_void_p,c.c_void_p)(b)
        self.lib=c.WinDLL(BCG_LIBRARY)
        def bind(name,result,*args):
            f=getattr(self.lib,name);f.argtypes=list(args);f.restype=result;return f
        P,I=c.c_void_p,c.c_int
        self.klass=bind('?GetThisClass@CBCGPGridCtrl@@SAPEAUCRuntimeClass@@XZ',P)()
        self.rows=bind('?GetRowCount@CBCGPGridCtrl@@QEBAHH@Z',I,P,I)
        self.columns=bind('?GetColumnCount@CBCGPGridCtrl@@QEBAHH@Z',I,P,I)
        self.getrow=bind('?GetRow@CBCGPGridCtrl@@QEBAPEAVCBCGPGridRow@@H@Z',P,P,I)
        self.getitem=bind('?GetItem@CBCGPGridRow@@QEBAPEAVCBCGPGridItem@@H@Z',P,P,I)
        self.setro=bind('?SetReadOnly@CBCGPGridItem@@QEAAXH@Z',None,P,I)
        self.getro=bind('?IsReadOnly@CBCGPGridItem@@QEBAHXZ',I,P)
        self.gridro=bind('?SetReadOnly@CBCGPGridCtrl@@QEAAXH@Z',None,P,I)
        self.end_edit=bind('?EndEditItem@CBCGPGridCtrl@@UEAAHH@Z',I,P,I)
        self.edit_first_click=bind('?SetEditFirstClick@CBCGPGridCtrl@@QEAAXH@Z',None,P,I)
        self.editing=bind('?IsInPlaceEditing@CBCGPGridItem@@QEBAHXZ',I,P)
        self.enable=bind('?Enable@CBCGPGridItem@@QEAAXH@Z',None,P,I)
        self.enabled=bind('?IsEnabled@CBCGPGridItem@@QEBAHXZ',I,P)
        self.header_align=bind('?SetHeaderAlign@CBCGPGridCtrl@@QEAAHHH@Z',I,P,I,I)
        self.highlight=bind('?SetHighlightActiveItem@CBCGPGridCtrl@@QEAAXH@Z',None,P,I)
        self.selection_border=bind('?SetSelectionBorder@CBCGPGridCtrl@@QEAAXH@Z',None,P,I)
        self.active_border=bind('?SetSelectionBorderForActiveItem@CBCGPGridCtrl@@QEAAXH@Z',None,P,I)
        self.lines=bind('?EnableGridLines@CBCGPGridCtrl@@QEAAXH@Z',None,P,I)
        self.clear_selection=bind('?SetCurSel@CBCGPGridCtrl@@QEAAXPEAVCBCGPGridRow@@H@Z',None,P,P,I)
        self.get_theme=bind('?GetColorTheme@CBCGPGridCtrl@@QEBAAEBVCBCGPGridColors@@XZ',P,P)
        self.set_theme=bind('?SetColorTheme@CBCGPGridCtrl@@UEAAXAEBVCBCGPGridColors@@HH@Z',None,P,P,I,I)
        self.set_width=bind('?SetColumnWidth@CBCGPGridCtrl@@QEAAHHH@Z',I,P,I,I)
        self.get_width=bind('?GetColumnWidth@CBCGPGridCtrl@@QEBAHH@Z',I,P,I)
        self.header=bind('?EnableHeader@CBCGPGridCtrl@@QEAAXHK@Z',None,P,I,c.c_uint32)
        self.autosize=bind('?EnableColumnAutoSize@CBCGPGridCtrl@@QEAAXH@Z',None,P,I)
        self.row_height=bind('?SetCustomRowHeight@CBCGPGridCtrl@@QEAAXHH@Z',None,P,I,I)
        self.show_vertical=bind('?ShowVertScrollBar@CBCGPGridCtrl@@QEAAXH@Z',None,P,I)
        self.show_horizontal=bind('?ShowHorzScrollBar@CBCGPGridCtrl@@QEAAXH@Z',None,P,I)
        self.adjust=bind('?AdjustLayout@CBCGPGridCtrl@@UEAAXXZ',None,P)
        # MSVC x64 CRect return uses this in RCX and result buffer in RDX;
        # verified against GetListRect's export code for the guarded build.
        self.list_rect=bind('?GetListRect@CBCGPGridCtrl@@QEBA?AVCRect@@XZ',P,P,c.POINTER(w.RECT))
        self.u.GetWindowThreadProcessId.argtypes=[w.HWND,c.POINTER(w.DWORD)]
        self.u.GetClassNameW.argtypes=[w.HWND,w.LPWSTR,c.c_int]
        self.u.GetWindowTextW.argtypes=[w.HWND,w.LPWSTR,c.c_int]
        self.u.GetWindowRect.argtypes=[w.HWND,c.POINTER(w.RECT)]
        self.u.GetClientRect.argtypes=[w.HWND,c.POINTER(w.RECT)]
        self.u.GetDpiForWindow.argtypes=[w.HWND];self.u.GetDpiForWindow.restype=w.UINT
        self.u.GetSystemMetricsForDpi.argtypes=[c.c_int,w.UINT];self.u.GetSystemMetricsForDpi.restype=c.c_int
        self.u.GetParent.argtypes=[w.HWND];self.u.GetParent.restype=w.HWND
        self.u.SendMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM]
        self.u.SendMessageW.restype=c.c_ssize_t
        self.u.RedrawWindow.argtypes=[w.HWND,c.c_void_p,c.c_void_p,w.UINT]
        self.handles={}
        self.geometry_keys={};self.fit_count=0;self.styled=set();self.row_profiles={}

    def locate(self):
        E=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM);windows=[];items=[]
        @E
        def child(h,unused):
            cls=c.create_unicode_buffer(256);r=w.RECT()
            self.u.GetClassNameW(h,cls,256);self.u.GetWindowRect(h,c.byref(r))
            items.append((int(h),cls.value,r.top));return True
        @E
        def top(h,unused):
            pid=w.DWORD();self.u.GetWindowThreadProcessId(h,c.byref(pid))
            if pid.value==os.getpid():
                text=c.create_unicode_buffer(256);self.u.GetWindowTextW(h,text,256)
                if text.value==self.title:windows.append(h)
            return True
        self.u.EnumWindows(top,0)
        if len(windows)!=1:raise RuntimeError('Cannot identify the owned Crank dialog')
        self.window=windows[0]
        self.u.EnumChildWindows(windows[0],child,0)
        parents={int(self.u.GetParent(h)) for h,cls,y in items if cls=='ScrollBar' and self.u.GetParent(h)}
        grids=sorted([v for v in items if v[0] in parents],key=lambda v:v[2])
        if len(grids)!=2:raise RuntimeError('Cannot identify the two native station tables')
        self.handles=dict(zip(('journal','pin'),[v[0] for v in grids]))
    def grid(self,group):
        if not self.handles:self.locate()
        obj=self.from_handle(self.handles[group])
        if not obj or not self.is_kind(obj,self.klass):raise RuntimeError('Unexpected Jupiter table runtime class')
        name=group+'_dimensions'
        if self.rows(obj,0)!=self.dlg.get_total_row(name) or self.columns(obj,0)!=self.dlg.get_total_column(name):
            raise RuntimeError('Native table dimensions differ from JDG')
        return obj

    def apply(self,editor):
        for group in ('pin','journal'):
            grid=self.grid(group);self.gridro(grid,int(editor.view=='cad' or editor.locked))
            if group not in self.styled:
                # Use the vendor grid's own one-click edit mode. This keeps
                # ordinary cell entry on PSJ/BCG instead of requiring the
                # helper's double-click selection path.
                self.edit_first_click(grid,1)
                self.highlight(grid,0);self.selection_border(grid,0);self.active_border(grid,0)
                self.lines(grid,1);self.header(grid,1,0);self.autosize(grid,0);self.row_height(grid,22,1)
                # Local theme value, no writes into the live C++ grid object.
                theme=c.create_string_buffer(c.string_at(self.get_theme(grid),420),420)
                for offset in (172,176):c.c_uint32.from_buffer(theme,offset).value=0xCCCCCC
                self.set_theme(grid,theme,1,0)
                self.styled.add(group)
            rect=w.RECT();self.u.GetClientRect(self.handles[group],c.byref(rect))
            # Five fixed parameter rows need no extra vertical scroll range.
            # The vendor otherwise reserves another row and creates coupled
            # scrollbars even when all five rows fit the compact viewport.
            horizontal=self.columns(grid,0)>6
            profile=(horizontal,rect.bottom-rect.top,self.u.GetDpiForWindow(self.handles[group]))
            if self.row_profiles.get(group)!=profile:
                self.show_vertical(grid,0);self.show_horizontal(grid,int(horizontal))
                self.adjust(grid)
                body=w.RECT();self.list_rect(grid,c.byref(body))
                scroll=self.u.GetSystemMetricsForDpi(3,profile[2]) if horizontal else 0
                height=max(16,min(22,(rect.bottom-body.top-scroll-2)//5))
                self.row_height(grid,height,1);self.adjust(grid)
                self.row_profiles[group]=profile
            key=(self.columns(grid,0),rect.right-rect.left)
            if self.geometry_keys.get(group)!=key:
                self.fit_columns(group,grid);self.geometry_keys[group]=key;self.fit_count+=1
            for col in range(self.columns(grid,0)):self.header_align(grid,col,2)
            for row in range(self.rows(grid,0)):
                native_row=self.getrow(grid,row)
                if not native_row:raise RuntimeError('Native table row is missing')
                for col in range(self.columns(grid,0)):
                    item=self.getitem(native_row,col)
                    if not item:raise RuntimeError('Native table cell is missing')
                    locked=not editor.can_edit(group,row,col)
                    self.setro(item,int(locked))
                    # Padding has no entity behind it and cannot accept input.
                    present=col==0 or col<=sum(r['group']==group for r in editor.records)
                    self.enable(item,int(present))
                    if bool(self.getro(item))!=locked:raise RuntimeError('Native readonly cell readback failed')

    def commit(self):
        for group in ('pin','journal'):self.end_edit(self.grid(group),1)

    def restore_display_values(self):
        # Escape restores GetValue/JDG data but can leave the label cache showing
        # the rejected text. A same-value JDG write restores that native label;
        # plain RedrawWindow does not. Never overwrite a newer active editor.
        with self.batch():
            for group in ('pin','journal'):
                grid=self.grid(group);name=group+'_dimensions'
                for row in range(self.rows(grid,0)):
                    native_row=self.getrow(grid,row)
                    for col in range(1,self.columns(grid,0)):
                        item=self.getitem(native_row,col)
                        if self.enabled(item) and not self.editing(item):
                            value=self.dlg.get_cell_value(name,row,col)
                            self.dlg.set_cell_value(name,row,col,value)

    def reject_padding(self,group):
        self.clear_selection(self.grid(group),None,1)

    @contextmanager
    def batch(self):
        if not self.handles:self.locate()
        handles=list(self.handles.values())
        try:
            for hwnd in handles:self.u.SendMessageW(hwnd,0x000B,0,0) # WM_SETREDRAW
            yield
        finally:
            for hwnd in handles:
                self.u.SendMessageW(hwnd,0x000B,1,0)
                self.u.RedrawWindow(hwnd,None,None,0x0085) # invalidate, erase, children; one deferred paint

    def fit_columns(self,group,grid=None):
        from crank_meshing.ui.dialog_layout import TABLE_LABEL_WIDTH, TABLE_MIN_STATIONS
        grid=grid or self.grid(group);hwnd=self.handles[group];rect=w.RECT()
        self.u.GetClientRect(hwnd,c.byref(rect))
        label=round(TABLE_LABEL_WIDTH*self.u.GetDpiForWindow(hwnd)/96)
        # Fit the initial six columns exactly; additional stations retain the
        # same data-column width and use the native horizontal scrollbar.
        # Resolve coupled native scrollbars: first fit the current list area,
        # then refill any width released when an unnecessary scrollbar hides.
        for unused in range(4):
            self.list_rect(grid,c.byref(rect));width=rect.right-rect.left
            available=max(TABLE_MIN_STATIONS,width-label-1)
            base,remainder=divmod(available,TABLE_MIN_STATIONS)
            self.set_width(grid,0,label)
            for col in range(1,self.columns(grid,0)):
                self.set_width(grid,col,base+(1 if col<=remainder else 0))
            self.adjust(grid)
            self.list_rect(grid,c.byref(rect))
            if width==rect.right-rect.left:break
