"""Preview drawing for Crank Meshing."""
import math
import struct
import zlib
from pathlib import Path

# coding: utf-8

# Drawing integrated from the retired standalone preview; form and presets omitted.
# Only render header supports an absolute TABLE XYZ label; drawing algorithms retained.
TITLE = 'Crankshaft Preview | PSJ | XZ'
IMAGE_WIDTH, IMAGE_HEIGHT = 1000, 420
FORM_WIDTH = 800  # JDG layout units at the verified Windows 125% display scale.
MAX_STATIONS = 12
JOURNAL_FIELDS = ('x', 'radius', 'width')
PIN_FIELDS = ('x', 'radius', 'width', 'throw', 'phase')
JOURNAL_COLUMNS = ('x', 'width')
PIN_COLUMNS = ('x', 'width', 'throw', 'phase')


def number(value, label, positive=False):
    try:
        result = float(value)
    except (ValueError, TypeError):
        raise ValueError(label + ': enter a number')
    if not math.isfinite(result):
        raise ValueError(label + ': enter a finite number')
    if positive and result <= 0:
        raise ValueError(label + ': must be greater than zero')
    return result


def fmt(value):
    return ('%.3f' % (0. if abs(value) < .0005 else value)).rstrip('0').rstrip('.')


def project_parameters(journals, pins, rotation=0., reference=0):
    """Validate atomically; return normalized inputs and physical XZ rectangles.

    Pin phase is relative to the selected zero pin. At crank rotation=0 that
    pin is on +Z. Global rotation applies to every pin, including the zero pin.
    Y = throw*sin(phase+rotation); Z = throw*cos(phase+rotation).
    """
    rotation = number(rotation, 'Crank rotation') % 360.
    clean = []
    for group, rows, fields in (('J', journals, JOURNAL_FIELDS), ('P', pins, PIN_FIELDS)):
        if len(rows) > MAX_STATIONS:
            raise ValueError('Maximum %d stations per group' % MAX_STATIONS)
        clean.append([{key: number(row.get(key), '%s%d %s' % (group, i+1, key),
                                  key in ('radius', 'width', 'throw'))
                       for key in fields} for i, row in enumerate(rows)])
    js, ps = clean
    if ps and not 0 <= reference < len(ps):
        raise ValueError('Select an existing zero pin')
    base = ps[reference]['phase'] % 360. if ps else 0.
    rectangles = []
    for group, rows in (('J', js), ('P', ps)):
        for i, row in enumerate(rows):
            if group == 'P':
                row['phase'] = (row['phase'] % 360. - base) % 360.
                angle = (row['phase'] + rotation) % 360.
                y = row['throw'] * math.sin(math.radians(angle))
                z = row['throw'] * math.cos(math.radians(angle))
            else:
                angle, y, z = 0., 0., 0.
            rectangle = dict(row, name=group+str(i+1), group=group, angle=angle,
                             y=y, z=z, xmin=row['x']-row['width']/2,
                             xmax=row['x']+row['width']/2,
                             zmin=z-row['radius'], zmax=z+row['radius'])
            if not all(math.isfinite(rectangle[k]) for k in ('xmin','xmax','zmin','zmax')):
                raise ValueError('Dimensions exceed the supported numeric range')
            rectangles.append(rectangle)
    return dict(journals=js, pins=ps, rotation=rotation, reference=reference,
                rectangles=rectangles)


def pin_angles(pins, a, b):
    """Positive directed ZOY separation and the smaller included angle."""
    delta = (pins[b]['phase']-pins[a]['phase']) % 360.
    return delta, min(delta, 360.-delta)


# Small embedded drafting font. No Pillow, Qt, matplotlib or Windows drawing API.
_FONT_ROWS = {
    '0':('01110','10001','10011','10101','11001','10001','01110'),
    '1':('00100','01100','00100','00100','00100','00100','01110'),
    '2':('01110','10001','00001','00010','00100','01000','11111'),
    '3':('11110','00001','00001','01110','00001','00001','11110'),
    '4':('00010','00110','01010','10010','11111','00010','00010'),
    '5':('11111','10000','10000','11110','00001','00001','11110'),
    '6':('01110','10000','10000','11110','10001','10001','01110'),
    '7':('11111','00001','00010','00100','01000','01000','01000'),
    '8':('01110','10001','10001','01110','10001','10001','01110'),
    '9':('01110','10001','10001','01111','00001','00001','01110'),
    'A':('01110','10001','10001','11111','10001','10001','10001'),
    'B':('11110','10001','10001','11110','10001','10001','11110'),
    'C':('01110','10001','10000','10000','10000','10001','01110'),
    'D':('11110','10001','10001','10001','10001','10001','11110'),
    'E':('11111','10000','10000','11110','10000','10000','11111'),
    'F':('11111','10000','10000','11110','10000','10000','10000'),
    'G':('01110','10001','10000','10111','10001','10001','01110'),
    'H':('10001','10001','10001','11111','10001','10001','10001'),
    'I':('01110','00100','00100','00100','00100','00100','01110'),
    'J':('00111','00010','00010','00010','00010','10010','01100'),
    'K':('10001','10010','10100','11000','10100','10010','10001'),
    'L':('10000','10000','10000','10000','10000','10000','11111'),
    'M':('10001','11011','10101','10101','10001','10001','10001'),
    'N':('10001','11001','11001','10101','10011','10011','10001'),
    'O':('01110','10001','10001','10001','10001','10001','01110'),
    'P':('11110','10001','10001','11110','10000','10000','10000'),
    'Q':('01110','10001','10001','10001','10101','10010','01101'),
    'R':('11110','10001','10001','11110','10100','10010','10001'),
    'S':('01111','10000','10000','01110','00001','00001','11110'),
    'T':('11111','00100','00100','00100','00100','00100','00100'),
    'U':('10001','10001','10001','10001','10001','10001','01110'),
    'V':('10001','10001','10001','10001','10001','01010','00100'),
    'W':('10001','10001','10001','10101','10101','10101','01010'),
    'X':('10001','10001','01010','00100','01010','10001','10001'),
    'Y':('10001','10001','01010','00100','00100','00100','00100'),
    'Z':('11111','00001','00010','00100','01000','10000','11111'),
    '+':('00000','00100','00100','11111','00100','00100','00000'),
    '-':('00000','00000','00000','11111','00000','00000','00000'),
    '.':('00000','00000','00000','00000','00000','00110','00110'),
    ':':('00000','00110','00110','00000','00110','00110','00000'),
    '/':('00001','00001','00010','00100','01000','10000','10000'),
    '=':('00000','00000','11111','00000','11111','00000','00000'),
    '(':('00010','00100','01000','01000','01000','00100','00010'),
    ')':('01000','00100','00010','00010','00010','00100','01000'),
    ' ':('00000',)*7,
}
INK = (36, 58, 69)
DIM = (65, 88, 99)
TEAL = (25, 96, 124)
PIN_COLOR = (182, 91, 41)
CENTER = (247, 187, 65)
DATUM = (163, 76, 13)
HIDDEN = (25, 39, 46)


def front_depth(rectangle,z):
    """Visible cylinder surface for a fixed camera on -Y looking toward +Y."""
    dz = z-rectangle['z']
    ratio = min(1.,abs(dz)/rectangle['radius'])
    return rectangle['y']-rectangle['radius']*math.sqrt(max(0.,1.-ratio*ratio))


def outline_hidden(rectangle,rectangles,x,z):
    depth = front_depth(rectangle,z)
    for other in rectangles:
        if other is rectangle: continue
        if other['xmin']-1e-10 <= x <= other['xmax']+1e-10 and other['zmin']-1e-10 <= z <= other['zmax']+1e-10:
            if front_depth(other,z)<depth-1e-9:
                return True
    return False


class Drawing:
    def __init__(self, width, height):
        self.width, self.height = width, height
        self.pixels = bytearray(b'\xff\xff\xff' * width * height)

    def pixel(self, x, y, color):
        x, y = int(round(x)), int(round(y))
        if 0 <= x < self.width and 0 <= y < self.height:
            k = (y*self.width+x)*3
            self.pixels[k:k+3] = bytes(color)

    def line(self, x1, y1, x2, y2, color=INK, dashed=False, centerline=False):
        count = max(1, int(math.ceil(max(abs(x2-x1), abs(y2-y1)))))
        for i in range(count+1):
            if (centerline and (i%20<11 or 14<=i%20<16)) or (not centerline and (not dashed or i%9<5)):
                self.pixel(x1+(x2-x1)*i/count, y1+(y2-y1)*i/count, color)

    def rect(self, x1, y1, x2, y2, color=TEAL):
        a, b = sorted((max(0, min(self.width, round(x1))), max(0, min(self.width, round(x2)))))
        c, d = sorted((max(0, min(self.height, round(y1))), max(0, min(self.height, round(y2)))))
        for y in range(c, d):
            k = (y*self.width+a)*3
            self.pixels[k:k+(b-a)*3] = bytes(color)*(b-a)

    def text(self, x, y, text, color=INK, scale=1, center=False, vertical=False):
        text = str(text).upper()
        length = max(0, len(text)*6-1)*scale
        if center:
            if vertical: y += length/2
            else: x -= length/2
        for index, char in enumerate(text):
            for gy, row in enumerate(_FONT_ROWS.get(char, _FONT_ROWS[' '])):
                for gx, value in enumerate(row):
                    if value == '1':
                        for sy in range(scale):
                            for sx in range(scale):
                                u, v = (index*6+gx)*scale+sx, gy*scale+sy
                                self.pixel(x+v if vertical else x+u,
                                           y-u if vertical else y+v, color)

    def arrow(self, x1, y1, x2, y2, color=DIM):
        self.line(x1, y1, x2, y2, color)
        angle = math.atan2(y2-y1, x2-x1)
        for offset in (-.45, .45):
            self.line(x2, y2, x2-5*math.cos(angle+offset), y2-5*math.sin(angle+offset), color)

    def circle(self,x,y,r,color=INK):
        for i in range(32):
            a,b = i*math.tau/32,(i+1)*math.tau/32
            self.line(x+r*math.cos(a),y+r*math.sin(a),x+r*math.cos(b),y+r*math.sin(b),color)

    def h_dimension(self, a, b, anchor_a, anchor_b, y, label):
        self.line(a, anchor_a, a, y+4, DIM)
        self.line(b, anchor_b, b, y+4, DIM)
        self.arrow(a, y, b, y)
        self.arrow(b, y, a, y)
        span = (len(label)*6+3)
        self.rect((a+b-span)/2, y-12, (a+b+span)/2, y-2, (255,255,255))
        self.text((a+b)/2, y-10, label, DIM, center=True)

    def save(self, path, output_size=None):
        if Path(path).suffix.lower()=='.bmp':
            stride=(self.width*3+3)&~3;rows=[]
            for y in range(self.height-1,-1,-1):
                row=self.pixels[y*self.width*3:(y+1)*self.width*3];bgr=bytearray(len(row))
                bgr[0::3]=row[2::3];bgr[1::3]=row[1::3];bgr[2::3]=row[0::3]
                rows.append(bytes(bgr)+b'\0'*(stride-len(bgr)))
            pixels=b''.join(rows);header=struct.pack('<2sIHHI',b'BM',54+len(pixels),0,0,54)
            info=struct.pack('<IiiHHIIiiII',40,self.width,self.height,1,24,0,len(pixels),0,0,0,0)
            Path(path).write_bytes(header+info+pixels);return
        if output_size and tuple(output_size)!=(self.width,self.height):
            # Fit the complete existing drawing into JDG's native image frame.
            # JDG centers/crops oversized bitmaps rather than scaling them.
            width,height=output_size
            resized=Drawing(width,height)
            for y in range(height):
                y1=int(y*self.height/height);y2=max(y1+1,int((y+1)*self.height/height))
                for x in range(width):
                    x1=int(x*self.width/width);x2=max(x1+1,int((x+1)*self.width/width))
                    samples=[(sy*self.width+sx)*3 for sy in range(y1,min(y2,self.height))
                             for sx in range(x1,min(x2,self.width))]
                    b=(y*width+x)*3
                    resized.pixels[b:b+3]=bytes(sum(self.pixels[a+k] for a in samples)//len(samples) for k in range(3))
            return resized.save(path)
        def chunk(kind, data):
            return struct.pack('>I', len(data))+kind+data+struct.pack('>I', zlib.crc32(kind+data)&0xffffffff)
        raw = b''.join(b'\0'+self.pixels[y*self.width*3:(y+1)*self.width*3] for y in range(self.height))
        png = b'\x89PNG\r\n\x1a\n'
        png += chunk(b'IHDR', struct.pack('>IIBBBBB', self.width, self.height, 8, 2, 0, 0, 0))
        png += chunk(b'IDAT', zlib.compress(raw))+chunk(b'IEND', b'')
        Path(path).write_bytes(png)


def render_preview(plan, path, dimensions=True, grid=True, output_size=None):
    """Equal X/Z scale, fit all envelopes, fixed lower-left orientation logo."""
    d = Drawing(IMAGE_WIDTH, IMAGE_HEIGHT)
    rects = plan['rectangles']
    d.text(20, 14, 'OXZ / MM', scale=2)
    d.text(260, 18, 'ROTATION '+fmt(plan['rotation'])+' DEG / '+
           plan.get('orientation_label', 'ZERO '+('P%d' % (plan['reference']+1) if plan['pins'] else '-')))
    left, right, top, bottom = 75, IMAGE_WIDTH-245, 64, IMAGE_HEIGHT-110
    screen = []
    hidden_samples = 0
    if rects:
        xmin = min(0.,min(r['xmin'] for r in rects))
        xmax = max(0.,max(r['xmax'] for r in rects))
        zmin = min(0., min(r['zmin'] for r in rects))
        zmax = max(0., max(r['zmax'] for r in rects))
        dx, dz = xmax-xmin, zmax-zmin
        if not all(math.isfinite(v) and v > 0 for v in (dx,dz)):
            raise ValueError('Geometry extents must be finite and nonzero')
        scale = min((right-left)/dx, (bottom-top)/dz)
        cx, cz = xmin+dx/2, zmin+dz/2
        def sx(x): return (left+right)/2+(x-cx)*scale
        def sz(z): return (top+bottom)/2-(z-cz)*scale
        if grid:
            # Screen grid is decorative; dimension values always come from mm.
            for x in range(18, int(right)+25, 24):
                d.line(x, top-18, x, bottom+8, (234,238,241))
            for y in range(top-18, bottom+9, 24):
                d.line(18, y, right+18, y, (234,238,241))
        d.line(26, sz(0), right+18, sz(0), (123,146,156), dashed=True)
        d.line(sx(0),top-25,sx(0),bottom+91,DATUM,dashed=True)
        d.text(sx(0),top-38,'0',DATUM,center=True)
        # A cylinder's front depth varies with Z. Paint each scanline far to
        # near using the actual circular section, rather than sorting center Y.
        for py in range(max(0,int(top)),min(IMAGE_HEIGHT,int(bottom)+1)):
            z = cz+((top+bottom)/2-py)/scale
            covering = [r for r in rects if r['zmin']<=z<=r['zmax']]
            for r in sorted(covering,key=lambda r:front_depth(r,z),reverse=True):
                d.rect(sx(r['xmin']),py,sx(r['xmax'])+1,py+1,
                       TEAL if r['group']=='J' else PIN_COLOR)
        # Only truly occluded outline portions are dashed. Hidden edges are
        # drawn after fills so they remain legible through the front surface.
        for r in rects:
            for a,b in (((r['xmin'],r['zmax']),(r['xmax'],r['zmax'])),
                        ((r['xmin'],r['zmin']),(r['xmax'],r['zmin'])),
                        ((r['xmin'],r['zmin']),(r['xmin'],r['zmax'])),
                        ((r['xmax'],r['zmin']),(r['xmax'],r['zmax']))):
                count = max(1,int(math.ceil(max(abs(sx(b[0])-sx(a[0])),abs(sz(b[1])-sz(a[1]))))))
                for i in range(count+1):
                    x,z = a[0]+(b[0]-a[0])*i/count,a[1]+(b[1]-a[1])*i/count
                    hidden = outline_hidden(r,rects,x,z)
                    if hidden: hidden_samples += 1
                    if not hidden or i%9<5:
                        d.pixel(sx(x),sz(z),HIDDEN if hidden else (10,49,65))
        occupied_widths = []
        for r in rects:
            x1,x2,y1,y2 = sx(r['xmin']),sx(r['xmax']),sz(r['zmax']),sz(r['zmin'])
            px,pz = sx(r['x']),sz(r['z'])
            d.line(x1-4,pz,x2+4,pz,(227,242,247),centerline=True)
            d.line(px,y1-4,px,y2+4,(227,242,247),centerline=True)
            d.circle(px,pz,5,(10,49,65))
            d.circle(px,pz,4,CENTER)
            d.line(px-9,pz,px+9,pz,CENTER)
            d.line(px,pz-9,px,pz+9,CENTER)
            d.rect(px-1,pz-1,px+2,pz+2,(255,255,255))
            # Outside tags stay readable even for physically very narrow inserts.
            d.text(px, y2+6, r['name'], center=True)
            screen.append(dict(name=r['name'], bounds=[x1,y1,x2,y2], center=[px,pz]))
            if dimensions:
                label = fmt(r['width'])
                half = (len(label)*6+6)/2
                base = y1-15
                # Reserve label boxes and stagger only when neighboring widths
                # cannot fit on the same tier. Witness lines still use true ends.
                for tier in range(5):
                    yy = base-14*tier
                    box = (px-half,yy-12,px+half,yy)
                    if not any(box[0]<b[2] and box[2]>b[0] and box[1]<b[3] and box[3]>b[1]
                               for b in occupied_widths): break
                occupied_widths.append(box)
                d.h_dimension(x1,x2,y1-2,y1-2,yy,label)
        if dimensions:
            # One radius per type. Pick an outer journal and the highest pin so
            # radial dimensions occupy open space rather than neighboring blocks.
            for group in ('J','P'):
                rows = [r for r in rects if r['group']==group]
                if not rows: continue
                r = min(rows,key=lambda r:r['x']) if group=='J' else max(rows,key=lambda r:(r['z'],-r['x']))
                xx,y1,y2 = sx(r['xmin'])-18,sz(r['zmax']),sz(r['z'])
                d.line(xx-3,y1,sx(r['xmin'])-2,y1,DIM)
                d.line(xx-3,y2,sx(r['xmin'])-2,y2,DIM)
                d.arrow(xx,y1,xx,y2)
                d.arrow(xx,y2,xx,y1)
                d.text(xx-13,(y1+y2)/2,'R'+fmt(r['radius']),DIM,center=True,vertical=True)
            # Ordinate dimensions: every station is measured from the same X=0
            # center datum. Two rails separate Journal and Pin; no nested chains.
            for group, y in (('J',bottom+42),('P',bottom+78)):
                rows = sorted((r for r in rects if r['group']==group),key=lambda r:r['x'])
                if not rows: continue
                d.text(100,y-3,group+' X')
                d.line(min(sx(rows[0]['x']),sx(0)),y,max(sx(rows[-1]['x']),sx(0)),y,DIM)
                d.circle(sx(0),y,3,DATUM)
                for r in rows:
                    xx = sx(r['x'])
                    d.arrow(xx,y-21,xx,y,DIM)
                    d.text(xx,y-31,r['name'],DIM,center=True)
                    d.text(xx,y+6,fmt(r['x']),DIM,center=True)
        d.text(260,IMAGE_HEIGHT-13,'MM / X DIMENSIONS FROM CENTER (0)')
        if dimensions:
            # Phases/true eccentricities cannot be measured as angles/lengths
            # in the fixed XZ projection. Keep their true ZOY values in a note.
            d.line(795,45,795,bottom+8,(205,216,222))
            d.text(810,49,'PIN / ZOY',scale=2)
            d.text(810,73,'THROW / PHASE')
            for i,r in enumerate(r for r in rects if r['group']=='P'):
                yy = 111+i*15
                d.text(810,yy,r['name']+' '+fmt(r['throw'])+' MM / '+fmt(r['phase'])+' DEG',DIM)
            d.text(810,bottom+20,'TRUE VALUES IN ZOY')
            if hidden_samples:
                d.line(810,bottom+52,850,bottom+52,HIDDEN,dashed=True)
                d.text(860,bottom+49,'HIDDEN EDGE')
    else:
        d.text(IMAGE_WIDTH/2,180,'ADD JOURNAL OR PIN STATIONS',scale=2,center=True)
    # Absolute screen coordinates: independent of bounds, rotation and fitting.
    ox, oz = 28, IMAGE_HEIGHT-22
    d.arrow(ox,oz,ox+40,oz,INK)
    d.arrow(ox,oz,ox,oz-40,INK)
    d.text(ox+45,oz-3,'X',scale=2)
    d.text(ox-4,oz-58,'Z',scale=2)
    d.text(ox-12,oz+4,'O')
    d.rect(810,15,820,25,TEAL)
    d.text(825,17,'JOURNAL')
    d.rect(910,15,920,25,PIN_COLOR)
    d.text(925,17,'PIN')
    d.save(path,output_size)
    return dict(width=IMAGE_WIDTH,height=IMAGE_HEIGHT,projection='XZ',
                x_direction='right',z_direction='up',logo_origin=[ox,oz],rectangles=screen,
                camera='-Y looking toward +Y',hidden_edge_samples=hidden_samples,
                radius_dimensions=[dict(group=g,radius=next(r['radius'] for r in rects if r['group']==g))
                                   for g in ('J','P') if dimensions and any(r['group']==g for r in rects)],
                width_dimensions=[dict(name=r['name'],width=r['width']) for r in rects if dimensions],
                x_ordinates=[dict(name=r['name'],datum=0.,value=r['x']) for r in rects if dimensions])


def station_names(names):
    parts=[]
    for group in ('J','P'):
        ids=sorted(int(n[1:]) for n in names if n.startswith(group))
        for value in ids:
            if parts and parts[-1][0]==group and parts[-1][-1]+1==value:parts[-1].append(value)
            else:parts.append([group,value])
    return ' '.join(p[0]+str(p[1])+('-'+str(p[-1]) if len(p)>2 else '') for p in parts)


def z_coordinate(value):
    """Signed engineering ordinates; retain small CAD offsets instead of ranges."""
    precision=6 if 0<abs(value)<.01 else 3
    if abs(value)<.5e-6:return '0.000'
    return ('%+.*f'%(precision,value))


def ordinate_label_positions(actual,low,high,gap):
    """Closest ordered label rows with a minimum gap (isotonic regression)."""
    if not actual:return []
    gap=min(gap,(high-low)/max(1,len(actual)-1))
    blocks=[]
    for i,y in enumerate(actual):
        blocks.append([float(y)-i*gap,1])
        while len(blocks)>1 and blocks[-2][0]>blocks[-1][0]:
            b=blocks.pop();a=blocks.pop();count=a[1]+b[1]
            blocks.append([(a[0]*a[1]+b[0]*b[1])/count,count])
    upper=high-(len(actual)-1)*gap
    bases=[max(low,min(upper,mean)) for mean,count in blocks for _ in range(count)]
    return [y+i*gap for i,y in enumerate(bases)]


def coordinate_ticks(low,high,step):
    """World-coordinate ticks, anchored at zero rather than bitmap margins."""
    first=math.ceil(low/step-1e-10);last=math.floor(high/step+1e-10)
    return [0. if i==0 else i*step for i in range(first,last+1)]


def coordinate_step(scale,ui_scale):
    target=18.*ui_scale/scale
    decade=10.**math.floor(math.log10(target))
    return next(factor*decade for factor in (1.,2.,5.,10.) if factor*decade>=target)


def render_table_preview(plan,path,dimensions=True,grid=True,output_size=(500,280)):
    """XZ coordinate grid; only Pin centers have Z-to-zero dimensions."""
    width,height=output_size;d=Drawing(width,height)
    k=width/500.;font=max(1,round(k));rects=plan['rectangles']
    left,right,top,bottom=16*k,width-8*k,30*k,height-91*k
    report=dict(width=width,height=height,projection='XZ',side_legend=False,
                radius_dimensions=[],width_dimensions=[],x_ordinates=[],z_ordinates=[],rectangles=[],z_axis=None,
                coordinate_grid=None,pin_z_dimensions=[],journal_z_dimensions=[])
    if not rects:
        d.text(width/2,height/2,'SELECT JOURNAL / PIN FACES',scale=font,center=True)
        d.save(path);return report
    xmin=min(0.,min(r['xmin'] for r in rects));xmax=max(0.,max(r['xmax'] for r in rects))
    zmin=min(0.,min(r['zmin'] for r in rects));zmax=max(0.,max(r['zmax'] for r in rects))
    dx,dz=xmax-xmin,zmax-zmin
    if not all(math.isfinite(v) and v>0 for v in (dx,dz)):
        raise ValueError('Preview extents must be finite and nonzero')
    scale=min((right-left-28*k)/dx,(bottom-top)/dz);cx=xmin+dx/2;cz=zmin+dz/2
    def sx(x):return (left+right)/2+(x-cx)*scale
    def sz(z):return (top+bottom)/2-(z-cz)*scale
    step=coordinate_step(scale,k)
    xlo=cx+(left-(left+right)/2)/scale;xhi=cx+(right-(left+right)/2)/scale
    zlo=cz+((top+bottom)/2-bottom)/scale;zhi=cz+((top+bottom)/2-top)/scale
    xticks=[dict(value=v,screen_x=sx(v)) for v in coordinate_ticks(xlo,xhi,step)]
    zticks=[dict(value=v,screen_y=sz(v),label=fmt(v)) for v in coordinate_ticks(zlo,zhi,step)]
    report['coordinate_grid']=dict(step_mm=step,visible=bool(grid),x_ticks=xticks,z_ticks=zticks,
        plot=[left,top,right,bottom],pixels_per_mm=scale)
    if grid:
        for tick in xticks:d.line(tick['screen_x'],top,tick['screen_x'],bottom,(230,236,241))
        for tick in zticks:d.line(left,tick['screen_y'],right,tick['screen_y'],(230,236,241))
    d.line(sx(0),bottom,sx(0),height-12*k,DATUM,dashed=True)
    origin=(sx(0),sz(0))
    report['datum']=dict(x_mm=0.,z_mm=0.,label='X = 0 mm',z_label='Z = 0 mm',screen_x=sx(0),screen_z=sz(0),origin=list(origin))
    # Same actual circular front-depth / hidden-edge logic as the passed tool.
    for py in range(round(top),round(bottom)+1):
        z=cz+((top+bottom)/2-py)/scale
        for r in sorted((r for r in rects if r['zmin']<=z<=r['zmax']),
                        key=lambda r:front_depth(r,z),reverse=True):
            d.rect(sx(r['xmin']),py,sx(r['xmax'])+1,py+1,TEAL if r['group']=='J' else PIN_COLOR)
    for r in rects:
        for a,b in (((r['xmin'],r['zmax']),(r['xmax'],r['zmax'])),
                    ((r['xmin'],r['zmin']),(r['xmax'],r['zmin'])),
                    ((r['xmin'],r['zmin']),(r['xmin'],r['zmax'])),
                    ((r['xmax'],r['zmin']),(r['xmax'],r['zmax']))):
            count=max(1,math.ceil(max(abs(sx(b[0])-sx(a[0])),abs(sz(b[1])-sz(a[1])))))
            for i in range(count+1):
                x=a[0]+(b[0]-a[0])*i/count;z=a[1]+(b[1]-a[1])*i/count
                if not outline_hidden(r,rects,x,z) or i%9<5:d.pixel(sx(x),sz(z),HIDDEN)
        px,pz=sx(r['x']),sz(r['z'])
        d.line(px-5*k,pz,px+5*k,pz,CENTER);d.line(px,pz-5*k,px,pz+5*k,CENTER)
        yy=sz(r['zmin'])+4*k
        d.text(px,yy,r['name'],scale=font,center=True)
        if dimensions:
            below=False # Width dimensions always sit above Journal and Pin.
            y1=sz(r['zmin'] if below else r['zmax']);rail=y1+28*k if below else y1-10*k
            d.line(sx(r['xmin']),y1,sx(r['xmin']),rail+2*k if below else rail-2*k,DIM)
            d.line(sx(r['xmax']),y1,sx(r['xmax']),rail+2*k if below else rail-2*k,DIM)
            d.arrow(sx(r['xmin']),rail,sx(r['xmax']),rail,DIM)
            d.arrow(sx(r['xmax']),rail,sx(r['xmin']),rail,DIM)
            label=fmt(r['width']);text_width=(len(label)*6-1)*font
            outside=text_width>1.05*(sx(r['xmax'])-sx(r['xmin']))
            tx=sx(r['xmax'])+7*k+text_width/2 if outside else px
            if outside:d.line(sx(r['xmax']),rail,tx+text_width/2+3*k,rail,DIM)
            d.text(tx,rail-7*font-4*k,label,DIM,scale=font,center=True)
            report['width_dimensions'].append(dict(name=r['name'],width=r['width'],label_outside=outside,side='below' if below else 'above'))
            report['z_ordinates'].append(dict(name=r['name'],datum=0.,value=r['z']))
        report['rectangles'].append(dict(name=r['name'],bounds=[sx(r['xmin']),sz(r['zmax']),sx(r['xmax']),sz(r['zmin'])],center=[px,pz]))
    if dimensions:
        # Axes identify the zero datums without a numbered vertical ruler.
        zfont=max(1,int(k))
        report['z_axis']=dict(datum=0.,label='Z',style='coordinate-axes',screen_x=sx(0),ticks=[])
        # Center offsets from X for both groups; outside text at 105% of span.
        for r in rects:
            if abs(round(r['z'],3))==0:continue
            xx=sx(r['xmin'])-7*k;y0=sz(0.);y1=sz(r['z']);label=fmt(round(r['z'],3))
            text_length=(len(label)*6-1)*zfont
            outside=text_length>1.05*abs(y1-y0)
            d.line(sx(r['x']),y0,xx-3*k,y0,DIM)
            d.line(sx(r['x']),y1,xx-3*k,y1,DIM)
            if not outside:
                d.arrow(xx,y0,xx,y1,DIM);d.arrow(xx,y1,xx,y0,DIM)
                d.text(xx-7*zfont-4*k,(y0+y1)/2,label,DIM,scale=zfont,center=True,vertical=True)
            else:
                down=r['group']=='P' and r['z']<0
                end=max(y0,y1)+30*k if down else min(y0,y1)-18*k
                d.line(xx,min(y0,y1)-5*k if down else max(y0,y1)+5*k,xx,end,DIM)
                if abs(y1-y0)>2*k:
                    d.arrow(xx,y0+7*k,xx,y0,DIM);d.arrow(xx,y1-7*k,xx,y1,DIM)
                tx=max(3*k,xx-text_length-4*k)
                d.line(min(tx-3*k,xx),end,max(xx,tx+text_length+3*k),end,DIM)
                d.text(tx,end-7*zfont-4*k,label,DIM,scale=zfont)
            report['journal_z_dimensions' if r['group']=='J' else 'pin_z_dimensions'].append(dict(name=r['name'],datum=0.,value=r['z'],distance=abs(r['z']),
                label=label,side='left',label_outside=outside,external_direction='below' if outside and r['group']=='P' and r['z']<0 else 'above',from_point=[xx,y0],to_point=[xx,y1]))
        for group,y in (('J',height-53*k),('P',height-20*k)):
            rows=[r for r in rects if r['group']==group]
            if not rows:continue
            d.line(min(sx(0),min(sx(r['x']) for r in rows)),y,
                   max(sx(0),max(sx(r['x']) for r in rows)),y,DIM)
            for r in rows:
                x=sx(r['x']);d.line(x,y-5*k,x,y+3*k,DIM)
                d.text(x,y-16*k,r['name'],DIM,scale=font,center=True)
                d.text(x,y+6*k,fmt(r['x']),DIM,scale=font,center=True)
                report['x_ordinates'].append(dict(name=r['name'],datum=0.,value=r['x']))
            d.circle(sx(0),y,3*k,DATUM)
    # Outside the silhouettes, both zero references remain visible at any pose.
    # Draw reference axes over the silhouettes, with only their direction labels.
    axis_color=(160,30,30)
    for offset in (0,1):
        d.line(left,sz(0)+offset,right,sz(0)+offset,axis_color,dashed=True)
        d.line(sx(0)+offset,bottom,sx(0)+offset,top-10*k,axis_color,dashed=True)
    for end,angle in (((right,sz(0)),0.),((sx(0),top-10*k),-math.pi/2)):
        for delta in (-.45,.45):
            d.line(end[0],end[1],end[0]-6*k*math.cos(angle+delta),end[1]-6*k*math.sin(angle+delta),axis_color)
    d.text(right+2*k,sz(0)+6*k,'X',axis_color,scale=font)
    d.text(sx(0)+6*k,top-17*k,'Z',axis_color,scale=font)
    d.circle(*origin,3*k,DATUM)
    d.save(path);return report
