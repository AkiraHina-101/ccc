"""Shaft alignment for Crank Meshing."""
import math
from copy import deepcopy
import time
from crank_meshing.model_parts import native_transaction
from crank_meshing.model_parts import model_stamp

def dot(a,b):return sum(x*y for x,y in zip(a,b))
def sub(a,b):return [x-y for x,y in zip(a,b)]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def unit(a):
    length=math.sqrt(dot(a,a))
    if length<1e-15:raise ValueError('Cannot determine the Journal shaft axis')
    return [v/length for v in a]


def canonical_axis(vector):
    result=unit(vector)
    pivot=next(k for k in range(3) if abs(result[k])>1e-6)
    return [-v for v in result] if result[pivot]<0 else result


def shaft_frame(records, effective=None):
    """Use CAD cylinder direction; center X on the effective middle Journal(s)."""
    journals=[r for r in records if r['group']=='journal']
    if not journals:raise ValueError('Select Journal faces to define the shaft axis')
    axis=journals[0].get('axis_vector')
    if axis is None:axis=[float(k=='XYZ'.index(journals[0].get('axis','X'))) for k in range(3)]
    ex=canonical_axis(axis)
    for row in records:
        direction=row.get('axis_vector')
        if direction is not None and abs(dot(unit(direction),ex))<1-1e-8:
            raise ValueError('Journal and Pin cylinder axes must be parallel')
    seed=[0.,1.,0.] if abs(ex[1])<.9 else [0.,0.,1.]
    ey=unit(sub(seed,[v*dot(seed,ex) for v in ex]));ez=cross(ex,ey)
    # CAD line location is independent of user edits to individual insert Y/Z.
    transverse=[[dot(r['center']['xyz_m'],v) for v in (ey,ez)] for r in journals]
    center=[sum(p[k] for p in transverse)/len(transverse) for k in range(2)]
    if any(math.dist(p,center)>5e-6 for p in transverse):
        raise ValueError('Journal faces do not share the crank axis')
    stations=sorted(dot(r['center']['xyz_m'],ex) for r in (effective or records) if r['group']=='journal')
    mid=len(stations)//2
    axial=stations[mid] if len(stations)%2 else (stations[mid-1]+stations[mid])/2
    origin=[axial*ex[k]+center[0]*ey[k]+center[1]*ez[k] for k in range(3)]
    return dict(origin=origin,rows=[ex,ey,ez],datum='middle Journal' if len(stations)%2 else 'midpoint of middle Journals')


def point(frame,xyz):return [dot(row,sub(xyz,frame['origin'])) for row in frame['rows']]


def rotation_frame(angle):
    angle=float(angle)
    if not math.isfinite(angle):raise ValueError('Pin angle must be finite')
    sn,cs=math.sin(math.radians(angle)),math.cos(math.radians(angle))
    return dict(origin=[0.,0.,0.],rows=[[1.,0.,0.],[0.,cs,-sn],[0.,sn,cs]],angle=angle)


def pin_phase(records,zero_face,frame):
    pin=next((r for r in records if r['group']=='pin' and r['face_id']==zero_face),None)
    if pin is None:raise ValueError('Select an existing zero pin')
    _,y,z=point(frame,pin['center']['xyz_m'])
    if math.hypot(y,z)<1e-12:raise ValueError('Zero pin lies on the Journal shaft')
    return math.degrees(math.atan2(y,z))%360.


def aligned_frame(cad,effective=None,zero_face=None,angle=None):
    effective=cad if effective is None else effective
    frame=shaft_frame(cad,effective)
    phase=pin_phase(effective,zero_face,frame) if zero_face is not None else 0.
    angle=phase if angle is None else float(angle)
    if not math.isfinite(angle):raise ValueError('Pin angle must be finite')
    ey,ez=frame['rows'][1:];sn,cs=math.sin(math.radians(angle)),math.cos(math.radians(angle))
    frame['rows'][1]=[y*cs-z*sn for y,z in zip(ey,ez)]
    frame['rows'][2]=[z*cs+y*sn for y,z in zip(ey,ez)]
    frame.update(zero_face=zero_face,angle=angle,cad_pin_angle=phase)
    return frame


def transform_records(records,frame,preserve_order=False):
    result=deepcopy(records)
    for row in result:
        xyz=point(frame,row['center']['xyz_m'])
        row['center']['xyz_m']=xyz
        row.update(axis='X',axis_vector=[1.,0.,0.],
            boundary_planes_m=[xyz[0]-row['width_m']/2,xyz[0]+row['width_m']/2])
    return result if preserve_order else sorted(result,key=lambda r:(r['group']!='journal',r['center']['xyz_m'][0]))


def execution_geometry(cad,inputs,options):
    """Prepare both CAD transform and insert targets once for preview and Apply.

    Final-frame inputs are coordinates in the resulting model, so overrides
    must be applied AFTER the rigid CAD transform, never transformed twice.
    Legacy recorded runs retain their original pre-transform input contract.
    """
    from crank_meshing.shaft_parameters import effective_geometry
    final=bool(inputs and inputs.get('coordinate_frame')=='final')
    source=cad if final else effective_geometry(cad,inputs)
    frame=aligned_frame(cad,source,options.get('zero_face'),options.get('angle'))
    baseline=transform_records(cad,frame,preserve_order=True)
    effective=(effective_geometry(baseline,inputs) if final else
        transform_records(source,frame,preserve_order=True))
    return frame,baseline,effective


def apply_native(session,groups,inputs,options):
    """Transform the one source part once, before helper nodes or meshing exist."""
    from crank_meshing.cad_geometry import preview_faces
    from Tools.Measure.Radius import Edge
    from Geometry.Transform import ThreePoints
    from macro_defs import Part
    jpt=session.jpt
    from crank_meshing.model_parts import capture_sources
    parts,crank=capture_sources(session,groups)
    radius=lambda e:Edge('%d:%d'%(e.typeID,e.id),iPrecision=12)
    cad=preview_faces(jpt,groups,radius)
    frame,expected,effective=execution_geometry(cad,inputs,options)
    # Read a few existing boundary nodes, not the complete node database.
    wanted={r['face_id'] for r in cad};sample={}
    for face in jpt.GetAllFaces():
        if int(face.id) not in wanted:continue
        for edge in face.edges:
            for node in list(edge.nodes)[:3]:
                sample[int(node.id)]=[float(node.pos.x),float(node.pos.y),float(node.pos.z)]
    origin=frame['origin'];rows=frame['rows'];span=.1
    original=[origin,[a+span*b for a,b in zip(origin,rows[0])],
              [a+span*b for a,b in zip(origin,rows[1])]]
    target=[[0.,0.,0.],[span,0.,0.],[0.,span,0.]]
    checkpoint=dict(started=True,verified=False,frame=frame,original_cad=cad,
        effective_geometry=effective,sampled_nodes=len(sample))
    session.state['alignment']=checkpoint;session.save()
    session.operation('alignment.Geometry.Transform.ThreePoints',lambda:ThreePoints(
        [Part(int(p.id)) for p in parts],original,target,bCreateNewPart=False))
    if {int(p.key) for p in jpt.GetAllParts()}!={int(p.key) for p in parts}:
        raise RuntimeError('Native alignment changed source part ownership')
    actual=preview_faces(jpt,groups,radius)
    byid={r['face_id']:r for r in actual}
    errors=[]
    for row in expected:
        now=byid[row['face_id']]
        errors.append(math.dist(now['center']['xyz_m'],row['center']['xyz_m']))
        if abs(now['radius_m']-row['radius_m'])>1e-8 or abs(now['width_m']-row['width_m'])>1e-8:
            raise RuntimeError('Native alignment changed cylinder dimensions')
        if abs(now['axis_vector'][0])<1-1e-8:raise RuntimeError('Native alignment did not align the shaft to X')
    for nid,xyz in sample.items():
        found=jpt.GetEntitiesByID(jpt.DItemType.NODE,nid)
        if len(found)!=1:raise RuntimeError('Native alignment lost a boundary node')
        node=jpt.CastDItemToDNode(found[0])
        errors.append(math.dist([float(node.pos.x),float(node.pos.y),float(node.pos.z)],point(frame,xyz)))
    if errors and max(errors)>1e-8:raise RuntimeError('Native alignment coordinate readback differs')
    checkpoint.update(verified=True,max_error_m=max(errors,default=0.))
    session.context['aligned_effective']=effective
    session.context['cad_preview']=actual
    session.save()
    return checkpoint




def helper_ids(session):
    ids=[r['center']['node_id'] for r in session.state['geometry']]
    for entry in session.state.get('preparation',{}).get('manual_renumber',[]):
        if entry.get('verified'):
            mapping={int(k):v for k,v in entry.get('mapping',{}).items()}
            ids=[mapping.get(n,n) for n in ids]
    return ids


def rotate_completed(flow,angle):
    session=flow.session;jpt=session.jpt;session.require_document()
    if session.busy:raise ValueError('A step is already running')
    if not session.state.get('grouping_complete') or not session.state.get('volume_complete'):
        raise ValueError('Complete meshing before using Rotate')
    frame=rotation_frame(angle)
    if abs(float(angle)%360.)<1e-12:return dict(verified=True,angle=float(angle),seconds=0.,noop=True)
    history=session.state.setdefault('post_mesh_rotations',[])
    if history and history[-1].get('started') and not history[-1].get('verified'):
        raise ValueError('The last rotation was interrupted; inspect its checkpoint before continuing')
    parts=list(jpt.GetAllParts());parts_before=[(int(p.id),int(p.key)) for p in parts]
    expected=set(session.state['source_part_keys'])|set(flow.preparation.progress['batch']['part_keys'])
    if not expected.issubset({key for pid,key in parts_before}):raise ValueError('Activate the completed crank model for this run')
    def connections():return {int(c.id):(tuple(int(n.id) for n in c.masters),tuple(int(n.id) for n in c.slaves))
        for c in jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION)}
    rigids=connections();sample={}
    for c in jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION):
        for item in list(c.masters)+list(c.slaves):
            n=jpt.CastDItemToDNode(item)
            sample[int(n.id)]=[float(n.pos.x),float(n.pos.y),float(n.pos.z)]
    helpers=helper_ids(session)
    for nid in helpers:
        found=jpt.GetEntitiesByID(jpt.DItemType.NODE,nid)
        if len(found)!=1:raise RuntimeError('Measurement helper node is missing')
        node=jpt.CastDItemToDNode(found[0]);sample[nid]=[float(node.pos.x),float(node.pos.y),float(node.pos.z)]
    index=session.context.get('_model_index');warm=index is not None and index.current()
    # Check the licensed helper-node API before rotating any part. A rejected
    # license must leave the completed model in its original orientation.
    from MeshEdit.MoveNode import Absolute
    if helpers:
        xyz=sample[helpers[0]]
        response=Absolute(*xyz,crlNodes='[10:%d]'%helpers[0])
        if str(response)=='0':raise RuntimeError('Native helper-node preflight failed')
    counts=(jpt.GetCountByType(jpt.DItemType.NODE),jpt.GetCountByType(jpt.DItemType.ELEM))
    entry=dict(started=True,verified=False,angle=float(angle),command='Geometry.Transform.ThreePoints',
        scope='Rigid rotation of all current model parts about global X; no meshing')
    history.append(entry);session.busy=True;start=time.monotonic();session.save()
    if warm:index.stamp=None
    try:
        from Geometry.Transform import ThreePoints
        from macro_defs import Part
        original=[[0.,0.,0.],[.1,0.,0.],[0.,.1,0.]]
        with native_transaction(jpt,'Crank rotate completed model'):
            entry['response']=str(ThreePoints([Part(pid) for pid,key in parts_before],original,
                [point(frame,p) for p in original],bCreateNewPart=False))
            # Part transforms omit seven free measurement helpers. Move only
            # those known IDs; all actual mesh and RBE2 nodes move natively.
            for nid in helpers:
                target=point(frame,sample[nid])
                response=Absolute(*target,crlNodes='[10:%d]'%nid)
                if str(response)=='0':raise RuntimeError('Native helper-node rotation failed')
        errors=[]
        for nid,xyz in sample.items():
            found=jpt.GetEntitiesByID(jpt.DItemType.NODE,nid)
            if len(found)!=1:raise RuntimeError('Rotation lost a checked node')
            node=jpt.CastDItemToDNode(found[0]);pos=[float(node.pos.x),float(node.pos.y),float(node.pos.z)]
            errors.append(max(abs(a-b) for a,b in zip(pos,point(frame,xyz))))
        if max(errors,default=0.)>1e-9 or connections()!=rigids:
            raise RuntimeError('Rotation RBE2 coordinate/connectivity readback differs')
        if counts!=(jpt.GetCountByType(jpt.DItemType.NODE),jpt.GetCountByType(jpt.DItemType.ELEM)) or parts_before!=[(int(p.id),int(p.key)) for p in jpt.GetAllParts()]:
            raise RuntimeError('Rotation changed entity counts or part ownership')
        for key in ('geometry','effective_geometry'):
            if key in session.state:session.state[key]=transform_records(session.state[key],frame)
        session.context['geometry']=deepcopy(session.state['geometry'])
        session.context['aligned_effective']=deepcopy(session.state['effective_geometry'])
        session.context['cad_preview']=deepcopy(session.state['geometry'])
        if warm:
            index.points={nid:point(frame,xyz) for nid,xyz in index.points.items()}
            index.stamp=model_stamp(jpt)
        for key in ('_native_meshes','_prepared_batch','patches'):session.context.pop(key,None)
        entry.update(verified=True,sampled_nodes=len(sample),maximum_error_m=max(errors,default=0.),
            index_kept=warm,counts_preserved=True,rbe2_preserved=True,helpers_rotated=len(helpers))
        return entry
    except BaseException:
        session.context.pop('_model_index',None);raise
    finally:
        session.busy=False;entry['seconds']=time.monotonic()-start
        session.print_timing('[CRANK-TIME] Rotate %s | %.3f s'%('VERIFIED' if entry['verified'] else 'FAILED',entry['seconds']))
        session.save()
