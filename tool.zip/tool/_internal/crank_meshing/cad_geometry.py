"""Cad geometry for Crank Meshing."""
import math
import statistics
from copy import deepcopy
from crank_meshing.model_parts import FaceGroups
from crank_meshing.mesh import journal_pin_mesh

def circle_center(points, axis):
    """Least-squares circle in its transverse plane; no model mutations."""
    transverse=[i for i in range(3) if i!=axis]
    origin=[sum(p[k] for p in points)/len(points) for k in transverse]
    xy=[(p[transverse[0]]-origin[0],p[transverse[1]]-origin[1]) for p in points]
    matrix=[[sum(x*x for x,y in xy),sum(x*y for x,y in xy),sum(x for x,y in xy)],
            [sum(x*y for x,y in xy),sum(y*y for x,y in xy),sum(y for x,y in xy)],
            [sum(x for x,y in xy),sum(y for x,y in xy),float(len(xy))]]
    rhs=[sum(x*(x*x+y*y) for x,y in xy),sum(y*(x*x+y*y) for x,y in xy),sum(x*x+y*y for x,y in xy)]
    for col in range(3):
        pivot=max(range(col,3),key=lambda i:abs(matrix[i][col]))
        matrix[col],matrix[pivot]=matrix[pivot],matrix[col];rhs[col],rhs[pivot]=rhs[pivot],rhs[col]
        divisor=matrix[col][col]
        if abs(divisor)<1e-18: raise ValueError('Circular boundary is degenerate')
        matrix[col]=[v/divisor for v in matrix[col]];rhs[col]/=divisor
        for i in range(3):
            if i==col: continue
            factor=matrix[i][col]
            matrix[i]=[a-factor*b for a,b in zip(matrix[i],matrix[col])];rhs[i]-=factor*rhs[col]
    result=[0.,0.,0.]
    result[axis]=statistics.median(p[axis] for p in points)
    for k,v in zip(transverse,(origin[0]+rhs[0]/2,origin[1]+rhs[1]/2)):result[k]=v
    return result


def preview_faces(jpt, groups, radius_by_edge):
    available={int(f.id):f for f in jpt.GetAllFaces()}
    records=[]
    for group in ('journal','pin'):
        for fid in groups.get(group,[]):
            face=available.get(int(fid))
            if face is None: raise ValueError('Face %d no longer exists'%fid)
            edges=list(face.edges)
            if len(edges)!=2: raise ValueError('Face %d requires two circular boundaries'%fid)
            boundaries=[[(float(n.pos.x),float(n.pos.y),float(n.pos.z)) for n in edge.nodes] for edge in edges]
            if any(len(p)<3 or not all(math.isfinite(v) for point in p for v in point) for p in boundaries):
                raise ValueError('Face %d has invalid circular boundary nodes'%fid)
            axes=[k for k in range(3) if all(len(p)>=3 and max(x[k] for x in p)-min(x[k] for x in p)<1e-7 for p in boundaries)]
            if len(axes)==1:
                axis=axes[0];centers=[circle_center(p,axis) for p in boundaries]
                direction=[float(k==axis) for k in range(3)]
            else:
                fitted=[circle_center_3d(p) for p in boundaries]
                centers=[item[0] for item in fitted]
                from crank_meshing.shaft_alignment import sub, dot, canonical_axis
                if abs(dot(fitted[0][1],fitted[1][1]))<1-1e-8:
                    raise ValueError('Face %d has noncoaxial circular boundaries'%fid)
                # Plane normals define the CAD cylinder direction. Fitted
                # centers carry micrometre tessellation noise; using their
                # difference would turn that noise into a spurious shaft tilt.
                direction=canonical_axis(fitted[0][1])
                delta=sub(centers[1],centers[0]);projection=dot(delta,direction)
                if math.sqrt(sum((delta[k]-projection*direction[k])**2 for k in range(3)))>5e-6:
                    raise ValueError('Face %d has noncoaxial circular boundaries'%fid)
                axis=max(range(3),key=lambda k:abs(direction[k]))
            radius=[float(radius_by_edge(edge)) for edge in edges]
            if not all(math.isfinite(r) and r>0 for r in radius) or abs(radius[0]-radius[1])>1e-7:raise ValueError('Face %d is not constant-radius'%fid)
            xyz=[sum(c[k] for c in centers)/2 for k in range(3)]
            for p,c,r in zip(boundaries,centers,radius):
                if max(abs(math.dist(v,c)-r) for v in p)>r*.005:
                    raise ValueError('Face %d has a noncircular boundary'%fid)
            planes=sorted(sum(c[k]*direction[k] for k in range(3)) for c in centers)
            if planes[1]-planes[0]<=1e-7: raise ValueError('Face %d has no axial width'%fid)
            if len(axes)==1 and math.dist([centers[0][k] for k in range(3) if k!=axis],
                         [centers[1][k] for k in range(3) if k!=axis])>5e-6:
                raise ValueError('Face %d has noncoaxial boundaries'%fid)
            records.append(dict(group=group,face_id=int(fid),axis='XYZ'[axis],axis_vector=direction,radius_m=sum(radius)/2,
                width_m=planes[1]-planes[0],boundary_planes_m=planes,boundary_edge_ids=[int(e.id) for e in edges],
                center=dict(group=group,face_id=int(fid),node_id=None,xyz_m=xyz),
                evidence='Native arc radius + least-squares circle centers from CAD boundary nodes'))
    direction=records[0]['axis_vector'] if records else [1.,0.,0.]
    return sorted(records,key=lambda r:(r['group']!='journal',sum(a*b for a,b in zip(r['center']['xyz_m'],direction))))


def circle_center_3d(points):
    """Project a planar CAD circle into a local basis, then fit without numpy."""
    from crank_meshing.shaft_alignment import sub, dot, cross, unit
    origin=[sum(p[k] for p in points)/len(points) for k in range(3)]
    u=unit(max((sub(p,origin) for p in points),key=lambda v:dot(v,v)))
    normal=unit(max((cross(u,sub(p,origin)) for p in points),key=lambda v:dot(v,v)))
    if max(abs(dot(sub(p,origin),normal)) for p in points)>1e-7:
        raise ValueError('Circular boundary is not planar')
    v=cross(normal,u)
    projected=[[dot(sub(p,origin),u),dot(sub(p,origin),v),0.] for p in points]
    center=circle_center(projected,2)
    return [origin[k]+center[0]*u[k]+center[1]*v[k] for k in range(3)],normal


def measure_faces(jpt, groups, centers, radius_by_edge, tolerance_m=1e-7):
    """Read native arc radii and two planar circular boundaries per face.

    Explicitly reject unsupported topology instead of guessing from tessellation.
    Native node positions and Tools.Measure.Radius.Edge return SI metres.
    """
    state = FaceGroups()
    for name in ('journal', 'pin'):
        state.capture(name, groups[name])
    groups = state.validate()
    available = {int(face.id): face for face in jpt.GetAllFaces()}
    records = []
    for group in ('journal', 'pin'):
        for fid in groups[group]:
            if fid not in available or fid not in centers:
                raise ValueError('Face/center is missing: %d' % fid)
            face = available[fid]
            edges = list(face.edges)
            if len(edges) != 2:
                raise ValueError('Face %d: expected two circular boundaries; partitioned faces need a separate topology path' % fid)
            boundaries = []
            for edge in edges:
                points = [(float(n.pos.x), float(n.pos.y), float(n.pos.z)) for n in edge.nodes]
                if len(points) < 3 or not all(math.isfinite(v) for p in points for v in p):
                    raise ValueError('Face %d: insufficient/invalid boundary nodes' % fid)
                radius = float(radius_by_edge(edge))
                if not math.isfinite(radius) or radius <= 0:
                    raise ValueError('Face %d: native circular-edge radius measurement failed' % fid)
                boundaries.append(dict(edge_id=int(edge.id), points=points, radius_m=radius))
            candidates = []
            for axis in range(3):
                if all(max(p[axis] for p in b['points']) - min(p[axis] for p in b['points']) <= tolerance_m for b in boundaries):
                    planes = [statistics.median(p[axis] for p in b['points']) for b in boundaries]
                    if abs(planes[1] - planes[0]) > tolerance_m:
                        candidates.append((axis, sorted(planes)))
            if len(candidates) != 1:
                raise ValueError('Face %d: cannot determine a unique axis from circular boundary planes' % fid)
            axis, planes = candidates[0]
            radii = [b['radius_m'] for b in boundaries]
            if abs(radii[0] - radii[1]) > tolerance_m:
                raise ValueError('Face %d: boundary radii differ (not a constant-radius cylinder)' % fid)
            center = centers[fid]
            if center['group'] != group:
                raise ValueError('Face group/center mismatch')
            if abs(center['xyz_m'][axis] - sum(planes)/2) > tolerance_m:
                raise ValueError('Face %d: native center does not match boundary midpoint' % fid)
            records.append(dict(group=group, face_id=fid, center=center,
                axis='XYZ'[axis], radius_m=sum(radii)/2, width_m=planes[1]-planes[0],
                boundary_planes_m=planes, boundary_edge_ids=[b['edge_id'] for b in boundaries],
                evidence='native arc radius + planar circular-edge node coordinates'))
    if len({r['axis'] for r in records}) != 1:
        raise ValueError('Journal/Pin cylinder axes must be parallel')
    axis = 'XYZ'.index(records[0]['axis'])
    transverse = [i for i in range(3) if i != axis]
    journals = [r for r in records if r['group'] == 'journal']
    origin = journals[0]['center']['xyz_m']
    # Native cylinder-center has micrometre-level transverse fitting noise.
    if any(math.dist([r['center']['xyz_m'][i] for i in transverse],
                     [origin[i] for i in transverse]) > max(tolerance_m, 5e-6) for r in journals):
        raise ValueError('Journal faces do not share the crank axis')
    return sorted(records, key=lambda r: (r['group'] != 'journal', r['center']['xyz_m'][axis]))


def refresh_surface_boundaries(jpt, records, tolerance_m=1e-7, maximum_segment_m=0.):
    """Keep measured CAD dimensions; bind them to the new tessellated rings.

    Radius.Edge fits the remeshed polygon, so it no longer gives the exact CAD
    radius. Check the new rings against the original dimensions instead.
    """
    from crank_meshing.model_parts import ring_geometry
    available = {int(f.id): f for f in jpt.GetAllFaces()}
    refreshed = deepcopy(records)
    for row in refreshed:
        face = available.get(row['face_id'])
        if face is None or len(list(face.edges)) != 2:
            raise ValueError('Surface mesh changed cylinder topology: %d' % row['face_id'])
        rings, edge_ids = [], []
        for edge in face.edges:
            nodes = {int(n.id): [float(n.pos.x), float(n.pos.y), float(n.pos.z)] for n in edge.nodes}
            ring = ring_geometry(dict(nodes=list(nodes)), nodes, 'XYZ'.index(row['axis']), row['center']['xyz_m'])
            radius=row['radius_m']
            # Tri3 boundary points can lie on linear CAD tessellation chords.
            # The native 5mm maximum introduces a sagitta of about 0.14mm on
            # R22.5, already larger than the old fixed 0.5% (0.1125mm).
            half=min(maximum_segment_m/2,radius)
            sagitta=half*half/(radius+math.sqrt(max(0.,radius*radius-half*half))) if half else 0.
            allowed=radius*.005+sagitta
            if max(abs(ring[key]-radius) for key in ('radius_min_m','radius_max_m')) > allowed:
                raise ValueError('Surface boundary differs from measured cylinder: %d' % row['face_id'])
            rings.append(ring['plane_m']); edge_ids.append(int(edge.id))
        if any(abs(a-b)>tolerance_m for a,b in zip(sorted(rings),row['boundary_planes_m'])):
            raise ValueError('Surface mesh changed cylinder end planes: %d' % row['face_id'])
        row['boundary_edge_ids'] = edge_ids
        row['surface_boundary_evidence'] = 'Complete concentric planar rings; CAD radius retained; 0.5% fitting plus native maximum-size chord sagitta; original end planes retained'
    return refreshed


def make_face_plan(records, layer_settings, doc_units_per_m=1000.0, sectors=32):
    """Only layers/ratios come from user settings; physical dimensions from faces."""
    core = journal_pin_mesh
    scale = core.positive(doc_units_per_m, 'Document length scale')
    rows, totals, stations = [], 0, {'journal': 0, 'pin': 0}
    if not records:
        raise ValueError('Measure Journal/Pin faces first')
    for record in records:
        group = record['group']
        settings = layer_settings[group]
        width, radius = record['width_m']*scale, record['radius_m']*scale
        wl = core.levels(width, settings['width_layers'], settings['width_ratios'], 'Width')
        rl = core.levels(radius, settings['radial_layers'], settings['radial_ratios'], 'Radius')
        totals += 3*(len(wl)-1)*int(sectors)*(2*(len(rl)-1)-1)
        if totals > core.MAX_TETS:
            raise ValueError('Combined inserts exceed 250000 tetrahedra')
        stations[group] += 1
        params = dict(centers=str(record['center']['node_id']), xyz='', axis=record['axis'],
            width=str(width), radius=str(radius), nw=str(len(wl)-1), nr=str(len(rl)-1),
            wr=settings['width_ratios'], rr=settings['radial_ratios'], sectors=str(sectors),
            order=10, rbe=True, ring='1', dofs='123456', renumber=False, targets='',
            step='1', material='0', prefix='%s_%d' % (group.capitalize(), stations[group]))
        mesh = core.geometry(tuple(v*scale for v in record['center']['xyz_m']),
                             record['axis'], width, wl, rl, sectors, 10)
        rows.append(dict(group=group, station=stations[group], center=record['center'],
            geometry=record, params=params, stats=core.validate(mesh),
            effective_planes_mm=[(record['boundary_planes_m'][0]*scale + value)*1000/scale for value in wl],
            radial_levels_mm=[value*1000/scale for value in rl]))
    return rows
