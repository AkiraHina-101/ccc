"""Model parts for Crank Meshing."""
from contextlib import contextmanager
import math
from collections import defaultdict
import hashlib

@contextmanager
def native_transaction(jpt,name):
    """Public API batches undo and defers scene/status redraw; always unfreeze."""
    jpt.BeginDatabaseTransaction(name)
    try: yield
    finally: jpt.EndDatabaseTransaction()


class FaceGroups:
    def __init__(self):
        self.groups = {'journal': [], 'pin': []}

    def capture(self, group, ids):
        if group not in self.groups:
            raise ValueError('Unknown face group')
        ids = list(dict.fromkeys(int(value) for value in ids))
        if not ids or any(value <= 0 for value in ids):
            raise ValueError('Select at least one valid ' + group + ' face in the model')
        other = 'pin' if group == 'journal' else 'journal'
        overlap = set(ids) & set(self.groups[other])
        if overlap:
            raise ValueError('Faces already assigned to ' + other + ': ' + ', '.join(map(str, sorted(overlap))))
        self.groups[group] = ids
        return list(ids)

    def validate(self):
        for group in ('journal', 'pin'):
            if not self.groups[group]:
                raise ValueError('Capture ' + group + ' faces first')
        return {name: list(values) for name, values in self.groups.items()}


def capture_sources(session,groups):
    parts=list(session.jpt.GetAllParts())
    selected={int(fid) for ids in groups.values() for fid in ids}
    owners=[p for p in parts if selected.issubset({int(f.id) for f in p.faces})]
    if len(owners)!=1:raise ValueError('Journal and Pin faces must belong to one crankshaft part')
    keys=[int(p.key) for p in parts]
    prior=session.state.get('source_part_keys')
    if prior is not None and set(prior)!=set(keys):
        raise ValueError('Original model parts changed during this run')
    session.state.update(source_part_keys=keys,crank_part_key=int(owners[0].key))
    return parts,owners[0]


def crank_keys(state):
    return {state['crank_part_key']} if 'crank_part_key' in state else set(state['source_part_keys'])




def snapshot(jpt, part_ids=None):
    parts = list(jpt.GetAllParts())
    if part_ids is not None:
        wanted = set(map(int, part_ids))
        parts = [p for p in parts if int(p.id) in wanted]
        if {int(p.id) for p in parts} != wanted:
            raise ValueError('Target part is missing')
    faces = {int(f.id): f for p in parts for f in p.faces}
    edges = {int(e.id): e for f in faces.values() for e in f.edges}
    nodes = {int(n.id): n for f in faces.values() for n in f.nodes}
    nodes.update({int(n.id): n for e in edges.values() for n in e.nodes})
    elems = {int(e.id): e for f in faces.values() for e in f.elems}
    return dict(parts=[dict(id=int(p.id), name=str(p.name), faces=[int(f.id) for f in p.faces]) for p in parts],
        faces=[dict(id=fid, edges=[int(e.id) for e in f.edges], nodes=[int(n.id) for n in f.nodes],
                    elems=[int(e.id) for e in f.elems]) for fid, f in faces.items()],
        edges=[dict(id=eid, nodes=[int(n.id) for n in e.nodes]) for eid, e in edges.items()],
        nodes={nid: [float(n.pos.x), float(n.pos.y), float(n.pos.z)] for nid, n in nodes.items()},
        elements={eid: [int(n.id) for n in e.nodes] for eid, e in elems.items()})


def indexed(data):
    return ({int(f['id']): f for f in data['faces']},
            {int(e['id']): e for e in data['edges']},
            {int(n): p for n, p in data['nodes'].items()},
            {int(e): n for e, n in data['elements'].items()})


def face_signature(face, nodes):
    return tuple(sorted(tuple(round(v, 10) for v in nodes[int(n)]) for n in face['nodes']))


def map_copied_faces(source, copied, selected):
    sf, _, sn, _ = indexed(source)
    cf, _, cn, _ = indexed(copied)
    lookup = defaultdict(list)
    for fid, face in cf.items():
        lookup[face_signature(face, cn)].append(fid)
    result = {}
    for fid in selected:
        matches = lookup.get(face_signature(sf[int(fid)], sn), [])
        if len(matches) != 1:
            raise ValueError('Copy mapping is ambiguous for face %d' % fid)
        result[int(fid)] = matches[0]
    return result


def ring_geometry(edge, nodes, axis, center, tolerance=1e-7):
    points = [nodes[int(n)] for n in edge['nodes']]
    if len(points) < 8:
        raise ValueError('Connection boundary has insufficient ring nodes')
    axial = [p[axis] for p in points]
    if max(axial)-min(axial) > tolerance:
        raise ValueError('Connection boundary is not a planar ring')
    transverse = [i for i in range(3) if i != axis]
    angles = sorted(set(round(math.atan2(p[transverse[1]]-center[transverse[1]],
                                       p[transverse[0]]-center[transverse[0]]), 10) for p in points))
    gaps = [b-a for a, b in zip(angles, angles[1:])] + [angles[0]+2*math.pi-angles[-1]]
    if max(gaps) >= math.pi/2:
        raise ValueError('Connection boundary is not a complete circular ring')
    radii = [math.hypot(p[transverse[0]]-center[transverse[0]],
                        p[transverse[1]]-center[transverse[1]]) for p in points]
    radius = sum(radii)/len(radii)
    if min(radii) <= 0 or max(radii)-min(radii) > radius*.02:
        raise ValueError('Connection boundary is not concentric with its cylinder')
    return dict(plane_m=sum(axial)/len(axial), radius_m=radius,
                radius_min_m=min(radii), radius_max_m=max(radii))


def removal_plan(data, geometry):
    """Accept only one short two-ring connection at each cylinder end.

    Identification combines shared-edge topology and complete-ring geometry.
    It never walks recursively into neighboring webs or deletes arbitrary small faces.
    """
    faces, edges, nodes, elems = indexed(data)
    adjacency = defaultdict(set)
    for fid, face in faces.items():
        for eid in face['edges']:
            adjacency[int(eid)].add(fid)
    cylinders = {int(r['face_id']) for r in geometry}
    if not cylinders or len(cylinders) != len(geometry):
        raise ValueError('Unique cylinder geometry records required')
    connections, used = [], set()
    for row in geometry:
        fid = int(row['face_id'])
        if fid not in faces or set(faces[fid]['edges']) != set(row['boundary_edge_ids']):
            raise ValueError('Cylinder topology changed after measurement')
        axis = 'XYZ'.index(row['axis'])
        center = row['center']['xyz_m']
        for eid in row['boundary_edge_ids']:
            neighbors = adjacency[eid]-{fid}
            if len(neighbors) != 1:
                raise ValueError('Expected one connection face per cylinder boundary')
            cid = neighbors.pop()
            face = faces[cid]
            if cid in cylinders or cid in used or len(face['edges']) != 2:
                raise ValueError('Connection face is ambiguous or unsupported')
            outer = next(e for e in face['edges'] if e != eid)
            retained = adjacency[outer]-{cid}
            if len(retained) != 1 or retained & cylinders:
                raise ValueError('Connection has no unique retained crankshaft neighbor')
            inner_ring = ring_geometry(edges[eid], nodes, axis, center)
            outer_ring = ring_geometry(edges[outer], nodes, axis, center)
            delta = outer_ring['plane_m']-inner_ring['plane_m']
            direction = inner_ring['plane_m']-center[axis]
            radius = row['radius_m']
            if delta*direction <= 0 or not 1e-7 < abs(delta) < radius*.15:
                raise ValueError('Adjacent face is not a short outward axial connection')
            if not radius*.8 < outer_ring['radius_m'] < radius*1.2:
                raise ValueError('Connection outer ring differs too much from cylinder radius')
            connections.append(dict(cylinder_face_id=fid, group=row['group'], face_id=cid,
                inner_edge_id=eid, outer_edge_id=outer, retained_face_id=next(iter(retained)),
                inner_ring=inner_ring, outer_ring=outer_ring,
                outer_node_ids=list(edges[outer]['nodes']), old_element_ids=list(face['elems'])))
            used.add(cid)
    delete = cylinders | used
    return dict(cylinder_face_ids=sorted(cylinders), connection_face_ids=sorted(used),
        delete_face_ids=sorted(delete), connections=connections,
        delete_element_ids=sorted({int(e) for fid in delete for e in faces[fid]['elems']}),
        retained_face_ids=sorted(set(faces)-delete),
        retained_boundary_node_ids=sorted({int(n) for c in connections for n in c['outer_node_ids']}))


def delete_old_faces(jpt, plan, progress):
    """Run explicit native deletion once and prove the scoped readback."""
    from Geometry.DeleteEntity import Face
    if progress.get('delete_started'):
        raise ValueError('Removal already attempted; inspect partial state before retrying')
    targets = plan['delete_face_ids']
    if not targets:
        raise ValueError('Explicit nonempty removal targets required')
    before_faces = {int(f.id) for f in jpt.GetAllFaces()}
    before_elems = {int(e.id) for e in jpt.GetAllElems()}
    if not set(targets).issubset(before_faces):
        raise ValueError('Removal targets are stale')
    progress['delete_started'] = True
    progress['delete_result'] = str(Face('[%s]' % ', '.join('6:%d' % fid for fid in targets),
                                       bIgnoreFaceOnSolidBody=False))
    after_faces = {int(f.id) for f in jpt.GetAllFaces()}
    after_elems = {int(e.id) for e in jpt.GetAllElems()}
    progress['removed_face_ids'] = sorted(before_faces-after_faces)
    progress['removed_element_ids'] = sorted(before_elems-after_elems)
    if before_faces-after_faces != set(targets) or after_faces-before_faces:
        raise RuntimeError('Native deletion did not remove exactly the planned faces')
    if set(plan['delete_element_ids']) & after_elems:
        raise RuntimeError('Deleted faces still have their old surface elements')
    after_nodes = {int(n.id) for n in jpt.GetAllNodes()}
    if not set(plan['retained_boundary_node_ids']).issubset(after_nodes):
        raise RuntimeError('Native deletion removed retained connection boundary nodes')
    jpt.ClearAllSelection()
    progress['delete_verified'] = True
    return progress




def digest(rows):
    total=0;count=0
    for row in rows:
        total^=int.from_bytes(hashlib.sha256(repr(row).encode('ascii')).digest(),'big');count+=1
    return (count,'%064x'%total)


def model_stamp(jpt):
    return (str(jpt.GetActiveDocument().docID),jpt.GetUndoCount(),jpt.GetRedoCount(),
        jpt.GetCountByType(jpt.DItemType.NODE),jpt.GetCountByType(jpt.DItemType.ELEM),
        tuple(sorted((int(p.key),int(p.id)) for p in jpt.GetAllParts())))


class ModelIndex:
    def __init__(self,jpt):
        self.jpt=jpt;self.elements={};self.rows={};self.solids={};self.adjacency={}
        self.node_handles={};self.points={};self.stamp=None;self.maximum=0
        for c in jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION):
            for n in c.masters:
                self.adjacency[int(n.id)]=set();self.node_handles[int(n.id)]=jpt.CastDItemToDNode(n)
            for n in c.slaves:self.node_handles[int(n.id)]=jpt.CastDItemToDNode(n)
        wanted=set(self.adjacency)
        for e in jpt.GetAllElems():
            eid=int(e.id);row=tuple(int(n.id) for n in e.nodes)
            self.elements[eid]=e;self.rows[eid]=row
            if e.kind==jpt.ElemKind.ELEMKIND_3D:self.solids[eid]=row
            for nid in wanted.intersection(row):self.adjacency[nid].add(eid)

    def finish(self,points):
        self.points=points;self.maximum=max(points,default=0);self.stamp=model_stamp(self.jpt)
        return self

    def current(self):
        return self.stamp==model_stamp(self.jpt)

    def free_ids(self,count,forbidden):
        from crank_meshing.node_renumbering import MAX_RENUMBER_ID
        candidate=self.maximum+1
        if candidate+count-1>MAX_RENUMBER_ID:candidate=1
        result=[]
        while len(result)<count and candidate<=MAX_RENUMBER_ID:
            if candidate not in self.points and candidate not in forbidden:result.append(candidate)
            candidate+=1
        if len(result)!=count:raise ValueError('Not enough free node IDs below 8 digits.')
        return result

    def related(self,node_ids):
        missing=set(node_ids)-set(self.adjacency)
        if missing:
            for nid in missing:self.adjacency[nid]=set()
            # Collision targets are rare; scan cached tuples, never native mesh again.
            for eid,row in self.rows.items():
                for nid in missing.intersection(row):self.adjacency[nid].add(eid)
        return {eid for nid in node_ids for eid in self.adjacency[nid]}

    def snapshot(self,node_ids,remap=None,element_ids=None):
        jpt=self.jpt;remap=remap or {};nodes=[]
        for nid in node_ids:
            source=remap.get(nid,nid);node=self.node_handles.get(source)
            if node is None:
                found=jpt.GetEntitiesByID(jpt.DItemType.NODE,nid)
                if len(found)!=1:raise RuntimeError('Renumber node lookup is missing or ambiguous')
                node=jpt.CastDItemToDNode(found[0]);self.node_handles[source]=node
            if int(node.id)!=nid:raise RuntimeError('Cached node handle differs from the requested ID')
            pos=node.pos;nodes.append((source,float(pos.x),float(pos.y),float(pos.z)))
        wanted=self.related(node_ids) if element_ids is None else set(element_ids)
        actual={}
        for eid in wanted:
            e=self.elements[eid]
            if int(e.id)!=eid:raise RuntimeError('Cached element handle is no longer valid')
            actual[eid]=tuple(int(n.id) for n in e.nodes)
        self.last_rows=actual
        connections=list(jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION))
        return dict(scope='native indexed affected-element readback + connections/counts',
            nodes=digest(nodes),elements=digest((eid,tuple(remap.get(n,n) for n in row)) for eid,row in actual.items()),
            element_ids=sorted(wanted),
            connections=digest((int(c.id),tuple(sorted(remap.get(int(n.id),int(n.id)) for n in c.masters)),
                tuple(sorted(remap.get(int(n.id),int(n.id)) for n in c.slaves))) for c in connections),
            global_counts=(jpt.GetCountByType(jpt.DItemType.NODE),jpt.GetCountByType(jpt.DItemType.ELEM),len(connections)),
            parts=sorted((int(p.key),int(p.id)) for p in jpt.GetAllParts()))

    def remap(self,changed):
        for table in (self.points,self.node_handles,self.adjacency):
            moved={new:table[old] for old,new in changed.items() if old in table}
            for old in changed:table.pop(old,None)
            table.update(moved)
        self.rows.update(self.last_rows)
        for eid,row in self.last_rows.items():
            if eid in self.solids:self.solids[eid]=row
        self.maximum=max(self.maximum,max(changed.values(),default=0))
        self.stamp=model_stamp(self.jpt)


def get_model_index(session):
    index=session.context.get('_model_index')
    if index is not None and index.current():return index,False
    from crank_meshing.mesh.volume_meshing import node_positions
    index=ModelIndex(session.jpt).finish(node_positions(session.jpt))
    session.context['_model_index']=index
    return index,True



def validate_faces(jpt, groups):
    state = FaceGroups()
    for name in ('journal', 'pin'):
        if not groups.get(name): raise ValueError('Missing '+name.capitalize()+' faces')
        state.capture(name, groups[name])
    result = state.validate()
    available = {int(f.id) for f in jpt.GetAllFaces()}
    missing = set(result['journal']+result['pin'])-available
    if missing: raise ValueError('Faces no longer exist: '+str(sorted(missing)))
    return result




def group_inserts(preparation):
    p, session, jpt = preparation, preparation.s, preparation.jpt
    entry = p.progress.setdefault('insert_groups', {})
    if entry.get('started'):
        raise ValueError('Insert grouping already attempted; inspect the saved result.')
    if not p.progress.get('merge_parts', {}).get('verified'):
        raise ValueError('Complete shared surface attachment before grouping inserts.')
    batch = p.progress['batch']
    rows = session.state['main_plan']['inserts']
    keys = list(batch['part_keys'])
    if len(rows) != len(keys):
        raise RuntimeError('Insert ownership does not match the captured plan.')
    parts = {int(part.key): part for part in jpt.GetAllParts()}
    if set(parts) != set(keys) | set(session.state['source_part_keys']):
        raise RuntimeError('Insert grouping requires the retained crankshaft and this run\'s inserts.')
    if len({int(part.id) for part in parts.values()}) != len(parts):
        raise RuntimeError('Insert part IDs are ambiguous.')
    groups = {g: [parts[key] for row, key in zip(rows, keys) if row['group'] == g]
              for g in ('journal', 'pin')}
    if sum(map(len, groups.values())) != len(keys):
        raise RuntimeError('Unknown insert group in the captured plan.')
    before_elements, before_nodes = {}, {}
    for group, members in groups.items():
        before_elements[group] = {int(e.id): tuple(int(n.id) for n in e.nodes)
                                  for part in members for e in part.elems}
        for part in members:
            for node in part.nodes:
                pos = node.pos
                before_nodes[int(node.id)] = (float(pos.x), float(pos.y), float(pos.z))
    before_connections = p.connection_connectivity()
    shared_ids = {int(f.id) for f in p.shared_readback()}
    counts = (jpt.GetCountByType(jpt.DItemType.NODE), jpt.GetCountByType(jpt.DItemType.ELEM))
    point_ids = {int(e.id) for e in jpt.GetElemsByKind(jpt.ElemKind.ELEMKIND_0D)}
    index = session.context.get('_model_index')
    warm = index is not None and index.current()
    entry.update(started=True, original_part_keys=keys, groups={})
    session.save()
    if warm:
        index.stamp = None  # Partial native writes must never reuse a valid cache.
    from Geometry.MergeEntities import Parts
    expected_keys = set(parts)
    for group, members in groups.items():
        if not members:
            continue
        target = members[0]
        action = dict(started=True, source_keys=[int(part.key) for part in members],
                      command='Geometry.MergeEntities.Parts', remove_shared_face=False)
        entry['groups'][group] = action
        session.save()
        with native_transaction(jpt, 'Crank group '+group):
            if len(members) > 1:
                action['response'] = str(Parts(
                    crlParts='[%s]' % ', '.join('3:%d' % part.id for part in members),
                    dMergeTolerance=1e-10, bRemoveSharedFace=False))
            target.name = 'Journal' if group == 'journal' else 'Pin'
        expected_keys -= set(action['source_keys'][1:])
        current = {int(part.key): part for part in jpt.GetAllParts()}
        if set(current) != expected_keys:
            raise RuntimeError('Native grouping did not retain the intended part owner.')
        owner = current[action['source_keys'][0]]
        actual_elements = {int(e.id): e for e in owner.elems}
        actual_rows = {eid: tuple(int(n.id) for n in elem.nodes) for eid, elem in actual_elements.items()}
        # MergePart regenerates vertex marker elements (one node), while the
        # line/surface/solid mesh must retain every ID and node reference.
        retained_before = {eid: row for eid, row in before_elements[group].items() if len(row) != 1}
        retained_after = {eid: row for eid, row in actual_rows.items() if len(row) != 1}
        if retained_after != retained_before:
            raise RuntimeError('Insert grouping changed mesh IDs or connectivity.')
        action.update(verified=True, part_key=int(owner.key), part_id=int(owner.id), name=owner.name,
                      vertex_markers_before=len(before_elements[group])-len(retained_before),
                      vertex_markers_after=len(actual_rows)-len(retained_after))
        if warm:
            removed = set(before_elements[group]) - set(actual_rows)
            for eid in removed:
                index.elements.pop(eid, None)
                index.rows.pop(eid, None)
            for related in index.adjacency.values():
                related.difference_update(before_elements[group])
            for eid, row in actual_rows.items():
                for nid in set(row).intersection(index.adjacency):
                    index.adjacency[nid].add(eid)
            index.elements.update(actual_elements)
            index.rows.update(actual_rows)
        session.save()
    current = {int(part.key): part for part in jpt.GetAllParts()}
    # Shared sections also belong to the crankshaft: MergePart may rebuild
    # their vertex markers there. Fetch only 0D markers, never the full mesh.
    point_elements = {int(e.id): e for e in jpt.GetElemsByKind(jpt.ElemKind.ELEMKIND_0D)}
    expected_element_count = counts[1] - len(point_ids) + len(point_elements)
    if warm:
        for eid in point_ids:
            index.elements.pop(eid, None)
            index.rows.pop(eid, None)
        for related in index.adjacency.values():
            related.difference_update(point_ids)
        for eid, elem in point_elements.items():
            row = tuple(int(n.id) for n in elem.nodes)
            index.elements[eid] = elem
            index.rows[eid] = row
            for nid in set(row).intersection(index.adjacency):
                index.adjacency[nid].add(eid)
    owners = [entry['groups'][g]['part_key'] for g in ('journal', 'pin') if g in entry['groups']]
    after_nodes = {}
    for key in owners:
        for node in current[key].nodes:
            pos = node.pos
            after_nodes[int(node.id)] = (float(pos.x), float(pos.y), float(pos.z))
    if before_nodes != after_nodes or (counts[0], expected_element_count) != (
            jpt.GetCountByType(jpt.DItemType.NODE), jpt.GetCountByType(jpt.DItemType.ELEM)):
        raise RuntimeError('Insert grouping changed nodes or global mesh counts.')
    if before_connections != p.connection_connectivity() or shared_ids != {int(f.id) for f in p.shared_readback()}:
        raise RuntimeError('Insert grouping changed RBE2 or shared faces.')
    batch['original_part_keys'] = keys
    batch['part_keys'] = owners
    batch['part_ids'] = [int(current[key].id) for key in owners]
    for row, record in zip(rows, batch.get('parts', [])):
        owner = entry['groups'][row['group']]
        record.update(group_part_key=owner['part_key'], group_part_id=owner['part_id'])
    if warm:
        index.stamp = model_stamp(jpt)
    entry.update(verified=True, parts=len(current), nodes_preserved=True,
                 mesh_preserved=True, rbe2_preserved=True, shared_faces_preserved=True,
                 renumber_index_kept=warm)
    session.save()
    return entry
