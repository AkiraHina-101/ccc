"""Crank Meshing version and safe runtime reload order."""
import importlib
import sys

__version__ = '1.3.2'
_RUNTIME = (
    'mesh.journal_pin_mesh', 'mesh.interface_stitching', 'model_parts',
    'cad_geometry', 'shaft_parameters', 'shaft_alignment', 'run_state',
    'mesh.journal_pin_solids', 'mesh.mesh_preparation', 'mesh.surface_meshing',
    'mesh.volume_meshing', 'workflow', 'node_renumbering', 'ui.dialog_layout',
    'ui.psj_table_controls', 'ui.parameter_table', 'ui.preview_drawing',
    'ui.crank_preview', 'application',
)


def reload_runtime():
    """Retire the owned dialog before refreshing the host's cached modules."""
    previous = sys.modules.get(__name__ + '.application')
    owner = getattr(previous, '_callbacks', None)
    if owner is not None and not owner.retire():
        return previous
    if owner is None and getattr(previous, '_dialog', None) is not None:
        if getattr(getattr(previous, '_session', None), 'busy', False):
            return previous
        previous._dialog.close()
    importlib.invalidate_caches()
    for name in _RUNTIME:
        qualified = __name__ + '.' + name
        if qualified in sys.modules:
            importlib.reload(sys.modules[qualified])
        else:
            importlib.import_module(qualified)
    return sys.modules[__name__ + '.application']
