"""Run state for Crank Meshing."""
import json
import os
import time
from pathlib import Path
from uuid import uuid4
from copy import deepcopy

def migrate_drafts(root, legacy_roots):
    """Copy the last matching-table draft once; never replace existing settings."""
    import shutil
    destination = Path(root) / 'data/user-settings/last-tables.json'
    if destination.exists():
        return
    for previous in legacy_roots:
        candidate = Path(previous) / 'data/user-settings/last-tables.json'
        if candidate.is_file() and candidate.resolve() != destination.resolve():
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(str(candidate), str(destination))
            return

def write_json(path, value, compact=False):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=None if compact else 2, ensure_ascii=False,
                              separators=(',', ':') if compact else None), encoding='utf-8')
    # Windows readers can briefly deny atomic rename while inspecting a report.
    for attempt in range(6):
        try:
            temp.replace(path)
            return
        except PermissionError as exc:
            if getattr(exc, 'winerror', None) not in (5, 32) or attempt == 5:
                raise
            time.sleep(.025 * 2**attempt)


def counts(jpt):
    return dict(parts=len(jpt.GetAllParts()), faces=len(jpt.GetAllFaces()),
        nodes=len(jpt.GetAllNodes()), elements=len(jpt.GetAllElems()),
        solids=len(jpt.GetElemsByKind(jpt.ElemKind.ELEMKIND_3D)),
        connections=len(jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_CONNECTION)))


class DebugSession:
    def __init__(self, jpt, root):
        self.jpt, self.root = jpt, Path(root)
        self.folder = self.root / 'data/runs' / ('debug_' + uuid4().hex)
        self.folder.mkdir(parents=True)
        self.state = dict(schema_version=2, pid=os.getpid(), events=[], steps={}, feedback=[])
        if hasattr(jpt,'GetActiveDocument'):
            self.state['document_id']=str(jpt.GetActiveDocument().docID)
        self.context = {}
        self.busy = False
        self.save()

    def save(self):
        write_json(self.folder / 'debug-session.json', self.state, compact=True)

    def require_document(self):
        expected = self.state.get('document_id')
        if expected is not None and str(self.jpt.GetActiveDocument().docID) != expected:
            raise ValueError('Activate the model belonging to this Crank run before continuing.')
        if self.context.get('_stop_requested'):
            raise ValueError('Crank stopped after the current step because its dialog was closed.')

    def operation(self, name, action):
        entry = dict(name=name, status='RUNNING', started=time.time())
        self.state['active_operation'] = entry
        self.save()
        started = time.monotonic()
        try:
            result = action()
            entry['status'] = 'VERIFIED'
            return result
        except BaseException as exc:
            entry.update(status='FAILED', error=str(exc))
            raise
        finally:
            entry['seconds'] = time.monotonic()-started
            self.save()

    def measure(self):
        from crank_meshing.model_parts import FaceGroups
        from crank_meshing.cad_geometry import measure_faces
        from Tools.Measure.Radius import Edge as MeasureRadius
        state = FaceGroups()
        for group in ('journal', 'pin'):
            state.capture(group, self.context.get('groups', {}).get(group, []))
        groups = state.validate()
        from crank_meshing.cad_geometry import preview_faces
        from MeshEdit.CreateNode import Absolute
        radius = lambda e: MeasureRadius('%d:%d' % (e.typeID, e.id), iPrecision=12)
        # Preview and execution share one CAD measurement. Create helper nodes
        # only at execution, in a single native batch with targeted readback.
        preview = preview_faces(self.jpt, groups, radius)
        centers = {r['face_id']:dict(r['center']) for r in preview}
        geometry = measure_faces(self.jpt, groups, centers, radius)
        first = int(self.jpt.GetMaxIDEntity(self.jpt.DItemType.NODE))+1
        ids = list(range(first, first+len(geometry)))
        positions = [r['center']['xyz_m'] for r in geometry]
        response = self.operation('measure.create_centers', lambda: Absolute(positions, ids))
        if response is False or str(response)=='0':
            raise RuntimeError('Native center-node batch failed')
        for row, nid in zip(geometry, ids):
            found = self.jpt.GetEntitiesByID(self.jpt.DItemType.NODE, nid)
            if len(found)!=1:
                raise RuntimeError('Center node readback failed: %d'%nid)
            node = self.jpt.CastDItemToDNode(found[0])
            xyz = [float(node.pos.x),float(node.pos.y),float(node.pos.z)]
            if max(abs(a-b) for a,b in zip(xyz,row['center']['xyz_m']))>1e-10:
                raise RuntimeError('Center node coordinate readback differs')
            row['center'].update(node_id=nid,xyz_m=xyz)
        self.context['centers'] = centers
        self.state['measured_centers'] = centers
        self.context['geometry'] = geometry
        self.state['geometry'] = geometry
        return dict(geometry=geometry, scope='Measured geometry only; center nodes created, no mesh')





def cad_signature(records):
    return sorted((r['group'],int(r['face_id']),r['axis'],
        tuple(round(float(v),9) for v in r['center']['xyz_m']),
        round(float(r['radius_m']),9),round(float(r['width_m']),9)) for r in records)


class TableDrafts:
    def __init__(self,root):
        self.path=Path(root)/'data/user-settings/last-tables.json'
        self.last=None

    def read(self):
        try:
            data=json.loads(self.path.read_text(encoding='utf-8'))
            if data.get('schema')!=1 or not isinstance(data.get('values'),dict):return None
            return data
        except (OSError,ValueError,TypeError):return None

    def matches(self,data,records):
        # Normalize JSON arrays/tuples before comparison.
        return json.dumps(data.get('cad'))==json.dumps(cad_signature(records))

    def save(self,records,values,view,preview=None):
        groups={g:[r['face_id'] for r in records if r['group']==g] for g in ('journal','pin')}
        data=dict(schema=1,groups=groups,cad=cad_signature(records),values=deepcopy(values),view=view,preview=deepcopy(preview or {}))
        key=json.dumps(data,sort_keys=True)
        if key==self.last:return
        self.path.parent.mkdir(parents=True,exist_ok=True)
        write_json(self.path,data);self.last=key
