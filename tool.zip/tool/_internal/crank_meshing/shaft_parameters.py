"""Shaft parameters for Crank Meshing."""
import math
from copy import deepcopy
import re
from crank_meshing.cad_geometry import make_face_plan
from crank_meshing.mesh import journal_pin_mesh

def number(value, label):
    try:
        result = float(value)
    except (TypeError, ValueError):
        raise ValueError(label+' must be a number')
    if not math.isfinite(result) or result <= 0:
        raise ValueError(label+' must be greater than zero')
    return result


def ordered(records, group):
    return sorted((r for r in records if r['group'] == group),
                  key=lambda r:(r['center']['xyz_m'][0], r['face_id']))


def centered_positions(gaps):
    positions = [0.]
    for gap in gaps:
        positions.append(positions[-1]+number(gap, 'Center spacing'))
        if not math.isfinite(positions[-1]): raise ValueError('Cumulative center spacing must be finite')
    middle = len(positions)//2
    origin = positions[middle] if len(positions)%2 else (positions[middle-1]+positions[middle])/2
    return [v-origin for v in positions]


def default_inputs():
    return {group:dict(placement='centered', widths={}, radii={}, gaps={})
            for group in ('journal','pin')}


def pair_key(a, b):
    return '%d:%d' % (a['face_id'], b['face_id'])


def cad_values(records, group, index):
    rows = ordered(records, group)
    row = rows[index]
    return dict(radius=row['radius_m']*1000, width=row['width_m']*1000,
        gap=(rows[index+1]['center']['xyz_m'][0]-row['center']['xyz_m'][0])*1000
            if index+1 < len(rows) else None)


def effective_geometry(records, inputs=None):
    """CAD topology is kept separately; only new insert geometry is changed."""
    if inputs is None:
        return deepcopy(records)
    if inputs.get('mode')=='manual':
        from crank_meshing.ui.dialog_layout import cad_cell, format_cell
        result=deepcopy(records)
        for row in result:
            values=inputs.get('values',{}).get(row['group'],{}).get(str(row['face_id']),{})
            for field,value in values.items():
                if field not in ('radius','width','x','y','z'):continue
                # An untouched display value must reuse full CAD precision.
                if str(value)==format_cell(cad_cell(row,field)):continue
                if field in ('radius','width'):
                    row[field+'_m']=number(value,row['group']+' '+field)*.001
                else:
                    try: coordinate=float(value)
                    except (TypeError,ValueError):raise ValueError(row['group']+' '+field.upper()+' must be a number')
                    if not math.isfinite(coordinate):raise ValueError('Center coordinates must be finite')
                    row['center']['xyz_m']['xyz'.index(field)]=coordinate*.001
            axial=row['center']['xyz_m']['XYZ'.index(row['axis'])]
            row['boundary_planes_m']=[axial-row['width_m']/2,axial+row['width_m']/2]
            row['input_source']='manual table'
        return result
    output=[]
    for group in ('journal','pin'):
        rows = ordered(records,group)
        settings = inputs.get(group,{})
        placement = settings.get('placement','centered')
        if placement not in ('cad','centered'):
            raise ValueError('Unknown station placement')
        if any(row['axis']!='X' for row in rows) and placement!='cad':
            raise ValueError('Centered stations require cylinders parallel to X')
        gaps=[]
        for a,b in zip(rows,rows[1:]):
            source=(b['center']['xyz_m'][0]-a['center']['xyz_m'][0])*1000
            gaps.append(settings.get('gaps',{}).get(pair_key(a,b),source))
        xs = centered_positions(gaps) if rows and placement=='centered' else None
        for index,cad in enumerate(rows):
            row=deepcopy(cad)
            fid=str(row['face_id'])
            row['width_m']=number(settings.get('widths',{}).get(fid,cad['width_m']*1000),group+' width')*.001
            row['radius_m']=number(settings.get('radii',{}).get(fid,cad['radius_m']*1000),group+' radius')*.001
            if xs is not None:
                row['center']['xyz_m'][0]=xs[index]*.001
                if group=='journal': row['center']['xyz_m'][1:]=[0.,0.]
            axial=row['center']['xyz_m']['XYZ'.index(row['axis'])]
            row['boundary_planes_m']=[axial-row['width_m']/2,axial+row['width_m']/2]
            row['input_source']='cad' if placement=='cad' else 'centered spacing'
            output.append(row)
    return output


def validate_clearance(geometry, removal):
    """Check new insert ends against retained CAD rings before deleting CAD faces."""
    rows={r['face_id']:r for r in geometry}
    for connection in removal['connections']:
        row=rows[connection['cylinder_face_id']]
        inner=connection['inner_ring']['plane_m']
        outer=connection['outer_ring']['plane_m']
        side=-1 if outer<inner else 1
        end=row['boundary_planes_m'][0 if side<0 else 1]
        if side*(outer-end) <= 1e-8:
            raise ValueError('%s face %d: new width/spacing crosses its retained CAD ring; reduce it or reuse CAD'
                % (row['group'].capitalize(),row['face_id']))



SEGMENTS = (32, 40)
DEFAULT_TARGETS = dict(journal='201-207 211-217 221-227 231-237',
                       pin='311-317 321-327 331-337 341-347')
FIXED_LAYERS = {group:dict(width_layers='6',radial_layers='6',
    width_ratios='1:2:3:3:2:1' if group=='journal' else '1:1:1:1:1:1',
    radial_ratios='1:1:1:1:1:1') for group in ('journal','pin')}


def clean_settings(values=None):
    """Crank product defaults fixed by the user; generic geometry core stays reusable."""
    settings=deepcopy(values or {})
    settings.update(layers=deepcopy(FIXED_LAYERS),rbe=True,ring=2,dofs='123456')
    settings['segments']=40
    settings.setdefault('renumber',False)
    settings.setdefault('targets',deepcopy(DEFAULT_TARGETS))
    settings.setdefault('increment','1')
    return settings


def expand_targets(text, increment):
    core = journal_pin_mesh
    step = core.integer(increment, 'Renumber increment', 1, core.MAX_ID)
    ids, seen = [], set()
    for token in text.replace(',', ' ').split():
        match = re.fullmatch(r'(\d+)(?:-(\d+))?', token)
        if not match:
            raise ValueError('Target IDs: use ranges such as 201-207 211-217')
        first = core.integer(match[1], 'Target ID', 1, core.MAX_ID)
        last = core.integer(match[2] or match[1], 'Target ID', first, core.MAX_ID)
        if len(ids)+(last-first)//step+1 > 10000:
            raise ValueError('Target list exceeds 10000 IDs')
        for nid in range(first, last+1, step):
            if nid in seen:
                raise ValueError('Duplicate target ID %d' % nid)
            ids.append(nid)
            seen.add(nid)
    return ids


def configured_plan(geometry, settings, scale, segments=32, rbe=True, ring=1,
                    dofs='123456', renumber=True, targets=None, increment=1, existing_ids=()):
    core = journal_pin_mesh
    segments = core.integer(segments, 'Segments', 3, 720)
    if segments not in SEGMENTS:
        raise ValueError('Segments must be 32 or 40')
    axis = 'XYZ'.index(geometry[0]['axis']) if geometry else 0
    geometry = sorted(geometry, key=lambda r: (r['group'] != 'journal', r['center']['xyz_m'][axis]))
    rows = make_face_plan(geometry, settings, scale, segments)
    if rbe and (not dofs or any(d not in '123456' for d in dofs) or len(set(dofs)) != len(dofs)):
        raise ValueError('RBE2 DOFs must be distinct digits 1..6')
    ring = core.integer(ring, 'RBE2 radial ring', 1, 1000)
    targets = DEFAULT_TARGETS if targets is None else targets
    assignments, usage = {}, {}
    for group in ('journal', 'pin'):
        selected = [r for r in rows if r['group'] == group]
        need = sum(int(r['params']['nw'])+1 for r in selected)
        ids = expand_targets(targets[group], increment) if renumber else []
        if renumber and len(ids) < need:
            raise ValueError('%s needs %d axial-center IDs; only %d supplied' % (group.capitalize(), need, len(ids)))
        usage[group] = dict(required=need, used=ids[:need], unused=ids[need:])
        offset = 0
        for row in selected:
            p = row['params']
            if rbe and ring > int(p['nr']):
                raise ValueError('%s radial ring %d exceeds %s R layers' % (group, ring, p['nr']))
            count = int(p['nw'])+1
            p.update(rbe=bool(rbe), ring=str(ring), dofs=dofs, renumber=bool(renumber),
                targets=' '.join(map(str, ids[offset:offset+count])), step='1',
                master_targets=ids[offset:offset+count] if renumber else [])
            assignments[row['center']['face_id']] = p['master_targets']
            offset += count
    used = [nid for group in usage.values() for nid in group['used']]
    if len(set(used)) != len(used):
        raise ValueError('Journal and Pin target lists overlap')
    collisions = sorted(set(used) & set(existing_ids))
    return rows, dict(groups=usage, assignments=assignments, collisions=collisions,
        import_ready=not collisions, ring=ring, segments=segments,
        numbering='Faces sorted along axis within each group; centers numbered from low to high axial plane')


def ordered_batch_targets(meshes, plan):
    """Adapt per-face center IDs to the core writer's global axial sorting."""
    if not any(row['params'].get('renumber') for row in plan):
        return []
    if len(meshes) != len(plan) or len({r['params']['axis'] for r in plan}) != 1:
        raise ValueError('One parallel-axis plan row per mesh required')
    axis = 'XYZ'.index(plan[0]['params']['axis'])
    ordered = []
    for index, (mesh, row) in enumerate(zip(meshes, plan)):
        ids = row['params'].get('master_targets', [])
        if len(ids) != mesh['nw']+1:
            raise ValueError('Every renumbered insert needs one target for each axial plane')
        for layer, nid in enumerate(ids):
            ordered.append((mesh['points'][layer*mesh['disk_nodes']][axis], index, layer, nid))
    targets = [item[3] for item in sorted(ordered)]
    if len(set(targets)) != len(targets):
        raise ValueError('Duplicate batch target IDs')
    return targets
