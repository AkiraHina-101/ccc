"""Mesh preparation for Crank Meshing."""
from pathlib import Path
import math
from crank_meshing.mesh.journal_pin_solids import prepared_batch, batch_key, verify_import
from crank_meshing.model_parts import native_transaction
from crank_meshing.mesh.journal_pin_solids import build_native_batch
from crank_meshing.mesh.interface_stitching import section_patches, bridge_rings, verify_closed_skin
from crank_meshing.model_parts import indexed, delete_old_faces
from crank_meshing.mesh import journal_pin_mesh
from crank_meshing.mesh.interface_stitching import tri6_signature
from crank_meshing.mesh.interface_stitching import optimize_diagonals, quality_summary

def index_tri6_faces(faces):
    """Fetch each face's native element vector once per operation."""
    index = {}
    for face in faces:
        elements = list(face.elems)
        if not elements: continue
        triangles = [tuple(int(n.id) for n in e.nodes) for e in elements]
        if any(len(triangle) != 6 for triangle in triangles): continue
        key = frozenset(tri6_signature(triangle) for triangle in triangles)
        index.setdefault(key, []).append(face)
    return index


class Preparation:
    def __init__(self, session):
        self.s, self.jpt = session, session.jpt
        self.progress = session.state.setdefault('preparation', {})

    def save(self, value=None):
        self.s.save()

    def command(self, key, command):
        if self.progress.get(key, {}).get('started'):
            raise ValueError(key+' already attempted; inspect the saved native state')
        entry = self.progress.setdefault(key, {})
        entry.update(started=True, command=command)
        self.save()
        callback = getattr(self.s, 'progress_notify', None)
        if callback: callback(key)
        entry['response'] = str(self.jpt.Exec(command))
        self.save()
        return entry

    def remove(self):
        progress = self.progress.setdefault('removal', {})
        # Persist the once-only guard BEFORE calling the deletion adapter.
        if progress.get('attempted'):
            raise ValueError('Deletion already attempted; inspect the model before recovery')
        progress['attempted'] = True
        self.save()
        result = delete_old_faces(self.jpt, self.s.state['main_plan']['removal'], progress)
        self.save()
        return result

    def inserts(self):
        before = {int(p.key) for p in self.jpt.GetAllParts()}
        result = build_native_batch(self.jpt, self.s.state['main_plan']['inserts'], self.s.folder,
                             self.progress.setdefault('batch', {}), self.save, context=self.s.context)
        result['part_keys'] = [int(p.key) for p in self.jpt.GetAllParts() if int(p.key) not in before]
        self.save()
        return result

    def patches(self):
        if 'patches' in self.s.context:
            return self.s.context['patches']
        plan = self.s.state['main_plan']
        batch = self.progress['batch']
        self.ensure_native_meshes()
        scale = batch['scale']
        points = {}
        # GetAllNodes includes solid-only nodes that are absent from face snapshots.
        points.update({int(n.id): (float(n.pos.x), float(n.pos.y), float(n.pos.z))
                       for n in self.jpt.GetAllNodes()})
        bridges, disks, baseline_bridges = [], [], []
        for row, mesh, mapping in zip(plan['inserts'], prepared_batch(plan['inserts'], scale, self.s.context), batch['export']['mapping']):
            sections, meshpoints = section_patches(mesh, mapping, row['params']['axis'], scale)
            points.update(meshpoints)
            face_id = row['geometry']['face_id']
            connections = [c for c in plan['removal']['connections'] if c['cylinder_face_id'] == face_id]
            # Pair left/right source rings with left/right NEW insert ends.
            # Their planes intentionally differ when station inputs change.
            if len(connections)!=2 or len(sections)!=2:
                raise ValueError('Each insert requires two retained CAD connections')
            connections.sort(key=lambda c:c['inner_ring']['plane_m'])
            sections.sort(key=lambda disk:disk['plane_m'])
            for disk,connection in zip(sections,connections):
                baseline=bridge_rings(disk['ring_node_ids'], connection['outer_node_ids'], points,
                    row['params']['axis'], row['center']['xyz_m'],optimize=False)
                triangles=optimize_diagonals(baseline,disk['ring_node_ids'],points,row['params']['axis'])
                baseline_bridges.extend(baseline)
                bridges.append(dict(kind='bridge', face_id=face_id,triangles=triangles,
                    inner_node_ids=disk['ring_node_ids'],outer_node_ids=connection['outer_node_ids'],
                    inner_edge_ids=disk.get('native_edge_ids'),
                    outer_edge_id=connection['outer_edge_id'],axis=row['params']['axis'],
                    quality=dict(before=quality_summary(baseline,points),after=quality_summary(triangles,points))))
                # Reverse the insert-outward section to point outward from the remainder.
                disks.append(dict(kind='section', face_id=face_id, plane_m=disk['plane_m'],
                    triangles=[tuple(f[i] for i in (0, 2, 1, 5, 4, 3)) for f in disk['faces']]))
        source = self.s.state['source_snapshot']
        _, _, _, elems = indexed(source)
        deleted = set(plan['removal']['delete_element_ids'])
        skin = [n for eid, n in elems.items() if eid not in deleted and len(n) in (3, 6)]
        skin += [t[:3] for p in bridges+disks for t in p['triangles']]
        proof = verify_closed_skin(skin)
        self.s.context['patches'] = dict(bridges=bridges, disks=disks, points=points)
        self.s.state['closure_proof'] = proof
        self.s.state['bridge_quality']=dict(method='Constrained cross-ring diagonal flips; max-min 3D angle',
            rings=len(bridges),before=quality_summary(baseline_bridges,points),
            after=quality_summary([t for patch in bridges for t in patch['triangles']],points))
        self.save()
        return self.s.context['patches']

    def import_patches(self, kind):
        """Separate surface-only BDF; fresh nodes map explicitly to existing IDs."""
        from Home.ImportMesh import NastranBdf
        key = 'surface_'+kind
        if self.progress.get(key, {}).get('started'):
            raise ValueError('Surface import already attempted; inspect its checkpoint')
        patches = self.patches()['bridges' if kind == 'bridges' else 'disks']
        self.reserve_part_ids(kind, len(patches))
        jpt, core = self.jpt, journal_pin_mesh
        before_parts = {int(p.key) for p in jpt.GetAllParts()}
        before_elems = {int(e.id) for e in jpt.GetAllElems()}
        next_e = max(before_elems | {0})+1
        next_n = int(jpt.GetMaxIDEntity(jpt.DItemType.NODE))+1
        prop_start = max({int(p.id) for p in jpt.GetAllParts()} |
            {int(p.id) for p in jpt.GetAllByTableTypeID(jpt.DTableType.DTABLE_PROPERTY)} | {0})+1
        nodes = sorted({n for p in patches for t in p['triangles'] for n in t})
        mapping = dict(zip(nodes, range(next_n, next_n+len(nodes))))
        points = self.patches()['points']
        scale = self.progress['batch']['scale']
        path = Path(self.s.folder) / (kind+'.bdf')
        expected = {}
        with path.open('w', encoding='ascii', newline='\n') as stream:
            stream.write('BEGIN BULK\n')
            for old, new in mapping.items():
                core.write_card(stream, 'GRID', [new, '', *('%.16g' % (v*scale) for v in points[old])])
            for index, patch in enumerate(patches):
                pid = prop_start+index
                stream.write('$HMNAME COMP %d "Crank_%s_%d"\n' % (pid, kind, index+1))
                core.write_card(stream, 'PSHELL', [pid, '', '1.'])
                for tri in patch['triangles']:
                    expected[next_e] = [mapping[n] for n in tri]
                    core.write_card(stream, 'CTRIA6' if len(tri) == 6 else 'CTRIA3', [next_e, pid, *expected[next_e]])
                    next_e += 1
            stream.write('ENDDATA\n')
        entry = self.progress.setdefault(key, {})
        entry.update(started=True, file=str(path), node_mapping=mapping, expected=expected)
        self.save()
        entry['response'] = str(NastranBdf([str(path)], iImportType=2, bReadNameComment=True, iCreateDup1DElemAnswer=0))
        # Import also creates native edge/vertex elements (2/1 nodes).
        # Compare every newly created surface, excluding those topology helpers.
        actual = {int(e.id): [int(n.id) for n in e.nodes]
                  for e in jpt.GetElemsByKind(jpt.ElemKind.ELEMKIND_2D) if int(e.id) not in before_elems}
        if actual != expected:
            raise RuntimeError('Imported '+kind+' surface connectivity differs from the TET10/bridge plan')
        parts = [p for p in jpt.GetAllParts() if int(p.key) not in before_parts]
        entry.update(part_keys=[int(p.key) for p in parts], verified=True, elements=len(actual))
        self.save()
        return dict(patches=len(patches), elements=len(actual), quadratic=(kind == 'disks'))

    def bridges(self):
        try:
            from Geometry.Face import Edges
        except ImportError:
            return self.import_patches('bridges')
        with native_transaction(self.jpt,'Crank Face Edges bridges'):
            return self.native_bridges(Edges)

    def native_bridges(self,create_face):
        """Vendor Face > Edges triangulation with exact original ring boundaries."""
        entry=self.progress.setdefault('surface_bridges',{})
        if entry.get('started'): raise ValueError('Bridge creation already attempted; inspect its checkpoint')
        jpt=self.jpt; patches=self.patches()['bridges']
        before_nodes={int(n.id):(float(n.pos.x),float(n.pos.y),float(n.pos.z)) for n in jpt.GetAllNodes()}
        before_solids=self.solid_connectivity(); before_connections=self.connection_connectivity()
        edge_nodes=None
        targets=[]
        for patch in patches:
            ring=set(patch['inner_node_ids'])
            matches=patch.get('inner_edge_ids')
            if not matches:
                if edge_nodes is None: edge_nodes={int(e.id):{int(n.id) for n in e.nodes} for e in jpt.GetAllEdges()}
                matches=[eid for eid,nodes in edge_nodes.items() if ring.issubset(nodes)]
                if len(matches)!=1: raise ValueError('Cannot identify native insert boundary edges')
            targets.append(list(matches)+[patch['outer_edge_id']])
        entry.update(started=True,backend='Geometry.Face.Edges',
            actions=[dict(started=True,edge_ids=ids) for ids in targets],node_mapping={},expected={},part_keys=[])
        self.save()
        for patch,ids,action in zip(patches,targets,entry['actions']):
            prior_keys={int(part.key) for part in jpt.GetAllParts()}
            action['response']=str(create_face('[%s]'%', '.join('5:%d'%eid for eid in ids),
                bCreatePart=True,bSmoothFace=False,bSharedFace=False,bIncludeMidNodes=False))
            new=[part for part in jpt.GetAllParts() if int(part.key) not in prior_keys]
            if len(new)!=1: raise RuntimeError('Face Edges did not create one bridge part; inspect its checkpoint')
            actual={int(e.id):tuple(int(n.id) for n in e.nodes) for f in new[0].faces for e in f.elems}
            if not actual or any(len(t)!=3 for t in actual.values()):
                raise RuntimeError('Face Edges did not produce a TRI3 bridge')
            def boundary(triangles):
                from collections import Counter
                counts=Counter(tuple(sorted((t[i],t[j]))) for t in triangles for i,j in ((0,1),(1,2),(2,0)))
                if any(n>2 for n in counts.values()): raise RuntimeError('Nonmanifold native bridge')
                return {e for e,n in counts.items() if n==1}
            if boundary(actual.values())!=boundary(patch['triangles']):
                raise RuntimeError('Face Edges changed the required insert/crank boundary segments')
            patch['triangles']=list(actual.values())
            entry['part_keys'].append(int(new[0].key)); entry['expected'].update(actual)
            action.update(verified=True,part_key=int(new[0].key),elements=len(actual))
        points={int(n.id):(float(n.pos.x),float(n.pos.y),float(n.pos.z)) for n in jpt.GetAllNodes()}
        if any(points.get(n)!=xyz for n,xyz in before_nodes.items()) or \
                before_solids!=self.solid_connectivity() or before_connections!=self.connection_connectivity():
            raise RuntimeError('Face Edges changed an existing node, insert solid or RBE2')
        self.s.context['patches']['points'].update(points)
        for patch in patches: patch['quality']['after']=quality_summary(patch['triangles'],points)
        proof=self.s.state['bridge_quality']; proof.update(method='Geometry.Face.Edges; exact ring boundaries',
            after=quality_summary([t for patch in patches for t in patch['triangles']],points))
        _,_,_,source=indexed(self.s.state['source_snapshot'])
        deleted=set(self.s.state['main_plan']['removal']['delete_element_ids'])
        skin=[t for eid,t in source.items() if eid not in deleted and len(t) in (3,6)]
        skin.extend(t[:3] for kind in ('bridges','disks') for patch in self.s.context['patches'][kind] for t in patch['triangles'])
        self.s.state['closure_proof']=verify_closed_skin(skin)
        entry.update(verified=True,elements=len(entry['expected']),quality=proof,
            original_nodes_unchanged=True,insert_solids_unchanged=True,rbe2_unchanged=True)
        self.save()
        return dict(patches=len(patches),elements=entry['elements'],quadratic=False,native_face_edges=True,quality=proof)

    def sections(self):
        from Geometry import ExtractSurfaces
        entry = self.progress.setdefault('surface_disks', {})
        if entry.get('started'): raise ValueError('Section extraction already attempted')
        patches = self.patches()['disks']
        face_index = index_tri6_faces(self.jpt.GetAllFaces())
        originals = []
        for patch in patches:
            wanted = {tri6_signature(t) for t in patch['triangles']}
            matches = face_index.get(frozenset(wanted), [])
            if len(matches) != 1: raise ValueError('Expected one actual native TET10 section face')
            originals.append(matches[0])
        before_keys = {int(part.key) for part in self.jpt.GetAllParts()}
        entry.update(started=True, original_face_ids=[int(f.id) for f in originals])
        self.save()
        entry['response'] = str(ExtractSurfaces('[%s]' % ', '.join('6:%d' % f.id for f in originals),
            dFaceAngle=0., strName='Crank_sections', bMergePart=True))
        new = [part for part in self.jpt.GetAllParts() if int(part.key) not in before_keys]
        points = self.patches()['points']
        lookup = {}
        needed = {n for patch in patches for t in patch['triangles'] for n in t}
        for n in needed:
            key = tuple(round(v, 10) for v in points[n])
            if key in lookup and lookup[key] != n: raise ValueError('Ambiguous section coordinates')
            lookup[key] = n
        inverse = {}
        for part in new:
            for node in part.nodes:
                key = tuple(round(v, 10) for v in (node.pos.x, node.pos.y, node.pos.z))
                if key not in lookup: raise RuntimeError('Extracted section includes an unexpected node')
                inverse[int(node.id)] = lookup[key]
        actual = {int(e.id): [int(n.id) for n in e.nodes] for part in new for f in part.faces for e in f.elems}
        wanted = {tri6_signature(t) for patch in patches for t in patch['triangles']}
        found = {tri6_signature([inverse[n] for n in tri]) for tri in actual.values()}
        if found != wanted or len(actual) != sum(len(p['triangles']) for p in patches):
            raise RuntimeError('Native extraction lost section triangles or midside edge assignments')
        entry.update(node_mapping={old: new_id for new_id, old in inverse.items()}, expected=actual,
            part_keys=[int(part.key) for part in new], extracted_face_ids=[int(f.id) for part in new for f in part.faces],
            verified=True, elements=len(actual))
        self.save()
        return dict(patches=len(patches), elements=len(actual), quadratic=True, native_extraction=True)

    def merge_nodes(self):
        originals, copies = [], []
        for kind in ('bridges', 'disks'):
            mapping = self.progress['surface_'+kind]['node_mapping']
            originals.extend(map(int, mapping.keys()))
            copies.extend(map(int, mapping.values()))
            if not mapping:
                originals.extend(n for nodes in self.progress['surface_'+kind]['expected'].values() for n in nodes)
        targets = sorted(set(originals+copies))
        if not targets:
            raise ValueError('Explicit local interface nodes are required')
        command = 'MergeNode(1e-10, 3, [%s], 0, 1)' % ', '.join('10:%d' % n for n in targets)
        entry = self.command('merge_nodes', command)
        present = {int(n.id) for n in self.jpt.GetAllNodes()}
        if not set(originals).issubset(present) or set(copies) & present:
            raise RuntimeError('Merge must keep every original interface ID and remove every surface copy')
        actual = {int(e.id): [int(n.id) for n in e.nodes]
                  for e in self.jpt.GetElemsByKind(self.jpt.ElemKind.ELEMKIND_2D)}
        for kind in ('bridges', 'disks'):
            patch = self.progress['surface_'+kind]
            inverse = {int(v): int(k) for k, v in patch['node_mapping'].items()}
            for eid, nodes in patch['expected'].items():
                if actual.get(int(eid)) != [inverse.get(n,n) for n in nodes]:
                    raise RuntimeError('Merged surface lost exact original corner/midside connectivity')
        entry.update(verified=True, merged_copies=len(set(copies)))
        self.save()
        return entry

    def shared(self):
        entry = self.progress.setdefault('shared_faces', {})
        if entry.get('started'): raise ValueError('Shared-face pairing already attempted')
        self.check_part_scope()
        disks = self.patches()['disks']
        face_index = index_tri6_faces(self.jpt.GetAllFaces())
        extracted = set(self.progress['surface_disks']['extracted_face_ids'])
        pairs = []
        for disk in disks:
            wanted = {tri6_signature(t) for t in disk['triangles']}
            matches = face_index.get(frozenset(wanted), [])
            new = [f for f in matches if int(f.id) in extracted]
            old = [f for f in matches if int(f.id) not in extracted]
            if len(new) != 1 or len(old) != 1: raise RuntimeError('Section pairing is missing or ambiguous')
            pairs.extend([int(new[0].id), int(old[0].id)])
        entry.update(started=True, face_pairs=pairs)
        self.save()
        before_solids = self.solid_connectivity()
        before_connections = self.connection_connectivity()
        # Geometric AssembleFaceEx invalidates existing solid meshes. Convert the
        # already merged interface nodes instead, then restore quadratic skins.
        entry['response'] = self.command('convert_shared_nodes', 'CreateSharedFace()')['response']
        self.quadratic_shared_sections(disks)
        shared = self.shared_readback()
        needed = {tri6_signature(t) for p in disks for t in p['triangles']}
        found = {tri6_signature([int(n.id) for n in e.nodes]) for f in shared for e in f.elems if len(e.nodes) == 6}
        if not needed.issubset(found):
            raise RuntimeError('Shared section triangles: %d/%d. Model kept for inspection.' % (len(needed & found), len(needed)))
        if self.solid_connectivity() != before_solids or self.connection_connectivity() != before_connections:
            raise RuntimeError('Shared conversion changed inserts or RBE2. Model kept for inspection.')
        entry.update(verified=True, face_ids=[int(f.id) for f in shared], section_triangles=len(needed))
        self.save()
        return entry

    def check_part_scope(self):
        allowed = set(self.s.state['source_part_keys'])
        for key in ('batch', 'surface_bridges', 'surface_disks'):
            allowed.update(self.progress[key]['part_keys'])
        actual = {int(part.key) for part in self.jpt.GetAllParts()}
        if actual != allowed:
            raise ValueError('A part was added or removed during this run. Keep this test model unchanged.')

    def reserve_part_ids(self, stage, count):
        """BDF importer numbers fresh parts from 1; move existing IDs out first.

        RenumberSpecify's part-only type4 is verified on Jupiter5.0.4. Never
        address a duplicate external ID. Keys, mesh IDs and connectivity stay.
        """
        prior = self.progress.get('reserve_parts_'+stage, {})
        if prior.get('started') and not prior.get('verified'):
            raise ValueError('Part numbering was already attempted; inspect its result before importing.')
        parts = list(self.jpt.GetAllParts())
        ids = [int(part.id) for part in parts]
        if len(set(ids)) != len(ids):
            raise ValueError('This model already has duplicate part numbers. Run the updated tool on a clean copy.')
        if not any(pid <= count for pid in ids): return
        before_nodes = {int(n.id): (n.pos.x, n.pos.y, n.pos.z) for n in self.jpt.GetAllNodes()}
        before_elems = {int(e.id): tuple(int(n.id) for n in e.nodes) for e in self.jpt.GetAllElems()}
        keys = {int(part.key) for part in parts}
        start = max(ids + [count]) + 1
        cursors = '[%s]' % ', '.join('3:%d' % pid for pid in ids)
        entry = self.command('reserve_parts_'+stage,
                             'RenumberSpecify(%s, 4, 0, %d, 1, 1)' % (cursors, start))
        after = list(self.jpt.GetAllParts())
        after_ids = [int(part.id) for part in after]
        if {int(part.key) for part in after} != keys or len(set(after_ids)) != len(ids) or min(after_ids) <= count:
            raise RuntimeError('Part numbering was not reserved for import. Model kept.')
        if before_nodes != {int(n.id): (n.pos.x, n.pos.y, n.pos.z) for n in self.jpt.GetAllNodes()} or \
                before_elems != {int(e.id): tuple(int(n.id) for n in e.nodes) for e in self.jpt.GetAllElems()}:
            raise RuntimeError('Part numbering changed mesh IDs or connectivity.')
        entry.update(verified=True, before_ids=ids, after_ids=after_ids)
        self.save()

    def solid_connectivity(self):
        return {int(e.id): tuple(int(n.id) for n in e.nodes)
                for e in self.jpt.GetElemsByKind(self.jpt.ElemKind.ELEMKIND_3D)}

    def verify_insert_geometry(self, allow_remainder=False, actual_nodes=None, actual_solids=None):
        batch = self.progress['batch']
        self.ensure_native_meshes()
        export = batch['export']
        wanted_nodes = set(export['node_ids'])
        if actual_nodes is None:
            actual_nodes = {}
            for node in self.jpt.GetAllNodes():
                nid = int(node.id)
                if nid in wanted_nodes:
                    pos = node.pos
                    actual_nodes[nid] = (float(pos.x), float(pos.y), float(pos.z))
        solids = self.solid_connectivity() if actual_solids is None else actual_solids
        if allow_remainder:
            expected = set(export['element_ids'])
            solids = {eid:nodes for eid,nodes in solids.items() if eid in expected}
        return verify_import(prepared_batch(self.s.state['main_plan']['inserts'], batch['scale'], self.s.context),
                             export, actual_nodes, solids, batch['scale'])

    def ensure_native_meshes(self):
        batch=self.progress.get('batch',{})
        if batch.get('backend')=='native_circular_sweep' and '_native_meshes' not in self.s.context:
            import json
            meshes=json.loads(Path(batch['native_mesh_file']).read_text(encoding='utf-8'))
            self.s.context['_native_meshes']=dict(key=batch_key(self.s.state['main_plan']['inserts'],batch['scale']),meshes=meshes)

    def connection_connectivity(self):
        return {int(c.id): (tuple(int(n.id) for n in c.masters), tuple(int(n.id) for n in c.slaves))
                for c in self.jpt.GetAllByTableTypeID(self.jpt.DTableType.DTABLE_CONNECTION)}

    def quadratic_shared_sections(self, disks):
        corners = {tuple(sorted(t[:3])) for d in disks for t in d['triangles']}
        owners = [part for part in self.jpt.GetAllParts()
                  if int(part.key) in self.progress['surface_disks']['part_keys']]
        # ExtractSurfaces(bMergePart=True) creates one disk-only part. Scope the
        # conversion to that owner: never convert source/bridge/insert surfaces.
        if len(owners) != 1:
            raise RuntimeError('The extracted sections must belong to one surface part.')
        owner = owners[0]
        if sum(int(part.id) == int(owner.id) for part in self.jpt.GetAllParts()) != 1:
            raise RuntimeError('The extracted section part needs a unique number.')
        actual_corners = {tuple(sorted(int(n.id) for n in e.nodes[:3]))
                          for f in owner.faces for e in f.elems}
        if actual_corners != corners:
            raise RuntimeError('The section part includes other surfaces; conversion stopped.')
        self.command('shared_sections_quadratic', 'ElementConv_Surface([3:%d], 1)' % owner.id)
        edge_mid = {}
        for d in disks:
            for a, b, c, ab, bc, ca in d['triangles']:
                for edge, mid in (((a, b), ab), ((b, c), bc), ((c, a), ca)):
                    edge_mid[tuple(sorted(edge))] = mid
        points = {int(n.id): (n.pos.x, n.pos.y, n.pos.z) for n in self.jpt.GetAllNodes()}
        mapping = {}
        for f in self.shared_readback():
            for e in f.elems:
                ids = [int(n.id) for n in e.nodes]
                if tuple(sorted(ids[:3])) not in corners: continue
                if len(ids) != 6: raise RuntimeError('A shared section is still TRI3.')
                a, b, c, ab, bc, ca = ids
                for edge, mid in (((a, b), ab), ((b, c), bc), ((c, a), ca)):
                    original = edge_mid[tuple(sorted(edge))]
                    if mid == original: continue
                    if mid < original or math.dist(points[mid], points[original]) > 1e-10:
                        raise RuntimeError('A shared midside differs from its TET10 edge.')
                    mapping[mid] = original
        if mapping:
            targets = sorted(set(mapping) | set(mapping.values()))
            self.command('shared_midpoint_merge', 'MergeNode(1e-10, 3, [%s], 0, 1)' %
                         ', '.join('10:%d' % n for n in targets))
        self.progress['shared_faces']['midside_copies'] = len(mapping)
        self.save()

    def shared_readback(self):
        from crank_meshing.model_parts import crank_keys
        keys=crank_keys(self.s.state)
        for name in ('batch','surface_disks','surface_bridges'):
            keys.update(self.progress.get(name,{}).get('part_keys',[]))
        targets = self.jpt.DItemVector()
        for part in self.jpt.GetAllParts():
            if int(part.key) in keys:targets.append(self.jpt.CastToDItem(part))
        return [self.jpt.CastDItemToDFace(item) for item in self.jpt.GetSharedFaces(targets)]

    def merge_parts(self, bulk=True):
        self.check_part_scope()
        parts = list(self.jpt.GetAllParts())
        shared_ids = set(self.progress['shared_faces']['face_ids'])
        before_solids = {int(e.id): tuple(int(n.id) for n in e.nodes)
                         for e in self.jpt.GetElemsByKind(self.jpt.ElemKind.ELEMKIND_3D)}
        before_connections = self.connection_connectivity()
        # Native imports may repeat external IDs. Never interpret a key as an
        # external ID: commands and cursor utilities use different lookups.
        if len({int(p.id) for p in parts}) != len(parts):
            raise ValueError('Native part IDs are duplicated; final merge is blocked until ownership can be addressed unambiguously')
        entry = dict(passes=[])
        self.progress['merge_parts'] = entry
        from crank_meshing.model_parts import crank_keys
        original_keys=set(self.s.state['source_part_keys'])
        source_keys = crank_keys(self.s.state)
        bridge_keys = set(self.progress['surface_bridges']['part_keys'])
        disk_keys = set(self.progress['surface_disks']['part_keys'])
        insert_keys = set(self.progress['batch']['part_keys'])
        needed = {tri6_signature(t) for d in self.patches()['disks'] for t in d['triangles']}
        if bulk:
            source = [part for part in parts if int(part.key) in source_keys]
            surfaces = [part for part in parts if int(part.key) in bridge_keys | disk_keys]
            if len(source) != 1:
                raise RuntimeError('Cannot identify the retained crankshaft part.')
            surfaces.sort(key=lambda part: int(part.key))
            ordered = source + surfaces
            cursors = '[%s]' % ', '.join('3:%d' % part.id for part in ordered)
            result = self.command('merge_surface_parts_bulk', 'MergePart(1e-8, 0, %s)' % cursors)
            result.update(before_parts=len(parts), after_parts=len(self.jpt.GetAllParts()))
            entry['passes'].append(result)
            entry['mode'] = 'bulk_surfaces_only'
            self.save()
            if {int(part.key) for part in self.jpt.GetAllParts()} != original_keys | insert_keys:
                raise RuntimeError('Bulk surface merge did not retain source and inserts.')
        for index in range(len(parts)):
            current = list(self.jpt.GetAllParts())
            source = [part for part in current if int(part.key) in source_keys]
            if len(source) != 1:
                raise RuntimeError('Cannot identify the retained crankshaft part.')
            slaves = [part for part in current if int(part.key) in bridge_keys | disk_keys]
            if not slaves: break
            slaves.sort(key=lambda part: (0 if int(part.key) in bridge_keys else
                                         1 if int(part.key) in disk_keys else 2, int(part.key)))
            # Attach the replacement surfaces to the crankshaft remainder.
            # Separate insert solids retain shared interfaces for later meshing.
            target = slaves[0]
            cursors = '[3:%d, 3:%d]' % (source[0].id, target.id)
            result = self.command('merge_parts_pass_%d' % index, 'MergePart(1e-8, 0, %s)' % cursors)
            after_count = len(self.jpt.GetAllParts())
            result.update(before_parts=len(current), after_parts=after_count)
            entry['passes'].append(result)
            self.save()
            if after_count >= len(current):
                raise RuntimeError('Part merge made no progress; uncertain command will not be repeated')
            expected_keys = {int(part.key) for part in current} - {int(target.key)}
            if {int(part.key) for part in self.jpt.GetAllParts()} != expected_keys:
                raise RuntimeError('Part merge did not retain the intended crankshaft owner.')
            if self.solid_connectivity() != before_solids or self.connection_connectivity() != before_connections:
                raise RuntimeError('Part merge changed insert connectivity or RBE2.')
            found = {tri6_signature([int(n.id) for n in e.nodes])
                     for f in self.shared_readback() for e in f.elems if len(e.nodes) == 6}
            if not needed.issubset(found):
                raise RuntimeError('Part merge changed shared TRI6 sections.')
        after_solids = {int(e.id): tuple(int(n.id) for n in e.nodes)
                        for e in self.jpt.GetElemsByKind(self.jpt.ElemKind.ELEMKIND_3D)}
        if before_solids != after_solids or not shared_ids.issubset({int(f.id) for f in self.jpt.GetAllFaces()}):
            raise RuntimeError('Merge changed insert solids or removed section shared faces')
        if {int(part.key) for part in self.jpt.GetAllParts()} != original_keys | insert_keys:
            raise RuntimeError('The crankshaft still has unattached surface parts.')
        found = {tri6_signature([int(n.id) for n in e.nodes])
                 for f in self.shared_readback() for e in f.elems if len(e.nodes) == 6}
        if not needed.issubset(found) or self.connection_connectivity() != before_connections:
            raise RuntimeError('Final merge did not preserve every shared TRI6 section and RBE2.')
        source = next(part for part in self.jpt.GetAllParts() if int(part.key) in source_keys)
        shared_keys = {int(f.key) for f in self.shared_readback()}
        if not shared_keys.issubset({int(f.key) for f in source.faces}):
            raise RuntimeError('A shared section is not attached to the crankshaft remainder.')
        skin = {int(e.id): [int(n.id) for n in e.nodes] for f in source.faces for e in f.elems}
        closure = verify_closed_skin(list(skin.values()))
        geometry_proof = self.verify_insert_geometry()
        entry.update(verified=True, remainder_part_key=int(source.key), remainder_part_id=int(source.id),
                     insert_part_keys=sorted(insert_keys), remainder_closure=closure, insert_geometry=geometry_proof,
                     stopped_before_crankshaft_tet10=True)
        self.save()
        return entry

    def volume_mesh(self):
        from crank_meshing.mesh.volume_meshing import mesh_remainder
        return mesh_remainder(self)

    def group_inserts(self):
        from crank_meshing.model_parts import group_inserts
        return group_inserts(self)

    def surface_mesh(self):
        from crank_meshing.mesh.surface_meshing import mesh_surface
        return mesh_surface(self)
