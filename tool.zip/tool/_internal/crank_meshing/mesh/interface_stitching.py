"""Interface stitching for Crank Meshing."""
import math
from collections import Counter
from collections import Counter, defaultdict

def tri6_signature(nodes):
    if len(nodes) != 6: raise ValueError('A quadratic triangle is required')
    a,b,c,ab,bc,ca=nodes
    return tuple(sorted((a,b,c))),tuple(sorted((tuple(sorted(edge)),mid)
        for edge,mid in (((a,b),ab),((b,c),bc),((c,a),ca))))


def tet10_signature(nodes):
    if len(nodes) != 10: raise ValueError('A quadratic tetrahedron is required')
    a,b,c,d,ab,bc,ca,ad,bd,cd=nodes
    return tuple(sorted((a,b,c,d))),tuple(sorted((tuple(sorted(edge)),mid)
        for edge,mid in (((a,b),ab),((b,c),bc),((c,a),ca),((a,d),ad),((b,d),bd),((c,d),cd))))


FACE_SLOTS = ((0, 1, 2, 4, 5, 6), (0, 1, 3, 4, 8, 7),
              (0, 2, 3, 6, 9, 7), (1, 2, 3, 5, 9, 8))
_MISSING=object()


def boundary_faces(tets):
    faces = {}
    for tet in tets:
        if len(tet) != 10 or len(set(tet)) != 10:
            raise ValueError('Expected valid TET10 connectivity')
        for slots in FACE_SLOTS:
            corners = tuple(sorted(tet[i] for i in slots[:3]))
            a, b, c = [tet[i] for i in slots[:3]]
            mids = tuple(sorted((min(u, v), max(u, v), tet[mid])
                                for (u, v), mid in zip(((a, b), (b, c), (a, c)), slots[3:])))
            previous=faces.get(corners,_MISSING)
            if previous is _MISSING:
                faces[corners]=mids
            elif previous is None:
                raise ValueError('Nonmanifold solid face')
            elif previous != mids:
                raise ValueError('Internal face has inconsistent quadratic midpoint nodes')
            else:
                # Keep a sentinel to reject a third incident tetra, release mids.
                faces[corners]=None
    return {corners:mids for corners,mids in faces.items() if mids is not None}


def verify_shared_interface(insert_tets, remainder_tets, required_corner_faces):
    """Verify whole expected triangular patches, not merely coincident nodes."""
    left, right = boundary_faces(insert_tets), boundary_faces(remainder_tets)
    return verify_boundary_interface(left,right,required_corner_faces)


def verify_boundary_interface(left,right,required_corner_faces):
    """Use already validated boundaries, preserving every quadratic edge check."""
    required = {tuple(sorted(face)) for face in required_corner_faces}
    if not required:
        raise ValueError('Explicit contact-face patches required; cannot infer contact from arbitrary common nodes')
    missing = required - (set(left) & set(right))
    if missing:
        raise ValueError('Solid interface is incomplete: %d required triangles do not share corner node IDs' % len(missing))
    if any(left[face] != right[face] for face in required):
        raise ValueError('Solid interface midside nodes differ; merging corner nodes alone is insufficient for TET10')
    return {'shared_triangles': len(required),
            'shared_node_ids': sorted({nid for face in required for nid in face + tuple(row[2] for row in left[face])})}




def triangle_min_angle(triangle,points):
    xyz=[points[n] for n in triangle[:3]]
    angles=[]
    for i in range(3):
        u=[xyz[(i+1)%3][k]-xyz[i][k] for k in range(3)]
        v=[xyz[(i+2)%3][k]-xyz[i][k] for k in range(3)]
        cross=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
        angles.append(math.degrees(math.atan2(math.sqrt(sum(x*x for x in cross)),sum(a*b for a,b in zip(u,v)))))
    return min(angles)


def quality_summary(triangles,points):
    values=sorted(triangle_min_angle(t,points) for t in triangles)
    return dict(triangles=len(values),minimum_angle_deg=values[0] if values else None,
                below_5_deg=sum(a<5 for a in values),below_10_deg=sum(a<10 for a in values),
                mean_minimum_angle_deg=sum(values)/len(values) if values else None)


def optimize_diagonals(triangles,inner_ids,points,axis):
    """Flip a convex strip quad only when its sorted pair of min angles improves.

    Test convexity in the ring plane and quality in 3D (axial offsets matter).
    Restrict replacement diagonals to cross-ring edges, so no ring chord cuts
    across the insert disk. Boundary segments, triangle count and IDs stay fixed.
    """
    faces=list(triangles); inner=set(inner_ids)
    transverse=[k for k in range(3) if k!='XYZ'.index(axis)]
    def orient(a,b,c):
        u,v=transverse; pa,pb,pc=points[a],points[b],points[c]
        return (pb[u]-pa[u])*(pc[v]-pa[v])-(pb[v]-pa[v])*(pc[u]-pa[u])
    def edge_rows():
        rows={}
        for i,t in enumerate(faces):
            for a,b in ((t[0],t[1]),(t[1],t[2]),(t[2],t[0])):
                rows.setdefault(tuple(sorted((a,b))),[]).append(i)
        return rows
    before=edge_rows(); boundary={e for e,rows in before.items() if len(rows)==1}
    scores=[triangle_min_angle(t,points) for t in faces]
    changed=True
    while changed:
        changed=False
        adjacency=edge_rows()
        for (a,b),rows in sorted(adjacency.items()):
            if len(rows)!=2: continue
            i,j=rows
            # Earlier flips in this pass may have removed this edge.
            if not {a,b}.issubset(faces[i]) or not {a,b}.issubset(faces[j]): continue
            c=next(n for n in faces[i] if n not in (a,b))
            d=next(n for n in faces[j] if n not in (a,b))
            if c==d or (c in inner)==(d in inner): continue
            diagonal=tuple(sorted((c,d)))
            if diagonal in adjacency: continue
            if orient(a,b,c)*orient(a,b,d)>=0 or orient(c,d,a)*orient(c,d,b)>=0: continue
            candidates=[(c,d,a),(d,c,b)]
            for k,old in enumerate((faces[i],faces[j])):
                if orient(*candidates[k])*orient(*old)<0:
                    x,y,z=candidates[k]; candidates[k]=(x,z,y)
            new=[triangle_min_angle(t,points) for t in candidates]
            old_pair=sorted((scores[i],scores[j])); new_pair=sorted(new)
            if not (new_pair[0]>old_pair[0]+1e-10 or
                    (abs(new_pair[0]-old_pair[0])<=1e-10 and new_pair[1]>old_pair[1]+1e-10)): continue
            faces[i],faces[j]=candidates; scores[i],scores[j]=new
            changed=True
            # Rebuild after a successful flip; do not use stale adjacency.
            break
    after=edge_rows()
    if {e for e,rows in after.items() if len(rows)==1}!=boundary or any(len(rows)>2 for rows in after.values()):
        raise ValueError('Bridge optimization changed its boundary or manifold topology')
    return faces




def oriented_boundary(mesh, mapping):
    """Return outward TRI6 faces with the same corner/midside IDs as TET10."""
    entries = {}
    for tet in mesh['tets']:
        for slots in FACE_SLOTS:
            local = [tet[i] for i in slots]
            key = tuple(sorted(local[:3]))
            entries.setdefault(key, []).append((local, next(i for i in tet[:4] if i not in local[:3])))
    result = []
    points = mesh['points']
    for rows in entries.values():
        if len(rows) == 2:
            continue
        if len(rows) != 1:
            raise ValueError('Nonmanifold insert boundary')
        local, opposite = rows[0]
        a, b, c = [points[i] for i in local[:3]]
        u = [b[i]-a[i] for i in range(3)]
        v = [c[i]-a[i] for i in range(3)]
        normal = [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]
        if sum(normal[i]*(points[opposite][i]-a[i]) for i in range(3)) > 0:
            # TRI6 ordering: a,b,c,ab,bc,ca.
            local = [local[i] for i in (0, 2, 1, 5, 4, 3)]
        result.append(tuple(mapping[i] for i in local))
    return result


def section_patches(mesh, mapping, axis, scale):
    """Extract both full section disks and outer corner rings from insert boundary."""
    index = 'XYZ'.index(axis)
    points = {mapping[i]: tuple(v/scale for v in p) for i, p in enumerate(mesh['points'])}
    lo = min(p[index] for p in points.values())
    hi = max(p[index] for p in points.values())
    native=mesh.get('native_sections')
    boundary = oriented_boundary(mesh, mapping) if native is None else []
    sections = []
    for plane in (lo, hi):
        item=min(native,key=lambda sec:abs(sec['plane_m']-plane)) if native is not None else None
        faces = [tuple(mapping[n] for n in f) for f in item['faces']] if item is not None else [face for face in boundary if all(abs(points[n][index]-plane) < 1e-9 for n in face)]
        if not faces:
            raise ValueError('No complete quadratic section patch')
        edges = Counter(tuple(sorted((face[i], face[j]))) for face in faces for i, j in ((0, 1), (1, 2), (2, 0)))
        ring = {n for edge, count in edges.items() if count == 1 for n in edge}
        if len(ring) != mesh['ns'] or any(count > 2 for count in edges.values()):
            raise ValueError('Section disk has unexpected boundary topology')
        section=dict(plane_m=plane, faces=faces, ring_node_ids=sorted(ring))
        if item is not None: section['native_edge_ids']=item['native_edge_ids']
        sections.append(section)
    return sections, points


def bridge_rings(inner_ids, outer_ids, points, axis, center, optimize=True):
    """Angular strip followed by quality flips; reuse both rings' node IDs."""
    transverse = [i for i in range(3) if i != 'XYZ'.index(axis)]
    def ordered(ids):
        if len(set(ids)) != len(ids) or len(ids) < 3:
            raise ValueError('Expected distinct ring node IDs')
        rows = sorted((math.atan2(points[n][transverse[1]]-center[transverse[1]],
                                 points[n][transverse[0]]-center[transverse[0]]) % (2*math.pi), n) for n in ids)
        gaps = [b[0]-a[0] for a, b in zip(rows, rows[1:])] + [rows[0][0]+2*math.pi-rows[-1][0]]
        if min(gaps) < 1e-9 or max(gaps) >= math.pi:
            raise ValueError('Repeated angles or incomplete ring')
        return rows
    inner, outer = ordered(inner_ids), ordered(outer_ids)
    ni, no = len(inner), len(outer)
    i = j = 0
    faces = []
    while i < ni or j < no:
        ai = inner[(i+1) % ni][0] + (2*math.pi if i+1 >= ni else 0) if i < ni else math.inf
        ao = outer[(j+1) % no][0] + (2*math.pi if j+1 >= no else 0) if j < no else math.inf
        a, b = inner[i % ni][1], outer[j % no][1]
        if ai <= ao:
            faces.append((a, inner[(i+1) % ni][1], b))
            i += 1
        else:
            faces.append((a, outer[(j+1) % no][1], b))
            j += 1
    counts = Counter(tuple(sorted((f[i], f[j]))) for f in faces for i, j in ((0, 1), (1, 2), (2, 0)))
    expected = {tuple(sorted((r[k], r[(k+1) % len(r)]))) for r in
                ([n for _, n in inner], [n for _, n in outer]) for k in range(len(r))}
    if {edge for edge, count in counts.items() if count == 1} != expected or any(count > 2 for count in counts.values()):
        raise ValueError('Bridge is not a manifold annulus')
    for f in faces:
        a, b, c = [points[n] for n in f]
        u, v = ([b[k]-a[k] for k in range(3)], [c[k]-a[k] for k in range(3)])
        normal = [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]
        if sum(n*n for n in normal) <= 1e-28:
            raise ValueError('Degenerate connection triangle')
    return optimize_diagonals(faces,inner_ids,points,axis) if optimize else faces


def verify_closed_skin(triangles):
    """Topology check before volume meshing; geometry quality is checked separately."""
    keys = [tuple(sorted(t[:3])) for t in triangles]
    if len(set(keys)) != len(keys):
        raise ValueError('Duplicate surface triangles')
    counts = Counter(tuple(sorted((t[i], t[j]))) for t in triangles for i, j in ((0, 1), (1, 2), (2, 0)))
    if any(count != 2 for count in counts.values()):
        raise ValueError('Remainder skin is open or nonmanifold: %d invalid edges' % sum(c != 2 for c in counts.values()))
    return dict(triangles=len(triangles), edges=len(counts), closed=True)




def internal_edge_ids(part):
    """Keep cap circles: remove an edge only if every segment is inside its faces."""
    face_counts, edge_faces = {}, defaultdict(list)
    for face in part.faces:
        counts = Counter()
        for elem in face.elems:
            nodes = [int(n.id) for n in elem.nodes]
            if len(nodes) == 6:
                counts.update(tuple(sorted((nodes[a], nodes[b]))) for a,b in ((0,1),(1,2),(2,0)))
        face_counts[int(face.id)] = counts
        for edge in face.edges:
            edge_faces[int(edge.id)].append(int(face.id))
    targets = []
    for edge in part.edges:
        segments = [tuple(sorted(int(n.id) for n in elem.nodes[:2]))
                    for elem in edge.elems if len(elem.nodes) in (2,3)]
        faces = edge_faces[int(edge.id)]
        if segments and faces and all(face_counts[fid][segment] == 2 for fid in faces for segment in segments):
            targets.append(int(edge.id))
    return targets


def seed_face_ids(part, row, points, scale):
    axis = 'XYZ'.index(row['params']['axis'])
    normal = (axis + 2) % 3
    plane = row['center']['xyz_m'][normal] * scale
    targets = []
    for face in part.faces:
        elems = list(face.elems)
        if not elems or not all(len(e.nodes) == 8 for e in elems):
            continue
        node_ids = {int(n.id) for elem in elems for n in elem.nodes}
        if any(n not in points or abs(points[n][normal] - plane) > 1e-8 for n in node_ids):
            raise RuntimeError('Unexpected Quad8 face outside the Circular seed plane.')
        targets.append(int(face.id))
    return targets


def remove_seed_faces(jpt, part, row, points, solids, scale):
    targets = seed_face_ids(part, row, points, scale)
    result = dict(face_ids=targets, removed_faces=0, edge_ids=[], removed_edges=0, verified=False)
    retained = {int(e.id): tuple(int(n.id) for n in e.nodes)
                for f in part.faces if int(f.id) not in targets for e in f.elems}
    if targets:
        # DeleteElement rejects solid-owned surface elements. DeleteFace with
        # keepSolid=0 removes the internal face and its mesh; scoped readback
        # proves existing solids/nodes and the retained TRI6 skin survive.
        result['response'] = str(jpt.Exec('DeleteFace(%s, 0)' % targets))
        faces = list(part.faces)
        if set(targets).intersection(int(f.id) for f in faces):
            raise RuntimeError('Circular seed face cleanup left a target face.')
        result['removed_faces'] = len(targets)
    edges = internal_edge_ids(part)
    result['edge_ids'] = edges
    if edges:
        boundary_ids = {int(e.id) for e in part.edges} - set(edges)
        result['edge_response'] = str(jpt.Exec('DeleteEdge(%s)' % edges))
        present = {int(e.id) for e in part.edges}
        if set(edges).intersection(present) or not boundary_ids.issubset(present):
            raise RuntimeError('Circular edge cleanup did not retain the required boundaries.')
        result['removed_edges'] = len(edges)
    if targets or edges:
        faces = list(part.faces)
        after_solids = {int(e.id): tuple(int(n.id) for n in e.nodes)
                        for e in part.elems if e.kind == jpt.ElemKind.ELEMKIND_3D}
        after_skin = {int(e.id): tuple(int(n.id) for n in e.nodes) for f in faces for e in f.elems}
        after_points = {}
        for node in part.nodes:
            pos = node.pos
            after_points[int(node.id)] = (float(pos.x)*scale, float(pos.y)*scale, float(pos.z)*scale)
        if solids != after_solids or retained != after_skin or points != after_points:
            raise RuntimeError('Circular seed face cleanup changed retained mesh or nodes.')
    result['verified'] = True
    return result
