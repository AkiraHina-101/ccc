"""Journal pin mesh for Crank Meshing."""
import math
import re
from collections import Counter

MAX_TETS = 250000
MAX_ID = 2147483647
EDGES = ((0, 1), (1, 2), (2, 0), (0, 3), (1, 3), (2, 3))
DEFAULT_MASTER_IDS = '301-307 311-317 321-327 331-337'


def positive(value, label):
    value = float(value)
    if not math.isfinite(value) or not 0 < value < 1e100:
        raise ValueError(label + ': enter a finite positive number.')
    return value


def integer(value, label, lower, upper):
    if not re.fullmatch(r'[0-9]+', str(value).strip()):
        raise ValueError(label + ': enter an integer.')
    value = int(value)
    if not lower <= value <= upper:
        raise ValueError('{}: allowed range {}..{}.'.format(label, lower, upper))
    return value


def levels(total, count, ratios, label):
    total = positive(total, label)
    weights = ([positive(w.strip(), label + ' ratio') for w in ratios.strip().split(':')]
               if ratios.strip() else [1.0] * integer(count, label + ' layers', 1, 1000))
    if len(weights) > 1000:
        raise ValueError(label + ': at most 1000 layers.')
    scale = max(weights)
    weights = [w / scale for w in weights]
    denominator = math.fsum(weights)
    result = [0.0]
    acc = 0.0
    for w in weights:
        acc += w
        result.append(total * acc / denominator)
    result[-1] = total
    if any(b <= a for a, b in zip(result, result[1:])):
        raise ValueError(label + ': ratios create indistinguishable layers; reduce their range.')
    return result


def determinant(p, q, r, s):
    a = [q[i] - p[i] for i in range(3)]
    b = [r[i] - p[i] for i in range(3)]
    c = [s[i] - p[i] for i in range(3)]
    return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])


def geometry(center, axis, width, wl, rl, ns, order=10):
    if axis not in ('X', 'Y', 'Z') or order not in (4, 10):
        raise ValueError('Axis must be X/Y/Z; element order must be 4/10.')
    if len(center) != 3 or not all(math.isfinite(float(x)) for x in center):
        raise ValueError('Center must contain three finite coordinates.')
    ns = integer(ns, 'Circumference segments', 3, 720)
    nw, nr = len(wl) - 1, len(rl) - 1
    if 3*nw*ns*(2*nr-1) > MAX_TETS:
        raise ValueError('Mesh exceeds 250000 tetrahedra. Reduce layer/segment counts.')
    disk = [(0.0, 0.0)]
    for radius in rl[1:]:
        for j in range(ns):
            angle = 2*math.pi*j/ns
            disk.append((radius*math.cos(angle), radius*math.sin(angle)))
    triangles = []
    for j in range(ns):
        k = (j + 1) % ns
        triangles.append((0, 1+j, 1+k))
        for ring in range(1, nr):
            a, b = 1+(ring-1)*ns+j, 1+(ring-1)*ns+k
            c, d = 1+ring*ns+j, 1+ring*ns+k
            triangles.extend(((a, c, d), (a, d, b)))
    points = []
    for w in wl:
        axial = w - width/2.0
        for u, v in disk:
            delta = {'X': (axial, u, v), 'Y': (v, axial, u), 'Z': (u, v, axial)}[axis]
            points.append(tuple(float(center[i]) + delta[i] for i in range(3)))
    tets = []
    n = len(disk)
    for layer in range(nw):
        lo, hi = layer*n, (layer+1)*n
        for triangle in triangles:
            i, j, k = sorted(triangle)
            a, b, c, A, B, C = lo+i, lo+j, lo+k, hi+i, hi+j, hi+k
            for tet in ((a, b, c, C), (a, b, B, C), (a, A, B, C)):
                volume = determinant(*(points[x] for x in tet))
                if not math.isfinite(volume) or volume == 0:
                    raise ValueError('Degenerate mesh: check dimensions, coordinates and ratios.')
                if volume < 0:
                    tet = (tet[1], tet[0], tet[2], tet[3])
                tets.append(tet)
    corner_count = len(points)
    if order == 10:
        midpoints = {}
        quadratic = []
        for tet in tets:
            mids = []
            for i, j in EDGES:
                edge = tuple(sorted((tet[i], tet[j])))
                if edge not in midpoints:
                    midpoints[edge] = len(points)
                    points.append(tuple(points[edge[0]][d]/2 + points[edge[1]][d]/2 for d in range(3)))
                mids.append(midpoints[edge])
            quadratic.append(tet + tuple(mids))
        tets = quadratic
    return {'points': points, 'tets': tets, 'corner_count': corner_count,
            'disk_nodes': n, 'nw': nw, 'nr': nr, 'ns': ns, 'order': order}


def parse_ids(text):
    tokens = text.replace(',', ' ').split()
    if not tokens:
        return []
    return list(dict.fromkeys(integer(t, 'Center node ID', 1, MAX_ID) for t in tokens))


def target_ids(text, increment, count):
    step = integer(increment, 'Renumber increment', 1, MAX_ID)
    result = []
    for token in text.replace(',', ' ').split():
        match = re.fullmatch(r'([0-9]+)(?:-([0-9]+))?', token)
        if not match:
            raise ValueError('Target IDs: use IDs/ranges such as 301-307 311-317.')
        first = integer(match[1], 'Target ID', 1, MAX_ID)
        last = integer(match[2] or match[1], 'Target ID', first, MAX_ID)
        for value in range(first, last+1, step):
            if value in result:
                raise ValueError('Duplicate target node ID {}.'.format(value))
            result.append(value)
            if len(result) == count:
                return result
    if not result:
        raise ValueError('Enter target IDs for axial centers.')
    return result


def validate(mesh):
    """Check orientation, conformity and straight quadratic node placement."""
    points, tets = mesh['points'], mesh['tets']
    faces, mids = Counter(), {}
    volume = 0.0
    for tet in tets:
        six = determinant(*(points[i] for i in tet[:4]))
        if six <= 0 or not math.isfinite(six):
            raise ValueError('Nonpositive tetrahedron volume.')
        volume += six/6
        for slots in ((0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3)):
            faces[tuple(sorted(tet[i] for i in slots))] += 1
        if len(tet) == 10:
            for offset, (i, j) in enumerate(EDGES):
                edge = tuple(sorted((tet[i], tet[j])))
                mid = tet[4+offset]
                if edge in mids and mids[edge] != mid:
                    raise ValueError('Adjacent tetrahedra do not share midpoint nodes.')
                mids[edge] = mid
                expected = tuple(points[edge[0]][d]/2 + points[edge[1]][d]/2 for d in range(3))
                if points[mid] != expected:
                    raise ValueError('Incorrect TET10 midpoint.')
    if any(count not in (1, 2) for count in faces.values()):
        raise ValueError('Nonmanifold tetrahedral faces.')
    boundary = sum(count == 1 for count in faces.values())
    expected_boundary = 2*mesh['ns']*(2*mesh['nr']-1) + 2*mesh['nw']*mesh['ns']
    if boundary != expected_boundary:
        raise ValueError('Unexpected internal crack/boundary face count.')
    return {'nodes': len(points), 'elements': len(tets), 'boundary_faces': boundary, 'volume': volume}


def write_card(stream, name, fields):
    """Free-field Nastran: 8 data fields per line, explicit continuation marker."""
    fields = [str(x) for x in fields]
    while len(fields) > 8:
        stream.write(name + ',' + ','.join(fields[:8]) + ',+\n')
        fields, name = fields[8:], '+'
    stream.write(name + ',' + ','.join(fields) + '\n')


def write_bdf(path, meshes, node_start=1, elem_start=1, prop_start=1,
              prefix='JournalPin', rbe_ring=0, dofs='123456', targets=(), axis='X', material_id=0,
              pattern_axis=None):
    nodes, elements, properties = [], [], []
    next_n, next_e = node_start, elem_start
    mapping, ordered = [], []
    for mesh in meshes:
        ids = list(range(next_n, next_n+len(mesh['points'])))
        next_n += len(ids)
        mapping.append(ids)
        for layer in range(mesh['nw']+1):
            index = layer*mesh['disk_nodes']
            ordered.append((mesh['points'][index]['XYZ'.index(pattern_axis or axis)], len(mapping)-1, index))
    for target, (_, part, index) in zip(targets, sorted(ordered)):
        mapping[part][index] = target
    if any(x > MAX_ID for ids in mapping for x in ids):
        raise ValueError('Node ID limit exceeded.')
    if any(rbe_ring > mesh['nr'] for mesh in meshes):
        raise ValueError('RBE2 ring exceeds radial layer count.')
    with open(path, 'w', encoding='ascii', newline='\n') as stream:
        stream.write('$ JournalPin PSJ: mesh only; assign/verify material before analysis.\nBEGIN BULK\n')
        for part, (mesh, ids) in enumerate(zip(meshes, mapping)):
            pid = prop_start+part
            properties.append(pid)
            stream.write('$HMNAME COMP {} "{}_{}"\n'.format(pid, prefix, pid))
            write_card(stream, 'PSOLID', [pid, material_id or ''])
            for nid, point in zip(ids, mesh['points']):
                nodes.append(nid)
                write_card(stream, 'GRID', [nid, '', *('{:.16g}'.format(x) for x in point)])
            for tet in mesh['tets']:
                elements.append(next_e)
                write_card(stream, 'CTETRA', [next_e, pid, *(ids[i] for i in tet)])
                next_e += 1
        if rbe_ring:
            for mesh, ids in zip(meshes, mapping):
                for layer in range(mesh['nw']+1):
                    base = layer*mesh['disk_nodes']
                    first = base+1+(rbe_ring-1)*mesh['ns']
                    write_card(stream, 'RBE2', [next_e, ids[base], dofs, *ids[first:first+mesh['ns']]])
                    elements.append(next_e)
                    next_e += 1
        stream.write('ENDDATA\n')
    if max(elements + properties + [0]) > MAX_ID:
        raise ValueError('Element/property ID limit exceeded.')
    return {'node_ids': nodes, 'element_ids': elements, 'property_ids': properties,
            'mapping': mapping, 'file': path}


def rigid_plan(meshes, mapping, ring):
    plan = []
    for part_index, (mesh, ids) in enumerate(zip(meshes, mapping)):
        for layer in range(mesh['nw']+1):
            base = layer*mesh['disk_nodes']
            first = base+1+(ring-1)*mesh['ns']
            slaves = ids[first:first+mesh['ns']]
            master = ids[base]
            if master in slaves or len(set(slaves)) != mesh['ns']:
                raise ValueError('Invalid local RBE2 master/slave set.')
            plan.append(dict(master=master, slaves=slaves, part=part_index, layer=layer))
    return plan
