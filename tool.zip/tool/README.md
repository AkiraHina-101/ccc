# Crank Meshing | ver.1.3.2

Chạy **crank_meshing.py** bằng Python/PSJ trong Jupiter.
Máy này và máy khác dùng cùng một bản `tool`. Copy nguyên folder để chuyển máy.

## Tự nhận folder

Copy nguyên folder `tool` rồi chạy `crank_meshing.py`; không phải sửa đường dẫn máy cũ.
Launcher dùng vị trí file, filename của code PSJ, tham số chạy hoặc folder hiện tại.
Nếu chạy bằng cách copy/paste toàn bộ nội dung, host có thể làm mất mọi thông tin
về file gốc; hãy dùng chức năng chạy file Python thay vì copy/paste nội dung.

- `DATA_FOLDER`: tùy chọn nơi lưu Modify và log; để trống dùng
  `%LOCALAPPDATA%/CrankMeshing`. Không phải đường dẫn cài Jupiter.

## Chọn bộ cài Jupiter

Ở đầu **crank_meshing.py** có `JUPITER_HOME = ''`. Để trống dùng phiên Jupiter
đang mở. Bạn có thể sửa thành:

```python
JUPITER_HOME = r'C:/Program Files/TechnoStar/Jupiter_5.0.1'
```

Sau đó mở Jupiter từ đúng bộ cài 5.0.1 và chạy file này. Tool dùng command Python
từ `JUPITER_HOME/macro` và module GUI từ host đó; không chuyển native JPT/pyjdg
của một tiến trình 5.0.4 thành 5.0.1. Khi cấu hình bộ cài khác host đang chạy,
tool báo rõ hai đường dẫn. Console cũng in host, thư mục macro và file pyjdg
thực tế đang dùng. Builder giữ JUPITER_HOME đã sửa.

Không sửa đường dẫn trong `_internal`. Không cần Python ngoài, pip hoặc DLL riêng.
Đổi đường dẫn và API tương thích là hai việc khác nhau: đã kiểm chứng trên Jupiter
5.0.4; **5.0.1 chưa được kiểm chứng**. Chỗ tích hợp bảng theo build nằm riêng trong
`_internal/crank_meshing/ui/psj_table_controls.py`; không bỏ kiểm tra build để gọi
DLL không tương thích. API meshing thuộc từng module trong `mesh` để sửa sau.

## Thao tác

- CAD chỉ đọc; Modify sửa bảng và giữ bản sửa khi đóng/mở. Chỉ dùng lại draft khớp CAD.
- Reference pin và Angle to +Z: 0 độ đưa pin chuẩn về +Z.
- Xoay và surface mesh áp dụng các part CAD gốc đã ghi nhận.
- Hoàn tất mặt nối, gom Journal thành một part, Pin thành một part, rồi hỏi lên 3D.
- No: giữ mesh 2D các part gốc và các solid Journal/Pin/RBE2 đã gom.
- Yes: tạo TET10 cho các part gốc, giữ mesh và RBE2 của Journal/Pin.
- Apply/Next step tiếp tục từ chỗ dừng, không gom lại part đã hoàn tất.
- Renumber là thao tác riêng. Thời gian từng bước in ra console.

Build giữ JUPITER_HOME/DATA_FOLDER đã sửa và không xóa dữ liệu người dùng.
Khi nâng từ bản cũ, tool sao chép draft cũ một lần nếu nơi mới chưa có draft.
Folder phát hành không kèm model thử, tests, probe, log hoặc dữ liệu Modify của người gửi.
