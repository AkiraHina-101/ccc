# Semantic groups and Vietnamese aliases; Tcl 8.5, UTF-8.
namespace eval ::CAEGallery {
    variable group {Tất cả nhóm}
    variable groups {
        {Khung nhóm có tiêu đề} {Khung và chia vùng} {Nút bấm}
        {Ô nhập và chọn giá trị} {Chọn và đánh dấu} {Danh sách}
        {Bảng và cây dữ liệu} {Thẻ tab} {Thanh công cụ và menu}
        {Tiến độ và thanh kéo} {Văn bản và thông báo} {Hình ảnh và đồ họa}
        {Ngày giờ} {Hộp thoại và cửa sổ} {Bố trí và cơ chế GUI}
    }
}
proc ::CAEGallery::normalize {text} {
    set text [string tolower $text]
    foreach {plain accented} {
        a àáạảãâầấậẩẫăằắặẳẵ e èéẹẻẽêềếệểễ
        i ìíịỉĩ o òóọỏõôồốộổỗơờớợởỡ
        u ùúụủũưừứựửữ y ỳýỵỷỹ d đ
    } {
        foreach char [split $accented {}] {set text [string map [list $char $plain] $text]}
    }
    # Also accept decomposed Vietnamese input from an IME.
    set text [string map [list \u0300 {} \u0301 {} \u0303 {} \u0309 {} \u0323 {} \u0302 {} \u0306 {} \u031b {}] $text]
    return $text
}
proc ::CAEGallery::metadata {row} {
    lassign $row family api desc
    set tail [string tolower [namespace tail $api]]
    if {$family eq "Infrastructure" || $tail in {metawidget pkgindex widgettour}} {
        return [list {Bố trí và cơ chế GUI} {bố trí sự kiện cửa sổ phông chữ theme layout event font style hỗ trợ thư viện}]
    }
    foreach {pattern title keys} {
        {labelframe|labelledframe|groupbox} {Khung nhóm có tiêu đề} {khung có tên viền nhóm đường bao tiêu đề nhóm group frame border}
        {notebook|tabcontrol|tabset} {Thẻ tab} {thẻ tab nhiều trang chuyển trang}
        {tree|table|gridcontrol|gridview|propertysheet|selectlist} {Bảng và cây dữ liệu} {bảng hàng cột cây thư mục dữ liệu thuộc tính table tree}
        {calendar|clock|date|time} {Ngày giờ} {lịch ngày tháng đồng hồ thời gian}
        {progress|scale|slider|scrollbar|sizegrip} {Tiến độ và thanh kéo} {tiến độ phần trăm thanh kéo trượt cuộn progress slider}
        {toolbar|menu|hyperlink} {Thanh công cụ và menu} {thanh công cụ menu thực đơn liên kết đường dẫn}
        {check|radio|bool|toggle} {Chọn và đánh dấu} {nút tích ô tích chọn nhiều chọn một bật tắt đánh dấu checkbox}
        {combobox|combo|entry|spin|real|integer|^int$|^str$|float|color|fileopen|filesave|choosedir} {Ô nhập và chọn giá trị} {ô nhập chữ nhập số danh sách xổ xuống giá trị chọn màu chọn tệp entry input dropdown}
        {button} {Nút bấm} {nút bấm nhấn lệnh thực hiện button}
        {list|iconbox} {Danh sách} {danh sách lựa chọn nhiều mục list}
        {dialog|window|tk_get|tk_choose|tk_message|document} {Hộp thoại và cửa sổ} {hộp thoại cửa sổ mở lưu tệp thư mục xác nhận popup dialog}
        {frame|pane|split|expand} {Khung và chia vùng} {khung vùng chia đôi ngăn kéo giãn thu gọn frame panel}
        {canvas|image|thumbnail|icon|bitmap} {Hình ảnh và đồ họa} {hình ảnh vẽ đồ họa biểu tượng canvas icon}
        {label|text|message|tooltip|status|log|report} {Văn bản và thông báo} {nhãn chữ văn bản thông báo chú thích trạng thái nhật ký text label}
    } {
        if {[regexp $pattern $tail]} {return [list $title $keys]}
    }
    return [list {Bố trí và cơ chế GUI} {thành phần hỗ trợ giao diện tùy biến chuyên dụng}]
}
proc ::CAEGallery::matches {row query group family} {
    lassign $row f api desc
    lassign [metadata $row] title keys
    if {$family ne "All" && $family ne $f} {return 0}
    if {$group ne "Tất cả nhóm" && $group ne $title} {return 0}
    set haystack [normalize "$title $keys $f $api $desc"]
    foreach word [regexp -all -inline {\S+} [normalize $query]] {
        if {[string first $word $haystack] < 0} {return 0}
    }
    return 1
}
proc ::CAEGallery::explain_vi {row} {
    lassign $row family api desc
    lassign [metadata $row] group keys
    set tail [string tolower [namespace tail $api]]
    if {[string match *menu* $tail]} {
        return "Giải thích: Menu là danh sách lệnh xổ xuống. Menu Button là nút mở danh sách đó. Bấm nút/mũi tên để xem bốn lệnh mẫu; chọn mục để đổi nhãn nút (với Menu Button). Mẫu này chỉ minh họa chọn lệnh, chưa phải Split Button có vùng chạy lệnh riêng."
    }
    if {[string match *button* $tail] || $tail eq "ibutton"} {
        return "Giải thích: Nút bấm dùng để thực hiện một thao tác. Có thể dùng chữ, ký hiệu Unicode, bitmap hoặc ảnh; ghép ảnh và chữ bằng -compound. Trạng thái gồm bình thường, vô hiệu hóa, hoặc bật/tắt. Mẫu bên dưới có ghi tên kiểu để bạn yêu cầu build. Ký hiệu hiển thị phụ thuộc phông chữ; emoji màu không được bảo đảm trên Tk 8.5."
    }
    return "Giải thích: Thành phần thuộc nhóm ‘$group’, dùng cho các thao tác: $keys. Chọn mẫu để xem cách hiển thị; tên API giữ nguyên để tra cứu. Các số liệu trong preview chỉ là dữ liệu minh họa."
}
