source -encoding utf-8 [file join [file dirname [info script]] runtime_paths.tcl]
# Native GUI catalog for exact HyperMesh 2022.3; no model commands.
namespace eval ::CAEGallery {
    variable tool_dir [file dirname [info script]]
    variable base [::CAERuntimePaths::tcl_root]
    variable query ""
    variable family All
    variable rows {}
    variable shown {}
    variable status "Select a component to preview it."
    variable value 35
    variable serial
    if {![info exists serial]} {set serial 0}
}
source -encoding utf-8 [file join [file dirname [info script]] gui_gallery_previews.tcl]
source -encoding utf-8 [file join [file dirname [info script]] gui_gallery_search.tcl]
proc ::CAEGallery::cleanup {prefix} {
    # Cancel only callbacks that explicitly refer to this gallery's widget subtree.
    foreach id [after info] {
        if {![catch {after info $id} details] && [string first $prefix [lindex $details 0]] >= 0} {
            after cancel $id
        }
    }
    if {[llength [info commands image]]} {
        foreach name [image names] {
            if {[string first $prefix $name] == 0} {image delete $name}
        }
    }
}
proc ::CAEGallery::resetpreview {} {
    variable serial
    foreach w [winfo children .cae_gallery.right.sample] {
        cleanup $w
        destroy $w
    }
    incr serial
    return .cae_gallery.right.sample.w$serial
}
proc ::CAEGallery::close {} {
    cleanup .cae_gallery
    catch {destroy .cae_gallery_window}
    catch {destroy .cae_gallery}
}
proc ::CAEGallery::layout {path tail} {
    # Samples show realistic control sizes instead of stretching every widget.
    switch -- $tail {
        text - canvas - listbox - notebook - treeview - selectlist - propertysheet - datatable - gridview - treectrl - treetable - listview - mclistbox - messagelog - thumbnails - thumbnailsview {
            pack $path -fill both -expand 1 -padx 18 -pady 16
        }
        frame - labelframe - panedwindow - pane - splitframe - expandframe - dndnotebook {
            pack $path -fill both -expand 1 -padx 18 -pady 16
        }
        separator {pack $path -fill x -padx 32 -pady 45}
        scrollbar {catch {$path configure -orient horizontal}; pack $path -fill x -padx 70 -pady 45; catch {$path set 0.2 0.65}}
        default {pack $path -anchor nw -padx 24 -pady 24}
    }
}
proc ::CAEGallery::catalog {} {
    variable base
    set rows {}
    foreach n {button canvas checkbutton entry frame label labelframe listbox menu menubutton message panedwindow radiobutton scale scrollbar spinbox text toplevel} {
        lappend rows [list Tk $n "Tk standard widget"]
    }
    foreach n {button checkbutton combobox entry frame label labelframe menubutton notebook panedwindow progressbar radiobutton scale scrollbar separator sizegrip spinbox treeview} {
        lappend rows [list Ttk ::ttk::$n "Themed Tk widget"]
    }
    foreach f [lsort [glob -nocomplain -directory [file join $base hwtk widgets] *.tbc *.tcl]] {
        set n [file rootname [file tail $f]]
        lappend rows [list HWTK ::hwtk::$n "Altair module: [file tail $f]"]
    }
    foreach f [lsort [glob -nocomplain -directory [file join $base hwtk widgets editors] *.tcl]] {
        set n [file rootname [file tail $f]]
        lappend rows [list Editor $n "HWTK property editor module: [file tail $f]"]
    }
    foreach f [lsort [glob -nocomplain -directory [file join $base hwt demos] *.tcl]] {
        lappend rows [list HWT [file rootname [file tail $f]] "Legacy HWT demonstration; open through official Widget Tour"]
    }
    foreach f [lsort [glob -nocomplain -directory [file join $base hwt mkWidgets] *.tcl]] {
        lappend rows [list MetaWidget [file rootname [file tail $f]] "Legacy metawidget source module"]
    }
    foreach n {tk_messageBox tk_getOpenFile tk_getSaveFile tk_chooseDirectory tk_chooseColor} {
        lappend rows [list Dialog $n "Native dialog; opens only when requested"]
    }
    lappend rows [list Altair ::hwt::WidgetTour "Official Altair widget tour"]
    foreach n {pack grid place bind wm font image ttk::style} {
        lappend rows [list Infrastructure $n "Layout / events / window / styling API"]
    }
    return $rows
}
proc ::CAEGallery::filter {} {
    variable rows; variable shown; variable query; variable family; variable group
    set shown {}
    .cae_gallery.left.list delete 0 end
    if {[winfo exists .cae_gallery.right.sample]} {
        resetpreview
        .cae_gallery.right.api configure -state normal
        .cae_gallery.right.api delete 0 end
        .cae_gallery.right.api configure -state readonly
        note "Ch\u1ecdn m\u1ed9t bi\u1ebfn th\u1ec3 trong danh s\u00e1ch \u0111\u1ec3 xem preview."
    }
    foreach row $rows {
        lassign $row f api desc
        if {![matches $row $query $group $family]} {continue}
        lappend shown $row
        .cae_gallery.left.list insert end "$f | $api"
    }
    set ::CAEGallery::status "[llength $shown] / [llength $rows] th\u00e0nh ph\u1ea7n \u2014 nh\u00f3m: $group. Ch\u1ecdn bi\u1ebfn th\u1ec3 \u0111\u1ec3 xem preview v\u00e0 sao ch\u00e9p API."
    if {![llength $shown]} {set ::CAEGallery::status "Kh\u00f4ng c\u00f3 k\u1ebft qu\u1ea3. Th\u1eed t\u1eeb ng\u1eafn h\u01a1n, ch\u1ecdn T\u1ea5t c\u1ea3 nh\u00f3m ho\u1eb7c th\u01b0 vi\u1ec7n All."}
}
proc ::CAEGallery::clear {} {
    set ::CAEGallery::query ""
    set ::CAEGallery::group "T\u1ea5t c\u1ea3 nh\u00f3m"
    set ::CAEGallery::family All
    filter
    focus .cae_gallery.top.search
}
proc ::CAEGallery::copy {} {
    clipboard clear
    clipboard append [.cae_gallery.right.api get]
    set ::CAEGallery::status "API name copied."
}
proc ::CAEGallery::note {text} {
    set selected [.cae_gallery.left.list curselection]
    if {[llength $selected]} {
        lassign [metadata [lindex $::CAEGallery::shown [lindex $selected 0]]] title keys
        set row [lindex $::CAEGallery::shown [lindex $selected 0]]
        set text "Nh\u00f3m: $title\nT\u1eeb kh\u00f3a: $keys\n[explain_vi $row]\n\n$text"
    }
    .cae_gallery.right.options configure -state normal
    .cae_gallery.right.options delete 1.0 end
    .cae_gallery.right.options insert end $text
    .cae_gallery.right.options configure -state disabled
}
proc ::CAEGallery::dialog {api} {
    set code [catch {
        switch -- $api {
            tk_messageBox {tk_messageBox -title "Gallery: tk_messageBox" -message "Information / warning / confirmation dialog" -type okcancel}
            tk_getOpenFile {tk_getOpenFile -title "Gallery: choose input file"}
            tk_getSaveFile {tk_getSaveFile -title "Gallery: choose output path (no file written)"}
            tk_chooseDirectory {tk_chooseDirectory -title "Gallery: choose directory"}
            tk_chooseColor {tk_chooseColor -title "Gallery: choose color"}
            ::hwt::WidgetTour {package require hwt; ::hwt::WidgetTour}
        }
    } result]
    set ::CAEGallery::status "$api returned: $result"
}
proc ::CAEGallery::preview {} {
    variable shown
    set selected [.cae_gallery.left.list curselection]
    if {![llength $selected]} {return}
    lassign [lindex $shown [lindex $selected 0]] family api desc
    .cae_gallery.right.api configure -state normal
    .cae_gallery.right.api delete 0 end
    .cae_gallery.right.api insert 0 $api
    .cae_gallery.right.api configure -state readonly
    set p [resetpreview]
    set ::CAEGallery::preview_mode Native
    note "$api\n$desc\n"
    if {$family in {Dialog Altair}} {
        set kind $api
        if {$family eq "Altair"} {set kind notebook}
        semantic $p $api $kind "Inline example; original dialog/tour opens only on demand."
        ttk::button .cae_gallery.right.sample.launch -text "Open original $api" -command [list ::CAEGallery::dialog $api]
        pack .cae_gallery.right.sample.launch -anchor e -padx 16 -pady 8
        return
    }
    if {$family eq "Infrastructure"} {
        infrastructure $p $api
        return
    }
    if {$family eq "MetaWidget"} {meta $p $api; return}
    if {$family eq "HWT"} {hwt_preview $p $api; return}
    if {$family eq "Editor"} {
        set code [catch {
            ::hwtk::propertysheet $p
            pack $p -fill both -expand 1 -padx 16 -pady 16
            set sample 1
            switch -- $api {
                real {set sample 2.5}
                str - ientry {set sample Bracket_A}
                combobox - editablecombobox - multiselectcombobox {set sample Steel}
                fileopen - filesave - choosedir {set sample {C:/CAE/demo_model.hm}}
                intcolor - icolor {set sample 4}
            }
            $p itemcreate sample -text "Editor: $api" -type $api -value $sample
            note "Property editor: $api\nAPI: hwtk::propertysheet itemcreate ... -type $api\nEditor created. Click its value to edit."
        } result]
        if {$code} {
            cleanup $p
            catch {destroy $p}
            editor_preview $p $api $result
        } else {set ::CAEGallery::preview_mode "Native property editor"}
        return
    }
    set tail [namespace tail $api]
    if {$tail in {toplevel dialog}} {
        semantic $p $api window "Window contents shown inline to avoid automatic popups."
        ttk::button .cae_gallery.right.sample.launch -text "Open native window" -command [list ::CAEGallery::openwindow $api]
        pack .cae_gallery.right.sample.launch -anchor e -padx 16 -pady 8
        return
    }
    if {$family eq "HWTK" && ![llength [info commands $api]] && ![auto_load $api]} {
        semantic $p $api $tail "Installed module has no public constructor in this session."
        return
    }
    # These modules require a host context or a posted dialog, not an inline widget.
    if {$tail in {autocomplete boxlayout choosecolor choosedirectory chooseentitycolor getopenfile getsavefile inputdialog contextmenu gradientmenu popupwindow preferencesdialog tooltip window wizard propertysheetxml}} {
        semantic $p $api $tail "Original requires a posted dialog or host context."
        return
    }
    if {$tail in {buttonbar buttonbox buttongroup datatable dndnotebook entrybutton expandframe formentry gridview hintentry html hyperlink listview mcform messagelog multiselectcombobox pane rgbcolorpallet scalerange searchentry splitframe statebutton thumbnails thumbnailsview toolbutton treectrl}} {
        semantic $p $api $tail "Populated functional example; advanced native initialization remains separate."
        return
    }
    set code [catch {
        set opts {}
        switch -- $tail {
            button - label - checkbutton - radiobutton - menubutton - message - labelframe {set opts [list -text "$tail sample"]}
            entry - spinbox - combobox {set opts [list -textvariable ::CAEGallery::sampletext]}
            scale {set opts [list -from 0 -to 100 -variable ::CAEGallery::value]}
            progressbar {set opts [list -value 65]}
            canvas {set opts [list -width 420 -height 170 -background white]}
            text {set opts [list -width 50 -height 6]}
            listbox {if {$family eq "Tk"} {set opts [list -height 6]}}
            menu {if {$family eq "Tk"} {set opts [list -tearoff 0]}}
        }
        switch -- $tail {
            button {set opts [list -text "Preview Mesh" -command {set ::CAEGallery::status "Demo: 2,480 elements checked; no model was changed."}]}
            checkbutton {set opts [list -text "Show element labels" -variable ::CAEGallery::checked]; set ::CAEGallery::checked 1}
            radiobutton {set opts [list -text "TRIA3 mesh" -variable ::CAEGallery::meshtype -value TRIA3]; set ::CAEGallery::meshtype TRIA3}
            label {set opts [list -text "Bracket_A  |  2,480 elements  |  Steel"]}
            message {set opts [list -text "Mesh preview complete.\n2,480 elements, 1,326 nodes.\nIllustrative data; the model is unchanged." -width 360]}
            labelframe {set opts [list -text "Mesh Settings"]}
            menubutton {set opts [list -text "Mesh Type"]}
        }
        if {$tail eq "toplevel" || $tail eq "dialog"} {
            ttk::button $p -text "Open $api window" -command [list ::CAEGallery::openwindow $api]
        } else {
            uplevel #0 [linsert $opts 0 $api $p]
        }
        if {[winfo exists $p] && [winfo toplevel $p] ne $p} {layout $p $tail}
        switch -- $tail {
            button {pack configure $p -pady 8; button_variants .cae_gallery.right.sample.v$::CAEGallery::serial}
            menubutton {
                if {$family eq "HWTK"} {::hwtk::menu $p.dropdown} else {menu $p.dropdown -tearoff 0}
                menu_items $p.dropdown $family $p
                $p configure -menu $p.dropdown -text "Component Actions  \u25be"
            }
            entry {set ::CAEGallery::sampletext Bracket_A; catch {$p configure -width 28}}
            spinbox {set ::CAEGallery::sampletext 2.5; catch {$p configure -from 0.5 -to 10 -increment 0.5}; catch {$p configure -width 12}}
            combobox {set ::CAEGallery::sampletext Steel; $p configure -values {Steel Aluminum Titanium}; catch {$p configure -width 24}}
            scale - slider {catch {$p configure -orient horizontal -length 280}; catch {$p set 35}}
            progressbar {catch {$p configure -length 300}; catch {$p configure -value 65}}
            canvas {$p create rectangle 35 25 210 120 -fill #dde9f2 -outline #345a76; $p create oval 235 25 350 120 -fill #a9c4d7; $p create text 180 145 -text "canvas: shapes, text, diagrams"}
            text {$p insert end "Mesh Quality Report - Demo\n\nComponent: Bracket_A\nElements: 2,480\nNodes: 1,326\nMinimum Jacobian: 0.82\nAverage aspect ratio: 1.35\n\nThese values are illustrative."}
            listbox {if {$family eq "Tk"} {$p insert end Steel Aluminum Titanium} elseif {$family eq "HWTK"} {$p add steel Steel aluminum Aluminum titanium Titanium}}
            notebook {ttk::frame $p.one; ttk::frame $p.two; $p add $p.one -text "Mesh"; $p add $p.two -text "Result"; ttk::label $p.one.l -text "Element size: 2.5 mm\nMesh type: TRIA3\nMaterial: Steel"; ttk::label $p.two.l -text "2,480 elements\nMinimum Jacobian: 0.82\nStatus: Preview ready"; pack $p.one.l $p.two.l -padx 20 -pady 20 -anchor nw}
            treeview {$p configure -columns {id value} -show {tree headings}; $p heading #0 -text Component; $p heading id -text ID; $p heading value -text Value; set a [$p insert {} end -text Assembly -values {1 0.8}]; $p insert $a end -text Part -values {2 1.2}; $p item $a -open 1}
            selectlist {$p columnadd name -text Component; $p columnadd id -text ID; $p columnadd size -text "Size (mm)"; $p rowadd r1 -values {name Bracket_A id 101 size 2.5}; $p rowadd r2 -values {name Cover_B id 102 size 4.0}; $p rowadd r3 -values {name Bolt_C id 103 size 1.5}}
            propertysheet {$p itemcreate thickness -text Thickness -type real -value 2.5; $p itemcreate name -text Name -type str -value Steel}
            frame - labelframe {ttk::label $p.child -text "Element size (mm):"; ttk::entry $p.size -width 12; $p.size insert 0 2.5; ttk::button $p.apply -text "Preview" -command {set ::CAEGallery::status "Demo settings applied to preview only."}; grid $p.child -row 0 -column 0 -padx 12 -pady 12 -sticky w; grid $p.size -row 0 -column 1 -padx 8 -pady 12; grid $p.apply -row 1 -column 1 -padx 8 -pady 8 -sticky e}
            panedwindow {frame $p.a; frame $p.b; $p add $p.a; $p add $p.b; label $p.a.l -text "Pane A"; label $p.b.l -text "Pane B"; pack $p.a.l $p.b.l}
            menu {menu_items $p $family; ttk::button .cae_gallery.right.sample.post -text "Component Actions  \u25be" -command [list ::CAEGallery::postmenu $p]; pack .cae_gallery.right.sample.post -anchor nw -padx 24 -pady 24}
        }
        set lines "$api\n$desc\nStatus: constructed in this GUI session.\n\nConfiguration options:\n"
        if {[winfo exists $p]} {
            foreach option [$p configure] {append lines "[lindex $option 0]   [lindex $option end]\n"}
        }
        note $lines
    } result options]
    if {$code} {
        cleanup $p
        catch {destroy $p}
        semantic $p $api $tail "Native initialization requires additional setup: $result"
        return
    }
    set ::CAEGallery::status "$api selected."
}
proc ::CAEGallery::openwindow {api} {
    catch {destroy .cae_gallery_window}
    if {[catch {$api .cae_gallery_window} result]} {set ::CAEGallery::status $result; return}
    catch {wm title .cae_gallery_window "Gallery: $api"}
    if {$api eq "::hwtk::dialog"} {catch {.cae_gallery_window post}}
}
proc ::CAEGallery::postmenu {menu} {
    tk_popup $menu [winfo pointerx .cae_gallery] [winfo pointery .cae_gallery]
}
proc ::CAEGallery::show {} {
    package require Tk
    catch {package require hwtk}
    catch {package require hwt}
    if {![string match "2022.3.*" [string trim [hm_info -appinfo DISPLAYVERSION]]]} {error "Gallery requires HyperMesh 2022.3"}
    if {[winfo exists .cae_gallery]} {close}
    set ::CAEGallery::rows [catalog]
    toplevel .cae_gallery
    wm title .cae_gallery "CAE GUI TK Gallery - API Names - HyperMesh 2022.3"
    wm geometry .cae_gallery 1080x760
    wm minsize .cae_gallery 780 540
    wm protocol .cae_gallery WM_DELETE_WINDOW ::CAEGallery::close
    ttk::frame .cae_gallery.top -padding 10
    pack .cae_gallery.top -side top -fill x
    ttk::label .cae_gallery.top.label -text "T\u00ecm theo m\u00f4 t\u1ea3 / API:"
    ttk::entry .cae_gallery.top.search -textvariable ::CAEGallery::query
    ttk::button .cae_gallery.top.clear -text "X\u00f3a b\u1ed9 l\u1ecdc" -command ::CAEGallery::clear
    ttk::button .cae_gallery.top.designer -text Designer -command [list source [file join $::CAEGallery::tool_dir .. GUI_Designer launch_gui_designer.tcl]]
    ttk::combobox .cae_gallery.top.family -state readonly -textvariable ::CAEGallery::family -values {All Tk Ttk HWTK Editor HWT MetaWidget Dialog Altair Infrastructure} -width 15
    pack .cae_gallery.top.label -side left -padx 4
    pack .cae_gallery.top.search -side left -fill x -expand 1 -padx 4
    pack .cae_gallery.top.clear .cae_gallery.top.family .cae_gallery.top.designer -side left -padx 4
    bind .cae_gallery.top.search <KeyRelease> {::CAEGallery::filter}
    bind .cae_gallery.top.family <<ComboboxSelected>> {::CAEGallery::filter}
    ttk::frame .cae_gallery.browse -padding {10 0 10 6}
    pack .cae_gallery.browse -side top -fill x
    ttk::label .cae_gallery.browse.label -text "Nh\u00f3m theo c\u00f4ng d\u1ee5ng:"
    ttk::combobox .cae_gallery.browse.group -state readonly -width 29 -textvariable ::CAEGallery::group -values [linsert $::CAEGallery::groups 0 {T\u1ea5t c\u1ea3 nh\u00f3m}]
    ttk::label .cae_gallery.browse.hint -text "V\u00ed d\u1ee5: khung c\u00f3 t\u00ean \u00b7 \u00f4 nh\u1eadp s\u1ed1 \u00b7 danh s\u00e1ch x\u1ed5 xu\u1ed1ng" -wraplength 460
    pack .cae_gallery.browse.label .cae_gallery.browse.group -side left -padx 4
    pack .cae_gallery.browse.hint -side left -padx 12
    bind .cae_gallery.browse.group <<ComboboxSelected>> {::CAEGallery::filter}
    ttk::label .cae_gallery.status -textvariable ::CAEGallery::status -padding 8 -wraplength 1000
    pack .cae_gallery.status -side bottom -fill x
    ttk::frame .cae_gallery.left -padding 8
    ttk::frame .cae_gallery.right -padding 8
    pack .cae_gallery.left -side left -fill y
    pack .cae_gallery.right -side left -fill both -expand 1
    listbox .cae_gallery.left.list -width 38 -exportselection 0 -yscrollcommand {.cae_gallery.left.scroll set}
    ttk::scrollbar .cae_gallery.left.scroll -command {.cae_gallery.left.list yview}
    pack .cae_gallery.left.scroll -side right -fill y
    pack .cae_gallery.left.list -fill both -expand 1
    bind .cae_gallery.left.list <<ListboxSelect>> {::CAEGallery::preview}
    ttk::label .cae_gallery.right.title -text "API name - use this name when requesting a tool"
    ttk::entry .cae_gallery.right.api -state readonly
    ttk::button .cae_gallery.right.copy -text "Copy API" -width 12 -command ::CAEGallery::copy
    pack .cae_gallery.right.title .cae_gallery.right.api -fill x -pady 3
    pack .cae_gallery.right.copy -anchor e -pady 4
    ttk::labelframe .cae_gallery.right.sample -text "Live preview" -height 390
    pack .cae_gallery.right.sample -fill both -expand 1 -pady 8
    pack propagate .cae_gallery.right.sample 0
    ttk::frame .cae_gallery.right.detail
    pack .cae_gallery.right.detail -fill both -expand 1
    text .cae_gallery.right.options -height 14 -wrap word -state disabled -yscrollcommand {.cae_gallery.right.detail.scroll set}
    ttk::scrollbar .cae_gallery.right.detail.scroll -command {.cae_gallery.right.options yview}
    pack .cae_gallery.right.detail.scroll -side right -fill y
    pack .cae_gallery.right.options -in .cae_gallery.right.detail -fill both -expand 1
    filter
    focus .cae_gallery.top.search
    puts "CAE_GALLERY_READY count=[llength $::CAEGallery::rows]"
}
if {![info exists ::CAEGallery::no_autoshow] || !$::CAEGallery::no_autoshow} {::CAEGallery::show}

