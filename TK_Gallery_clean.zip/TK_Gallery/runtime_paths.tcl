# Resolve installed runtime resources without a fixed installation path.
namespace eval ::CAERuntimePaths {}
proc ::CAERuntimePaths::root_from {candidate} {
    if {$candidate eq ""} {return ""}
    foreach suffix {{} {hw} {hwdesktop hw}} {
        set root [file join $candidate {*}$suffix]
        if {[file isdirectory [file join $root tcl hwtk]] ||
            [file isdirectory [file join $root tcl hwt]]} {
            return [file normalize $root]
        }
    }
    return ""
}
proc ::CAERuntimePaths::hw_root {} {
    set candidates {}
    if {[llength [info commands ::hm_info]] &&
        ![catch {::hm_info -appinfo ALTAIR_HOME} root]} {
        lappend candidates $root
    }
    foreach key {CAE_HW_ROOT ALTAIR_HOME HW_ROOT} {
        if {[info exists ::env($key)]} {lappend candidates $::env($key)}
    }
    lappend candidates [file dirname [info nameofexecutable]] [info library]
    if {[info exists ::auto_path]} {
        foreach path $::auto_path {lappend candidates $path}
    }
    foreach candidate $candidates {
        for {set depth 0} {$candidate ne "" && $depth < 8} {incr depth} {
            set root [root_from $candidate]
            if {$root ne ""} {return $root}
            set parent [file dirname $candidate]
            if {$parent eq $candidate} {break}
            set candidate $parent
        }
    }
    return ""
}
proc ::CAERuntimePaths::tcl_root {} {
    set root [hw_root]
    if {$root eq ""} {return ""}
    return [file join $root tcl]
}
