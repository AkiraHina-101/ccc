# Populated demonstrations. Native APIs are identified separately from functional analogues.
proc ::CAEGallery::menu_pick {button label} {
    if {$button ne "" && [winfo exists $button]} {$button configure -text "$label  \u25be"}
    set ::CAEGallery::status "Đã chọn: $label — chỉ minh họa, không chạy lệnh CAE."
}
proc ::CAEGallery::menu_items {path family {button ""}} {
    set i 0
    foreach label {{Xem thành phần} {Kiểm tra chất lượng lưới} {Xuất báo cáo} {Thiết lập lưới}} {
        set command [list ::CAEGallery::menu_pick $button $label]
        if {$family eq "HWTK"} {
            $path item action[incr i] -caption $label -command $command
        } else {
            $path add command -label $label -command $command
        }
    }
}
proc ::CAEGallery::button_variants {p} {
    ttk::labelframe $p -text "Các kiểu nút — bấm thử (chỉ minh họa)" -padding 8
    pack $p -fill x -padx 16 -pady 4
    set image ${p}.photo
    image create photo $image -width 16 -height 16
    $image put #345a76 -to 1 1 15 15
    $image put white -to 4 4 12 6
    $image put white -to 4 8 12 10
    ttk::button $p.text -text "Chạy lưới" -command {set ::CAEGallery::status "Nút chữ: đã bấm thử."}
    ttk::button $p.symbol -text "▶  Chạy" -command {set ::CAEGallery::status "Nút ký hiệu Unicode: đã bấm thử."}
    ttk::button $p.icon -image $image -command {set ::CAEGallery::status "Nút chỉ có ảnh: đã bấm thử."}
    ttk::button $p.compound -text "Báo cáo" -image $image -compound left -command {set ::CAEGallery::status "Nút ảnh + chữ: đã bấm thử."}
    button $p.bitmap -bitmap question -command {set ::CAEGallery::status "Nút bitmap Tk: trợ giúp mẫu."}
    ttk::button $p.disabled -text "Chưa khả dụng" -state disabled
    set ::CAEGallery::button_toggle 0
    ttk::checkbutton $p.toggle -text "Bật nhãn lưới" -style Toolbutton -variable ::CAEGallery::button_toggle -command {set ::CAEGallery::status "Nút bật/tắt: $::CAEGallery::button_toggle"}
    ttk::frame $p.split
    ttk::button $p.split.main -text "Xem thành phần" -command [list ::CAEGallery::run_split $p.split.main]
    menu $p.split.menu -tearoff 0
    menu_items $p.split.menu Tk $p.split.main
    ttk::menubutton $p.split.arrow -text "▾" -menu $p.split.menu -width 2
    pack $p.split.main $p.split.arrow -side left
    canvas $p.shape -width 120 -height 28 -highlightthickness 1 -takefocus 1
    $p.shape create polygon 8 2 112 2 120 14 112 26 8 26 0 14 -fill #dde9f2 -outline #345a76 -tags action
    $p.shape create text 60 14 -text "Nút hình vẽ" -tags action
    $p.shape bind action <Button-1> {set ::CAEGallery::status "Hình trên Canvas có sự kiện click; không phải widget button native."}
    bind $p.shape <Return> {set ::CAEGallery::status "Kích hoạt hình nút bằng Enter (Canvas)."}
    bind $p.shape <space> {set ::CAEGallery::status "Kích hoạt hình nút bằng Space (Canvas)."}
    foreach {id caption row col} {
        text {Chữ} 0 0 symbol {Ký hiệu + chữ} 0 1 icon {Chỉ ảnh} 0 2
        compound {Ảnh + chữ} 1 0 bitmap {Bitmap có sẵn} 1 1 disabled {Vô hiệu hóa} 1 2
        toggle {Bật / tắt} 2 0 split {Split Button ghép} 2 1 shape {Hình tùy biến (Canvas)} 2 2
    } {
        ttk::frame $p.cell$id
        grid $p.cell$id -row $row -column $col -sticky nw -padx 6 -pady 4
        ttk::label $p.cell$id.label -text $caption
        pack $p.cell$id.label -anchor w -pady 2
        pack $p.$id -in $p.cell$id -anchor w
    }
    ttk::label $p.key -text "Ký hiệu gợi ý: +  −  ×  ✓  ✕  ▶  ■  ↻  ⚙  ▾  …   |   Viền Tk: flat, raised, sunken, groove, ridge, solid" -wraplength 620
    grid $p.key -row 3 -column 0 -columnspan 3 -sticky w -padx 6 -pady 4
    ttk::frame $p.reliefs
    ttk::label $p.reliefs.label -text "Thử kiểu viền:"
    ttk::combobox $p.reliefs.choice -state readonly -values {flat raised sunken groove ridge solid} -width 10
    $p.reliefs.choice set raised
    button $p.reliefs.sample -text "Nút Tk" -relief raised -borderwidth 3
    bind $p.reliefs.choice <<ComboboxSelected>> [list ::CAEGallery::set_relief $p.reliefs.choice $p.reliefs.sample]
    pack $p.reliefs.label $p.reliefs.choice $p.reliefs.sample -side left -padx 4
    grid $p.reliefs -row 4 -column 0 -columnspan 3 -sticky w -pady 4
}
proc ::CAEGallery::set_relief {choice button} {$button configure -relief [$choice get]}
proc ::CAEGallery::run_split {button} {
    set ::CAEGallery::status "Chạy thử: [$button cget -text] — không thay đổi model."
}
proc ::CAEGallery::demo_note {api mode detail} {
    set ::CAEGallery::preview_mode $mode
    note "$api\nPreview: $mode\n$detail\nIllustrative data only; no model operation."
}
proc ::CAEGallery::demo_table {p} {
    ttk::treeview $p -columns {id size quality} -show {tree headings} -height 5
    $p heading #0 -text Component
    foreach {c text width} {id ID 60 size {Size (mm)} 90 quality Jacobian 90} {
        $p heading $c -text $text
        $p column $c -width $width -minwidth 45
    }
    $p column #0 -width 190 -minwidth 100
    $p insert {} end -text Bracket_A -values {101 2.5 0.82}
    $p insert {} end -text Cover_B -values {102 4.0 0.94}
    $p insert {} end -text Bolt_C -values {103 1.5 0.91}
    pack $p -fill both -expand 1 -padx 16 -pady 14
}
proc ::CAEGallery::demo_tree {p} {
    ttk::treeview $p -height 6
    set a [$p insert {} end -text Assembly -open 1]
    set b [$p insert $a end -text Components -open 1]
    foreach n {Bracket_A Cover_B Bolt_C} {$p insert $b end -text $n}
    $p insert $a end -text Materials
    pack $p -fill both -expand 1 -padx 16 -pady 14
}
proc ::CAEGallery::demo_form {p} {
    ttk::frame $p -padding 12
    pack $p -anchor nw -padx 16 -pady 10
    foreach {row label value} {0 Component Bracket_A 1 {Mesh size (mm)} 2.5 2 Material Steel} {
        ttk::label $p.l$row -text $label
        ttk::entry $p.e$row -width 24
        $p.e$row insert 0 $value
        grid $p.l$row -row $row -column 0 -sticky w -padx 8 -pady 7
        grid $p.e$row -row $row -column 1 -sticky ew -padx 8 -pady 7
    }
    ttk::button $p.go -text Preview -command {set ::CAEGallery::status "Demo: mesh size 2.5 mm selected."}
    grid $p.go -row 3 -column 1 -sticky e -padx 8 -pady 10
}
proc ::CAEGallery::demo_canvas {p kind} {
    canvas $p -width 440 -height 180 -background white -highlightthickness 1
    pack $p -fill both -expand 1 -padx 16 -pady 14
    switch -- $kind {
        clock {
            $p create oval 135 15 285 165 -outline #345a76 -width 3
            foreach {x y t} {210 30 12 270 90 3 210 150 6 150 90 9} {$p create text $x $y -text $t}
            $p create line 210 90 210 45 -width 4
            $p create line 210 90 250 115 -width 2
        }
        icons {
            foreach {x text color} {30 Mesh #dde9f2 165 Material #d9eddb 300 Report #f3e1c5} {
                $p create rectangle $x 30 [expr {$x+90}] 115 -fill $color -outline #345a76
                $p create text [expr {$x+45}] 140 -text $text
            }
        }
        default {
            $p create rectangle 30 30 170 115 -fill #dde9f2 -outline #345a76 -tags part
            $p create oval 230 30 350 115 -fill #d9eddb -outline #345a76 -tags part
            $p create text 200 150 -text "Click a shape to highlight it"
            $p bind part <Button-1> [list $p itemconfigure current -fill #f3e1c5]
        }
    }
}
proc ::CAEGallery::semantic {p api kind {reason ""}} {
    set key [string tolower [namespace tail $kind]]
    switch -glob -- $key {
        autocomplete - searchentry {
            ttk::frame $p -padding 14
            pack $p -fill both -expand 1 -padx 16 -pady 14
            ttk::label $p.l -text "Type Bracket, Cover or Bolt to filter"
            ttk::entry $p.query -width 28
            listbox $p.results -height 5 -exportselection 0
            $p.results insert end Bracket_A Bracket_B Cover_C Bolt_D
            bind $p.query <KeyRelease> [list ::CAEGallery::filter_demo $p.query $p.results]
            pack $p.l $p.query -anchor w -pady 6
            pack $p.results -fill both -expand 1 -pady 8
        }
        *toolbutton* - *statebutton* - ibutton {
            ttk::frame $p -padding 14
            pack $p -anchor nw -padx 16 -pady 14
            set ::CAEGallery::demo_enabled 1
            ttk::checkbutton $p.toggle -text "Mesh labels" -variable ::CAEGallery::demo_enabled
            ttk::button $p.action -text "Inspect Mesh" -width 16 -command {set ::CAEGallery::status "Demo mesh inspected."}
            pack $p.toggle $p.action -anchor w -pady 10
        }
        expandframe {
            ttk::frame $p -padding 14
            pack $p -anchor nw -padx 16 -pady 14
            ttk::button $p.toggle -text "Show / hide advanced settings" -command [list ::CAEGallery::toggle_demo $p.content]
            ttk::labelframe $p.content -text "Advanced settings" -padding 12
            ttk::label $p.content.l -text "Minimum Jacobian: 0.7\nMaximum aspect ratio: 5.0"
            pack $p.content.l -anchor w
            pack $p.toggle $p.content -anchor w -pady 8
        }
        metawidget - pkgindex - general {
            ttk::frame $p -padding 14
            pack $p -anchor nw -padx 16 -pady 10
            ttk::label $p.l -text "Composite control = label + entry + action"
            pack $p.l -anchor w -pady 8
            demo_form $p.form
            ttk::label $p.package -text "package require Metawidget 1.3\npackage require mkWidgets 1.3\nmetawidget create Class ..."
            pack $p.package -anchor w -pady 8
        }
        msgcat {
            ttk::frame $p -padding 14
            pack $p -anchor nw -padx 16 -pady 10
            set ::CAEGallery::locale_label "Select components"
            ttk::label $p.l -textvariable ::CAEGallery::locale_label
            ttk::button $p.en -text English -command {set ::CAEGallery::locale_label "Select components"}
            ttk::button $p.vi -text Vietnamese -command {set ::CAEGallery::locale_label "Chon component"}
            pack $p.l $p.en $p.vi -anchor w -pady 8
        }
        *slider* - *scale* - *range* {
            ttk::frame $p -padding 14
            pack $p -anchor nw -padx 16 -pady 10
            set ::CAEGallery::range_start 2.5
            set ::CAEGallery::range_end 8.0
            ttk::label $p.l -text "Element size range (mm)"
            ttk::scale $p.start -from 0.5 -to 10 -length 320 -variable ::CAEGallery::range_start
            ttk::scale $p.end -from 0.5 -to 10 -length 320 -variable ::CAEGallery::range_end
            ttk::label $p.a -textvariable ::CAEGallery::range_start
            ttk::label $p.b -textvariable ::CAEGallery::range_end
            pack $p.l $p.start $p.a $p.end $p.b -anchor w -pady 4
        }
        *hyperlink* {
            ttk::frame $p -padding 14
            pack $p -anchor nw -padx 16 -pady 18
            label $p.link -text "Mesh quality reference" -foreground #225d91 -cursor hand2
            pack $p.link -anchor w
            bind $p.link <Button-1> {set ::CAEGallery::status "Demo hyperlink selected; no external page opened."}
        }
        *html* {semantic $p $api text "Formatted document preview; no HTML engine instantiated."; return}
        *tree* {demo_tree $p}
        *table* - *gridview* - *gridcontrol* - *columnlist* - *property* {demo_table $p}
        *clock* {demo_canvas $p clock}
        *calendar* {
            ttk::frame $p -padding 10
            pack $p -anchor nw -padx 20 -pady 10
            ttk::label $p.title -text "October 2026"
            grid $p.title -row 0 -column 0 -columnspan 7 -pady 8
            set col 0
            foreach day {Mon Tue Wed Thu Fri Sat Sun} {ttk::label $p.h$col -text $day; grid $p.h$col -row 1 -column $col -padx 5; incr col}
            for {set d 1} {$d <= 31} {incr d} {
                ttk::button $p.d$d -text $d -width 3 -command [list set ::CAEGallery::status "Demo date: 2026-10-$d"]
                set index [expr {$d+2}]
                grid $p.d$d -row [expr {2+$index/7}] -column [expr {$index%7}] -padx 2 -pady 2
            }
        }
        *progress* - working - animate {
            ttk::frame $p -padding 16
            pack $p -anchor nw -padx 20 -pady 10
            ttk::label $p.l -text "Mesh check: 65%  |  1,612 / 2,480 elements"
            ttk::progressbar $p.bar -length 340 -variable ::CAEGallery::demo_progress
            set ::CAEGallery::demo_progress 65
            ttk::scale $p.slider -from 0 -to 100 -length 340 -variable ::CAEGallery::demo_progress
            pack $p.l $p.bar $p.slider -anchor w -pady 10
        }
        *tab* - *notebook* - *dndnotebook* {
            ttk::notebook $p
            foreach {id title detail} {mesh Mesh {TRIA3 / 2.5 mm} material Material {Steel / E = 210000 MPa} result Results {2480 elements / Jacobian = 0.82}} {
                ttk::frame $p.$id -padding 20
                ttk::label $p.$id.l -text $detail
                pack $p.$id.l -anchor nw
                $p add $p.$id -text $title
            }
            pack $p -fill both -expand 1 -padx 16 -pady 14
        }
        *pane* - *split* - framesplit {
            ttk::panedwindow $p -orient horizontal
            ttk::frame $p.left -padding 14
            ttk::frame $p.right -padding 14
            ttk::label $p.left.l -text "Components\nBracket_A\nCover_B\nBolt_C"
            ttk::label $p.right.l -text "Properties\nPSHELL\nThickness: 2.5 mm\nMaterial: Steel"
            pack $p.left.l $p.right.l -anchor nw
            $p add $p.left -weight 1
            $p add $p.right -weight 2
            pack $p -fill both -expand 1 -padx 16 -pady 14
        }
        *combobox* - *multiselect* - *selectlist* - *list* - *scrollbox* {
            ttk::frame $p -padding 12
            pack $p -fill both -expand 1 -padx 16 -pady 14
            ttk::label $p.l -text "Select components (Ctrl / Shift for multiple)"
            listbox $p.list -height 5 -selectmode extended -exportselection 0
            $p.list insert end Bracket_A Cover_B Bolt_C Washer_D Plate_E
            $p.list selection set 0 1
            pack $p.l -anchor w -pady 6
            pack $p.list -fill both -expand 1
        }
        *toolbar* - *buttonbar* - *buttonbox* - *buttongroup* - *buttonlistbox* {
            ttk::frame $p -padding 14
            pack $p -anchor nw -padx 16 -pady 20
            foreach {id label} {select Select inspect Inspect report Report} {
                ttk::button $p.$id -text $label -width 12 -command [list set ::CAEGallery::status "Demo action: $label"]
                pack $p.$id -side left -padx 5
            }
        }
        *color* - *pallet* {
            ttk::frame $p -padding 14
            pack $p -anchor nw -padx 16 -pady 14
            ttk::label $p.l -text "Component colors - click to select"
            pack $p.l -anchor w -pady 8
            ttk::frame $p.swatches
            pack $p.swatches -anchor w
            set i 0
            foreach color {#345a76 #60966a #b77f48 #9273ad #d06060 #729cac} {
                button $p.swatches.c$i -width 5 -height 2 -background $color -command [list set ::CAEGallery::status "Demo color: $color"]
                grid $p.swatches.c$i -row [expr {$i/3}] -column [expr {$i%3}] -padx 5 -pady 5
                incr i
            }
        }
        *image* - *icon* - *thumbnail* {demo_canvas $p icons}
        *canvas* {demo_canvas $p shapes}
        *menu* {
            ttk::frame $p -padding 14
            pack $p -anchor nw -padx 16 -pady 20
            menu $p.menu -tearoff 0
            menu_items $p.menu Tk $p.open
            ttk::menubutton $p.open -text "Chọn thao tác  \u25be" -menu $p.menu
            pack $p.open -anchor w
            ttk::label $p.hint -text "Bấm mũi tên để xổ menu; chọn mục để đổi tên nút." -wraplength 500
            pack $p.hint -anchor w -pady 12
        }
        *tooltip* {
            ttk::frame $p -padding 14
            pack $p -anchor nw -padx 16 -pady 14
            ttk::button $p.target -text "Hover for mesh details"
            ttk::label $p.tip -text "Bracket_A | 2,480 elements | Jacobian 0.82" -relief solid -padding 8
            pack $p.target -anchor w -pady 8
            bind $p.target <Enter> [list pack $p.tip -anchor w -pady 8]
            bind $p.target <Leave> [list pack forget $p.tip]
        }
        *log* - *text* - *document* {
            text $p -height 8 -width 55 -wrap word
            $p insert end "Mesh inspection - demo\n\nComponent: Bracket_A\nElements: 2,480\nMinimum Jacobian: 0.82\n\n[format {%s} $api] example output."
            pack $p -fill both -expand 1 -padx 16 -pady 14
        }
        *messagebox* - message {
            ttk::labelframe $p -text "Confirm mesh preview" -padding 16
            pack $p -anchor nw -padx 16 -pady 14
            ttk::label $p.message -text "Inspect 3 components with a mesh size of 2.5 mm?"
            ttk::frame $p.actions
            ttk::button $p.actions.ok -text OK -width 10 -command {set ::CAEGallery::status "Demo confirmation: OK"}
            ttk::button $p.actions.cancel -text Cancel -width 10 -command {set ::CAEGallery::status "Demo confirmation: Cancel"}
            pack $p.message -anchor w -pady 12
            pack $p.actions -anchor e
            pack $p.actions.ok $p.actions.cancel -side left -padx 4
        }
        *statusbar* {
            ttk::frame $p -padding 14
            pack $p -fill x -padx 16 -pady 24
            ttk::label $p.state -text "Ready | Bracket_A | 2,480 elements" -relief sunken -padding 8
            ttk::progressbar $p.progress -value 65 -length 160
            pack $p.state -side left -fill x -expand 1
            pack $p.progress -side right -padx 10
        }
        *dialog* - *window* - prompt - *file* - *directory* {
            ttk::labelframe $p -text "Dialog content preview" -padding 14
            pack $p -anchor nw -padx 16 -pady 14
            ttk::label $p.l -text "Select component / file:"
            ttk::entry $p.e -width 36
            $p.e insert 0 {C:/CAE/demo_model.hm}
            ttk::frame $p.buttons
            foreach {n t} {ok OK cancel Cancel} {ttk::button $p.buttons.$n -text $t -width 10 -command [list set ::CAEGallery::status "Demo $t selected"]}
            pack $p.l $p.e -anchor w -pady 7
            pack $p.buttons -anchor e -pady 8
            pack $p.buttons.ok $p.buttons.cancel -side left -padx 4
        }
        *entry* - *spin* - *form* - *hint* - *search* - *expand* - labeledframe {demo_form $p}
        *wizard* {
            ttk::frame $p -padding 14
            pack $p -anchor nw -padx 16 -pady 14
            set ::CAEGallery::wizard_step 1
            ttk::label $p.title -textvariable ::CAEGallery::wizard_step
            ttk::label $p.l -text "1 Select components -> 2 Mesh settings -> 3 Review"
            ttk::button $p.next -text "Next step" -command {set ::CAEGallery::wizard_step [expr {$::CAEGallery::wizard_step%3+1}]}
            pack $p.l $p.title $p.next -anchor w -pady 8
        }
        default {demo_form $p}
    }
    demo_note $api "Functional illustration (Tk/Ttk)" "Example for $kind. $reason The original API is not claimed to have been constructed."
}
proc ::CAEGallery::editor_preview {p api reason} {
    ttk::labelframe $p -text "Property editor: $api" -padding 16
    pack $p -anchor nw -padx 16 -pady 14
    ttk::label $p.label -text "Property value"
    pack $p.label -anchor w -pady 6
    switch -glob -- $api {
        *check* - *bool* {
            set ::CAEGallery::editor_bool 1
            ttk::checkbutton $p.control -text Enabled -variable ::CAEGallery::editor_bool
        }
        *selector* - eeguidebar {
            ttk::combobox $p.control -values {Bracket_A Cover_B Bolt_C} -state readonly -width 24
            $p.control set Bracket_A
            ttk::label $p.info -text "Simulated entity selection: Component ID 101"
            pack $p.info -anchor w -pady 8
        }
        *color* {
            ttk::combobox $p.control -values {Red Green Blue SteelGray} -state readonly -width 24
            $p.control set SteelGray
        }
        *spin* - uint - int - real - intrange {
            spinbox $p.control -from 0 -to 100 -increment 0.5 -width 12
            $p.control delete 0 end
            $p.control insert 0 2.5
        }
        default {ttk::entry $p.control -width 28; $p.control insert 0 Bracket_A}
    }
    pack $p.control -anchor w -pady 8
    demo_note $api "Functional property editor illustration" "Native editor context unavailable: $reason. The sample does not select real model entities."
}
proc ::CAEGallery::hwt_preview {p api} {
    if {$api ni {entry notebook}} {
        semantic $p $api $api "Functional recreation of the installed HWT demonstration."
        return
    }
    set code [catch {
        switch -- $api {
            entry {
                set e [::hwt::AddEntry $p Label "Mesh size:" LabelWidth 12 entryWidth 16 withoutPacking]
                pack $e -anchor nw -padx 20 -pady 20
                [::hwt::Ent $e] insert 0 2.5
            }
            notebook {
                ::hwt::Notebook $p create -pages {Mesh Material Results} -pad 1
                pack $p -fill both -expand 1 -padx 16 -pady 14
                foreach page {Mesh Material Results} {
                    set f [::hwt::Notebook $p cget frame $page]
                    label $f.l -text "$page - Bracket_A / Steel / 2.5 mm"
                    pack $f.l -padx 16 -pady 18 -anchor nw
                }
            }
            default {semantic $p $api $api "Functional recreation of the installed HWT demonstration."; return}
        }
        demo_note $api "Native HWT control" "The installed ::hwt API constructs this example."
    } result]
    if {$code} {
        cleanup $p
        catch {destroy $p}
        semantic $p $api $api "Native HWT setup: $result."
    }
}
proc ::CAEGallery::infrastructure {p api} {
    ttk::frame $p -padding 14
    pack $p -fill both -expand 1 -padx 16 -pady 12
    switch -- $api {
        pack {
            ttk::label $p.l -text "pack - controls placed left to right"
            pack $p.l -anchor w -pady 8
            ttk::frame $p.row
            pack $p.row -anchor w
            foreach n {Select Inspect Report} {ttk::button $p.row.[string tolower $n] -text $n; pack $p.row.[string tolower $n] -side left -padx 5}
        }
        grid {
            ttk::label $p.l -text "grid - labels and values aligned in rows and columns"
            pack $p.l -anchor w
            demo_form $p.form
        }
        place {
            ttk::label $p.l -text "place - relative coordinates in a preview panel"
            pack $p.l -anchor w
            frame $p.area -width 450 -height 160 -background #dde9f2
            pack $p.area -fill both -expand 1 -pady 8
            foreach {id text x y} {a Select 0.1 0.2 b Inspect 0.5 0.5 c Report 0.8 0.8} {
                ttk::button $p.area.$id -text $text
                place $p.area.$id -relx $x -rely $y -anchor center
            }
        }
        bind {
            ttk::label $p.l -text "bind - click this button or press Enter"
            ttk::button $p.b -text "Event target"
            ttk::label $p.out -textvariable ::CAEGallery::event_text
            set ::CAEGallery::event_text "Waiting for an event"
            bind $p.b <ButtonRelease-1> {set ::CAEGallery::event_text "Mouse ButtonRelease-1 received"}
            bind $p.b <Return> {set ::CAEGallery::event_text "Keyboard Return received"}
            pack $p.l $p.b $p.out -anchor w -pady 8
        }
        wm {
            ttk::label $p.l -text "wm - window title, size, minimum size and close protocol"
            ttk::entry $p.title -width 40
            $p.title insert 0 "Mesh Preview"
            ttk::button $p.open -text "Open sample window" -command [list ::CAEGallery::openwindow toplevel]
            pack $p.l $p.title $p.open -anchor w -pady 8
        }
        font {
            foreach {n label font} {a {Normal - Component Bracket_A} TkDefaultFont b {Heading - Mesh Quality} TkHeadingFont c {Fixed - EID 101 | JAC 0.82} TkFixedFont} {
                ttk::label $p.$n -text $label -font $font
                pack $p.$n -anchor w -pady 10
            }
        }
        image {
            set img $p.photo
            image create photo $img -width 96 -height 72
            $img put #dde9f2 -to 0 0 96 72
            $img put #345a76 -to 14 14 82 58
            $img put #d9eddb -to 28 26 68 46
            ttk::label $p.icon -image $img -text "Native Tk photo image: 96 x 72 pixels" -compound top
            pack $p.icon -anchor nw -pady 14
        }
        ttk::style {
            ttk::style configure CAEGallery.Accent.TButton -padding {16 8}
            ttk::label $p.l -text "ttk::style - native button versus a padded style"
            ttk::button $p.standard -text "Standard"
            ttk::button $p.accent -text "Padded button" -style CAEGallery.Accent.TButton
            pack $p.l $p.standard $p.accent -anchor w -pady 8
        }
    }
    demo_note $api "Native support API demonstration" "The layout, event, font or style operation is executed on gallery widgets only."
}
proc ::CAEGallery::filter_demo {entry listbox} {
    if {![winfo exists $listbox]} {return}
    set query [string tolower [$entry get]]
    $listbox delete 0 end
    foreach item {Bracket_A Bracket_B Cover_C Bolt_D} {
        if {[string first $query [string tolower $item]] >= 0} {$listbox insert end $item}
    }
}
proc ::CAEGallery::toggle_demo {frame} {
    if {[winfo ismapped $frame]} {pack forget $frame} else {pack $frame -anchor w -pady 8}
}
proc ::CAEGallery::meta {p api} {
    variable base
    if {$api in {metawidget pkgIndex Window Document Tooltip}} {
        semantic $p $api $api "This module defines a framework, popup, or window lifecycle; its content is illustrated inline."
        return
    }
    set code [catch {
        set lib [file join $base hwt mkWidgets]
        if {$lib ni $::auto_path} {lappend ::auto_path $lib}
        package require mkWidgets
        set cmd ::[string tolower $api]
        if {![llength [info commands $cmd]]} {error "Constructor $cmd unavailable"}
        set opts {}
        switch -- $api {
            Combobox {set opts {-entries {Steel Aluminum Titanium} -width 26}}
            Calendar {set opts {-font TkDefaultFont}}
            Ibutton {set opts {-text {Preview Mesh}}}
            Spinentry {set opts {-value 2.5 -minimum 0.5 -maximum 10 -step 0.5}}
            Textframe {set opts {-text {Mesh Settings}}}
            Treecontrol {set opts {-text Assembly}}
        }
        uplevel #0 [linsert $opts 0 $cmd $p]
        pack $p -fill both -expand 1 -padx 18 -pady 16
        if {$api in {Combobox Calendar Aclock Ibutton Spinentry}} {pack configure $p -fill none -expand 0 -anchor nw}
        switch -- $api {
            Combobox {$p insert 0 Steel; pack configure $p -fill none -expand 0 -anchor nw}
            Calendar {$p set {2026-10-11}}
            Aclock {$p set {10:30:00}}
            Progressbar {$p set 65; pack configure $p -expand 0 -fill x}
            Scrollbox {$p insert end Bracket_A Cover_B Bolt_C}
            Tabcontrol {$p insert mesh 0 -text Mesh; $p insert material 0 -text Material; $p insert result 0 -text Result}
            Toolbar {$p add button select -text Select; $p add button inspect -text Inspect; $p add button report -text Report; pack configure $p -expand 0}
            Statusbar {$p push "Ready | Bracket_A | 2,480 elements"; pack configure $p -expand 0 -fill x}
            Treecontrol {$p insert bracket -text Bracket_A; $p insert cover -text Cover_B}
            Gridcontrol - Listcontrol {
                $p column insert component end -text Component
                $p column insert size end -text {Size (mm)}
                $p insert end {Bracket_A 2.5}
                $p insert end {Cover_B 4.0}
            }
            Iconbox {$p insert end mesh -text Mesh; $p insert end material -text Material; $p insert end report -text Report}
            Pane {
                ttk::label $p.a -text "Components\nBracket_A\nCover_B"
                ttk::label $p.b -text "Properties\nSteel\n2.5 mm"
                $p pack first $p.a -padx 12 -pady 12
                $p pack second $p.b -padx 12 -pady 12
            }
            Textframe {ttk::label $p.l -text "Size: 2.5 mm\nType: TRIA3\nMaterial: Steel"; $p pack $p.l -padx 12 -pady 12}
        }
        demo_note $api "Native MetaWidget: $cmd" "Constructor and example data executed using the installed 2022.3 mkWidgets package."
    } result]
    if {$code} {
        cleanup $p
        catch {destroy $p}
        semantic $p $api $api "Native attempt: $result."
    }
}
