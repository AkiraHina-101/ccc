# Native widget gallery

Entry: gui_gallery.tcl

Open through the single 01_CAE_TOOLS/cae_nastran.mac menu. Reference editors use shared runtimes in 00-CAE_LAUNCHER/third_party; Designer uses its sibling TK_Gallery package.
