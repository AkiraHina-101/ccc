# HyperMesh all collected surfaces — start here

This is a standalone, scoped source-documentation package. It includes its selected dependencies. No archive or original workstation is required.

1. Confirm the target product, Classic/new UI, version, solver profile and required result/input context. Source release is not proof of target compatibility.
2. Read this guide and use MODULE_INDEX.md through the lookup skill. Search exact name plus product/owner; read only matched body pages. Reviewed transcripts take priority.
3. Preserve documented syntax, arguments, handle acquisition and command order; unresolved source facts stay unresolved. Never invent a missing API.
4. Use the author/check skills. Source review is separate from Tcl parsing and runtime behavior. No Altair runtime was tested to build this package.
5. If a needed record is not in this scope, request the relevant additional package, not archive. Missing from a package does not mean unavailable in Altair.

Python helpers require the user-designated Python 3.8+ executable. Ask for its exact path unless already configured privately. Markdown reading needs no Python. Tcl parsing separately needs a compatible Tcl library.

Included source modules: hypermesh, desktop, gui, nastran. Source records: 7675.

Source-body omissions, images/layout and ambiguous source ownership retain their original labels. This package is not all installed APIs or an independent Tk language reference.

## Selected scope

HyperMesh all collected surfaces source references, with the modules listed above. Command availability still requires the target application context.

## Fast routes

Read the applicable workflow before selecting calls: [HyperMesh workflow routes](official_help/supplements/hypermesh/HYPERMESH_WORKFLOW_ROUTES.md), [Tcl 8.5/Tk patterns](official_help/supplements/gui/TCL8_5_TK_PATTERNS_FOR_ALTAIR_TOOLS.md). Use [CONTRACT_STANDARD.md](CONTRACT_STANDARD.md) to interpret source facts and [CONTRACT_QUALITY.md](CONTRACT_QUALITY.md) for known gaps.
