# HyperMesh workflow routes for Tcl tool authors

This page is a task router, not a replacement for the exact source contracts. The sequences below are an authoring checklist assembled from the linked public source pages. They are not claimed to be a single Altair-endorsed end-to-end macro. Before writing calls, confirm Classic versus the newer UI, the installed release, solver profile, GUI versus batch, and the model state the task assumes.

## Choose the work path

| User goal | Start with | Then inspect | Main limits to keep visible |
|---|---|---|---|
| Select and inspect existing entities | `*createmark` → `hm_getmark` → `*clearmark`; `hm_entityinfo`; `hm_getvalue` | [P1 selection/query contracts](HYPERMESH_P0_P1_WORKFLOW_CONTRACTS_2022_3.md), exact rows in `MODULE_INDEX.md` | Mark options and returned fields are entity-specific; use the full matching source body. |
| Create or edit mesh entities | `*createentity`, `*createelement` / `*createelements`, or `*tetmesh` as task requires | [core Tcl contracts](HYPERMESH_TCL_TOOL_CORE_CONTRACTS_2022_3.md), [P0/P1 contracts](HYPERMESH_P0_P1_WORKFLOW_CONTRACTS_2022_3.md), exact command transcripts | Entity tokens, argument grouping, element configuration and profile support must come from each exact contract. `*tetmesh` has conditional modes; do not flatten its command block. |
| Create a component, property or material relationship | Identify the entity and active solver profile; create the entity only with documented fields; set and read back the relationship | [`*createentity` and field notes](HYPERMESH_ENTITY_FIELDS_2022_3.md), [Nastran property fields](NASTRAN_PROPERTY_FIELDS_2022.md), exact `*setvalue`/`hm_getvalue` bodies | Card-image/PID/MID choices can depend on installed templates and active profile. Public field documentation does not prove the target profile supports a card. |
| Import a model or mesh | Select the reader and source format; find that reader's exact options; import to a controlled model | [`*feinputwithdata2` source limits](HYPERMESH_P0_P1_WORKFLOW_CONTRACTS_2022_3.md), [HMASCII batch route](HMBATCH_TOOL_AUTHORING_2022_3.md) | The generic import command does not define every reader's extra string-array values. HMASCII grammar and the reader command form are separate contracts. |
| Renumber entities | Select the exact entity set; establish ordering/start/increment; apply `*renumber`; read back IDs and relationships | [`*renumber` contract](HYPERMESH_P0_P1_WORKFLOW_CONTRACTS_2022_3.md) | The source form and the task's ordering/collision policy are separate. Do not assume selection order equals coordinate order. |
| Delete or replace entities | Compute and review the precise target set; use the matching deletion contract; query the result | P0/P1 deletion notes and exact delete-command transcript | A mark-based delete is consequential. A node connected to elements may not be deletable through that form. Never test it on a live user model. |
| Add a GUI to a Tcl tool | Use the target's embedded Tcl/Tk version; keep UI callbacks short and call named procedures | [GUI/Tk patterns](../gui/TCL8_5_TK_PATTERNS_FOR_ALTAIR_TOOLS.md), [HyperMesh GUI scripting](HYPERMESH_GUI_SCRIPTING_2022_3.md) | GUI toolkit availability, visual theme behavior and callback context require the actual target client. |
| Run without the interactive client | Separate file/reader setup from commands that need the GUI or active model; check HMBatch evidence | [HMBatch authoring](HMBATCH_TOOL_AUTHORING_2022_3.md) | A command's appearance in public Help does not prove HMBatch availability, license coverage or profile behavior. |

## A safe implementation order

1. Translate the request into inputs, target entities, solver/profile constraints, expected changes and read-back assertions.
2. Find every native command or HWI method by exact name and owner in the scoped package index. Read the source transcript and any linked issue/enrichment note; do not rely on a search-result signature alone.
3. Build selection and query logic before model-changing calls. Confirm mark number, entity type, model and empty-selection behavior.
4. Perform one bounded change at a time. Keep file imports, geometry/mesh creation, property assignment, renumbering and deletion as separate decisions.
5. Read back the resulting entities, connectivity, property/card data and IDs with documented queries. Report any assertion that cannot be expressed from available contracts.
6. Use the checker for Tcl grammar and exact-call routing. Run a target fixture only when the requested behavior needs runtime evidence and a separate scratch model/process is available.

This order is a tool-authoring safeguard, not a claim that the Help specifies a universal transaction or rollback API. Source facts, derived control flow, parser status and runtime behavior must be reported separately.

## What to ask before inventing a workflow

Ask for only the missing task inputs: target product/build and interface, solver profile, input model/reader, selection rule, intended new entities/relationships, ID and naming rules, whether a GUI or batch run is required, and objective read-back checks. A new task outside the examples above should still use the package: route to the exact source contract, then assemble only the calls its requirements need.
