# HyperMesh Batch tool-authoring reference (Altair Help 2022.3)

This is the public-source contract for starting HyperMesh Batch with command or Tcl inputs. Source release is **HyperWorks Desktop / HyperMesh 2022.3 Help**. The maintained RevolveTet4 tool declares HyperMesh 2022 / Tcl 8.5, so the 2022.3 published contract does not by itself establish compatibility with its target installation. Resolve the intended install from project machine configuration and confirm the actual release before execution. Do not copy a machine-specific executable path into shared tool code.

## What the documented program does

Altair describes HyperMesh Batch as a **non-graphical HyperMesh** that runs command files or Tcl scripts in batch mode. HyperMesh commands that require graphical display are ignored and Tk commands cannot be used. Processing ends when the command file or Tcl script reaches its end, or when the `*quit` command is encountered. A script that opens a Tk form, waits for GUI selection, or calls a display-required command therefore cannot be treated as an equivalent batch path. See [Start HyperMesh Batch](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/getting_started/start_hm_batch_on_windows_t.htm), section “Start HyperMesh Batch” (applies to its linked Windows/Linux launch routes).

## Resolve executable and platform

The official Windows guide says to open a system command prompt, change directory to the desired start-in directory, then invoke the full executable path plus startup options. Its example uses `<altair_home>\hm\bin\<platform>\hmbatch.exe`. The startup-options page gives the Linux example `<altair_home>/altair/scripts/hmbatch`. These are release documentation placeholders/examples, not paths to assume. Resolve `<ALTAIR_INSTALL_DIR>` and `<platform>` from project machine configuration or an explicitly confirmed installation. The library does not identify a local installation for this batch.

The public docs provide distinct Windows and Linux invocation examples. Use the shell and quoting rules of the selected platform; the Altair pages do not define a cross-shell escaping API. Prefer constructing an argument vector in the caller over concatenating an unquoted command string, then verify against that platform's Tcl `exec` and process APIs if implementing a launcher.

## Invocation forms documented by Altair

At least one command file or Tcl script option is required by the Windows start guide. The startup-options page specifies `-tcl` followed by a script filename and explicitly notes no space between the flag and its filename; the page's example nevertheless shows `-tcl <tcl_filename>` with a space. Preserve this source inconsistency: the option table and example disagree about spacing. Use the syntax verified for the exact installed executable. The following portable forms adapt the source examples by replacing filesystem paths with placeholders; they are not verbatim quotes. The documented spacing conflict is retained:

```text
<ALTAIR_INSTALL_DIR>\hm\bin\<PLATFORM>\hmbatch.exe -tcl <tcl_filename>
<ALTAIR_INSTALL_DIR>/altair/scripts/hmbatch -tcl <tcl_filename> -nobg
```

For an actual script whose Tcl argument may contain spaces, do not infer quoting from these bare-path examples; quote as required by the launching shell and Tcl process API.

Useful documented options from **HyperMesh Batch Startup Options**:

| Option | Published meaning |
|---|---|
| `-c<command_filename>` | Automatically run the command file. No space between option and filename. |
| `-tcl <tcl_filename>` | Automatically run the Tcl script. No space between option and filename is stated in the note, while the example uses a separating space; see ambiguity above. |
| `<filename>` | Automatically load the specified `.hm` file. |
| `-r<result_filename>` | Set the HyperMesh results file to the input filename with `.res` suffix or a specified file. No space between option and filename. |
| `-t<template_filename>` | Set global template to the specified file. No space between option and filename. |
| `-continue` | Always continue without prompting on errors when processing a command file. |
| `-h` | Print usage message. |
| `-version` | Print HyperMesh version. |
| `-nocommand` | Prevent creation/writing of the command file. |
| `-nowriteviewcommands` | Prevent writing view commands to the command file. |
| `-templex` | Allow Templex statements inside command files. |
| `-batchcontext` / `-nobatchcontext` | With `-batch`, set up / suppress OpenGL batch context. Help says `DISPLAY` must be defined and working for `-batchcontext`. |
| `-nobg` | With `-batch`, force foreground execution on Linux. |

The startup-options page names `-batch` in descriptions for `-batchcontext`, `-nobatchcontext`, and `-nobg`, but does not include it in either of its two complete launch examples. Confirm exact composition for the intended build rather than extrapolating a full command line from option prose.

An input `.hm` filename is a positional startup option and `-r` configures a results file. These are not a documented generic “input model/output model” pair. The startup-options page does not specify a general output-model filename flag. A Tcl script must issue the appropriate documented HyperMesh save/write operation if an output model is required; consult that operation's exact contract separately.

## Process completion, errors, and logs

Altair documents when batch processing terminates: end of the command file/Tcl script or `*quit`. It also documents `-continue` only as continuing without prompting on errors for **command-file** processing. The cited pages do not specify operating-system exit-code values, whether Tcl errors set a nonzero process code, whether the process code is reliable as a model-validity signal, standard-output/error routing, log filenames, or failure-log formats. Record all these as **source_not_stated**. Do not treat process exit 0 as proof that a model is valid, and do not invent a log/exit contract. A caller may observe process completion and inspect explicitly requested output files, but these are separate checks, not source-described exit semantics.

If the caller needs a reliable completion/result protocol, create an explicit sentinel/result artifact in the Tcl script and verify it alongside process completion, or perform a bounded check on the exact installed release. Label that as project implementation/runtime evidence, not as Altair public Help behavior.

## Project implementation evidence: Nastran Control

`src/nastran_control/lib/xlsx_io.tcl` uses Tcl `exec` to call a Python executable resolved by its project `config.tcl` helper. For example, `python_ok` runs `exec $python -c "import openpyxl"` inside `catch`, and an XLSX conversion runs `exec $python $script $manifest $xlsx_path` inside `catch`, then verifies the expected file exists. This is project-specific subprocess logic; it is not the HyperMesh Batch interface and does not establish hmbatch argument syntax, exit codes, or logging. The actual Python path is intentionally delegated to project configuration. No install path was resolved or embedded here.

## Source register

1. [HyperMesh Batch Startup Options](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/getting_started/hm_batch_startup_options_r.htm), Altair Help 2022.3, sections “HyperMesh Batch Startup Options” and “Example: Startup Options”. Supports the option descriptions and platform example executable locations above.
2. [Start HyperMesh Batch on Windows](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/getting_started/start_hypermesh_batch_on_windows_t.htm), Altair Help 2022.3, section “Start HyperMesh Batch on Windows”. Supports start-in directory, full executable path, minimum `-c`/`-tcl` options and Windows example.
3. [Start HyperMesh Batch](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/getting_started/start_hm_batch_on_windows_t.htm), Altair Help 2022.3, section “Start HyperMesh Batch”. Supports non-graphical behavior, ignored graphical commands, unavailable Tk commands, and termination at script/file end or `*quit`.
4. [HyperMesh Batch Linux route](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/getting_started/start_hm_batch_on_linux_t.htm), Altair Help 2022.3. The page is linked from the startup-options page; its content was not retrieved in this research pass. Linux executable example is supported by source 1 only.

No application was launched. No installed executable, local Help, or batch runtime behavior was inspected. Target release remains a separate machine-resolution task.
