# HyperMesh Tcl core tool contracts — reviewed source

Source baseline: Altair Help 2022.3, with matching exact 2022 pages retrieved for all five commands. Syntax, Type, Description, Inputs and Errors match after prose whitespace normalization. This establishes published 2022 documentation, not a runtime or Classic-specific behavior test. Solver profile-specific datanames remain separate.

Review status: two generic source contracts ready (*setvalue, hm_getmark), three partial because of source inconsistencies. Original code examples below are decoded source blocks with their line boundaries preserved; all 41 source locators resolve exactly. Examples are runtime not_run.

For other scoped commands, use the exact source contract index (outside this package; choose another package if needed). Missing return/default fields mean not stated, not unsupported.

## *createentity

Creates a new entity. The source says only data names may be set; the name data name sets the solver name for entity types enabled for the name pool.

[Altair 2022.3 source](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_createentity.htm) and [matching Altair 2022 source](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/_createentity.htm). Status: contract_partial.

```text
*createentity entity_type ?modelname=<name_of_model>? ?name1=value1? ?name2=value2? ... ?name3=valueN?
```

| Parameter in signature order | Meaning/constraints | Default stated by source |
|---|---|---|
| `entity_type` | Entity type to create. | not stated |
| `modelname=<name_of_model>` | Optional model to update when multiple models exist; otherwise current model. | current model |
| `<name>=<value>` | Data name/value pair(s) defining entity data. Do not use attributes: the source explicitly states attributes are unsupported. | not stated |

**Outcome and preconditions**

- Returns: not stated by source
- Output: not stated
- Errors: Incorrect usage results in Tcl error; source suggests catch for detection.
- Side effects: Creates entity; attributes and STATUS are unsupported.
- Preconditions: not stated by source

**Source gaps/constraints**

- Solver-specific entity data names are not enumerated.
- Return value not stated by source.
- Original HTML Inputs generically says “data name and/or attribute pairs” and describes attribute IDs, while Description explicitly says data names only and Attributes are not supported. Apply the explicit command limitation; attribute use remains an internal documentation inconsistency.

**Original 2022.3 examples; runtime not_run**

```tcl
*createentity sets
```

```tcl
*createentity sets type=1 ids={1 2 3 4}
```

```tcl
*createentity sets name=set1 cardimage=GRNOD
```

```tcl
*createentity nodes x=100 y=200 z=0
```

## *rigidlink

Creates a rigid link element between an independent node and multiple dependent nodes.

[Altair 2022.3 source](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_rigidlink.htm) and [matching Altair 2022 source](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/_rigidlink.htm). Status: contract_partial.

```text
*rigidlink independent mark dofs
```

| Parameter in signature order | Meaning/constraints | Default stated by source |
|---|---|---|
| `independent` | Independent node of the element. | not stated |
| `mark` | ID of the mark containing dependent nodes. The source does not state an allowed mark ID enum. | not stated |
| `dofs` | Degree-of-freedom code for which all element nodes are active; source Inputs labels the parameter “dof” although signature names it “dofs”. Source describes any of the digits 1-6; combination syntax is not further specified. | not stated |

**Outcome and preconditions**

- Returns: not stated by source
- Output: not stated
- Errors: Source says None.
- Side effects: Creates a rigid link element.
- Preconditions: *createmark command is required to define the mark.

**Source gaps/constraints**

- Return value not stated by source.
- Signature names the third parameter “dofs” while Inputs labels it “dof”. The 2022 page uses a different example command form from 2022.3; retain each source example as published and do not infer interchangeability.

**Original 2022.3 examples; runtime not_run**

```tcl
*createmark nodes 2 101 102 103
*rigidlink 100 2 123456 
```

## *setvalue

Updates existing entity data, attributes, or metadata when the proper card image is assigned; a name data name updates the solver name for entities enabled for the name pool.

[Altair 2022.3 source](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_setvalue.htm) and [matching Altair 2022 source](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/_setvalue.htm). Status: contract_ready.

```text
*setvalue entity_type <select_type>=<selection> <name1>=<value1> ?<name2>=<value2>? ... ?<nameN>=<valueN>? ?row=<row_index>? ?column=<column_index>? ?STATUS=<status>? ?locationunit={<entity_id>, <face_index>}? ?modelname=<name_of_model>?
```

| Parameter in signature order | Meaning/constraints | Default stated by source |
|---|---|---|
| `entity_type` | Type of entity to modify. | not stated |
| `<select_type>=<selection>` | One selector for entity/entities: id, name, mark, list, user_ids, or user_names; source says only one option may be used at a time. | not stated |
| `<name>=<value>` | Data name/value pair(s) for entity data, attributes, and/or metadata, subject to source constraints and the proper card image. The Inputs documents metadata update form metadata={<name> <value>} and metadata creation form metadata={<name> <value> <type>}; it also documents parameter assignment as {parameter parameter_name} and unassignment as {parameter "" }, where unassignment assigns the parameter value at that time. These are source-described forms, not reconstructed examples. | not stated |
| `row=<row_index>` | Optional row index for a 1D or 2D array. For 1D, sets the single value at the specified index; for 2D, it must be used together with column. Mandatory for string arrays. | not stated |
| `column=<column_index>` | Optional 2D array column, used with row. | not stated |
| `STATUS=<status>` | Attribute status; source values are 0 off, 1 on, 2 always on; must be uppercase. | not stated |
| `locationunit={<entity_id>, <face_index>}` | Engineering loads only; required for non-uniform load updates. For regular set only entity_id; for solid element faces include face_index. | not stated |
| `modelname=<name_of_model>` | Optional model when multiple models exist; otherwise current model. | current model |

**Outcome and preconditions**

- Returns: not stated by source
- Output: not stated
- Errors: Incorrect usage results in Tcl error; source suggests catch for detection.
- Side effects: Updates entity data, attributes, or metadata subject to source constraints and proper card image.
- Preconditions: Proper card image assigned; locationunit requirements apply to non-uniform engineering loads.

**Source gaps/constraints**

- Applicable solver datanames and their profile-specific meanings are not enumerated.
- Return value not stated by source.

**Original 2022.3 examples; runtime not_run**

```tcl
*setvalue sets name=node_set ids={nodes 1 2 3 4 5 6 7 8}
```

```tcl
*setvalue sets id=1 name=new_setnodes
```

```tcl
*setvalue mats id=1 Rho=1.1 STATUS=1
```

```tcl
*setvalue mats id=1 183=1.1 STATUS=1
```

```tcl
*setvalue comps mark=1 materialid=2
```

```tcl
*setvalue elems list=1 node1=2
```

```tcl
*setvalue comps user_ids={1 2} materialid=2
```

```tcl
*setvalue comps user_names={mid center} materialid=2
```

```tcl
*setvalue loads id=5 magnitude={5 4 10 15 20}
```

```tcl
*setvalue loads id=5 magnitude=15 locationunit={1654,3}
```

```tcl
*setvalue comps id=1 metadata={mymeta_int 15}
```

```tcl
*setvalue comps id=1 metadata= {mymeta_entity {mats 3}}
```

```tcl
*setvalue comps id=1 metadata= {mymeta_entityarray {mats 1 3}}
```

## hm_getmark

Returns entity IDs of the given entity type on the specified mark.

[Altair 2022.3 source](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/hm_getmark.htm) and [matching Altair 2022 source](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/hm_getmark.htm). Status: contract_ready.

```text
hm_getmark entity_type mark_id ?panel_sensitive? ?model_name?
```

| Parameter in signature order | Meaning/constraints | Default stated by source |
|---|---|---|
| `entity_type` | Entity type to query. | not stated |
| `mark_id` | ID of mark containing entities; valid values 1 and 2. | not stated |
| `panel_sensitive` | When panel levels are pushed, chooses previous or current panel; relevant only for marks created from panel entity selector in stated conditions. | 0 (previous panel) |
| `model_name` | Optional model for mark lookup; otherwise current model. | current model |

**Outcome and preconditions**

- Returns: Entity IDs
- Output: not separately stated
- Errors: Incorrect usage results in Tcl error; source suggests catch for detection.
- Side effects: not stated by source
- Preconditions: panel_sensitive semantics require the described pushed-panel and panel-selector context.

**Source gaps/constraints**

- Return shape/type beyond “entity IDs” not stated.

**Original 2022.3 examples; runtime not_run**

```tcl
hm_getmark comps 1
```

```tcl
hm_getmark comps 1 0 model-2
```

```tcl
hm_getmark loads 1 1
```

```tcl
hm_getmark loads 1 0
```

## hm_getvalue

Queries entity data names, attributes, and metadata, including indexed array values.

[Altair 2022.3 source](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/hm_getvalue.htm) and [matching Altair 2022 source](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/hm_getvalue.htm). Status: contract_partial.

```text
hm_getvalue entity_type <select_type>=<selection> ?dataname=<data name or attribute name/ID>? ?row=<row_index>? ?column=<column_index>? ?locationunit={<entity_id> <face_index>}? ?metadata_value=<metadata_name>? ?metadata_value_count=<metadata_name>? ?metadata_value_ids=<metadata_name>? ?metadata_value_type=<metadata_name>? ?modelname=<name_of_model>?
```

| Parameter in signature order | Meaning/constraints | Default stated by source |
|---|---|---|
| `entity_type` | Type of entity to query. | not stated |
| `<select_type>=<selection>` | One selector: id, name, mark, list, user_ids, or user_names; only one option may be used at a time. | not stated |
| `dataname=<data name or attribute name/ID>` | Selects data name or attribute to query; if omitted, one metadata_value... option must be used. | not stated |
| `row=<row_index>` | Optional array row; 1D returns a value, 2D returns entire row. | not stated |
| `column=<column_index>` | Optional 2D array column, used with row to return an indexed value. | not stated |
| `locationunit={<entity_id> <face_index>}` | Engineering loads only; required for non-uniform load query. Regular set requires entity_id; solid element face also needs face_index. | not stated |
| `metadata_value=<metadata_name>` | Queries metadata value; valid for all metadata types. | not stated |
| `metadata_value_count=<metadata_name>` | Queries metadata count; valid for all metadata types. | not stated |
| `metadata_value_ids=<metadata_name>` | Queries metadata entity IDs; valid for entity and entity-array metadata. | not stated |
| `metadata_value_type=<metadata_name>` | Queries metadata entity type; valid for entity and entity-array metadata. | not stated |
| `modelname=<name_of_model>` | Optional model for query; otherwise current model. | current model |

**Outcome and preconditions**

- Returns: Value of selected data name, attribute, metadata, or indexed array value, as described by source.
- Output: not separately stated
- Errors: Incorrect usage results in Tcl error; source suggests catch for detection.
- Side effects: not stated by source
- Preconditions: Exactly one selection form; use a metadata_value... option when dataname is omitted; locationunit constraints apply to engineering loads.

**Source gaps/constraints**

- Solver-specific datanames are not enumerated.
- The source input wording references row_index/column_index in prose while syntax uses row/column; do not alter verbatim signature.
- Syntax uses locationunit={<entity_id> <face_index>} with whitespace, but Inputs and examples use a comma between entity_id and face_index. Preserve the signature and examples literally; exact separator usage remains source-inconsistent.

**Original 2022.3 examples; runtime not_run**

```tcl
hm_getvalue sets name=node_set dataname=ids
```

```tcl
hm_getvalue sets id=1 dataname=name
```

```tcl
hm_getvalue mats id=1 dataname=Rho
```

```tcl
hm_getvalue mats id=1 dataname=183
```

```tcl
hm_getvalue comps mark=1 dataname=materialid
```

```tcl
hm_getvalue elems list=1 dataname=node1
```

```tcl
hm_getvalue comps user_names={mid center} dataname=materialid
```

```tcl
hm_getvalue includes id=10 dataname=typesundersubmodel
```

```tcl
hm_getvalue mats id=1 dataname=Rho modelname=model-2
```

```tcl
hm_getvalue loads id=5 dataname=magnitude locationunit={15}
```

```tcl
hm_getvalue loads id=5 dataname=magnitude locationunit={25,2}
```

```tcl
hm_getvalue comps id=1 metadata_value=mymeta_int
```

```tcl
hm_getvalue comps id=1 metadata_value=mymeta_entity 
```

```tcl
hm_getvalue comps id=1 metadata_value_count=mymeta_entityarray
```

```tcl
hm_getvalue comps id=1 metadata_value_ids=mymeta_entityarray
```

```tcl
hm_getvalue comps id=1 metadata_value_type=mymeta_entityarray
```

```tcl
hm_getvalue sets name=node_set dataname=ids-ids
```

```tcl
hm_getvalue sets name=node_set dataname=ids-count
```

```tcl
hm_getvalue sets name=node_set dataname=ids-type
```
