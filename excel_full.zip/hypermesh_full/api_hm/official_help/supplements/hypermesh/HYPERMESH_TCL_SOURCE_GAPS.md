# Production HyperMesh Tcl source gaps and deprecated routes

This note accounts for twelve names used in the bounded production scan but lacking an exact public Tcl contract in the 2022.3 command cache. It does not invent their signatures or treat a same-name HMASCII/template function as Tcl.

Eight have official deprecation/replacement routes, two are explicitly listed as undocumented in 2022, and two remain unresolved. A deprecation mapping does not preserve the old argument order: read the replacement contract before rewriting a call. Observed installation/callsite forms are not public contracts.

See the exact source contracts (outside this package; choose another package if needed) for documented replacements.

## *redrawblock

Status: source_gap_unresolved. Old exact syntax: not established by this source audit.

No exact API page/section found in the checked official 2022/2022.3 routes or retained catalogs. The callsites use *redrawblock with 0/1. HyperMesh Tcl Modify *setoption documents option block_redraw, but no checked source equates that option with this command. Do not infer alias or syntax.

- [Source: similar but not equivalent reference](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_setoption.htm) — Inputs > block_redraw

## *jacobian_calculate_cornerpts

Status: officially_listed_undocumented_no_signature. Old exact syntax: not established by this source audit.

Official 2022 list identifies the exact command as an undocumented Tcl modify command. No syntax/argument meaning is provided. Retained 2022 source triage captures the call form *jacobian_calculate_cornerpts $jacob_method from installed Tcl and explicitly says method choices/output are unknown; do not promote that observation to a public signature.

- [Source: official classification](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/undocumented_tcl_modify_commands.htm) — Undocumented Tcl Modify Commands

## *redraw

Status: source_gap_unresolved. Old exact syntax: not established by this source audit.

No exact public Tcl API page or historical official route found in checked catalogs/indexes. Keep distinct from hm_redraw and from *setoption block_redraw; neither exact-name variation establishes an alias.

- [Source: similar but not equivalent reference](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_setoption.htm) — Inputs > block_redraw

## hm_getentityvalue

Status: officially_deprecated_replacement_documented_old_syntax_not_in_deprecation_table. Old exact syntax: not established by this source audit.

The official 2022 Deprecated Tcl Query Commands table names hm_getentityvalue and maps it to hm_getvalue. That table is a deprecation crosswalk, not the old command signature. The replacement has a separate official contract. Keep distinct from the HyperMesh Template Function @getentityvalue().

- [Source: official deprecation](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/deprecated_tcl_query_commands_r.htm) — Deprecated Tcl Query Commands
- [Source: replacement contract](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/hm_getvalue.htm) — hm_getvalue syntax and inputs
- [Source: homonym separation](https://2022.help.altair.com/2022.1/hwdesktop/hwd/topics/reference/hm/_getentityvalue.htm) — @getentityvalue() Template Function; distinct exact name/surface

## *collectorcreateonly

Status: officially_deprecated_replacement_documented_old_syntax_contract_missing. Old exact syntax: not established by this source audit.

The 2022 Deprecated Tcl Modify Commands table maps *collectorcreateonly to *createentity. No legacy signature is given in that table. A 2019 official tutorial includes an example call only; that example is not a complete command contract. Do not use local install/probe signature as public syntax.

- [Source: official deprecation](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/deprecated_tcl_modify_commands.htm) — Deprecated Tcl Modify Commands
- [Source: official historical example only](https://2019.help.altair.com/2019/tutorials/hm_8090.pdf) — step 6, p. 4 (tutorial example)
- [Source: current replacement contract](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/_createentity.htm) — *createentity

## *elementorder

Status: officially_deprecated_replacement_documented_old_syntax_not_in_crosswalk. Old exact syntax: not established by this source audit.

The 2022 Deprecated Tcl Modify Commands list maps *elementorder to *setoption element_order. The official API Programmer’s Guide 14.0.130 independently states *elementorder is deprecated and directs users to element_order. Neither source provides the old command syntax. Do not treat local source/probe signature as public syntax.

- [Source: official deprecation](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/deprecated_tcl_modify_commands.htm) — Deprecated Tcl Modify Commands
- [Source: official release guide](https://help.altair.com/hwdesktop/hwd/topics/reference/hm/api_programmers_guide_14_0_130_r.htm) — Deprecated Commands
- [Source: replacement contract](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_setoption.htm) — Inputs > element_order

## *autocolorwithmark

Status: 2022_undocumented_later_release_contract_only. Old exact syntax: not established by this source audit.

The official 2022 undocumented-command list includes this exact name, so 2022 public syntax is not stated there. The current official page gives syntax *autocolorwithmark entity_type mark_id ?option? and says option was added in 2023; do not back-port that signature as a confirmed 2022 contract. Retained 2022 triage records an observed two-argument form only.

- [Source: official 2022 classification](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/undocumented_tcl_modify_commands.htm) — Undocumented Tcl Modify Commands
- [Source: current public contract](https://help.altair.com/hwdesktop/hwd/topics/reference/hm/_autocolorwithmark.htm) — Syntax, Inputs, Version History

## hm_nodelist

Status: officially_deprecated_replacement_documented_old_syntax_not_in_deprecation_table. Old exact syntax: not established by this source audit.

The 2022 official deprecated query table maps hm_nodelist to hm_getvalue. It gives no legacy command syntax or parameter translation. Use exact hm_getvalue docs for the replacement contract; do not invent a mechanically equivalent call.

- [Source: official deprecation](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/deprecated_tcl_query_commands_r.htm) — Deprecated Tcl Query Commands
- [Source: replacement contract](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/hm_getvalue.htm) — hm_getvalue syntax and inputs

## *createnode

Status: officially_deprecated_replacement_documented_old_syntax_not_in_crosswalk. Old exact syntax: not established by this source audit.

The 2022 official deprecated modify table maps *createnode to *createentity. It provides no legacy signature. An HMASCII *node command is a different exact name and surface and is not evidence for Tcl *createnode syntax. Do not use local registry/probe data as a public syntax contract.

- [Source: official deprecation](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/deprecated_tcl_modify_commands.htm) — Deprecated Tcl Modify Commands
- [Source: homonym separation](https://2025.help.altair.com/2025/hwdesktop/hwd/topics/reference/hm/_node.htm) — *node() HyperMesh HMASCII Command
- [Source: related public commands](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_createnodesbetweenpositions.htm) — *createnodesbetweenpositions

## *materialupdate

Status: officially_deprecated_replacement_documented_old_syntax_not_in_crosswalk. Old exact syntax: not established by this source audit.

The 2022 official deprecated modify table maps *materialupdate to *setvalue. No old signature is given by the crosswalk. An Altair Community Q&A contains a user-provided historical example and an accepted replacement suggestion; it is supporting context, not an API reference contract.

- [Source: official deprecation](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/deprecated_tcl_modify_commands.htm) — Deprecated Tcl Modify Commands
- [Source: community context](https://community.altair.com/discussion/4015/what-is-updated-command-for-materialupdate-in-latest-hypermesh-2021-version) — question and accepted answer, lines 35-47, 63-67
- [Source: replacement contract](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/_setvalue.htm) — *setvalue

## hm_attributeindexmax

Status: officially_deprecated_replacement_documented_old_syntax_not_in_deprecation_table. Old exact syntax: not established by this source audit.

The official 2022 deprecated query table maps hm_attributeindexmax to hm_getvalue. No legacy signature or argument mapping appears in the table.

- [Source: official deprecation](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/deprecated_tcl_query_commands_r.htm) — Deprecated Tcl Query Commands
- [Source: replacement contract](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/hm_getvalue.htm) — hm_getvalue syntax and inputs

## hm_attributeindexvalue

Status: officially_deprecated_replacement_documented_old_syntax_not_in_deprecation_table. Old exact syntax: not established by this source audit.

The official 2022 deprecated query table maps hm_attributeindexvalue to hm_getvalue. No legacy signature or argument mapping appears in the table.

- [Source: official deprecation](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/deprecated_tcl_query_commands_r.htm) — Deprecated Tcl Query Commands
- [Source: replacement contract](https://2022.help.altair.com/2022/hwdesktop/hwd/topics/reference/hm/hm_getvalue.htm) — hm_getvalue syntax and inputs

## Documented new-code redraw workflow

The [redraw workflow guide](HYPERMESH_REDRAW_WORKFLOW_2022_3.md) supplies the documented APIs for graphics update/blocking. The exact legacy names above remain unresolved; caught callsites are not availability evidence.
