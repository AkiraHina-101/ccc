# HyperMesh graphics redraw — documented workflow

Source release: Altair Help 2022.3. Runtime: not_run. This guide describes the documented operations for new tool code; it does not establish aliases for `*redraw` or `*redrawblock`.

## Documented contracts

[hm_redraw](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/hm_redraw.htm) redraws the HyperMesh window. Its public signature is:

```text
hm_redraw
```

[*setoption](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_setoption.htm), Inputs → `block_redraw`, controls graphics redraw: 0 allows redraw, 1 blocks redraw. While blocked, window resizing, de-iconifying or maximizing can still redraw; unblocking returns normal redraw behavior. The documented option/value call forms are:

```text
*setoption block_redraw=1
*setoption block_redraw=0
```

[hm_getoption](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/hm_getoption.htm) queries current values of certain HyperMesh options. Its optional `default=1` argument queries a default instead of the current value where supported; do not use that when saving current state.

```text
hm_getoption option ?default?
```

Read the [full setoption contract](../tool_contracts/hypermesh/Tcl_setoption_47f2ccd0190b.md) and [full getoption contract](../tool_contracts/hypermesh/Tcl_hm_getoption_e44ff3a97afb.md). Querying `block_redraw` is a derived use of the option list, not a quoted source example; handle a failed query explicitly on the intended target.

## Tool-authoring procedure

For a scoped operation, preserve the existing setting where query support is available, block redraw during the operation, restore that setting on success and failure, and request a redraw when appropriate. These are derived authoring steps, not an executed example. Do not assume the prior setting was zero. Coordinate nested operations so inner cleanup does not alter an outer operation's setting. Restoration failure needs its own error reporting.

Blocking graphics is unrelated to disabling geometry checks, hiding application errors or declaring a model operation successful.

## Observed names do not establish API availability

The maintained tool callsites put `*redraw` and `*redrawblock` inside `catch`, often without inspecting the result. A missing command can therefore be swallowed by the same code. Finding those names in a working script is not evidence of their availability or full signature. Existing default-batch, GUI-only and official-route lookup tables supplied no exact record in this review; those tables also do not prove universal absence in every installation/context.

Keep the two old-name [source gaps](HYPERMESH_TCL_SOURCE_GAPS.md) unresolved until exact evidence exists. For a new implementation needing the documented redraw behavior, use the contracts above. This is an operation choice, not a statement that either old name is an equivalent alias. No maintained tool was modified or executed by this documentation work.
