# Nastran property/material field workflow for RevolveTet4

This support note covers the actual property assignment pattern in `<04-Meshing_tool>/RevolveTet4/revolve_tet4.tcl`. It combines public HyperMesh Help (2022 / 2022.3) with a separately labeled installed-source observation from the selected Classic 2022 installation. It does not claim solver acceptance of an unassigned material, nor does it generalize installed template details to other Nastran profiles or releases.

## Target source pattern

RevolveTet4 creates each property with `*createentity props id=$pid cardimage=PSOLID name=$propertyName`, assigns it to a component with `*setvalue comps id=$cid propertyid=$pid`, and reads back component `propertyid`, property `name`, property `cardimage`, and property `materialid`. In this path, it does not assign any material; it expects the queried `materialid` to be numeric zero. That is the tool's readback expectation, not evidence that a zero or blank MID is solver-valid.

The exact public generic command forms are available in the reviewed [*createentity transcript](../tool_contracts/hypermesh/Tcl_createentity_57d9eb2e8b19.md) and [*setvalue transcript](../tool_contracts/hypermesh/Tcl_setvalue_2529df4e832d.md). Public source releases are Help 2022.3 and target Classic 2022 compatibility is a separate fact. `*createentity` accepts data-name/value pairs and says attributes/STATUS are unsupported. `*setvalue` updates existing entities and permits data-name updates when the proper card image is assigned. The public property data-name table identifies `cardimage`, `id`, `name`, and `materialid`; `materialid` is the integer ID of the material assigned to the property and may be valid or unresolved. The component data-name table identifies `propertyid` as the assigned property ID. These generic tables establish the data-name meanings but do not alone establish which solver card image or field mapping applies to a particular Nastran profile.

## Public Nastran relation and card scope

Altair's 2022 [Element Property and Material Assignment Rules](https://2022.help.altair.com/2022/hwdesktop/hm/topics/pre_processing/entities/element_propery_and_material_assignment_rules_r.htm) says the rules depend on current user profile. Nastran is in solver group 1. For that group, a property may be assigned directly to an element; absent that, the component's property becomes the element's property. Materials are assigned to properties, and elements inherit the material of their assigned property. If a property has no assigned material, elements have no material assignment. This describes HyperMesh's assignment relation; it does not say that an exported solver deck with no MID is valid.

The 2022 [Properties reference](https://2022.help.altair.com/2022/hwdesktop/hm/topics/pre_processing/entities/properties_r.htm) places PSOLID in the Nastran 3D property group and describes it as defining solid element properties for CHEXA, CPENTA and CTETRA entries. Only one card image may be loaded into a property collector. These are public UI/interface statements, not a Tcl field schema. The [Nastran interface reference](https://2022.help.altair.com/2022/hwdesktop/hm/topics/pre_processing/interfacing/nastran_interface_overview.htm) says the selected solver profile loads its template; exact field exposure is therefore template/profile-specific.

## Installed template evidence: selected Classic 2022 installation

The project `src/nastran_control/config.tcl` contains only placeholder template candidates; it does not identify a machine template. The selected user shortcut was resolved by the coordinator to a Classic 2022 installation. In that installation, the Nastran template root was inspected read-only. The top-level `general` template header identifies build `HWVERSION_2022.0.0.33_Mar 30 2022`; the relevant definitions are in the relative locators below. These installed-source observations describe this installed template only; the actual active in-session solver profile/template was not queried.

- `<ALTAIR_INSTALL_DIR>/hwdesktop/templates/feoutput/nastran/general`
- `<ALTAIR_INSTALL_DIR>/hwdesktop/templates/feoutput/nastran/include/properties.tpl`
- `<ALTAIR_INSTALL_DIR>/hwdesktop/templates/feoutput/nastran/include/propertieslf.tpl`

In both `properties.tpl` and `propertieslf.tpl`, the installed PSOLID card definition maps its printed `PID` field to entity data name `id`, and `MID` to entity data name `materialid`. The exported card is labeled PSOLID. This is the specific installed-source evidence supporting the use of `materialid` as the PSOLID MID field in that template. No numeric attribute ID is needed or documented by this mapping; do not substitute guessed numeric IDs.

The same template definitions expose PSOLID-specific optional fields (CORDM, IN, STRESS, ISOP, FCTN) with template-level choices. They do not change the card's PID/MID data-name mapping. This note omits their option details because the maintained target tool does not set them.

**MID default status:** no default value declaration for the PSOLID MID/materialid field was found in the inspected PSOLID card definition. The template field line merely emits `materialid`; that alone does not establish a default, blank-to-zero conversion, allowable unassigned state, solver acceptance, or validity for MSC versus NX solver versions. The target tool's check `hm_getvalue props ... dataname=materialid` equals 0 is application readback only. If assigning a material or claiming deck validity is required, inspect the exact active profile/template and applicable solver manual/version and validate the resulting deck separately.

## Query the active template without changing it

Read the exact [hm_info contract](../tool_contracts/hypermesh/Tcl_hm_info_99edf821eaac.md). Its Syntax contains two branches: a top-level `option`, or `-appinfo info_option ?value?`. The template keys are top-level options; they are not `-appinfo` sub-options. Source-derived query forms (not runtime-tested here):

```tcl
hm_info istemplateloaded
hm_info templatefilename
hm_info templatecodename
hm_info templateid
hm_info templatetype
```

`istemplateloaded` reports 1/0; `templatefilename` reports the current template filename. In contrast, installation information uses the separately listed `-appinfo` branch, for example `hm_info -appinfo ALTAIR_HOME`. Resolve and store actual returned paths in machine/project configuration, outside this shared API library. A template's reported type/name does not establish solver-deck validity.

## Suggested source-grounded workflow

1. Resolve the target release and active solver profile/template through project machine configuration or the running application. `Nastran (MSC)` and `Nastran (NX)` are distinct profiles; do not infer one from the word Nastran in a tool header.
2. Confirm the chosen template exposes the intended property card. Public Help establishes that solver profile selects/loads a template; the installed `general` source above is a named template, not proof that it is active.
3. For the inspected Classic 2022 installed Nastran `general` template only, the PSOLID field map supports `id` for PID and `materialid` for MID. The target tool's observed call form uses `cardimage=PSOLID`; the generic creation/update forms are source-documented, but exact card-image availability remains dependent on the active template.
4. Assign the property ID to the component via its documented `propertyid` data name; verify component property ID, property card image/name, and—if the workflow requires one—material relationship through readback. Do not treat a readback value of 0 as proof of solver-deck validity.
5. If the output requires a material, assign a material whose card image and ID are valid for the active solver profile; public 2022 Help establishes materials belong to properties for the Nastran group-1 relation. The target tool path covered here does not assign a material.

## Not established

- Whether `materialid=0` or a blank MID is accepted by any Nastran solver version.
- A default MID for PSOLID in the installed 2022 `general` template.
- Whether the active application session is using MSC, NX, or this `general` template.
- Solver-specific constraints or behavior for the target solver's PSOLID card.
- Runtime success of `*createentity`, `*setvalue`, or `hm_getvalue` in this session; no model was opened or modified.

## Source pointers

The generic command contracts are available as [*createentity](../tool_contracts/hypermesh/Tcl_createentity_57d9eb2e8b19.md) and [*setvalue](../tool_contracts/hypermesh/Tcl_setvalue_2529df4e832d.md), transcribed from Altair Help 2022.3. Their direct Altair source URLs and the public Nastran references are linked at the claims they support above. The companion source register remains in the evidence batch; reader use does not depend on it. Installed-source locators use `<ALTAIR_INSTALL_DIR>` for the suite root, with `hwdesktop` as the product subdirectory.
