# HyperMesh GUI and script-authoring routes (Altair Help 2022.3)

For a HyperMesh GUI script, first distinguish standard Tcl/Tk widgets from HyperMesh-specific GUI commands and from HWTK/HWAT. The shared catalog's GUI/toolkit source map (outside this package; choose another package if needed) explains those ownership boundaries. Use the direct Help routes below to find contracts rather than inferring callable APIs from a GUI workflow page.

- HyperMesh 2022.3 product Help (outside this package; choose another package if needed) routes panels, entity/model workflows, meshing and solver interfaces.
- HyperMesh HWD reference routes (outside this package; choose another package if needed) includes Tcl Modify/Query, GUI, utility, template and script-related routes grouped by Altair's source labels.
- HyperWorks Desktop Tcl reference (outside this package; choose another package if needed) covers the shared Tcl/Tk and client APIs; inspect each page's `Application` label.
- HWTK/HWAT guide (outside this package; choose another package if needed) covers the toolkit distinction and indexed widget/function catalogs.
- [HyperWorks Desktop Scripts overview](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/chapter_heads/scripts_r.htm), [Create Scripts](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/creating_scripts_r.htm), and [Run Scripts](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/running_scripts_r.htm) are direct public authoring/launch routes in the shared Desktop Help book.

The older expanded GUI reference is retained in `legacy_material` (outside this package; choose another package if needed). Keep Classic 2022 source/runtime observations there distinct from the public 2022.3 Help route summaries here.
