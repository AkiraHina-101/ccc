# HyperMesh priority workflow contracts (2022.3)

Use this page to navigate source-backed contracts for high-priority HyperMesh Tcl workflows. It links to full reader transcripts and evidence; syntax and inputs are not copied here. “Source-ready” means the public 2022.3 page documents a usable form. It does not prove runtime success, installed-version compatibility, solver-profile support, or correctness of every historical callsite.

## Build and edit mesh entities

- [`*createelements`](../tool_contracts/hypermesh/Tcl_createelements_c1a5703a6fd2.md) — source documents the 1D element creation form and integer array constraints; solver/profile compatibility remains unknown.
- [`*createelement`](../tool_contracts/hypermesh/Tcl_createelement_a65e7993d787.md) — source documents list-based node selection and ordering; dynamic config/type values remain profile-dependent.
- [`*renumber`](../tool_contracts/hypermesh/Tcl_renumber_c4c0b51a16cc.md) — source documents the reviewed node internal-ID mutation form and effect.
- [`*tetmesh`](../tool_contracts/hypermesh/Tcl_tetmesh_4bebeabdb903.md) — canonical documented entity token is `elems`; source supports that form. A historical call spelling `elements` remains unconfirmed and is not treated as an alias.
- [`*linecreatefromcoords`](../tool_contracts/hypermesh/Tcl_linecreatefromcoords_e0c475a2867a.md) — source documents the type codes, coordinate-array contract, and closed-line offset; use array ID 1 as stated by the page.
- [`*createentity`](../tool_contracts/hypermesh/Tcl_createentity_57d9eb2e8b19.md) and [entity field constraints](HYPERMESH_ENTITY_FIELDS_2022_3.md) — documented `name` and property `cardimage` fields are data names. Component name-only calls are source-supported. Observed property calls require `PSHELL`/`PSOLID` card-image values whose solver/template/profile support is not established here. The additive [Nastran property field guide](NASTRAN_PROPERTY_FIELDS_2022.md) now establishes public PSOLID card purpose and the selected installed-template PID/MID mapping; active-profile compatibility is still task-specific. Generic attribute support remains conflicted in the accepted core review; do not generalize to arbitrary attributes.
- [`*rigidlink`](../tool_contracts/hypermesh/Tcl_rigidlink_cba6d94d963a.md) — the observed positional call is source-supported with nonempty digits 1–6. The generic signature uses `dofs`, while Inputs labels `dof`; keep this source discrepancy visible.
- [`*deletemark`](../tool_contracts/hypermesh/Tcl_deletemark_a5fccc44cb04.md) — source documents deletion by entity type and mark; ordinary connected nodes cannot be deleted through this command.

## Import and legacy commands

- [`*feinputwithdata2`](../tool_contracts/hypermesh/Tcl_feinputwithdata2_a00080fc1e1d.md) — the generic command syntax and reader argument are documented. The page directs reader-specific extra strings to reader documentation; support for a particular `hmascii` reader form is not established by this generic contract. Treat reader/profile compatibility as unresolved.
- [`*createnode`](HYPERMESH_TCL_SOURCE_GAPS.md) — deprecated crosswalk maps it to [`*createentity`](../tool_contracts/hypermesh/Tcl_createentity_57d9eb2e8b19.md) but gives no legacy Tcl signature. The old call cannot be reconstructed or translated from that mapping alone.
- [`*materialupdate`](HYPERMESH_TCL_SOURCE_GAPS.md) — deprecated crosswalk maps it to [`*setvalue`](../tool_contracts/hypermesh/Tcl_setvalue_2529df4e832d.md) but gives no legacy Tcl signature. The documented new command is a navigation route, not an automatic parameter translation.

## Close a reader-specific import gap

For HMASCII, public file-format documentation establishes file grammar, not the `*feinputwithdata2` reader's extra strings. The selected Classic 2022 installed metadata can be consulted at `<ALTAIR_INSTALL_DIR>/hwdesktop/hm/scripts/ImportExport/xml/solver/import/hmascii.xml`; detection criteria and project calls are supporting observations, not a complete reader contract. Resolve the suite root from project configuration or the confirmed launcher. The exact `#hmascii/hmascii` alias and zero-string-array behavior remain unproven by these sources. Obtain a release-matched reader-options page, explicit reader source contract, or official command-file example identifying both reader and settings before claiming them supported. If a task requires runtime confirmation, use a separate approved scratch import fixture and report its scope.

## Select, inspect, and guard

The seven source contracts below cover documented forms and constraints. See the linked transcripts for accepted options, selectors, return shapes, and examples.

- [`*createmark`](../tool_contracts/hypermesh/Tcl_createmark_1089a71c8566.md) → [`hm_getmark`](../tool_contracts/hypermesh/Tcl_hm_getmark_b143fc951d58.md) → [`*clearmark`](../tool_contracts/hypermesh/Tcl_clearmark_520cdc0b9faf.md) — keep entity type, mark slot, and model scope consistent. `*createmark` options have entity-specific constraints; use the exact documented option.
- [`hm_entityinfo`](../tool_contracts/hypermesh/Tcl_hm_entityinfo_f117dbb8de84.md) — `exist` is an existence query; other options can have different return shapes.
- [`*setoption`](../tool_contracts/hypermesh/Tcl_setoption_47f2ccd0190b.md) / [`hm_getoption`](../tool_contracts/hypermesh/Tcl_hm_getoption_e44ff3a97afb.md) — only certain options are queryable; do not assume every setter key has a getter.
- [`hm_latestentityid`](../tool_contracts/hypermesh/Tcl_hm_latestentityid_441affeaaae7.md) — retrieves by recent creation order, not maximum numeric entity ID; intervening creates can change the result.

## Readiness and scope

The initial P0 source review below predates the additive Nastran field guide linked above. Its 9/12 count describes that review snapshot; conditional documented-form sufficiency and active-profile compatibility are separate axes. The P0 source review covers 12 priority identities. Nine have source-supported forms for documented operations, one (`*createentity`) is partial for observed property creation because the template/profile card-image values are not established, and two deprecated names (`*createnode`, `*materialupdate`) have legacy signature gaps despite documented replacement routes. For `*feinputwithdata2`, generic command-contract readiness is separate from the unresolved `hmascii` reader-specific form. For `*tetmesh`, the documented `elems` form is source-ready while the old `elements` spelling remains unconfirmed.

The P1 selection/query review covers seven identities and finds source sufficiency for their documented forms. Selected production context informed the workflow notes; no exhaustive old-callsite audit was performed. Runtime was not run and the target solver/profile remains unknown.

