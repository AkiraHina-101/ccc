# Generic HyperMesh entity-field guide

Source-reviewed generic field reference. Evidence is the original Altair Help 2022.3. Target release, active template, and solver profile are unknown. Use documented generic Tcl APIs with exact data names, and check solver-dependent values against the active installed template.

## Generic Tcl call forms and node fields

[`*createentity`](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_createentity.htm) creates entities from data names:

```tcl
*createentity entity_type ?modelname=<name_of_model>? ?name1=value1? ?name2=value2? ... ?name3=valueN?
```

Its Description says only data names may be set and explicitly says attributes and `STATUS` are unsupported. Inputs conflicts by describing data-name and/or attribute pairs. Follow the explicit limitation pending a source resolution. The documented node example is `*createentity nodes x=100 y=200 z=0`.

The original [node data-name table](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/data_names-nodes.htm) defines `x`, `y`, and `z` as double-precision coordinates in the local system. It defines `globalx`, `globaly`, and `globalz` as global coordinates, and `coordinates` as a global-coordinate triple. `localcoordinates` is query-only through `hm_getvalue`. Units are not specified.

[`*setvalue`](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_setvalue.htm) updates existing entities. It documents one selector per call: `id`, `name`, `mark`, `list`, `user_ids`, or `user_names`. Here `id=<id>` selects by entity ID; this is distinct from `solver_id` and template attribute IDs. A proper card image is required before data-name, attribute, or metadata updates. Examples include `*setvalue comps mark=1 materialid=2` and `*setvalue elems list=1 node1=2`; these do not define every field for every template.

## Component and property fields

The original [component data-name table](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/data_names-components_r.htm) defines:

- `cardimage`: assigned card image name, string; `cardimagetype`: assigned card image type, string.
- `id` and `internalid`: entity ID, unsigned integer; `name`: entity name, string.
- `propertyid`: ID of the property assigned to the component; may be valid or unresolved, integer.
- `property`: pointer to the assigned property; always a valid property ID if assigned.
- `internalpropertyid`: assigned property ID, may be valid or unresolved, integer.
- `solver_id`: solver ID, integer; `solvername`: solver name for name-pool-enabled entities, otherwise internal name.

The original [property data-name table](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/data_names-properties.htm) defines `cardimage` and `cardimagetype` as strings, `id` and `internalid` as unsigned integer entity IDs, `name` as entity name, and `solver_id` as integer. It does not list `propertyid` for property entities.

These original tables establish the component `propertyid` data-name meaning. The generic `*createentity` page accepts data-name/value pairs, and `*setvalue` allows data-name updates when the proper card image is assigned. The component table does not confirm writeability for every profile or provide a portable assignment sequence/value. Check the active template before writing it. Card-image values remain template/profile-specific.

## Elements and references

The original [elements data-name table](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/elements_data_names_hm_ref_r.htm) does not list `propertyid`, `property`, `cardimage`, `name`, or a generic `id` row. Do not infer an element property-association field from this table. Its `material` row is an entity reference: material ID resolved through the element's property, component, or component's property.

The [data-name reference page](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/data_names_r.htm) documents pointer notation generally: append a period and target entity data name to a pointer (its example uses `node1.id`). This page does not provide a component `property.id` example; avoid presenting one as a directly documented example. `*setvalue`'s typed metadata syntax such as `metadata={mymeta_entity {mats 3}}` is a separate metadata mechanism, not a property data-name assignment example.

Keep similarly named interfaces separate. HMASCII [`*component()`](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_component.htm) uses a `propertyid` parameter, and [`*property()`](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_property.htm) is also an HMASCII command. Template Language [`*components()`](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_components.htm) uses `card_image_name` and `mat_card_image_name`. These are not Tcl entity data-name contracts.

## Template and compatibility boundary

The [data-name overview](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/data_names_overview_r.htm) says solver-specific data are stored in card images and defined by FE output templates; names and numeric attribute IDs can vary by solver/card type. It points to `<altair_home>/templates/feoutput`. For a local lookup, use the portable root `<ALTAIR_INSTALL_DIR>/templates/feoutput/` and record the actual relative locator. Do not infer PSOLID fields, MID defaults, or card enums from a different solver or the Nastran interface supplement.

The dedicated 2022.3 [solver attributes and data names page](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/solver_attributes_and_data_names_r.htm) was not retrievable in this review; no claim here depends on it. The overview page supports the template-variation statement. No runtime, GUI, Tcl, or installed-template lookup was performed.

## Read with exact command contracts

Use the [reviewed creation/update/query core](HYPERMESH_TCL_TOOL_CORE_CONTRACTS_2022_3.md) and exact source index (outside this package; choose another package if needed) for full syntax, selection, errors and examples. This guide supplies field meanings; it does not replace those contracts. Original table excerpts are retained separately in builder evidence; reader use requires only this Markdown and its linked command pages.
