# Nastran deck support in the HyperMesh interface (Altair Help 2022)

This is a concise guide to how HyperMesh's Nastran solver interface reads, edits and writes Nastran decks. It is not a complete Nastran Bulk Data specification and does not claim to cover every MSC or NX solver-version rule. Use the solver's own manual for the full card grammar and solver semantics.

## Profiles, input formats and export templates

HyperMesh documents two Nastran profiles: **Nastran (MSC)** and **Nastran (NX)**. The input translator supports single, double, free and fixed formats. It assumes continuation lines follow the preceding line on input; on export it writes `+` or `*` continuation references. Unrecognized lines are placed in editable unsupported cards, and warnings/errors are written to a reviewable text file. A Nastran template must be loaded before exporting or editing cards; selecting the profile loads its template automatically. [Nastran Interface](https://2022.help.altair.com/2022/hwdesktop/hm/topics/pre_processing/interfacing/nastran_interface_overview.htm)

Two export/edit templates are described: `nastran/general` writes all cards in single-precision fixed format; `nastran/generallf` writes System, Grid, Element, Load, Subcase, Property and Material cards in fixed double-precision long format. These are HyperMesh template behaviors, not a statement that all Nastran readers accept the same formats.

## Cards, properties and solver mapping

The [Control Cards reference](https://2022.help.altair.com/2022/hwdesktop/hm/topics/pre_processing/entities/control_cards_r.htm) lists cards available through the active solver profile. Card availability and editable fields therefore depend on the selected profile/template; the route catalog is a navigation aid, not a universal schema. The [Properties reference](https://2022.help.altair.com/2022/hwdesktop/hm/topics/pre_processing/entities/properties_r.htm) groups properties by dimensionality and explains their card-image/template relationship. For a particular card, follow the direct card page and verify it against the intended solver release.

The interface guide notes that several load-related solver cards are represented as Analysis Parameters/LoadStepInputs rather than load collectors. It also describes Nastran ID-sharing exceptions for connector, aeroelasticity and structural entities. Consult the interface page for the full listed cases and restrictions.

## Complementary library routes

- 2022.3 HyperMesh product Help (outside this package; choose another package if needed) for user workflows and interface topics.
- 2022.3 HyperMesh reference routes (outside this package; choose another package if needed) for command, entity and solver-interface source pages.
- 2022.3 HyperWorks Desktop Help index (outside this package; choose another package if needed) for shared Desktop routes.

An older generated Nastran card-field snapshot (outside this package; choose another package if needed) reflects a particular installed HyperMesh template set. It is retained as historical/template-specific material, not generalized as the official card definition for every Nastran version.
