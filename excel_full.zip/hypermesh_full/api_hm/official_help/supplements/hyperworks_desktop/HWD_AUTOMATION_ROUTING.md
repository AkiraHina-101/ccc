# HyperWorks Desktop automation routing

HyperWorks Desktop is the shared host layer for multiple clients. Pick the interface before looking up syntax:

| Task | Start here | Boundary |
|---|---|---|
| Client Tcl methods (`hwi`/handles) | Tcl reference route catalog (2022.3) (outside this package; choose another package if needed) | Filter by each page's `Application` label; shared method names may not exist in every client. |
| Tcl commands and GUI integration | [HyperMesh GUI scripting routes](../hypermesh/HYPERMESH_GUI_SCRIPTING_2022_3.md) and toolkit map (outside this package; choose another package if needed) | Standard Tk, HyperMesh GUI Tcl, HWTK and HWAT are distinct layers. |
| HWC command language | HWD other Help route catalog (outside this package; choose another package if needed) | HWC syntax is its own command language, not Tcl or HWI method syntax. |
| Batch/report automation | HWD shared Help index (outside this package; choose another package if needed) and its `Batch`, `Report` and scripting entries | `hmbatch` startup/runtime and an application API are separate questions. Follow the source release and client scope. |
| HyperView results translation | HvTrans reference (outside this package; choose another package if needed) | HvTrans CLI/config translates solver results to H3D; it is not the HyperView capture API. |

Older focused 2022 notes for batch, Python capture and auxiliary clients remain preserved at `legacy_material` (outside this package; choose another package if needed). They contain a mixture of public-source summaries and installed-source evidence; inspect each note's provenance before reusing it as a contract.
