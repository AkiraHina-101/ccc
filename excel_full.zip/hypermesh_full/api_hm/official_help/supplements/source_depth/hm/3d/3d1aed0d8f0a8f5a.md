# Manage Transformations with the Transformation Manager

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/model_setup/transformation_manager.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `835ed28c861461aab155fb5ab7d3e73faad423fa21f48e79deeeb585917806c3`. Record: `3d1aed0d8f0a8f5a`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source images linked but not mirrored; textual record is not a complete copy of graphical instructions

## Original topic body (structured)

## Manage Transformations with the Transformation Manager


Manage the definition of transformation applied on the nodes and elements in order to easily position the entity using a combination of scale, rotate, and translate and symmetry functions.


These operations are usually applied on standard parts such as dummies, barriers, and so on for positioning in different crash setups. Also they can be used for repositioning components with strain history between multiple steps of simulation.


Access the Transformation Manager by selecting Tools > Transformation Manager from the menu bar.


The Transformation Manager has two basic folders/sections.

**Transformation Definition**


Lists the transformations defined in the model in a tree structure detailing the cross referencing between the entity and the transformation.


### Toolbars


The Transformation Manager includes toolbars and a context menu.
        Toolbars provide the ability to switch between the two views, show or hide entities on which
        transformation is applied within the model, and activate or deactivate the transformation
        applied on an entity. The context menu provide basic functions such
        as the creation, addition of entities, activation/inactivation of transformation, deletion,
        card edit, manipulating the sequence of transformation, display control, and review.


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Icon</th>
<th>Function</th>
</tr>
</thead>
<tbody>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/checkboxselectall_24.png"/></td>
<td>Activate the selected transformation. If none are selected, activate all the
                  transformations defined.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/checkboxunselectall_24.png"/></td>
<td>Inactive the selected transformation. If none are selected, inactivate all
                  the transformations defined.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/checkboxselectreverse_24.png"/></td>
<td>Active or inactive state depending in its current state for the selected
                  transformation. If none is selected, it is applied on all the transformations
                  defined.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tabtransformationentity_24.png"/></td>
<td>Switches to transformation – entity view</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tabentitytransformation_24.png"/></td>
<td>Switches to entity – transformation view </td>
</tr>
</tbody>
</table>
### Context Menu


A context menu is available for any selected item in the Transformation Manager tree. To view the context menu right-click on an entity folder, an individual entity, or in an empty space in the browser. Clicking in the empty space provides options applicable to all the entities in the transformation definition. The functions vary depending on whether it is performed on an entity in the transformation repository or in a transformation definition. There are also subtle differences in functions performed depending on the view.


### Transformation Definition


<table><caption><span><span>Table 1. </span>Entity- Transformation View</span></caption><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Item</th>
<th>Definition</th>
</tr>
</thead>
<tbody>
<tr>
<td>Add entity</td>
<td>Allows you to edit the entity on which transformation is defined. Available
                  only on entity.</td>
</tr>
<tr>
<td>Card edit</td>
<td>Opens the corresponding solver Card Image panel. Available on both entity and
                  transformation.</td>
</tr>
<tr>
<td>Delete</td>
<td>Deletes the selected entity. Available on both entity and
                  transformation.</td>
</tr>
<tr>
<td>Transform</td>
<td>Creates a new transformation and applies it on the selected entity. If
                  transformation already exists for the entity, it appends to it. Available on the
                  entity.</td>
</tr>
<tr>
<td>Rename</td>
<td>Renames the selected entity/ transformation. Available on both entity and
                  transformation.</td>
</tr>
<tr>
<td>Show, Hide, Isolate, Show all, Review, Reset review:</td>
<td>Similar to <span>Model Browser</span> functions. Available for both
                  transformation and entity.</td>
</tr>
<tr>
<td>Move UP</td>
<td>Swaps the ID of the selected transformation with the next smaller ID that is
                  attached to the same entity.</td>
</tr>
<tr>
<td>Move up</td>
<td>Swaps the ID of the selected transformation with the next higher ID that is
                  attached to the same entity.</td>
</tr>
<tr>
<td>Collapse All</td>
<td>Closes all of the folders in the tree structure, so that only the top-most
                  level of items displays.</td>
</tr>
<tr>
<td>Expand All</td>
<td>Opens all of the folders in the entire tree structure, exposing every item
                  nested at every level.</td>
</tr>
</tbody>
</table>
<table><caption><span><span>Table 2. </span>Transformation - Entity View</span></caption><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Item</th>
<th>Definition</th>
</tr>
</thead>
<tbody>
<tr>
<td>Create new</td>
<td>Creates new transformation.</td>
</tr>
<tr>
<td>Add entity</td>
<td>Allows to add a new entity on to the selected transformation. If the entity
                  is selected, you can edit the content. Available on both entity and
                  transformation.</td>
</tr>
<tr>
<td>Card edit</td>
<td>Opens the corresponding solver Card Image panel. Available on both entity and
                  transformation.</td>
</tr>
<tr>
<td>Delete</td>
<td>Deletes the selected entity. Available on both entity and
                  transformation.</td>
</tr>
<tr>
<td>Transform</td>
<td>Appends the defined transformation on the selected transformation. Available
                  only on the transformation.</td>
</tr>
<tr>
<td>Rename</td>
<td>Renames the selected entity. Available on both entity and
                  transformation.</td>
</tr>
<tr>
<td>Show, Hide, Isolate, Show all, Review, Reset review</td>
<td>Similar to <span>Model Browser</span> functions. Available for both
                  transformation and entity.</td>
</tr>
<tr>
<td>Move Up</td>
<td>Swaps the ID of the selected transformation with the next smaller ID that is
                  attached to the same entity.</td>
</tr>
<tr>
<td>Move Down</td>
<td>Swaps the ID of the selected transformation with the next higher ID that is
                  attached to the same entity.</td>
</tr>
<tr>
<td>Collapse All</td>
<td>Closes all of the folders in the tree structure, so that only the top-most
                  level of items displays.</td>
</tr>
<tr>
<td>Expand All</td>
<td>Opens all of the folders in the entire tree structure, exposing every item
                  nested at every level.</td>
</tr>
</tbody>
</table>
### Transformation Repository


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Item</th>
<th>Definition</th>
</tr>
</thead>
<tbody>
<tr>
<td>Transform</td>
<td>Creates new transformation on the selected entity. The transformation and the
                  entity show up in the transformation definition folder.</td>
</tr>
<tr>
<td>Card Edit</td>
<td>Opens the corresponding solver Card Image panel. </td>
</tr>
<tr>
<td>Rename</td>
<td>Renames the selected entity.</td>
</tr>
<tr>
<td>Show, Hide, Isolate, Review, Reset review:</td>
<td>Similar to <span>Model Browser</span> functions.</td>
</tr>
</tbody>
</table>
