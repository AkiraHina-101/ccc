# Dequations Panel

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help264.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `03f765c63d30e59d477c53ad9ec343712dbdcf9502b8a61dd62b990ed38b756e`. Record: `37d75acef8ce4a8e`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## Dequations Panel


Use the Dequations panel to create user-defined functions for responses and design properties.


Location: Analysis page > Optimization panel Note: Only available in the OptiStruct solver interface.


### Guidelines for Entering Equations


- Each dequation definition may consist of one or more equations, which are
                        separated by semicolons ( ; ). A semicolon must not follow the last
                        equation.
- The first equation must take the following form:

f ( x 1 , x 2 , ... x n ) = (some mathematical expression referencing all of the variables x 1 , x 2 , ... x n )
- Subsequent equations may reference the resultant variables of the previous
                        equations in the following manner: 

f 1 ( x 1 , x 2 , ... x n ) = (some mathematical expression referencing all of the variables x 1 , x 2 , ... x n )


f 2 = (some mathematical expression referencing f 1 )


f 3 = ...


...


f n = (some mathematical expression referencing f 1 , f 2 , f 3 , ... f n − 1 );
- Constants may be specified as integers or in a floating-point format. A
                        floating-point number can be in a format of either normal decimal-point
                        format (3.90) or scientific notation (2.0E-3.0).
- Only alphanumeric characters may be used in variable names. ( You may not
                        use underscores, monetary symbols, punctuation symbols, or mathematical
                        operators in variable names.)


### Panel Options


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Option</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td>dequation</td>
<td>Name for the dequation
                                    definition (max. 8 characters).</td>
</tr>
<tr>
<td>edit equation</td>
<td>Enter the function or
                                    functions. The functions must follow the guidelines listed in
                                        <a href="https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help264.htm#help264__help264_section_ubx_zgy_hdb">Guidelines for Entering Equations</a>.</td>
</tr>
</tbody>
</table>
### Command Buttons


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Button</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td>create</td>
<td>Create the dequation.</td>
</tr>
<tr>
<td>update</td>
<td>Update the dequation.</td>
</tr>
<tr>
<td>review</td>
<td>Review the dequation.</td>
</tr>
<tr>
<td>clear</td>
<td>Clear the selection.</td>
</tr>
<tr>
<td>prev</td>
<td>Move the previous page of equations.</td>
</tr>
<tr>
<td>next</td>
<td>Move to the next page of equations.</td>
</tr>
<tr>
<td>return</td>
<td>Exit the panel.</td>
</tr>
</tbody>
</table>
