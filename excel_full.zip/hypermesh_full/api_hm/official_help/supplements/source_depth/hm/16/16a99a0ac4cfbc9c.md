# XY Plotting

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/xy_plot/xy_plotting.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `c1164edceeefaec27741886e345b382ad2f7587f2d7cf21c1718c3a8ea00a7d1`. Record: `16a99a0ac4cfbc9c`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code

## Original topic body (structured)

## XY Plotting


Study relationships between data vectors in results files.


Information about xy plots is stored in plot collectors, which are referred to as plots. Plots maintain a list of pointers to curves that are to be displayed on the plot. The plot may contain any number of curves. There is no limit to the number of plot collectors that an HM database may contain.


Information about curves is stored in curve collectors, which are referred to as curves. To display a curve, you must assign the curve collector to a plot. A curve may appear on more than one plot at a time and there is no limit to the number of curves that an HM database may contain.


You can create standard plots or dual plots that show real/imaginary or phase/magnitude data.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### XY Plots Module


The XY Plots module is a group of panels that perform operations on plots and the curves displayed on those plots.


The XY Plots module can be accessed from the XY Plots menu.

**[Axis Labels Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help096.htm)**


Modify the x and y axes titles and labels. You can also change the color and font size used to display these entities.


**[Axis Scaling Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help098.htm)**


Modify the starting and ending values of the plot axes. You can set the values explicitly or implicitly by using the panel functions such as find curves, circle zoom, and zoom out.


**[Border Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help097.htm)**


Change the thickness and color of the border around the plot. You may also specify whether the border is displayed and the size of the margin between the border and the plot.


**[Curve Attribs Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help100.htm)**


Change the color, marker style (used to indicate the point location), thickness, and the line style (solid, dashed, and so on). You can apply a scaling factor to the original data points. You can also change the curve title that appears in the legend.


**[Edit Curves Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help183.htm)**


Creates and modifies the curves in the database. This panel allows you to read data vectors from files as well as perform advanced mathematical operations on curves.


**[Grid Attribs Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help094.htm)**


Change the color, line style, thickness of the grid lines, and the margin displayed around the grid lines.


**[Grid Labels Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help174.htm)**


Change the color, font, and number of significant places in the labels. Grid labels appear along the x and y axes in the plot (tick marks).


**[Integrate Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help102.htm)**


Calculates and displays the integral of a curve.


**[Legend Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help101.htm)**


Change the location and the font used to display the legend.


**[Plot Titles Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help095.htm)**


Change the plot title, subtitle, and label. In addition, you can change the color and font size used to display these entities.


**[Plots Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help099.htm)**


Create an xy plot and assign curves to the xy plot.


**[Query Curves Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help140.htm)**


Determine the coordinate values of points in a curve.


**[Read Curves Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help103.htm)**


Reads curves from an ASCII file.


**[Rename Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help092.htm)**


Eename curves.


**[Results Curves Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help109.htm)**


Generates a curve from the currently-selected results file.


**[Simple Math Panel](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help148.htm)**


Perform simple mathematical calculations on a curve.


In addition, you can use the Curve Editor to view and modify curves already defined in your HyperMesh model.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Create XY Plots


Create an entirely new plot or a new plot based on default values from an existing plot.


If you have complex data, you can create dual plots to display real/imaginary or phase/magnitude curve data. You can also select the curves that are to be displayed on the plot.


Plot attributes include the title, subtitle, and labels, and also the margin and border around the xy plot. These attributes can be adjusted before or after you add curves to the plot.


1. In the Model Browser, right-click and select Create > Plot from the context menu.


A new curve opens in the Entity Editor.
2. In the Name field, enter a name for the plot.
3. Define plot attributes by modifying their corresponding fields.


Plot attributes include a title, subtitle, axis title, and labels, and so on.
4. Select curves.


  1. Click Curves > 0 Curves.
  2. Click the curves entity selector.
  3. In the Select Curves dialog, select the curves to
                            display.
  4. Click OK.


Tip: When several plots are contained within a database, you can modify one of the values on all of the plots. For example, you may wish to change the axis titles so that they are all the same. You can simultaneously modify one plot so that it has the desired values, and then apply those modifications to the other plots, or a subset of the plots. When you modify xy plots using the panels of the xy plots module, the plot = field allows you to select one plot and the plots entity selector allows you to select multiple plots.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Manage XY Plot Windows


Every xy plot is placed within a window to help you to control multiple plots by resizing and moving plots around the screen.


1. Press W to open the Window panel.
2. Modify XY plot windows.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Create Curves on XY Plots


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

#### Create Curves Manually


Create and define new curves.


1. In the Model Browser, right-click and select Create > Curve from the context menu.


The Curve editor dialog opens.
2. Create curve.


  1. Click New.
  2. In the panel area, Name field, enter a name for
                            the curve.
  3. Click proceed.
3. In the X and Y table, enter curves X and Y coordinates.
4. To display the curve in the graph area, in the Curve List, right-click on the
                    curve and select Display only from the context menu.
5. Define curve attributes such as the title, the thickness of the curve line, the
                    style of the line used to draw the curve, the color of the line, and the marker
                    style used to identify the curve.


Edit a curve by right-clicking on it in the Model Browser and selecting Edit from the context menu. In the Curve editor dialog, edit the curve and click Update.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

#### Read Curves from ASCII Files


Create curves by reading in an xy data set from an ASCII file.


Each curve in the file is defined in a block format. The block begins with the statement,
        XYDATA. After XYDATA, the title assigned to the curve, which is displayed in the legend,
        follows on the same line. Point data follows with a set of (x, y) data pairs on each line.
        The block ends with an ENDDATA statement. In the above example, there are two blocks of
        data, which define two curves.


```text
XYDATA,TITLE
X1, Y1
X2, Y2
.
.
.
ENDDATA
XYDATA,TITLE
X1, Y1
X2, Y2
.
.
.
ENDDATA
```


Figure 1. Format of the input file


1. From the Post page, click XY Plots.
2. Click read curves.
3. Click plot= and select the plot on which to display the new
          curve.
4. Double-click file and select the file that contains the xy
          data.
5. Click input.


The specified curve data is loaded, and a new curve is created from it.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

#### Create Analysis Based Curves


Create analysis-based curves by extracting data from an HyperMesh binary results file.


When you create an analysis curve, you select entities of interest in your model, and then select a data type for the x axis data points and a data type for the y axis data points. After this information has been supplied, the required data is read from the results file and generates the appropriate curve.


This function is useful after running a model because it allows you to display the data in a two-dimensional format as an xy plot. Once the curve is created, you can integrate the curve and inspect points.


1. From the Post page, click XY Plots.
2. Click results curves.
3. Select the plot on which to display the new curve.


  - Choose plot= to select an existing plot.
  - Choose create new plot to create an entirely new
                        plot.
4. Select data.


If data is in vector format, you can extract the components or the magnitude of the vector. Click the switch after x data type/y data type to change the data that is extracted from the database.


  1. Click x data type and select the type of data
                            that should appear on the x axis.
  2. Click y data type to select the type of data
                            that should appear on the y axis.
5. Use the entity selector to select nodes or elements to include on the
                    curve.
6. Define the simulation range.


  1. In the start with field, enter the first simulation to be used.
  2. In the end with field, enter the last simulation to be used.
7. Click create.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

#### Create Curves using Simple Math Operators


Create curves using simple math operators.


You can combine two curves, transform a curve, or export the curve. For every operation, you can specify that the x or y values of the curve remain fixed.


You can also apply external filters to curves. Examples of external filters are in the filters subdirectory that is provided when this option is selected. Essentially, filters exchange data with HyperMesh, using the standard HyperMesh curve data file format.


1. From the Post page, click XY Plots.
2. Click simple math.
3. Click plot= and select the plot to edit.
4. Select curves.


For example, when subtracting, the second curve is subtracted from the first curve.


  1. Select the initial curve by clicking 1st curve=
                            and selecting a curve.
  2. Select the secondary curve by clicking 2nd
                                curve= and selecting a curve.
5. Select the mathematical operation to perform.


The available operations depend on the number of curves selected.
6. Specify which values of the curve should remain fixed during the
                    operation.


Only the values not chosen here are affected by the operation, for example, multiplied or subtracted.


  - Choose x-fixed to keep X values fixed.
  - Choose y-fixed to Y values fixed.
7. In the factor field, enter the amount, in model units, to translate or
                    scale.


Restriction: Only available when the operation is translate or scale.
8. In the filter field, specify a file.


Restriction: Only available when the operation is external.
9. In the params field, enter any necessary parameters.


Restriction: Only available when the operation is external.
10. Click execute.


The selected mathematical operations are performed on the selected curves.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

#### Create Curves from Files or Math Expressions


Create new curves using either a data vector in a data file or a math expression.


For example, the data source for the x vector could be a file, and the data source for the y vector could be a math expression.


The x and y fields displays the data sources for the x and y vectors once they are selected.


1. From the Post page, click XY Plots.
2. Click edit curves.
3. Select the create subpanel.
4. Click plot= and select the plot on which to create the
          curve.


An untitled plot is created if no plot currently exists.
5. Define data source.


<table>
<col/><col/><thead><tr><th>To define data source using</th>
<th>Do this</th></tr></thead>
<tbody><tr>
<th>Source file</th>
<td>
<ol>
<li>Select <span>file</span>.</li>
<li>In the File field, navigate to the file that contains curve data.</li>
<li>Click <span>type=</span> and select a data type.</li>
<li>Click <span>req=</span> and select a request set.</li>
<li>Click <span>comp=</span> and select a component.</li>
</ol>
<div><span>Tip:</span> For type, req, and comp, click <span>+</span> or
                  <span>-</span> to scroll through the list of available options.</div>
</td>
</tr>
<tr>
<th>Math expressions</th>
<td><ol>
<li>Select <span>math</span>.</li>
</ol>
The math expression must evaluate to an array.</td>
</tr>
</tbody></table>
6. Click create.


Use the modify subpanel to edit an existing curve.


To access the x and y vectors of a curve, you must indicate the curve number and the x or y
        vector, in the format, c#.vector. For example:

**c1.x**


Reference the x vector of curve 1.


**c1.y**


Reference the y vector of curve 1.


If you try to reference a curve that has not been created with this panel, you will receive the message, "This curve has no defined source. Convert to math curve?" Respond by clicking Yes or No. If the selected curve has too many points, it cannot be converted.
