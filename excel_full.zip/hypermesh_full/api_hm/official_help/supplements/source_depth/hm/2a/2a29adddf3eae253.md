# Nastran to LS-DYNA Conversion Tool

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/tool_nastran_to_dyna_conversion_r.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `dca21e4c59ace5107c91c7bdb9c073dc3509f951b16002e6a55655802856850f`. Record: `2a29adddf3eae253`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## Nastran to LS-DYNA Conversion Tool


Nastran that can be converted to LS-DYNA.


- PSHELL
- PSOLID
- PBAR
- PBARL
- PBEAM
- PBEAML


### PSHELL to *Section_Shell Conversion


A *Part card will be associated to the pshell component.

- A new LS-DYNA property *section_shell will be
                        created and assigned to the *Part card.
- The original material ID will be assigned to the *Part.
- The Nastran thickness will be assigned to the T1
                        *section_shell card.
- The Nastran NSM value will be assigned to the
                        MAREA LS-DYNA entry.


### PSOLID to *Section_Solid Conversion


A *Part card will be associated to the component.

- A new LS-DYNA property *section_solid will be
                        created and assigned to the corresponding *Part card.
- The original material ID will be assigned to the *Part.


### PBAR to *Section_Beam Conversion


HyperMesh will create different components so that the bar
                elements using a common Nastran property will be moved
                into a single component.

- A *Part card will be associated to this component.
- A new LS-DYNA property *section_beam with ELFORM 2
                        will be created and assigned to the *Part card.
- The original material ID will be assigned to the *Part.
- The Nastran A field will be mapped to the
                            LS-DYNA AREA entry; the Nastran Inertia I1 I2 and J will be assigned to the
                        corresponding LS-DYNA values Itt Iss and Irr.


### PBARL (ROD, TUBE, BAR types) to *Section_Beam Conversion


HyperMesh will create different components so that the bar
                elements using a common Nastran property will be moved
                into a single component.

- A *Part card will be associated to this component.
- A new LS-DYNA property *section_beam with ELFORM 1
                        will be created and assigned to the *Part card.
- The original material ID will be assigned to the *Part.
- The nonstructural mass, NSM, will be converted between the solvers.
- For the Pbarl-ROD type, the Nastran entry, DIM1,
                        will be moved to the LS-DYNA Ts1 and Ts2. In the
                        *section_beam card, the CST entry will be set to value 1.
- For the Pbarl-TUBE type, the Nastran entry DIM1
                        will be moved to the LS-DYNA Ts1 and Ts2, DIM2 will
                        be assigned to the LS-DYNA entries TT1 and TT2. In
                        the *section_beam card, the CST entry will be set to the value 1.
- For the Pbarl-BAR type only, the Nastran entry
                        DIM1 will be moved to the LS-DYNA Ts1 and Ts2. In
                        the *section_beam card, the CST entry will be set to value 0.


### PBEAM to *Section_Beam Conversion


HyperMesh will create different components so that the beam
                elements using a common Nastran property will be moved
                into a single component.

- A *Part card will be associated to this component.
- A new LS-DYNA property *section_beam with ELFORM 2
                        will be created and assigned to the *Part card.
- The original material ID will be assigned to the *Part.
- The Nastran A field will be mapped to the
                            LS-DYNA AREA entry; the Nastran Inertia I1 I2 and J will be assigned to the
                        corresponding LS-DYNA values Itt Iss and Irr. 

Note: LS-DYNA does not provide a field to store the I12 value; if the I12 value is available, the conversion will not occur.


### PBEAML to *Section_Beam Conversion


The conversion ignores the case of tapered Nastran beam with
                intermediate cross section.

- HyperMesh will create different components so that the
                        beam elements using a common Nastran property
                        will be moved into a single component.
- A *Part card will be associated to the component.
- A new LS-DYNA property *section_beam with ELFORM 1
                        will be created and assigned to the *Part card.
- The original material ID will be assigned to the *Part.
- The nonstructural mass NSM will be converted between the solvers.
- For the Pbeaml-ROD type, the Nastran entry
                        DIM1(A) will be moved to the LS-DYNA Ts1, the
                        DIM1(B) will be moved into Ts2. In the *Section_Beam card the CST entry will
                        be set to value 1.
- For the Pbeaml-TUBE type, the Nastran entry
                        DIM1(A) will be moved to the LS-DYNA Ts1, the
                        DIM1(B) will be moved into Ts2. The Nastran
                        entry DIM2(A) will be moved to the LS-DYNA TT1, the
                        DIM2(B) will be moved into TT2. In the *section_beam card the CST entry will
                        be set to value 1.
- For the Pbeaml-BAR type, the Nastran entry
                        DIM1(A) will be moved to the LS-DYNA TT1 the
                        DIM1(B) will be moved into TT2. The Nastran
                        entry DIM2(A) will be moved to the LS-DYNA TS1, the
                        DIM2(B) will be moved into TS2. In the *section_beam card the CST entry will
                        be set to value 0.
