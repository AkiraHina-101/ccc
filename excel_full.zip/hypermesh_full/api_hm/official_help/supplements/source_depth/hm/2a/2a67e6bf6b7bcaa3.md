# Composites

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/composites/composites.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `082b31f5bb6617032fa2be319019b0c0664caee9f22b8c5db565fb68205cbd35`. Record: `2a67e6bf6b7bcaa3`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## Composites


HyperMesh composites modeling.


HyperMesh provides a full suite of tools and entities to generate models of laminated composite structures. The workflow to generate these models places an emphasis on a modeling methodology which is consistent with the manufacturing process. This section outlines a general modeling methodology and workflow which should be followed for typical models.
