# Load Step: CRADIATE

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/user_interface/utility_menu_abaqus_load_step_cradiate_r.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `d6b76d5b0cd5add2b2769b6e00d44c478226d0e62252bff8ed845f1f03a6b0fd`. Record: `1aeac923cba663bd`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code

## Original topic body (structured)

## Load Step: CRADIATE


In the CRADIATE dialog, define the *CRADIATE cards on node sets.


To open this dialog from the Load Step dialog, select CRADIATE from the tree and a load collector from the Load collector table.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\?path2project-uri ../../?path2rootmap-uri ../../?

### Load Step: CRADIATE: Define Tab


In the Define tab, define a *CRADIATE card on node sets only.


*CRADIATE on individual nodes is not supported.


Use the Define CRADIATE on: Node sets option to define *CRADIATE on node sets. Note: Loads created on sets are not graphically displayed. Therefore, when you review a load collector in the Step Manager, only loads created on individual entities are highlighted. For loads defined on sets, the underlying nodes or elements are highlighted.


This dialog has a node sets drop down menu containing a list of the existing node
                sets. It also has a data line input table with the following columns:


<table><caption><span><span>Table 1. </span></span></caption><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Column</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td>Nodeset</td>
<td>The name of the node sets. Node sets are added or removed
                                    using → or ←, respectively.</td>
</tr>
<tr>
<td>Area</td>
<td>The area associated with the nodes.</td>
</tr>
<tr>
<td>Sink temp</td>
<td>Ambient reference temperature.</td>
</tr>
<tr>
<td>Emissivity</td>
<td>Surface emissivity.</td>
</tr>
</tbody>
</table>
For tips on entering information and navigating in the Define tab, see Step Manager Tab Environment.


The Define CRADIATE on: Node sets option has the following buttons:


<table><caption><span><span>Table 2. </span></span></caption><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Button</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td>Review/Reset Set</td>
<td>Reviews the selected node sets by highlighting them in the
                                        <span>HyperMesh</span> graphics. Right-click
                                        <span>Review</span> to clear the review
                                    selections.</td>
</tr>
<tr>
<td>Create/Edit Set..</td>
<td>Opens the Entity Sets panel in <span>HyperMesh</span>.
                                    When you finish creating/editing the set, click
                                        <span>return</span>. The <span>Step
                                        Manager</span> is updated with the new set appearing in
                                    the node set list.</td>
</tr>
<tr>
<td>→</td>
<td>Add the selected node set from the drop-down menu to the data
                                    line table on the right.</td>
</tr>
<tr>
<td>←</td>
<td>Delete the selected node set from the data line
                                    table.</td>
</tr>
<tr>
<td>Review</td>
<td>Reviews the selected node set in the data line table.
                                    Right-click <span>Review</span> to clear the
                                    highlighted selections.</td>
</tr>
<tr>
<td>Update</td>
<td>Updates the <span>HyperMesh</span> database with the
                                    data lines defined in the table. By default, <span>HyperMesh</span> does not create a display for loads
                                    defined with sets.</td>
</tr>
</tbody>
</table>
workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\?path2project-uri ../../?path2rootmap-uri ../../?

### Load Step: CRADIATE: Delete Tab


In the Delete tab, delete *CRADIATE and other loads.


There are three deletion options:


<table><caption><span><span>Table 3. </span></span></caption><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Option</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td>All loads in current collector</td>
<td>The Delete button deletes all the loads from the current load
                                    collector.</td>
</tr>
<tr>
<td>All 'CFILM' in current collector</td>
<td>The Delete button deletes only *CRADIATE loads from the
                                    current load collector.</td>
</tr>
<tr>
<td>By selection</td>
<td>The Pick Loads button opens the <span>HyperMesh</span>
                                    load selector panel. Pick the loads you want to delete and click
                                        <span>proceed</span>.<p>The corresponding Reset
                                        button resets the selected loads.</p>
<p>The Delete button
                                        deletes the selected loads.</p>
</td>
</tr>
</tbody>
</table>
workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\?path2project-uri ../../?path2rootmap-uri ../../?

### Load Step: CRADIATE: Parameter Tab


In the Parameter tab, define optional parameters for the *CRADIATE card.


The supported parameters include: Amplitude curve, OP, and Region Type.


Click Update to activate the optional parameter selection in the HyperMesh database.
