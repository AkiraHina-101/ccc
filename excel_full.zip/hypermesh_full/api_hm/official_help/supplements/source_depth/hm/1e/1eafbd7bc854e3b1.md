# Supported Solver Cards

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/composites/composites_supported_solver_cards_plies_r.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `2ca32955a6cf6fbc9cb3466c74a853a2fc839511390bc26fd2fde2bf3268f5a2`. Record: `1eafbd7bc854e3b1`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## Supported Solver Cards


Ply entity solver card support.


The following table defines solver cards supported by ply entity.


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Solver</th>
<th>Card</th>
</tr>
</thead>
<tbody>
<tr>
<td><span>Abaqus</span></td>
<td>None. Ply entity names become ply names of the composite
                                    properties SHELL SECTION and SHELL GENERAL SECTION, if used in a
                                    laminate entity and realized into a zone-based model.</td>
</tr>
<tr>
<td><span>ANSYS</span></td>
<td>None</td>
</tr>
<tr>
<td><span>LS-DYNA</span></td>
<td>None</td>
</tr>
<tr>
<td><span>Nastran</span></td>
<td>None. Ply entity IDs become global ply ID in the PCOMPG
                                    property card, if used in a laminate entity and realized into a
                                    zone-based model.</td>
</tr>
<tr>
<td><span>OptiStruct</span></td>
<td>PLY</td>
</tr>
<tr>
<td><span>Radioss</span></td>
<td>Property: /PROP/PLY (TYPE19) and Keyword: /PLY</td>
</tr>
</tbody>
</table>
