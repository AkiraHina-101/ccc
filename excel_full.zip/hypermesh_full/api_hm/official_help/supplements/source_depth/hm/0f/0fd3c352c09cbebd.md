# Intersect

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/mvd/check_perform_intersect_t.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `111c557885680234f39ce3a9d17c86c248227007eba5fc848e7a494fec532208`. Record: `0fd3c352c09cbebd`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source images linked but not mirrored; textual record is not a complete copy of graphical instructions
- Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code

## Original topic body (structured)

## Intersect


Intersect checks provide information in Power Point reports on all the inter-part intersection/overlapping in the CAD parts.


Once the model is done with the Intersection check, the tool locates the point of intersection as a cross-hair and summarizes all the intersections found in the PowerPoint report.


1. In the Comparison Browser, right-click and select Check > Intersect from the context menu.


The Intersection dialog opens.
2. Select Import Type for Base Model.


  - XML (PLMXML or UDMXML)
  - Assembly (CAD assembly files: UG Assembly, CATProduct, JT
                        Assembly…)
  - CAD (Refer Config / CAD files)
  - FE (nastran, pam, radioss, abaqus, optistruct, hyperMesh)
  - Multiple Assembly (Multiple CAD assembly files)
  - Spot Files (Not applicable)
  - FE Files (direct file selection)
  - Mixed Import (folder contains CAD and FE files)
3. Select a datatype.


Respective data types will be listed.
4. Click the folder icon and navigate to the model to import (Folder/File
                    selections).


The folder or the selected location must contain the spot weld file. The spot weld file type must be set in the config file.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/mvd_comparison_cmp_chk_user.png)


Figure 1.
5. In the Allowance field, enter a value between 0.1 to 5mm to display unmatched
                    entities.
6. In the Report Path field, navigate to the directory where the reports generated
                    by the Model Verification tool will be stored.
7. In the Project Name field, enter a name for the project.
8. In the Slide Number field, enter a starting number of the slides to use in the
                    PowerPoint report.
9. Choose a method for running the model.


  - Choose Interactive to run the model in the same
                            HyperMesh session.
  - Choose Background to launch a new HyperMesh session in batch mode.
10. The Processes drop-down list becomes active when you select the Background
                    option and it also depends on the processor.


The Model Verification tool launches as many hmbatch processes selected.


  - Choose Check to execute only the comparison
                        without the report generation.
  - Choose Report to generate only the Reports (Check
                        executed previously).
  - Choose Both to perform the comparison report
                        generation sequentially.
11. Click Run to execute the function.
12. Click Stop to stop the operation.


This closes front and background HyperMesh sessions.
13. Click View Report to display the Summary PowerPoint
                    report.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/mvd_intersection_ppt_summary.png)


Figure 2. PowerPoint Summary . (Stored in Report Path)


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/mvd_intersection_ppt_detailed_report.png)


Figure 3. PowerPoint Detailed Report . (Stored in Report Path)


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Output


Overview of the PowerPoint report generated from the Intersection check.


A PowerPoint report is separated into several sections.

**Report Header**


Project name, assembly name, and slide number.


**Assembly Picture**


Image of the components that have intersection issues.


**H3D Image**


Section can be viewed in the HyperView Player, and shows the CAD model with the intersection marked with Cross Hairs.


**Issue Details**


Details of components which have intersection issues.


**User Review**


Add additional information when exchanging information with designers/engineers.


**Additional Info**


Occurrences of the issue shown in the current slide. The number of instances show the number of occurrences of the issue.
