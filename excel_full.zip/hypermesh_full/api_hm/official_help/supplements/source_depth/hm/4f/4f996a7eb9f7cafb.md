# Temporary Nodes

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/model_setup/temporary_nodes.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `402bfa2cedd76960334fed1df4c6f804ffc158302b8ab2bbe7fe645038f16adb`. Record: `4f996a7eb9f7cafb`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## Temporary Nodes


A temporary node list retains nodes that are not attached to an element, protecting them from automatic removal by the database management.


Nodes are not protected from automatic removal for panels that automatically clear all temporary nodes, such as edges, faces, edit elements. There may be times when you wish to use an unattached node later in the modeling process.


The Temp Nodes panel allows you to modify the temporary node list. In the Temp Nodes panel,
        there are three functions: 

**add**


Adds selected individual nodes to the temporary node list.


**clear**


Removes selected individual nodes from the temporary node list.


**clear all**


Removes all the temporary nodes from the database.
