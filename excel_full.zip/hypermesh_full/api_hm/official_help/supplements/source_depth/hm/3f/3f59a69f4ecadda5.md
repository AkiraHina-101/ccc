# Solver Attribute Mapping

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/conversion_between_solvers/attribute_mapping_r.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `928d4ffde3a5c351b83bb8ad09e9b46a33ea2ebff5c4eca47cd17f1200e7828c`. Record: `3f59a69f4ecadda5`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## Solver Attribute Mapping


Automatic solver attribute mapping is supported for components, properties and materials when switching between solver interfaces.


### Mapped Attributes


Mapped attributes include the card image and engineering
                attributes, such as property integration points and thickness, or a material's
                Young's Modulus and density. Supported solver cards include:

- Abaqus
- LS-DYNA
- Nastran
- OptiStruct
- Permas
- Radioss
- Samcef


You can configure solver-to-solver mappings via the configuration file located in the installation directory: <ROOT\hwdesktop\hm\scripts\SolverConvertInterfaces\UnifiedConversion>.


An example of Abaqus to OptiStruct mapping
                is:

```text
*PropertyConversion
"*SOLID SECTION"......................"PSOLID"
"*SOLID SECTION, COMPOSITE"..........."PSOLID"
"*SHELL SECTION"......................"PSHELL".......thickness, integrationpoint
"*SHELL SECTION, COMPOSITE"..........."PCOMP"
"*SHELL GENERAL SECTION".............."PSHELL".......thickness
"*SHELL GENERAL SECTION,COMPOSITE"...."PCOMPG"
"*SHELL GENERAL SECTION,DIRECT"......."PSHELL".......thickness
"*SHELL GENERAL SECTION,USER"........."PSHELL".......thickness
"*MEMBRANE SECTION"..................."PSHELL".......thickness
"*GASKET SECTION"....................."PGASK"
"*BEAM SECTION"......................."PBEAM"
"*BEAM GENERAL SECTION"..............."PBEAM"
"*CONNECTOR SECTION".................."PBUSH"
"*SPRING"............................."PBUSH"
"*JOINT".............................."PBUSH"
"*FRICTION"..........................."PCONT"
"*SURFACE INTERACTION"................"PCONT"
"*GAP"................................"PGAP"
*END
```
