# Find Connectivity

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/model_setup/find_connectivity.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `d758c9a5f759630842f8057f875fe8b76c59acbf27d7ff3e35d045f2cc376fe2`. Record: `0be3436dddd55fbb`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source images linked but not mirrored; textual record is not a complete copy of graphical instructions
- Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code

## Original topic body (structured)

## Find Connectivity


Check the connectivity between two or more components.


Certain types of connections can be included or excluded while checking for connectivity. Restriction: Only available in the LS-DYNA and Radioss user profiles.


1. From the menu bar, click Tools > Find Connectivity.


The Find Connectivity Browser opens.
2. Invoke the Find Connectivity controller by right-clicking in the browser and selecting Find
                        Connectivity from the context menu.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/find_connectivity_invoke_controller.png)


Figure 1.
3. In the Entity Editor, enable the type(s) of
                    connectivity to include in the check. 


By default, all types of connectivity are enabled except Connectors.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/entity_editor_recursive.png)


Figure 2.
4. Use the Select Entities selector to select two or more components to check the
                    connectivity between.


Connectivity check works on all the selected components regardless of its
                    display state. Connectivity due to mass elements are completely excluded when
                    checking connectivity.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/find_connectivity_select_components.png)


Figure 3.
5. Click Check.


If two or more parts are connected, the number of connected parts are displayed in the browser. Expand the folders to see individual components. If the parts are free, the free part is displayed separately.


Results are displayed in the browser.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/find_connectivity_check_results.png)


Figure 4.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Connectivity Types


#### Radioss


**Recursive**


If checked, will isolate and find recursive connectivity.


**Physical connectivity**


Checks for node to node connectivity (for 1D, 2D and 3D).


**RBE2**


Checks for RBE2 connectivity.


**Rigids**


Checks for RBODY connectivity.


**Interface2**


Checks for contacts with INTER/TYPE2.


**Connectors**


Checks for FE realized connections with connectors.


**Rigid Links**


Checks for RLINK connectivity.


**RBE3**


Checks for RBE32 connectivity.


**Joints**


Checks for CYLJOINT connectivity.


#### LS-DYNA


**Physical connectivity**


Checks for node to node connectivity (for 1D, 2D and 3D).


**Constrained Extra Nodes**


Checks for connections using constrained extra nodes and extra noded joints.

- *CONSTRAINED_EXTRA_NODES


**Constrained Rigid Bodies**


Checks for connections using constrained rigid bodies.

- *CONSTRAINED_RIGID_BODIES


**Constrained Groups**


- *CONSTRAINED_TIE-BREAK
- *CONSTRAINED_TIED_NODES_FAILURE


**Contact Groups**


- *CONTACT_SPOTWELD


NodesToSurface (only following types)

- *CONTACT_TIED_NODES_TO_SURFACE
- *CONTACT_TIEBREAK_NODES_TO_SURFACE
- *CONTACT_TIED_SHELL_EDGE_TO_SURFACE


SurfaceToSurface (only following types)

- *CONTACT_TIEBREAK_SURFACE_TO_SURFACE
- *CONTACT_TIED_SURFACE_TO_SURFACE


SlidingOnly

- *CONTACT_SLIDING_ONLY


**Connectors**


Checks for FE realized connections with connectors.


**Rigid Links**


- *CONSTRAINED_NODAL_RIGID_BODY
- *CONSTRAINED_NODE_SET_ID
- *CONSTRAINED_GENERALIZED_WELD
- *CONSTRAINED_SHELL_TO_SOLID


**Welds**


- *CONSTRAINED_SPOTWELD


**RBE3**


- *CONSTRAINED_INTERPOLATION


**Joints**


Checks for connections with Joints


**Slipring and Retractor**


Checks for connections with sliprings and Retractor

- *ELEMENT_SEATBELT_SLIPRING
- *ELEMENT_SEATBELT_RETRACTOR
