# OptiStruct

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/user_interface/model_checker_optistruct_r.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `7a32d4315ea08db2bf6783ca84320a95a9c60cf0e8994be3065a1a888bac8595`. Record: `2c97fecf0d6e1aec`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## OptiStruct


### Errors


<table><colgroup><col/><col/><col/><col/><col/></colgroup><thead>
<tr>
<th>Name</th>
<th>Description</th>
<th>Result</th>
<th>Auto correction action</th>
<th>Manual correction action</th>
</tr>
</thead>
<tbody>
<tr>
<td>Material ID exceeds 8 characters</td>
<td><span>HyperMesh</span> does not write out more than eight
                                characters for IDs, so if you have more <span>HyperMesh</span>
                                will write out ***, which fails the solver. This check is disabled
                                when using a long format template.</td>
<td>Lists the failing materials.</td>
<td>Not supported.</td>
<td>Opens the Renumber panel</td>
</tr>
<tr>
<td>Property is missing material</td>
<td>Checks for properties without a material reference.</td>
<td>Lists the failing properties.</td>
<td>Not supported.</td>
<td>Opens the Properties panel.</td>
</tr>
<tr>
<td>Property ID exceeds 8 characters</td>
<td><span>HyperMesh</span> does not write out more than eight
                                characters for IDs, so if you have more <span>HyperMesh</span>
                                will write out ***, which fails the solver. This check is disabled
                                when using a long format template.</td>
<td>Lists the failing properties.</td>
<td>Not supported.</td>
<td>Opens the Renumber panel</td>
</tr>
<tr>
<td>Property with zero cross section area</td>
<td>Checks if the area of PBEAM, PBAR and PROD properties are less
                                than or equal to zero.</td>
<td>Lists the failing properties.</td>
<td>Not supported.</td>
<td>Opens the Properties panel.</td>
</tr>
<tr>
<td>Component with solids and shells</td>
<td>Checks if a component consists of both solid and shell
                                elements.</td>
<td>Lists the failing components.</td>
<td>Not supported.</td>
<td>Opens the Organize panel.</td>
</tr>
<tr>
<td>Node ID exceeds 8 character</td>
<td><span>HyperMesh</span> does not write out more than eight
                                characters for IDs, so if you have more <span>HyperMesh</span>
                                will write out ***, which fails the solver. This check is disabled
                                when using a long format template.</td>
<td>Lists the failing nodes.</td>
<td>Not supported.</td>
<td>Opens the Renumber panel.</td>
</tr>
<tr>
<td>Element ID exceeds 8 characters</td>
<td><span>HyperMesh</span> does not write out more than eight
                                characters for IDs, so if you have more <span>HyperMesh</span>
                                will write out ***, which fails the solver. This check is disabled
                                when using a long format template.</td>
<td>Lists the failing elements.</td>
<td>Not supported.</td>
<td>Opens the Renumber panel.</td>
</tr>
<tr>
<td>Free 1D elements</td>
<td>Checks for 1D elements that have one or more connection missing.
                                This check does not include RBE2 or RBE3 elements.</td>
<td>Lists the failing elements.</td>
<td>Deletes the failing 1D elements.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>RBE2 with constrained dependent nodes</td>
<td>Checks for RBE2 with constraints on dependent nodes. </td>
<td>Lists the failing elements.</td>
<td>Not supported.</td>
<td>Opens the Rigids panel.</td>
</tr>
<tr>
<td>Free Rigid elements</td>
<td>Checks for RBE2 elements that have one or more connection
                                missing, typically a leg that is missing a connection.</td>
<td>Lists the failing elements.</td>
<td>Deletes the free arms of the Rigid.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Free RBE3 elements</td>
<td>Checks for RBE3 elements that have one or more connection
                                missing, typically a leg that is missing a connection or an
                                independent node that is not connected to structure.</td>
<td>Lists the failing elements.</td>
<td>Deletes the free arms of RBE3.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>RBE3 elements are collinear</td>
<td>Checks if the dependent and independent nodes of an RBE3 element
                                are collinear.</td>
<td>Lists the failing elements.</td>
<td>Deletes the failing RBE3 elements.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>RBE3 dof connected to solid</td>
<td>Checks for rotational DOFs on independent nodes of an RBE3
                                connected to a solid element.</td>
<td>Lists the failing elements.</td>
<td>Removes rotational DOFs from affected independent grids of
                                failing RBE3 elements.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Zero-length CBUSH without CID</td>
<td>Checks if the CBUSH spring element of zero length has the element
                                coordinate system, CID defined.</td>
<td>Lists the failing elements.</td>
<td>Not supported.</td>
<td>Opens the Springs panel.</td>
</tr>
<tr>
<td>Elements have a dependency</td>
<td>Checks for rigid elements that share dependent nodes with other
                                rigid elements.</td>
<td>Lists the failing elements.</td>
<td>Deletes the failing rigid elements.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Element has rigid loops</td>
<td>Checks for rigid elements that form a closed loop; where the
                                dependent node of one rigid serves as independent node of the next
                                rigid in the loop.</td>
<td>Lists the failing elements.</td>
<td>Deletes the failing rigid elements.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Duplicate 1D Elements</td>
<td>Checks if any 1D elements share the same nodes in the same
                                order.</td>
<td>Lists the duplicate 1D elements.</td>
<td>Deletes the failing elements.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Duplicate 2D Elements</td>
<td>Checks if any 2D elements share the same nodes in the same
                                order.</td>
<td>Lists the duplicate 2D elements.</td>
<td>Deletes the failing elements.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Duplicate 3D Elements</td>
<td>Checks if any 3D elements share the same nodes in the same
                                order.</td>
<td>Lists the duplicate 3D elements.</td>
<td>Deletes the failing elements.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>NSM field not defined</td>
<td>Checks for invalid or missing entries on NSMADD loadcols.</td>
<td>Lists the failing loadcols.</td>
<td>Not supported.</td>
<td>Opens the Loadcols panel.</td>
</tr>
<tr>
<td>MPC with free independent nodes</td>
<td>Checks for MPC equations with free independent nodes.</td>
<td>Lists the failing equations.</td>
<td>Updates the MPC by removing the free independent node.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Node sets as SSID in CONTACT</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>Empty Rigidbodies</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>Invalid inertia</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>Missing reference node or COG</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>Set referenced in multiple rigid body</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>Empty Rigidwalls</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>G0 not defined</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>Length MM1 is null</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>Length MM2 is null</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>No data to handle support</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>Node_id common in RWALL</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>RWALL Type SPHER or CYL and Diameter = 0</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
</tbody>
</table>
### Warnings


<table><colgroup><col/><col/><col/><col/><col/></colgroup><thead>
<tr>
<th>Name</th>
<th>Description</th>
<th>Result</th>
<th>Auto correction action</th>
<th>Manual correction action</th>
</tr>
</thead>
<tbody>
<tr>
<td>Unused materials</td>
<td>Checks for any materials that are not referenced by a
                                property.</td>
<td>Lists the failing materials.</td>
<td>Deletes unused materials.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Material E is not defined</td>
<td>Checks if E of MAT1, MAT8 or MAT9ORT is less than or equal to
                                zero.</td>
<td>Lists the failing materials.</td>
<td>Not supported.</td>
<td>Opens the Materials panel.</td>
</tr>
<tr>
<td>Material Rho is not defined</td>
<td>Checks if Rho of MAT1, MAT2,MAT4, MAT5, MAT8, MAT9,MAT9ORT and
                                MAT10 is less than or equal to zero.</td>
<td>Lists the failing materials.</td>
<td>Not supported.</td>
<td>Opens the Materials panel.</td>
</tr>
<tr>
<td>Material Nu is zero</td>
<td>Checks if Nu of MAT1, MAT8 and MAT9ORT is equal to zero.</td>
<td>Lists the failing materials.</td>
<td>Not supported.</td>
<td>Opens the Materials panel.</td>
</tr>
<tr>
<td>Material is missing a card image</td>
<td>Checks for defined materials with no card image.</td>
<td>Lists the failing materials.</td>
<td>Not supported.</td>
<td>Opens the Materials panel.</td>
</tr>
<tr>
<td>Unused properties</td>
<td>Checks for properties that are not assigned to a component or
                                element.</td>
<td>Lists the failing properties.</td>
<td>Deletes unused properties.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Property is missing a card image</td>
<td>Checks for defined properties with no card image.</td>
<td>Lists the failing properties.</td>
<td>Not supported.</td>
<td>Opens the Properties panel.</td>
</tr>
<tr>
<td>PSHELL thickness is not defined</td>
<td>Checks if the property PSHELL thickness is less than or equal to
                                zero.</td>
<td>Lists the failing properties.</td>
<td>Not supported.</td>
<td>Opens the Properties panel.</td>
</tr>
<tr>
<td>PCOMP thickness is not defined</td>
<td>Checks if the first thickness value of Property PCOMP array is
                                less than or equal to zero. The first thickness value is
                                mandatory.</td>
<td>Lists the failing properties.</td>
<td>Not supported.</td>
<td>Opens the Properties panel.</td>
</tr>
<tr>
<td>1D Prop beamsection mismatch</td>
<td>Checks if the 1D property and the beam section attached to it
                                have the same area and area moments of inertia. A difference greater
                                than 0.01 will fail the check.</td>
<td>Lists the failing properties.</td>
<td>Disassociates the beam section from the 1D property.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Empty components</td>
<td>Checks for components that do not contain elements.</td>
<td>Lists the failing components.</td>
<td>Deletes the empty components.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Empty assemblies</td>
<td>Checks if assemblies are empty.</td>
<td>Lists the empty assemblies.</td>
<td>Deletes the empty assemblies.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Empty sets</td>
<td>Checks if sets are empty.</td>
<td>Lists the empty sets.</td>
<td>Deletes empty sets.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Empty contact surfaces</td>
<td>Checks if contact surfaces are empty.</td>
<td>Lists the empty contact surfaces.</td>
<td>Deletes the empty contact surfaces.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Empty groups</td>
<td>Checks if groups are empty.</td>
<td>Lists empty groups.</td>
<td>Deletes empty groups.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Empty plys</td>
<td>Checks if plys are empty.</td>
<td>Lists the empty plys.</td>
<td>Deletes empty plys.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Empty load collectors</td>
<td>Checks if load collectors are empty.</td>
<td>Lists the empty load collectors.</td>
<td>Deletes empty load collectors.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Empty vector collectors</td>
<td>Checks if vector collectors are empty.</td>
<td>Lists the empty vector collectors.</td>
<td>Deletes the empty vector collectors.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Empty laminates</td>
<td>Checks if laminates are not having any ply.</td>
<td>Lists the empty laminates.</td>
<td>Deletes the empty laminates.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>CONM1 with zero diagonal mass matrix values</td>
<td>Checks if the diagonal mass matrix values of CONM1 are less than
                                or equal to zero.</td>
<td>Lists failing CONM1.</td>
<td>Not supported.</td>
<td>Opens the Elements panel.</td>
</tr>
<tr>
<td>CONM2 with zero mass</td>
<td>Checks if the mass of CONM2 is less than or equal to
                                zero.</td>
<td>Lists failing CONM2.</td>
<td>Not supported.</td>
<td>Opens the Bars panel.</td>
</tr>
<tr>
<td>Orientation vector along axis vector</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>Element connectivity</td>
<td>Checks for shell elements connected by one or less nodes and
                                solid elements connected by two or less nodes.</td>
<td>Lists the failing elements.</td>
<td>Deletes the failing elements.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Unused BeamSections</td>
<td>Checks if any beamsection defined in the model is unused. </td>
<td>Lists the failing beamsections.</td>
<td>Deletes the unused beamsections.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Unused sets</td>
<td>Checks if any sets are not used.</td>
<td>Lists unused sets.</td>
<td>Deletes unused sets.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Unused curves</td>
<td>Checks if any curves are not used.</td>
<td>Lists unused curves.</td>
<td>Deletes unused curves.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Unused systems</td>
<td>Checks if any systems in the model are not used.</td>
<td>Lists unused systems.</td>
<td>Deletes unused systems.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Unused laminates</td>
<td>Checks if any laminates in the model are not used.</td>
<td>Lists unused laminates.</td>
<td>Deletes unused laminates.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Unused plys</td>
<td>Checks if any plys in the model are not used.</td>
<td>Lists unused plys.</td>
<td>Deletes unused plys.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Unused vectors</td>
<td>Checks if any vectors in the model are not used.</td>
<td>Lists unused vectors.</td>
<td>Deletes unused vectors.</td>
<td>Not supported.</td>
</tr>
<tr>
<td>Loadcol has two or more different load types</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>Unused parameter</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>No slave nodes detected</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
</tr>
</tbody>
</table>
### Info


<table><colgroup><col/><col/><col/><col/><col/></colgroup><thead>
<tr>
<th>Name</th>
<th>Description</th>
<th>Result</th>
<th>Auto correction action</th>
<th>Manual correction action</th>
</tr>
</thead>
<tbody>
<tr>
<td>Components share the same property</td>
<td>Checks for two or more components that have the same property
                                assigned.</td>
<td>Lists the failing components.</td>
<td>Not supported.</td>
<td>Opens the Components panel.</td>
</tr>
<tr>
<td>Component does not have a property</td>
<td>Checks for components that contain elements but do not have any
                                properties assigned.</td>
<td>Lists the failing components.</td>
<td>Not supported.</td>
<td>Opens the Components panel.</td>
</tr>
</tbody>
</table>
