# Surface Transparency Panel

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help319.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `24b421eb588d71b3b7f4c9ef88f33cb0d0b880c35dff27e360c689ec50f55017`. Record: `3c9daa5c5bac2a02`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## Surface Transparency Panel


Use the Surface Transparency panel to set the transparency level for the surfaces of selected components.


Location: Visualization toolbar, Geometry Transparency icon


A single transparency value between 0 and 10 can be applied to all the selected components using the slider bar. 0 represents opaque and 10 represents completely transparent (invisible surface shading). The transparency value and the list of components it should be applied to are stored in the database file.


This transparency is only applied to surfaces.


- Even though you are allowed to set transparency while surface visual mode is not
                    shaded (vis opts 3), its effects can only be seen in shaded mode.
- If you set the transparency to 10, it may create confusion by giving the
                    illusion that you are in geometry visual mode 2 (topology lines).
- Transparency affects only the display and does not affect selection. You can
                    select a completely or partially transparent surface and place nodes or perform
                    geometry cleanup operations on that surface.
- While importing a database file into an existing model, the transparency
                    settings of the model that currently exists in the session (not the one
                    imported) are honored.
