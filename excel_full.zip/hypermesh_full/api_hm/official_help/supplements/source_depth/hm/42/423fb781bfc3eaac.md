# Find Attached (Tied)

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/user_interface/utility_menu_find_attached_tied_r.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `58e8af0a9900c9f761e16d90307d574f2917de76ede5b92abf50b4ba93c8d04b`. Record: `423fb781bfc3eaac`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source images linked but not mirrored; textual record is not a complete copy of graphical instructions

## Original topic body (structured)

## Find Attached (Tied)


Find elements that are connected to displayed elements using the Find Attached (Tied) option.


Tied elements are those that are tied to each other, but are not attached physically. This option differs from the Find Attached option, which returns elements that are physically attached to each other via common nodes.


Find Attached (Tied) is available for the LS-DYNA user
                profile on the QA/Model Utility menu.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/Find_attached_tied2.png)


Figure 1.


The relationship between tied elements is defined using the following
                    CONTACT keywords:


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Element Type</th>
<th>Contact Keywords</th>
</tr>
</thead>
<tbody>
<tr>
<td>ContactSpotWeld</td>
<td>*CONTACT_SPOTWELD</td>
</tr>
<tr>
<td>NodesToSurface</td>
<td>*CONTACT_TIED_NODES_TO_SURFACE<p>*CONTACT_TIEBREAK_NODES_TO_SURFACE</p>
<p>*CONTACT_TIED_SHELL_EDGE_TO_SURFACE</p>
</td>
</tr>
<tr>
<td>SurfaceToSurface</td>
<td>*CONTACT_TIEBREAK_SURFACE_TO_SURFACE<p>*CONTACT_TIED_SURFACE_TO_SURFACE</p>
</td>
</tr>
<tr>
<td>SlidingOnly</td>
<td>*CONTACT_SLIDING_ONLY</td>
</tr>
<tr>
<td>ConstdTieBreak</td>
<td>*CONSTRAINED_TIE-BREAK</td>
</tr>
<tr>
<td>XtraNode</td>
<td>*CONSTRAINED_EXTRA_NODES_NODE<p>*CONSTRAINED_EXTRA_NODES_SET</p>
</td>
</tr>
<tr>
<td>TiedNodes</td>
<td>*CONSTRAINED_TIED_NODES_FAILURE</td>
</tr>
<tr>
<td>ConstRigidRbody</td>
<td>*CONSTRAINED_RIGID_BODIES</td>
</tr>
</tbody>
</table>
### Features


- Find Attached (Tied) returns any tied elements connected via TIED_CONTACTS as
                    defined using LS-DYNA.
- You can perform a Find Attached (Tied) operation on one or more displayed
                    elements or components.
- Element input and output is based on dimension as follows:
- <table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Input (displayed)</th>
<th>Output (attached or tied)</th>
</tr>
</thead>
<tbody>
<tr>
<td>1D/3D elements</td>
<td>2D elements</td>
</tr>
<tr>
<td>2D elements</td>
<td>1D/3D elements</td>
</tr>
<tr>
<td>2D elements</td>
<td>2D elements<div><span>Note:</span> For ContactSpotweld, the 1st and 2nd use
                                            case is valid.</div>
</td>
</tr>
</tbody>
</table>


### Use Cases


**Use Case 1:**


Two independent beam nodes are connected to a common layer.


**Result:**


If you start with the green shell and 1D beam in image 1., then the Find
                        Attached (Tied) operation returns the elements in the following
                            sequence:


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/UC1_img1.png)


Figure 2. 


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/UC1_img2.png)


Figure 3. 


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/UC1_img3.png)


Figure 4. 


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/UC1_img4.png)


Figure 5.


**Use Case 2:**


A common node between two 1D elements.


**Result:**


If you start with the 1D beam in image 1., then the Find Attached (Tied)
                        operation returns the elements in the following sequence:


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/UC2_img1.png)


Figure 6. 


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/UC2_img2.png)


Figure 7. 


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/UC2_img3.png)


Figure 8.


Note: The Find Attached (Tied) option works with displayed elements only.
