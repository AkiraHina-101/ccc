# Certification

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/aerospace/certification_r.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `b1725253421a3efc93c08268ff8363fc9ac2162fc10e426e7fcd370d631f8c87`. Record: `41d36aaacf77cbac`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## Certification


Framework to plug certification methods inside HyperWorks to assess margin of safety from the model and result information.


The Certification Browser contains methods on geometric regions (design points) representing a structural element. Methods are fed by attributes queried from the FE model and FE results as well as external information not in FE models. Restriction: Only available in the Nastran and OptiStruct user profiles. Restriction: You can now add your own methods. However, method and attribute registration is only available via the .xml file edition. There is no user interface for registration.


From the menu bar, click Aerospace > Certification > Certify.


The Certification Browser contains a region of the FE-model and evaluates an external math function to assess margin of safety while considering true geometry and properties of that region. The region is assigned a virtual property that is a placeholder to provide all of the required details to better represent physics and geometry. These regions are grouped together in sets where functions are assessed under multiple loadcases. Critical margins of safety can then be accessed to select critical loadcases. When an evaluation is done, the goal is to be able to update virtual properties of failed areas to reassess certification methods.


Design point sets, design points, structural properties and (design point) methods
                are HyperMesh entities that are present in a binary
                file. The following configurations are available:

- Rivet
- Spring
- Panel_composite
- Panel_metallic


Design point set is a collection of design points of the same configuration. Functions to evaluate and loadcases are defined at this level. Design point is the region that is instrumented. Each design point set configuration comes with an algorithm called Auto DDP that absorbs design points from user selection and various options. You will then populate and organize design point sets with several design points to assess methods. Each design point is a collection of several elements that materialize a geometric region on the FE model. Technically, design point is not limited to elements, it could point to any HyperMesh entity. However, the released configurations are made of elements that form a pattern.


Design point is the FE counterpart of a geometric zone with details not modeled in FE. To fill this gap, there is another entity called structural property. Depending on the design point configuration, structural property will have a different set of data names. Each design point can have its own structural property.


Design point set is then assigned a series of design point methods to be assessed on
                all design points that it contains. A framework is used that allows you to plug your
                math functions in HyperMesh. These functions can be
                coded as:

- Python functions
- Compose (OML) functions
- C++ dynamic libraries (DLL)
- Tcl procedures


The framework embeds Python/Tcl/Compose interpreters to evaluate such functions. When assigned to a design point set, the registered function becomes a design point method entity. The framework queries all of the required result and model information and passes them to methods for evaluation.
