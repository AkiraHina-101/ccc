# Scale Element Thickness

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/meshing/element_thickness_scale_t.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `6720af20b57221e4a750c288a65bf7c0e30c1ba4c10766352a9bf1469fca1721`. Record: `0a0da7d7aa29a8db`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source images linked but not mirrored; textual record is not a complete copy of graphical instructions
- Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code

## Original topic body (structured)

## Scale Element Thickness


Scale the thickness of elements in your model.


Restriction: Only available in the LS-DYNA, Radioss and PAM-CRASH 2G solver interfaces.


1. From the menu bar, click Mesh > Edit > Elements > Scale Thickness.


The Scale Thickness dialog opens.
2. Under Thickness location, define the thickness location of the entities you
                    want to scale. By defining the minimum thickness and/or the maximum thickness,
                    the scaled thickness will not go below the minimum and beyond the maximum
                    thickness mentioned.


  1. In the Minimum thickness field, enter a thickness the scaled thickness
                            will not go below.
  2. In the Maximum thickness field, enter a thickness the scaled thickness
                            will not exceed.


Note: Nodal thickness on elements is only available in the LS-DYNA solver interface.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/scale_thickness_tool_1.png)


Figure 1.
3. Under Selection, select entities to scale.


  - Choose All to select all of the entities in your
                        model.
  - Choose Entities to use the Elements selector to
                        manually select entities.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/scale_thickness_tool_2.png)


Figure 2.
4. Under Scale by, choose whether to multiply, add, or subtract the existing
                    thickness with a desired value. 


To subtract from the thickness, select Add and enter a
                    negative value.

Note: You cannot multiply with a negative value.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/scale_thickness_tool_3.png)


Figure 3.
5. Click Calculate.


Thickness is scaled.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Scale Thickness Behavior


Solver interface specific behavior for scaling the thickness of elements.


#### LS-DYNA


You can only perform thickness operations on *ELEMENT_SHELL_THICKNESS and *ELEMENT_SHELL_COMPOSITES elements. If the card image of elements is *ELEMENT_SHELL_COMPOSITES, then the total thickness will be calculated using the sum of all the THICK attributes. Scaling will be done in proportion with all the thickness attributes.


For example, consider the number of plies is four and the THICK attributes are: THICK(1) = 2, THICK(2) = 4, THICK(3) = 6, THICK(4) = 8. The total thickness will equal 20. If you add two to this thickness, then after scaling the thickness of these attributes will be: THICK(1) = 2.2, THICK(2) = 4.4, THICK(3) = 6.6, and THICK(4) = 8.8. After scaling, the total thickness will become 22.


#### Radioss


You can only perform thickness operations on /SHELL/ and /INISHE cards. /INISHE supports the following three cards: /INISHE/EPSP_F, /INISHE/STRA_F, and /INISHE/STRS_F. If the thickness attribute of /SHELL is not defined and /INISHE is not available, then the thickness will either be defined by the Property or Component. As of now, the thickness of Property and Component entities cannot be assigned using the Scale Thickness tool, therefore thickness will be assigned to the /SHELL thickness attribute.


#### PAM-CRASH 2G


You can perform thickness operations on elements with card image SHELL and TSHEL for the attribute "T". You also perform thickness operations on components that have the card image SHELL, TSHEL, or MEMBR for the attribute H. There is no impact on thickness for the TCONT contact.
