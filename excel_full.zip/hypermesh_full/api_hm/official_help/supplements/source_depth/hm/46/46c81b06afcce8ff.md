# Tie

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/user_interface/utility_menu_abaqus_tie_r.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `1241c3998c0b7f9f496d3d8ed762153094d1d9e1b3ed64aca8e8ed69fa3be164`. Record: `46c81b06afcce8ff`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code

## Original topic body (structured)

## Tie


In the Tie dialog, define the *TIE card.


The Tie dialog contains the following buttons:


<table><caption><span><span>Table 1. </span></span></caption><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Button</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td><span>OK</span></td>
<td>Updates the <span>HyperMesh</span> database with the
                                    changes and closes the <span>Tie</span> dialog.</td>
</tr>
<tr>
<td><span>Apply</span></td>
<td>Updates the <span>HyperMesh</span> database with the
                                    changes without closing the <span>Tie</span>
                                    dialog.</td>
</tr>
<tr>
<td>Cancel</td>
<td>Closes the <span>Tie</span> dialog without
                                    updates.</td>
</tr>
</tbody>
</table>
workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\?path2project-uri ../../?path2rootmap-uri ../../?

### Tie: Define Tab


In the Define tab, select slave surface and master surface for the *TIE card. You can also review the selected surfaces or create new ones.


The Define tab contains the following options:


<table><caption><span><span>Table 2. </span></span></caption><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Option</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td>Auto-generated surface from component</td>
<td>Select this option for <span>HyperMesh</span> to
                                    automatically generate *SURFACE cards from a selected
                                        component.<p>When this option is selected, the Surface field
                                        becomes a Component field, and you can select a component
                                        from the adjacent drop-down list. Click
                                            <span>Slave&gt;&gt;</span> or
                                            <span>Master&gt;&gt;</span> to add them to the table
                                        of included surfaces as slave or master,
                                    respectively.</p>
</td>
</tr>
<tr>
<td>Select slave surface</td>
<td>Select this option for <span>HyperMesh</span> to
                                    automatically generate *SURFACE cards from a selected
                                        component.<p>When this option is selected, the Surface field
                                        becomes a Component field, and you can select a component
                                        from the adjacent drop-down list. Click
                                            <span>Slave&gt;&gt;</span> or
                                            <span>Master&gt;&gt;</span> to add them to the table
                                        of included surfaces as slave or master,
                                    respectively.</p>
</td>
</tr>
<tr>
<td>Select master surface</td>
<td>The Surface field contains a list of the existing surfaces.
                                    Select a slave surface from the list or use the … button to open
                                    the Entity Browser to select a surface.<p>Click
                                            <span>Slave&gt;&gt;</span> to add the surface as a
                                        slave to the table of selected surfaces. Click
                                            <span>Master&gt;&gt;</span> to add the surface as a
                                        master. Click <span>Remove&gt;&gt;</span> to remove any
                                        selected surface from the table. You can add multiple sets
                                        of surfaces to the table.</p>
<p>Click
                                            <span>New</span> to create a new surface. Once
                                        you have specified the surface properties, the surface
                                        appears in the drop-down list, where you can select it and
                                        add it to the table.</p>
<p>The Review button highlights the
                                        selected slave surface in white and displays it through
                                        solid mesh in performance graphics in the <span>HyperMesh</span> window. If the surface is defined
                                        with sets, the underlying elements are highlighted.
                                        Right-click on <span>Review</span> to clear the
                                        review selections.</p>
</td>
</tr>
</tbody>
</table>
If you create multiple pairs of ties, they will appear on the Interface tab in separate entries using the same name.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\?path2project-uri ../../?path2rootmap-uri ../../?

### Tie: Parameter Tab


In the Parameter tab, define optional parameters for the *TIE card.


The supported parameters are: Position tolerance, Tied nset, Cyclic symmetry (standard only), Constraint ratio, No rotation, Adjust, No Thickness and Type. The Position tolerance and Tied nset are optional mutually exclusive parameters. Select None if you do not want to select either of them. See the Abaqus Online Documentation for detailed descriptions of these parameters.


The Parameter tab contains the following options:


<table><caption><span><span>Table 3. </span></span></caption><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Option</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td>Tied nset</td>
<td>The Tied nset menu contains a list of existing node sets. You
                                    can select a node set from the list.</td>
</tr>
<tr>
<td>Review Set</td>
<td>The Review Set button reviews the selected node set by
                                    highlighting it in the <span>HyperMesh</span>
                                    window.</td>
</tr>
<tr>
<td>Create/Edit Set</td>
<td>The Create/Edit Set button opens the Entity Sets panel in
                                        <span>HyperMesh</span>. When you finish
                                    creating/editing the set, click <span>return</span>.
                                    The Tie window is updated with the new set displayed in node set
                                    list.</td>
</tr>
</tbody>
</table>
