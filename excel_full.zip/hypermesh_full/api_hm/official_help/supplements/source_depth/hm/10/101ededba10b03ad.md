# Exercise 1: Kinematic Draping for a Woven Ply Modeled with Two UDs

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/hm_4090_kinematic_draping_for_a_woven_ply_modeled_with_two_uds_c.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `b23bc89c4dfc1bfa2bfd35f04cfd03a43eae9617aefeab696aec4b0657eb19fc`. Record: `101ededba10b03ad`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source images linked but not mirrored; textual record is not a complete copy of graphical instructions
- Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code

## Original topic body (structured)

## Exercise 1: Kinematic Draping for a Woven Ply Modeled with Two UDs


A dome is covered by a fabric. The fabric is idealized with two uni-directional plies. This method allows the material to be a simple, orthotropic, uni-directional ply level model. If the ply was modeled as a single woven ply, the material model would be anisotropic and vary spatially as the angle between the warp and weft directions changed. Nominal thickness of the uni-directional plies is 0.5 * woven thickness.


This exercise uses the dome.hm file, which can be found in the hm.zip file. Copy the file from this directory to your working directory.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Load the User Profile


In this task you will load the OptiStruct user profile.


1. Start HyperMesh Desktop.
2. In the User Profile dialog, select OptiStruct.
3. Click OK.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Open the Model File


In this task you will open the model file, dome.hm.


1. Open a model file by clicking File > Open > Model from the menu bar, or by clicking 
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/open_model_file.png)
 on
                    the Standard toolbar.
2. In the Open Model dialog, open the
                        dome.hm file. 


The model appears in the graphics area.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Drape Plies and Review Results


In this task you will drape the uni-directional plies.


1. In the Model Browser, select the plies folder.
2. Right-click and select Drape > Kinematic Drape from the context menu.
3. On the Drape Calculation tab, specify the Seed Point (id=5366). This is the
                    location the ply first touches the mold.
4. Leave method set to Quadrants. This method simulates a ply which is placed on
                    the mold at the seed point, and is then pressed to the mold uniformly in all
                    directions. Alternatively, Linear can be used. This method simulates a ply which
                    is placed on the mold at the seed point, is then pressed to the mold along the
                    fiber direction in a narrow strip, and is finally pressed to the mold uniformly
                    from the fiber strip in the matrix direction.
5. Click Apply.


Note: The second ply will throw a message in the bottom left of the screen, indicating that maximum shear was exceeded. This indicates that the fiber locking angle of the fabric was reached. By default, drape angles for any elements in this condition will be set to reflect a locked angle and no further action is required. Alternatively, the ply(s) can be draped again using a larger Max. shear angle in the Advanced options menu.


Review Results


1. From the Review tab, visualize the Draping Mesh for the first ply, which
                    idealizes the warp direction of the fabric.
2. From the Review tab, visualize the Draping Mesh to verify identical draping
                    mesh as in the first UD ply.
3. Turn on Composite Layers with Fiber Direction by clicking 
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/composite_layers.png)

                    on the Visualization toolbar. This visualizes fiber directions for both
                    uni-directional plies.


The dome draping results are compared to [10] in the following image.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/kinematic_draping_mesh.png)


Figure 1.
