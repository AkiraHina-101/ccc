# SPH Element Mapping

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/meshing/meshing_sph_element_mapping_r.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `d03e6220fa9d57b08e4ac300bed93e92d5d0f02bece44ab5443908c7f31c4342`. Record: `18b465e4bfdedcec`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## SPH Element Mapping


The generated SPH elements are mapped specific cards.


### Radioss


- SPHCEL
- A new property card PROP/SPH is also created.


### LS-DYNA


- *ELEMENT_SPH


### PAM-CRASH 2G


- SPHEL


### Abaqus


- *SECTION CONTROLS
