# Manage Subsystem Revisions

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/model_build_and_assembly/manage_subsystem_revisions_t.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `0c0c56fb193c3066ef2db923a568378841b61dfda6094c440991f8ba16d836e6`. Record: `4e06ed64adeb9cc5`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code

## Original topic body (structured)

## Manage Subsystem Revisions


Manage, control, and update Major, Study, and Library subsystem revisions using the Subsystem Library.


### About Subsystem Library and Revisions


The Subsystem Library is an integral part of data management and revision control within the Subsystem Browser.


The Part Library serves as a centralized library of HyperMesh subsystems, which in turn facilitates the collaboration between simulation teams. You must be connected to a subsystem library to access all subsystem library related options.


### Revisions


In the Subsystem Browser, the Revision column displays the Major revision, Study revision, and Library revision. All appropriate workflows have entry or access points to the part library, enabling quick and easy access to previous revisions or simply generating new revisions.


You can review the following revisions in the Entity Editor:

**Major Revision**


Depicts a change or set of changes that have been finalized and released for further review. In most cases the Major Revision should be mapped to the PDM Revision, but you can modify it.


**Study Revision**


Created locally to track experimental changes or prototyping changes that may or may not be published. The purpose of the Study Revision is to manage design and prototype exploratory concepts. You can modify the Study Revision.


**Library Revision**


Locally, published revision within the Subsystem Library. You cannot modify the Library Subsystem Revision. It automatically increments on each save when major and study revision are not changed


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Register and Connect Libraries


Register and connect to new libraries.


A default subsystem library is generated when the Subsystem Browser is enabled. It is located at <user home>\AltairLibraries\2020.


1. In the Subsystem Browser, right-click and select Library > Libraries from the context menu.


The Libraries dialog opens.
2. Register a new library:


  1. Click +.
  2. Select the library type. This can be either local or shared. Refer to
                                [Connect to Shared Library](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/model_build_and_assembly/postgresql_installation_and_configuration_c.htm#connecting_to_part_library_t).
  3. Type the library name and library path. The location should be on a
                            drive accessible by all users as well as the hosting machine. It does
                            not have to be on the same machine as that with Postgres
                            installed.
  4. Click Add.
3. Connect to local library:


  1. Select a disconnected library.
  2. Click Connect. If you are currently connected to
                            a different library, you will be disconnected from it.
4. Connect to the <postgres library>. Refer to [Connect to Shared Library](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/model_build_and_assembly/postgresql_installation_and_configuration_c.htm#connecting_to_part_library_t).


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Sync Library Revisions


Sync the in-session version of the library with the latest available Library version in the Subsystem Library.


If the version available in the current session is out of sync with what is saved in the Library, for example, because another user has saved an updated revision, use Sync to update the Revision column with the latest Library revision. Before you can sync library revisions, you must be connected to the library. Refer to [Register and Connect Libraries](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/model_build_and_assembly/manage_subsystem_revisions_t.htm#register_and_connect_libraries_t). Once the revision column is synced, you need to load the representation from the library to update your session with the latest revision.


In the Subsystem Browser, right-click on a subsystem and select Library > Sync from the context menu.
