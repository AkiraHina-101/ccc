# HM-4610: Use Curves, Beams, Rigid Bodies Joints, and Loads in LS-DYNA

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4610_t.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `68b002b896ef525984e65dd26dec3f9bddbf6c0f91632b09af4ba1a03b234143`. Record: `4ef7a0dff66c1d7c`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## HM-4610: Use Curves, Beams, Rigid Bodies Joints, and Loads in LS-DYNA


In this tutorial you will: create XY curves to define non-linear materials, constrained nodal rigid bodies, and joints; define beam elements with HyperBeam, *DEFORMABLE_TO_RIGID, *LOAD_BODY, *BOUNDARY_PRESCRIBED_MOTION_NODE; and use the HyperMesh Component Table tool to review the model's data.


Before you begin, copy the seat_start.hm and seat_2.hm from <hm.zip>/interfaces/lsdyna/ to your working directory.
