# OSSmooth Panel

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help302.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `8acd3c317d495d6042fc55ee328fa2b6704ac0a479d538e2d2a8f3218c9d80ea`. Record: `2dd8cd4aee8fee10`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## OSSmooth Panel


Use the Ossmooth panel to extract and import the final design geometry from OptiStruct's topology, topography and shape optimization results into HyperMesh.


Location: Post page
