# Tags

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/entities/tags_r.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `45dba47117aa37b62d0c0ad2bbd5126d45e1154f93ce5d55cdfa32f45f8eaf98`. Record: `2dbdbde4fc5cb963`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## Tags


Tag entities tag a piece of information, called the body, onto a node, element, line, surface, point, or solid within the model. They can be used to reference an entity across multiple versions of the same model.


### Limitations


Tags are automatically deleted when:

- A tag is on a surface edge and the edge is split, toggled (in either direction), or
            surface normals are adjusted.
- A tag is on a free line and the free line is split.
- A tag is on a surface vertex and all but one (owning parent of the vertex) of the
            associated surfaces are deleted, or the vertex is toggled (in either direction).
