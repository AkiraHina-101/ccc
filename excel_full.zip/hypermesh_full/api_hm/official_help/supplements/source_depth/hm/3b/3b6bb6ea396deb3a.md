# Springs Panel

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/panels/help057.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `e5b3cbbc71597eea0cef0e065e1c116d8d4ed3429b09b356b83bdf0eccd82a1c`. Record: `3b6bb6ea396deb3a`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source images linked but not mirrored; textual record is not a complete copy of graphical instructions

## Original topic body (structured)

## Springs Panel


Use the Springs panel to create spring elements.


Location: 1D page


A spring element is an element created in a space between two nodes of a model where a spring connection is desired. In Radioss, three noded or four noded springs can be created.


Spring elements store a property and a degree of freedom (DOF).


Spring elements are element config 21 and are displayed as a line between two nodes with the letter K written at the centroid of the element.


Springs can translate to CELAS2 in Nastran or *SPRING in Abaqus.


### Create Subpanel


Note: The Create subpanel is not available in the Radioss solver interface.


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Option</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td>node 1</td>
<td>
<div>Select the first end of the spring element.<figure>
<br/><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/springs_node1.png"/><br/>
<span><span>Figure 1. </span></span></figure>
</div>
</td>
</tr>
<tr>
<td>node 2</td>
<td>
<div>Select end b of the spring element. <div><span>Note:</span> Once you select
                    both end a and end b, <span>HyperMesh</span> creates the spring
                    element.</div>
<figure>
<br/><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/springs_node2.png"/><br/>
<span><span>Figure 2. </span></span></figure>
</div>
</td>
</tr>
<tr>
<td>no vector / orient
                                    vector</td>
<td>
<dl>
<dt>orient vector</dt>
<dd>Select an orientation vector.</dd>
<dt>no vector</dt>
<dd>Do not assign a vector.</dd>
</dl>
</td>
</tr>
<tr>
<td>dof1 - dof6</td>
<td><span>Select the degree of freedom (DOF) that applies to
                    the element.</span></td>
</tr>
<tr>
<td>property</td>
<td><span>Select a property to which the entity should
                    point.</span></td>
</tr>
</tbody>
</table>
### Update Subpanel


Note: The Create subpanel is not available in the Radioss solver interface.


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Option</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td>node 1</td>
<td>
<div>Select the first end of the spring element.<figure>
<br/><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/springs_node1.png"/><br/>
<span><span>Figure 3. </span></span></figure>
</div>
</td>
</tr>
<tr>
<td>node 2</td>
<td>
<div>Select end b of the spring element. <div><span>Note:</span> Once you select
                    both end a and end b, <span>HyperMesh</span> creates the spring
                    element.</div>
<figure>
<br/><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/springs_node2.png"/><br/>
<span><span>Figure 4. </span></span></figure>
</div>
</td>
</tr>
<tr>
<td>no vector / orient
                                    vector</td>
<td>
<dl>
<dt>orient vector</dt>
<dd>Select an orientation vector.</dd>
<dt>no vector</dt>
<dd>Do not assign a vector.</dd>
</dl>
</td>
</tr>
<tr>
<td>dof1 - dof6</td>
<td><span>Select the degree of freedom (DOF) that applies to
                    the element.</span></td>
</tr>
<tr>
<td>property</td>
<td><span>Select a property to which the entity should
                    point.</span></td>
</tr>
</tbody>
</table>
### Spring2, Spring3, Spring4 Subpanel


Use the Spring2, Spring3, and Spring4 subpanels to create two noded, three noded, and
                four noded springs. 

Note: Only available in the Radioss solver interface.


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Option</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td>node</td>
<td>Select the nodes to
                                    create spring elements between. <p>In the Spring3 subpanel, use
                                        the third node selector to select the direction
                                    node.</p>
</td>
</tr>
<tr>
<td>orientation</td>
<td>Choose a method for
                                    orienting springs in 3D space.<dl>
<dt>node</dt>
<dd>Select a node to specify the vector
                                                orientation.</dd>
<dt>vector</dt>
<dd>Use the standard plane and vector selector to
                                                determine the orientation of the spring.</dd>
<dt>components</dt>
<dd>To be used if the direction of the local y axis of
                                                the spring is to be specified by entering the X, Y,
                                                and Z components.</dd>
</dl>
</td>
</tr>
</tbody>
</table>
### Command Buttons


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Option</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td>reject</td>
<td>Revert the most recent
                                    change.</td>
</tr>
<tr>
<td>review</td>
<td>After each spring is
                                    selected, <span>HyperMesh</span> indicates which degree of
                                    freedom (dof1 through dof6) is active for the element, and also
                                    displays the appropriate values after property = . <p>This
                                        function assumes the spring element is active and on the
                                        screen.</p>
<p>To make a spring element with the same degree
                                        of freedom as an existing one, review the existing element.
                                        This places the appropriate degree of freedom and property
                                        into the panel.</p>
</td>
</tr>
<tr>
<td>update</td>
<td>Implement the changes
                                    made in the panel.</td>
</tr>
<tr>
<td>return</td>
<td>Exit the
                                    panel.</td>
</tr>
</tbody>
</table>
