# HM-4800: Setup a Permas Analysis

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `b589e990c69f3895baa245a23bc80fc17d78aa8e2f5366beeb6fd372fbd18932`. Record: `3abfc8d5b3ae1b18`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source images linked but not mirrored; textual record is not a complete copy of graphical instructions
- Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code

## Original topic body (structured)

## HM-4800: Setup a Permas Analysis


In this tutorial, you will complete the full setup of a Permas analysis.


Before you begin, copy permastube_clamping.hm from <hm.zip>/interfaces/permas/ to your working directory.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Load the Permas User Profile


In this step, you will load the Permas profile in HyperMesh.


1. Start HyperMesh Desktop.
2. In the User Profiles dialog, set the user profile to
                            Permas.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Retrieve and View the Model File


In this step, you will open the model file and view it in HyperMesh.


1. Open a model file by completing one of the following options:


  - Click File > Open > Model from the menu bar.
  - Click 
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/open_model_file.png)
 on the Standard
                        toolbar.
2. In the Open Model dialog, open the
                        permastube_clamping.hm file.


Note: This file contains pre-defined model data.


The model appears in the graphics area.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_model_file.png)


Figure 1.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Create a Permas $COMPONENT and $SYSTEM


In this step, you will create a component and system card in HyperMesh.


As a first recommended step for each model set up in the Permas user profile, you should create a component and a system card. If this is not done, a warning message is displayed in the message bar on export. Currently only one component and system per model is supported in HyperMesh.


1. From the menu bar, click Setup > Create > Control Cards.


The Card Image dialog opens.
2. In the Card Image dialog, click
                        COMPONENT.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_component_from_card_image_dialog.png)


Figure 2.
3. In the Name field, enter comp1.
4. Click return to create the card and close the card image.
5. Click SYSTEM.
6. In the Name field, enter sys1.
7. Click return to create the card and exit the card image.
8. Click return again to close the Card
                        Image dialog.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Create a Component Collector


In this step, you will create a new component collector.


1. In the Model Browser, right-click and select Create > Component from the context menu.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_creating_new_component.png)


Figure 3.


A new component opens in the Entity Editor.
2. Define the component properties in the Entity Editor.


  1. For Name, enter clamps1.
  2. Select a color for the component.
  3. Set card image to
                                <None>.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_defining_clmps1_settings.png)


Figure 4.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Organize the Elements


In this step, you will organize the elements of the model.


1. From the menu bar, click Mesh > Organize > Elements > To Component.


The Organize panel opens.
2. Select one element on one side of the clamp as seen in [Figure 5](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_p3q_tcm_b3b__fig_kd5_vcm_b3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_element_on_side_of_clamp.png)


Figure 5.
3. In the Organize panel, click elems > by attached.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_side_of_clamp.png)


Figure 6.


The entire side of the clamp becomes selected as seen in [Figure 6](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_p3q_tcm_b3b__fig_nyr_bdm_b3b).
4. Repeat steps [2](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_p3q_tcm_b3b__step_vk3_1pn_b3b)
                    and [3](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_p3q_tcm_b3b__step_rr4_1pn_b3b) to select
                    the elements on the other side of the clamp.


The other side of the clamp becomes selected as seen in [Figure 7](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_p3q_tcm_b3b__fig_imw_cdm_b3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_both_sides_of_clamp.png)


Figure 7.
5. In the dest component = field, ensure that clamps1 is
                    entered.
6. Click move.


HyperMesh organizes the selected elements into the
                    clamps1 component as seen in [Figure 8](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_p3q_tcm_b3b__fig_qdy_4pn_b3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_organizing_elements_into_the_clamps1_component.png)


Figure 8.
7. Click return to exit the panel.
8. In the Model Browser, Component folder, click
                        misc1.


The Entity Editor opens and displays the component's card data.
9. Define the misc1 properties in the Entity Editor.


  1. For Name, enter tube.
  2. Click the color box, and select a new display
                            color for the component.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_settings_for_tube.png)


Figure 9.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Create Material and Elemental Properties


In this step, you will create a solid property and two materials for the existing elements. You will also assign the property and materials to the previously created components.


Assigning a property/material to a component is equivalent to a property to set assignment in Permas. For 2D and 3D elements, this is currently the only method of property assignment.


1. In the Model Browser, right-click and select Create > Property from the context menu.


A new property opens in the Entity Editor.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_creating_new_property.png)


Figure 10.
2. Define the property properties in the Entity Editor.


  1. For Name, enter Solid.
  2. Set card image to
                            SOLID.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_settings_for_solid.png)


Figure 11.
3. In the Model Browser, right-click and select Create > Material from the context menu.


A new material opens in the Entity Editor.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_creating_new_material.png)


Figure 12.
4. Define the material properties in the Entity Editor.


  1. For Name, enter Mat_1.
  2. Set card image to
                                HOMOGENEOUS.
5. In the Model Browser, Materials folder, right-click on
                        Mat_1 and select Card Edit
                    from thecontext menu.
6. Define settings in the card image.


  1. Select the Elastic checkbox.
  2. In the E (elasticity modulus field) field, enter
                                210000.
  3. In the nu field, enter 0.3.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_mat_1_card_image_settings.png)


Figure 13.
7. Click return to close the card image.
8. In the Model Browser, right-click and select Create > Material from the context menu.


A new material opens in the Entity Editor.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_creating_new_material_v2.png)


Figure 14.
9. Define the material properties in the Entity Editor.


  1. For Name, enter Mat_2.
  2. Set card image to
                                HOMOGENEOUS.
10. Open the card image by right-clicking on
                        Mat_2 in the Model Browser,
                    Materials folder and selecting Card Edit from the
                        context menu.
11. Define settings in the Card Image dialog.


  1. Select the Elastic checkbox.
  2. In the E (elasticity modulus field) field, enter
                                7000.
  3. In the nu field, enter 0.330.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_mat_2_card_image_settings.png)


Figure 15.
12. Click return to close the card image.
13. On the Collectors toolbar, click 
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_components_icon.png)
.


The Components panel opens.
14. Open the update subpanel.
15. Click comps.
16. Select the clamps1 checkbox.
17. Click select.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_clamps1_checkbox.png)


Figure 16.
18. Click card image, and select
                        PART_ELPROP.
19. Set the property/no property toggle to property.
20. Click property= and select
                    solid.
21. Set the material/no material toggle to material.
22. Click material= and select
                    Mat_1.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_update_subpanel_settings.png)


Figure 17.
23. Click update.
24. In the Model Browser, Component folder, right-click on
                        clamps1 and select Card Edit
                    from thecontext menu.


The card image opens, and the name of the
                    component, property, and material you assigned is shown.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_displaying_names_in_card_image.png)


Figure 18.
25. Click return to close the card image.
26. Edit the tube component.


  1. Right-click on tube in the Model Browser, Component folder and select
                                Make Current from the context menu.
  2. On the Collectors toolbar, click 
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_components_icon.png)
.


The Components panel opens.
  3. Open the update subpanel.
  4. Click comps.
  5. Select the tube checkbox.
  6. Click select.
  7. Click card image, and
                            select PART_ELPROP.
  8. Set the property/no property toggle to
                            property.
  9. Click property= and select
                                solid.
  10. Set the material/no material toggle to
                            material.
  11. Click material= and select
                                Mat_2.
27. Click Update to complete the changes.
28. Click return to exit the Components panel.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Create Beam Elements


In this step, you will create beam elements and assign a property to individual elements during creation.


In comparison to 2D and 3D elements, you can assign mutually exclusive properties to elements or sets (components).


1. In the Model Browser, right-click and select Create > Component from the context menu.


A new component opens in the Entity Editor.
2. Define the component properties in the Entity Editor.


  1. For Name, enter Beam.
  2. Set card image to
                                <None>.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_beam_settings.png)


Figure 19.
3. In the Model Browser, right-click and select Create > Property from the context menu.


A new property opens in the Entity Editor.
4. Define the property properties in the Entity Editor.


  1. For Name, enter XBA.
  2. Set card image to
                            BEAM.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_xba_settings.png)


Figure 20.
5. In the Model Browser, Property folder, right-click on
                        XBA and select Card Edit from
                        thecontext menu.


The card image opens.
6. In the card image, enter the following
                    parameters:


- For A-1, enter 12.6.
  - For Ixx-1, enter 12.6.
  - For Iyy-1, enter 12.6.
  - For J-1, enter 25.1.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_xba_card_image_settings.png)


Figure 21.
7. Click return to exit the card image.
8. Open the Bars panel by clicking Mesh > Create > 1D Elements > Bars from the menu bar.
9. Set the orientation selector to z-axis.


Note: Because HyperMesh is a generic preprocessor, you have to provide an orientation vector to create the element, although this vector does not go anywhere in the Permas deck. For beams, use the node option in the same panel where a direction vector needs to be defined.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_setting_orientation_selector_to_z_axis.png)


Figure 22.
10. Click property = and select
                    XBA.
11. Using the node A selector, select the node on the top of one side of the clamp
                    as seen in [Figure 23](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_rbn_zgm_b3b__fig_rf3_ljm_b3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_node_on_top_side_of_clamp.png)


Figure 23.
12. Using the node B selector, select the node in the middle of the clamp that is
                    closest to the node you selected as node A as seen in [Figure 24](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_rbn_zgm_b3b__fig_qz3_5jm_b3b).


Tip: You may need to zoom in on the model to properly select the the node in the middle of the clamp which is closest to the node you selected as node A.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_middle_node_on_left_side.png)


Figure 24.


The beam is created automatically.
13. Repeat steps [11](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_rbn_zgm_b3b__step_ayn_hn5_b3b)
                    and [12](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_rbn_zgm_b3b__step_r5y_hn5_b3b) to connect
                    the other node on the top of the clamp with the other node in the middle of the
                    clamp.


The beam is created automatically.
14. Repeat steps [11](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_rbn_zgm_b3b__step_ayn_hn5_b3b)
                    and [12](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_rbn_zgm_b3b__step_r5y_hn5_b3b) for both
                    sets of nodes on the other side of the clamp.
15. In the Model Browser, Component folder, right-click on
                        clamps1 and select Hide from
                    the context menu to see the four sets of bars connecting
                    the six nodes.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_four_beams_visible.png)


Figure 25.
16. In the Model Browser, click 
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_properties_view_icon.png)
 to
                    display the elements in the color of the property that has been assigned to
                    them.


Tip: This is a good way to ensure that you have assigned the correct property to the elements.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_displaying_elements_in%20property_colors.png)


Figure 26.
17. In the Model Browser, click 
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_model_view_icon.png)
 to return
                    to the default display settings.


  1. Optional: 
If necessary, right-click on the clamps1
                            component and select Show to display the clamps
                            again.
18. Click return to exit the panel.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Create a Spring Element


In this step, you will create a spring element and change the element type used when elements are created. You will also use the coincident picking mechanism to help you precisely select nodes.


The coincident picking mechanism is useful in cases where entities, such as nodes and elements, are close to each other.


1. In the Model Browser, right-click and select Create > Component from the context menu.


Note: Springs should now be your current component collector, which ensures that newly created elements are put into this collector.


A new component opens in the Entity Editor.
2. Define the component properties in the Entity Editor.


  1. For Name, enter Springs.
  2. Set card image to
                                PART_ELPROP.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_springs_settings.png)


Figure 27.
3. Open the Element Type panel by clicking Mesh > Assign > Element Type from the menu bar.
4. Open the 1D subpanel.
5. Click spring =, and select
                        X2STIFF3.
6. Click return to exit the panel.
7. From the menu bar, click Preferences > Graphics.


The Graphics panel opens.
8. In the Graphics panel, select the coincident picking
                    checkbox.


Note: Coincident picking gives you more control during node selection. See the online help regarding the graphics subpanel for more information.
9. Click return to exit the panel.
10. In the Model Browser, right-click and select Create > Property from the context menu.


A new proptery opens in the Entity Editor.
11. Define the property properties in the Entity Editor.


  1. For Name, enter XST.
  2. Set card image to
                            SCALAR.
12. In the Model Browser, Property folder, right-click on
                        XST and select Card Edit from
                        thecontext menu.
13. Define settings in the card image.


  1. Select the DOF checkbox to enable the degrees of
                            freedom at the first and second node.
  2. In the coeff field, enter 100.
  3. In the DOF1 and DOF2 fields, enter 2.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_xst_card_image_settings.png)


Figure 28.
  4. Click return to close the card image.
14. Open the Springs panel by doing one of the following:


  - Open the ID page and then selecting
                            springs.

[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_opening_springs_panel.png)

Figure 29.
  - Click Mesh > Create > 1D Elements > Springs from the menu bar.
15. Click property = and select
                    XST.
16. Using the node selector, select the node shown in [Figure 30](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_lwz_mkm_b3b__fig_q51_zmm_b3b).


The coincident picking tool appears, and displays two nodes.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_node.png)


Figure 30.
17. Click the top node displayed by the coincident picking tool as seen in [Figure 31](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_lwz_mkm_b3b__fig_oxd_1nm_b3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_top_node.png)


Figure 31.
18. Using the node selector, click the node selected in step [17](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_lwz_mkm_b3b__step_xhy_dkw_23b).
19. Using the coincident picking tool, click the bottom node as seen in [Figure 32](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_lwz_mkm_b3b__fig_pms_cnm_b3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_bottom_node.png)


Figure 32.


HyperMesh creates a spring as seen in [Figure 33](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_lwz_mkm_b3b__fig_z23_4y5_b3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_created_spring.png)


Figure 33.
20. Repeat steps [16](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_lwz_mkm_b3b__step_ogx_52t_d3b)
                    through [19](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_lwz_mkm_b3b__step_hvl_v2t_d3b) to
                    create a spring on the other side of the model.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_nodes_on_other_side.png)


Figure 34.


HyperMesh creates a spring on the other side of the
                    model as seen in [Figure 35](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_lwz_mkm_b3b__fig_s15_fbv_b3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_second_spring_created.png)


Figure 35.
21. Click return to exit the panel.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Create Multi-Point Constraints


In this step, you will create two different types of multi-point constraints (MPCs). You will also create a component collector for each type of MPC so you can switch their display on and off separately.


Because MPCs do not need a property assignment in HyperMesh, a card image ($ELPROP) is needed for these components.


1. In the Model Browser, right-click and select Create > Component from the context menu.


A new component opens in the Entity Editor.
2. Define the component properties in the Entity Editor.


  1. For Name, enter MPC_Rigids.
  2. Set card image to
                                <None>.
3. Open the Rigids panel by clicking Mesh > Create > 1D Elements > Rigids from the menu bar.
4. Set the dependent switch to multiple nodes.
5. Clear the dof4, dof5 and
                        dof6 checkboxes.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_rigids_panel_settings.png)


Figure 36.
6. Using the independent node selector, select one of the nodes at the end of the
                    beam elements that were created in [Create Beam Elements](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_rbn_zgm_b3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_node_on_beam_element.png)


Figure 37.
7. Using the dependent node selector, select the nodes surrounding the first node
                    as seen in [Figure 38](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_zxl_p4m_b3b__fig_mz1_mpm_b3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_nodes_surrounding_node.png)


Figure 38.
8. Click create.


HyperMesh generates the MPC.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_creating_multi_point_constraint.png)


Figure 39.
9. Repeat steps [6](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_zxl_p4m_b3b__step_hrq_r2v_b3b)
                    through [8](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_zxl_p4m_b3b__step_vsc_s2v_b3b) to
                    create elements for the other three ends of the beam elements.
10. Click return to exit the panel.
11. Open the Utility menu by clicking View > Browsers > HyperMesh > Utility from the menu bar.
12. In the Utility menu, click
                    Disp.
13. Click Clear Temp Nodes.
14. In the Model Browser, right-click and select Create > Component from the context menu.


A new component opens in the Entity Editor.
15. Define the component properties in the Entity Editor.


  1. For Name, enter MPC_Same.
  2. Set card image to
                                <None>.
16. Open the Element Type panel by clicking Mesh > Assign >  Element Type from the menu bar.
17. Click rigid =, and select
                        MPC_SAME.
18. Click return to close the panel.


Note: MPC_Same should now be your current component collector. If not, right-click on MPC_Same, in the Model Browser, and select Make Current from the context menu.
19. Open the Rigids panel by repeating step [3](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_zxl_p4m_b3b__step_r41_xfv_b3b).


A MPC Same rigid will be used to connect the two beams created in [Create Beam Elements](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_rbn_zgm_b3b), where there is a small gap between each vertical section. You will use the Rigids panel to connect these two sections with a MPC Same rigid.
20. Select all of the DOF checkboxes, except dof2.


Dof2 is set free for the pretension load which is applied later in the tutorial.
21. Set the dependent switch to single node.
22. Using the independent node selector, select the inner end of one of the beams
                    created in [Create Beam Elements](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_rbn_zgm_b3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_selecting_inside_of_beam.png)


Figure 40.
23. Using the dependent node selector, select the inner end of the other
                    beam.


The MPC Same rigid is created.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_mpc_same_created.png)


Figure 41.
24. Click return to close the panel.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Set Definition


In this step, you will create sets that will later be used for contact definition.


1. In the Model Browser, Views folder, right-click on
                        set_def and select Show from
                    the context menu.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_showing_set_def.png)


Figure 42.
2. From the menu bar, click Tools > Create > Sets.


The Create set dialog opens.
3. Define the set within the Create set dialog.


  1. In the name field, enter SET_1.
  2. For Entity IDs click 0 Nodes > Nodes.


The Nodes panel opens.
  3. While pressing Shift,
                            draw a box around the lower edge of the split portion of the gap as seen
                            in [Figure 43](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_ynl_vqm_b3b__fig_dqf_1sm_b3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_drawing_box_around_lower_section_of_model_gap.png)


Figure 43.


All nodes within this section highlight as seen in [Figure 44](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_ynl_vqm_b3b__fig_r3f_tnp_c3b).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_nodes_within_section_highlighted.png)


Figure 44.
  4. Click proceed.


HyperMesh organizes all of the highlighted nodes into SET_1.
  5. Click Close to close the Create
                                set dialog.
4. In the Model Browser, Component folder, turn on the display
                    of Beam and MPC Same.
5. Repeat steps [3.a](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_ynl_vqm_b3b__substep_xgm_lft_d3b)
                    through [3.d](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_ynl_vqm_b3b__substep_pg2_4ft_d3b) to
                    create SET_2, SET_11, SET_12, SET_21, and SET_22 using the following
                    definitions:


- SET_2: upper edge of the split portion of the tube.
  - SET_11: lower node of 1st bolt connection.
  - SET_12: upper node of 1st bolt connection.
  - SET_21: lower node of 2nd bolt connection.
  - SET_22: upper node of 2nd bolt connection.
  - Clamps: nodes of the contact surfaces at the clamps to the tube.


Tip: Use the following parameters to create the sets:

  - SET_2 – Select the top set of nodes on the opening that was
                                selected.
  - SET_11 – Zoom in on the MPC SAME rigid, and select one node on the
                                bottom of the first MPC SAME rigid created.
  - SET_12 – Zoom in on the MPC SAME rigid, and select one node on the
                                top of the first MPC SAME rigid created in.
  - SET_21 – Zoom in on the MPC SAME rigid, and select one node on the
                                bottom of the second MPC SAME rigid created.
  - SET_22 – Zoom in on the MPC SAME rigid, and select one node on the
                                top of the second MPC SAME rigid created.
6. Click return.
7. In the Model Browser, Component folder, right-click on
                        clamps1 and select Isolate
                        Only from the context menu.
8. On the Standard Views toolbar, click 
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4410_xy_top_plane_view_icon.png)
.
9. From the menu bar, click Tools > Create > Sets.
10. In the name field, enter Clamps.
11. Click nodes > by window.
12. Draw a box to select the nodes.
13. Click create.


HyperMesh creates the set.
14. Click return to close the panel.


Tip: When you have a large amount of sets, use the Set Browser to create sets.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Create Surfaces from Solid Elements


In this step, you will create surfaces from solid elements.


The surface definition and the sets from above will be used later for contact definition.


1. In the Model Browser, Component folder, right-click on
                        Tube and select Isolate Only
                    from the context menu.
2. Open the Contact Surfaces panel by clicking BCs > Create > Contact Surfaces from the context menu.
3. Open the solid faces subpanel.
4. In the name field, enter Surf_tube.
5. Click card image =, and select
                        $SURFACE.
6. Set the switch to elems.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_set_switch_to_entities.png)


Figure 45.
7. Click elems > by collector.
8. Select the tube component.
9. Click select.
10. Using the nodes selector, select two nodes on the tube component.


Tip: These nodes should be on one solid element, diagonal from each other.


These nodes will be used to specify the faces of the
                    solids to be taken into account for this surface creation.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_select_nodes_with_nodes_selector.png)


Figure 46.
11. Click create.


HyperMesh creates the contact surface.
12. Click return to exit the panel.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Define the Contact Partners


In this step, you will define the contact partners using $CONTACT.


In this analysis, four contacts will be established.


<table><caption><span><span>Table 1. </span></span></caption><colgroup><col/><col/><col/><col/></colgroup><thead>
<tr>
<th>Contact Name</th>
<th>Type</th>
<th>Master</th>
<th>Slave</th>
</tr>
</thead>
<tbody>
<tr>
<td>Bolt_1</td>
<td>Node to Node</td>
<td>SET_11</td>
<td>SET_12</td>
</tr>
<tr>
<td>Bolt_2</td>
<td>Node to Node</td>
<td>SET_21</td>
<td>SET_22</td>
</tr>
<tr>
<td>Gap</td>
<td>Node to Node</td>
<td>SET_1</td>
<td>SET_2</td>
</tr>
<tr>
<td>Tube_clamps</td>
<td>Surface to Node</td>
<td>Surf_Tube</td>
<td>Clamps</td>
</tr>
</tbody>
</table>
1. Open the Interfaces panel by clicking BCs > Create > Interfaces from the menu bar.
2. Open the create subpanel.
3. In the name field, enter tube_clamps.
4. Click type =, and select
                        CONT_SURFACE_NODE to create a surface to node
                    contact.
5. Choose a color for the interface.
6. Click create.
7. Open the add subpanel.
8. Set the master switch to csurfs.
9. Using the contactsufs selector, select surf_tube.
10. Click update.
11. Set the slave switch to sets.
12. Using the sets selector, select Clamps.
13. Click update.
14. Click review.


You should now be able to see if you have set up master and slave surfaces
                    correctly for your contact definition. Master surfaces display in blue, and
                    slaves display in red. If one (or both) do not display, then you might have
                    missed clicking update. If this happens, select the missing entity (master or
                    slave) again and click update.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_review_surfaces.png)


Figure 47.
15. Click return to close the panel.
16. In the Model Browser, Component folder, turn on the display
                    of Beam, MPC Rigid, and
                        MPC Same.
17. From the menu bar, click BCs > Create > Interfaces.
18. Open the create subpanel.
19. In the name field, enter Bolt_1.
20. Click type =, and select
                        CONT_NODE_NODE for a node to node contact.
21. Choose a color for the interface.
22. Click create.
23. Open the add subpanel.
24. Set the master switch to sets.
25. Using the sets selector, select SET_11.
26. Click update.
27. Set the slave switch to sets.
28. Using the sets selector, select SET_12.
29. Click update.
30. Click review.
31. Rotate the model to view the interface.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_rotate_model.png)


Figure 48.
32. Click return to close the panel.
33. Create the Bolt_2 interface using the following criteria:


  1. Set Interface type to CONT_NODE_NODE.
  2. Set Master set to SET_21.
  3. Set Slave set to SET_22.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_create_bolt_2_interface.png)


Figure 49.
34. Isolate the display of the tube component and create the Gap interface using
                    the following cirteria:


  1. Set Interface type to CONT_NODE_NODE.
  2. Set Master set to SET_1.
  3. Set Slave set to SET_2.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_isolate_display_and_create_gap_interface.png)


Figure 50.
35. In the Model Browser, Group folder, right-click on
                        Gap and select Card Edit from
                    the context menu.
36. In the card image of the $CONTACT card, click
                        CONTSYS and select
                    DIRECT.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_select_direct.png)


Figure 51.
37. Click return.
38. Repeat steps [35](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_p2c_x5m_b3b__step_ull_kpw_23b)
                    and [36](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4800_t.htm#task_p2c_x5m_b3b__step_m3q_kpw_23b) for the
                    Bolt_1 and Bolt_2 interfaces.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Create the Boundary Conditions


In this step, you will create constraints and group them into one load collector. You will also create a $CONSTRAINTS variant (load step in HyperMesh) and attach the load collector with the previously created contact constraints.


1. In the Model Browser, right-click and select Create > Load Collector from the context menu.
2. Define settings in the Create Load Collector dialog.


  1. For Name, enter Boundary.
  2. Select a color for the load collector.
  3. Set the card image to
                                SUPPRESS.
  4. Click Create.
3. On the Standard Views toolbar, click 
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4410_xy_top_plane_view_icon.png)
.
4. Open the Constraints panel by clicking BCs > Create > Constraints from the menu bar.
5. Clear the dof4, dof5, and
                        dof6 checkboxes.
6. Verify that the Clamps1 component is displayed.
7. While pressing Shift, draw a box
                    around the bottom row of elements to select the nodes.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_draw_box_around_bottom_row.png)


Figure 52.
8. Rotate the model so that the underside of the bottom clamp is shown.
9. Right-click on the nodes around the MPC Rigids to deselect them.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_rotate_model_to_show_clamp.png)


Figure 53.
10. Deselect the nodes surrounding the other MPC Rigid on this side of the
                    clamp.
11. Click create.
12. In the Model Browser, Component folder, display the
                        tube component.
13. In the size field, enter 1.0 to reduce the size of the
                    constraints in the graphics area.
14. While pressing Shift, draw a box
                    around the far end of the tube to select those nodes in order to include them in
                    the constraint.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_draw_box_around_far_end_of_tube.png)


Figure 54.
15. Click nodes > on plane.
16. Select three nodes on the narrow edge of the tube, and then click
                        select entities.


All of the nodes on that plane highlight.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_highlight_nodes.png)


Figure 55.
17. Click create to create the constraints.
18. Click return to exit the panel.
19. Turn on the display of all of the components.


All of the constraints have been created.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Assign the Boundary Conditions to a Load Step


In this step, you will assign the boundary conditions to a load step.


1. From the menu bar, click Setup > Create > Load Steps.
2. In the name field, enter Con_1.
3. Using the loadcols selector, select Boundary.
4. Using the groups selector, select all four groups.
5. Click create.
6. Click edit.
7. In the card image, set AnalysisProcedure to
                        CONSTRAINTS.


Note: If the Analysis Procedure field is not set to constraints, the load collectors are included, but will not be exported.
8. Click return twice to close the panels.


Note: You can only attach a load collector card image SUPPRESS to a load step with analysis procedure CONSTRAINTS and a load collector with card image LOADS in one with analysis procedure LOADING. If this is not followed correctly your loads and boundary conditions will not be exported. Also, you will receive a warning in the card image of the load step as well as a comment in the exported deck.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Define the Load Collector and Contact Property


In this step, you will create one load pattern (LPAT) for a force applied to the tip of the tube as well as the contact properties for the contacts.


In HyperMesh a load pattern is represented by a load collector with card image LOADS. Finally these load patterns will be included into a $LOADING variant. The LOADING variant is mapped to a load step in HyperMesh.


1. In the Model Browser, right-click and select Create > Load Collector from the context menu.
2. Define settings in the Create Load Collector dialog.


  1. For Name, enter Single_Load.
  2. Select a color for the load collector.
  3. Set card image to
                            LOADS.
  4. Click Create.
3. Open the Forces panel by clicking BCs > Create > Forces from the menu bar.
4. Using the nodes selector, select the node.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_select_node.png)


Figure 56.
5. Set the orientation selector to y-axis.
6. In the magnitude= field, enter -12000.
7. Click create.
8. In the Model Browser, right-click and select Create > Load Collector from the context menu.
9. Define settings in the Create Load Collector dialog.


  1. For Name, enter Pretension_Bolt1.
  2. Select a color for the load collector.
  3. Set card image to
                            LOADS.
  4. Select the Card edit loadcollector upon creation
                            checkbox.
  5. Click Create.
10. In the card image, select the
                        CONTVAL checkbox.
11. Under No_of_Contacts, enter 1.
12. Double-click contid(1) and select
                        Bolt_1.
13. Click GAPWIDTH and select
                    ABS.
14. Click NORMAL and select
                        FORCE_LOCK.
15. In the ContactForce(1) field, enter 10000.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4800_enter_10000_for_contactforce.png)


Figure 57.
16. Click return to close the card image.
17. In the Model Browser, right-click and select Create > Load Collector from the context menu.
18. Define settings in the Create Load Collector dialog.


  1. For Name, enter Pretension_Bolt2.
  2. Select a color for the load collector.
  3. Set Same as to Pretension_Bolt1.
  4. Click Create.
19. In the card image, double-click
                        contid(1) and select
                    Bolt_2.
20. Click return to close the card image.
21. In the Model Browser, right-click and select Create > Load Collector from the context menu.
22. Define settings in the Create Load Collector dialog.


  1. For Name, enter Gap_Tube_Clamps.
  2. Select a color for the load collector.
  3. Set card image to
                            LOADS.
  4. Select the Card edit loadcollector upon creation
                            checkbox.
  5. Click Create.
23. In the card image, select the
                        CONTVAL checkbox.
24. Under No_of_Contacts, enter 2.
25. Double-click contid(1) and select
                        Gap.
26. Double-click contid(2) and select
                        tube_clamps.
27. Click GAPWIDTH and select
                    ABS.
28. Click NORMAL and select
                    CALCULATE.
29. Click return to close the card image.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Define the $NLLOAD Cards


In this step you will create a $NLLOAD card to specify how individual load patterns are acting over an artificial time.


1. Open the Load Steps panel by clicking Setup > Create > Load Steps from the menu bar.
2. In the name field, enter NLLOAD.
3. Using the loadcols selector, select the following load collectors:
                        Single_Load, Pretension_Bolt1,
                        Pretension_Bolt2, and
                        Gap_Tube_Clamps.
4. Click create.
5. Click edit to open the card image.
6. Define settings in the card image.


  1. Select the NLLOAD checkbox.
  2. In the TimeSteps field, enter 4.
  3. In the NoOfLPATS field, enter 4.
  4. Using the LPAT selectors, select the following load collectors:


- For LPAT(1), select Gap_Tube_Clamps.
    - For LPAT(2), select
                                    Pretension_Bolt1.
    - For LPAT(3), select
                                    Pretension_Bolt2.
    - For LPAT(4), select Single_Load.
  5. Enter the information for each of the load patterns.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/nlload_card.png)


Figure 58.


Note: Time values should be between 0 and 1.
7. Click return twice to close the panels.


Tip: Use the Plot NNLOAD tool, located on the Utility menu, to review the contents of the card. You can see the load history of each load pattern plotted as a graph. Also, you can edit values within the table of the tool. See the topic Creating an NLLOAD Card in the HyperMesh online help for more information.The entry fields for the NLLOAD entries require real numbers, and cannot understand hyphens, which are used commonly by PERMAS users. However, to define a hyphen for export you can write -999 which will display as ‘-‘ in the exported deck. This also applies to imported files. A hyphen will convert to ‘-999’ on import.


The NLLOAD card is defined.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Define the $SITUATION Card


In this step, you will build a $SITUATION card which specifies which loads, boundary conditions, and system definitions are combined for this analysis.


1. Open the Load Steps panel.
2. In the name field, enter SIT_NLLOAD.
3. Click create.
4. Click edit to open the card image.
5. Define the card image settings.


  1. Set AnalysisProcedure to SITUATION.
  2. Using the CONSTRAINTS selector, select
                            Con_1.
  3. Using the LOADING selector, select NLLOAD.
6. Click return twice to close the card image and the panel.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Export the Deck


In this step, you will export the deck as a .dat file.


1. From the menu bar, click File > Export > Solver Deck.


The Export - Solver Deck tab opens.
2. In the File field, enter tube_clamp_final.dat.
3. Next to Export Options, click 
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_export_options_icon.png)
.
4. Set Export to All.
5. Click Export.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Acknowledgements


Altair thanks INTES for their assistance and support during the creation of this tutorial.
