# HM-4615: Model Import, Airbags, Export Displayed, and Contacts with LS-DYNA

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4615_t.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `b320e4fe103177bd70c09d4213a6634db79b5a451e535519bac981b592e85911`. Record: `48bfc1cdec5c58b5`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source images linked but not mirrored; textual record is not a complete copy of graphical instructions
- Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code

## Original topic body (structured)

## HM-4615: Model Import, Airbags, Export Displayed, and Contacts with LS-DYNA


In this tutorial you will define the following: *AIRBAG_WANG_NEFSKE for the airbag mesh geometry; initial velocity of 3 mm/ms in the negative x-direction for the head with *INITIAL_VELOCITY_GENERATION; a contact between the airbag and head with *ICONTACT_AUTOMATIC_SURFACE_TO_SURFACE; *CONTACT_AIRBAG_SINGLE_SURFACE for the airbag; and a contact between the plate and the airbag with *CONTACT_NODES_TO_SURFACE.


Before you begin, copy airbag_start.key from <hm.zip>/interfaces/lsdyna/ to your working directory.


This tutorial will help you learn how to define LS-DYNA airbags, loads, and contacts using HyperMesh. The head and airbag are depicted in [Figure 1](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4615_t.htm#task_zgb_prp_xhb__tut_hm_4615_t_fig_vzs_dfr_c3b). 


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_head_and_airbag_model.png)


Figure 1.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### LS-DYNA Overview


In this section, you will learn how to import a LS-DYNA model, export displayed, and create and review contacts.


#### Import a LS-DYNA Model


**Warning and Error Messages**


When importing a LS-DYNA model, HyperMesh warning and error messages will be written to a file named dynkey.msg or dynaseq.msg, depending on the FE input translator being used. This file is created in the same folder from which HyperMesh was started.


**Unsupported Cards**


On import, the LS-DYNA cards not supported by HyperMesh are written to the unsupp_cards panel. Access this panel by clicking Setup > Create > Control Cards from the menu bar. Unsupported cards will be exported with the remaining model.


Care should be taken if an unsupported card points to an entity in HyperMesh. An example of this is when an unsupported material references a *PART. HyperMesh stores unsupported cards as text and does not consider pointers.


**LSTC Dummy Files**


You can read LSTC Hybrid III dummy files into HyperMesh by first converting the tree file to FTSS/ARUP tree file format.


**Include Files**


HyperMesh supports *INCLUDE. When Include files are imported into HyperMesh, the IDs of non-existing entities are maintained and will not be used for new entities. Use the Include files import option to specify whether to merge, preserve, or skip Include files on import. Access this option by clicking File > Import > Solver Deck from the menu bar.


Support of Include files:

- The LS-DYNA keywords *INCLUDE,
                                *INCLUDE_STAMPED_PART, *INCLUDE_STAMPED_PART_SET,
                                *INCLUDE_TRANSFORM, and *INCLUDE_COMPENSATION_OPTION are mapped to
                                Include files.
- Switch to different types of Include files using the context menu Include File option in the Model Browser, with the exception of
                                *INCLUDE_TRANSFORM, *INCLUDE_STAMPED_PART, and
                                *INCLUDE_STAMPED_PART_SET.
- Manage INCLUDE_TRANSFORM using the Transformation Manager.
- During import, if the same Include file is referenced more than once
                                using the *INCLUDE_TRANSFORM, then it will be imported, but appended
                                with .#, where # = 1…n is shown in the Model Browser. These will not be exported unless you
                                clear the Instance checkbox.
- During import, *INCLUDE_STAMPED_PART and *INCLUDE_STAMPED_PART_SET
                                are imported as "read only" by default to preserve the
                                associativity.
- During import, an Include file can be read when *INCLUDE comes after
                                *INCLUDE_TRANSFORM.
- When importing Include files, use Solver options in the Import
                                browser to choose the type of Include file to import. This option
                                enables you to set the Include file type to one of the following:
                                INCLUDE, INCLUDE_STAMPED_PART, INCLUDE_STAMPED_PART_SET, or
                                INCLUDE_COMPENSATION_options. This is the only option which
                                enanables you to attach any file of type INCLUDE_STAMPED_PART or
                                INCLUDE_STAMPED_PART_SET.


#### Export Displayed


From the Export - Solver Deck tab, select the Export Displayed option to export only displayed nodes and elements. Only model data associated to the displayed nodes and elements are exported. This model data includes materials and their associated curves, properties, portions of contacts, and output requests.


#### Create and Review Contacts


[Table 1](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4615_t.htm#reference_myj_bcv_xhb__table_i4n_xhv_xhb) describes how all secondary and main set types are created and specified in contacts.


<table><caption><span><span>Table 1. </span></span></caption><colgroup><col/><col/><col/><col/><col/><col/></colgroup><thead>
<tr>
<th>Secondary and Main Set Type</th>
<th><span>LS-DYNA</span> card</th>
<th colspan="2">Panel Used to Create Card</th>
<th colspan="2">Equivalent type in Interfaces
                                panel, add subpanel</th>
</tr>
</thead>
<tbody>
<tr>
<td>EQ. 0: set segment id</td>
<td>*SET_SEGMENT</td>
<td colspan="2">set_segment (contactsurfs) or
                                …</td>
<td colspan="2">csurfs</td>
</tr>
<tr>
<td> </td>
<td> </td>
<td colspan="2">Interfaces, add subpanel</td>
<td colspan="2">entity</td>
</tr>
<tr>
<td>EQ. 1: shell element</td>
<td>*SET_SHELL_Optio</td>
<td colspan="2">Entity Sets or…</td>
<td colspan="2">sets</td>
</tr>
<tr>
<td>set id</td>
<td>n</td>
<td colspan="2">Interfaces, add subpanel</td>
<td colspan="2">subpanel entity</td>
</tr>
<tr>
<td>EQ. 2: part set id</td>
<td>EQ. 2: part set id</td>
<td>Entity Sets or…</td>
<td>Interfaces, add subpanel</td>
<td>split</td>
<td>comps</td>
</tr>
<tr>
<td>EQ. 3: part id</td>
<td>*PART</td>
<td colspan="2">Collectors</td>
<td colspan="2">comps</td>
</tr>
<tr>
<td>* EQ. 4: node set id</td>
<td>*SET_NODE_Option</td>
<td colspan="2">Entity Sets or…</td>
<td colspan="2">sets</td>
</tr>
<tr>
<td> </td>
<td> </td>
<td colspan="2">Interfaces, add subpanel</td>
<td colspan="2">entity</td>
</tr>
<tr>
<td>* EQ. 5: include all</td>
<td> </td>
<td colspan="2">Interfaces, add subpanel</td>
<td colspan="2">all</td>
</tr>
<tr>
<td>* EQ. 6: part set id for exempted parts</td>
<td>*SET_PART_LIST</td>
<td colspan="2">Interfaces, add subpanel and then
                                    <span>card image</span> subpanel</td>
<td colspan="2">sets</td>
</tr>
</tbody>
</table>
**Add Subpanel**


While the Interfaces panel, add subpanel has several main and secondary entity types to choose from in order to specify the LS-DYNA main or secondary set for a *CONTACT, only the valid main and secondary types are selectable for the particular contact you are creating.


When the main or secondary type is set to comps and only one component is selected, the LS-DYNA type is 3, part ID, and *PART is created. When multiple components are selected, the LS-DYNA type is 2, part set ID, and *SET_PART_LIST is created.


When the main or secondary type is set to sets, only those sets valid for the particular contact you are creating are selectable. For example, for *CONTACT_NODES_TO_SURFACE, only a list of node sets is available for secondary; you will not see a list of other set types, like element or part sets.


**Review Contacts**


Review contacts by clicking review in the Interfaces panel, add subpanel.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Load the LS-DYNA User Profile


In this step, you will load the LS-DYNA user profile in HyperMesh.


1. Start HyperMesh Desktop.
2. In the User Profile dialog, set the user profile to
                        LsDyna.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Import the LS-DYNA Model


In this step, you will import the LS-DYNA model file into HyperMesh.


1. From the menu bar, click File > Import > Solver Deck.


The Import - Solver Deck tab opens.
2. In the File field, open the airbag_start.key file.
3. Click Import.


The Import Process Messages dialog opens.
4. Select Close to close the Import Process
                        Messages dialog.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Define *AIRBAG_WANG_NEFSKE


In this step, you will define *AIRBAG_WANG_NEFSKE for the airbag mesh geometry.


1. Create a set of parts, *SET_PART_LIST, containing the AirbagFront and
                    AirbagRear components.


  1. In the Model Browser, right-click and select Create > Set from the context menu.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_creating_new_set_in_model_browser.png)


Figure 2.


A new set opens in the Entity Editor.
  2. For Name, enter airbag_set.
  3. Set card image to
                            Part.
  4. For Entity IDs, click 0 Components > Components.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_setting_entity_ids_for_airbag_set.png)


Figure 3.
  5. In the Select Components dialog, select
                                AirbagFront and
                                AirbagRear and then click OK.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_select_components_dialog.png)


Figure 4.
2. Define the airbag (*AIRBAG_WANG_NEFSKE).


  1. Open the Solver Browser by clicking View > Browsers > HyperMesh > Solver from the menu bar.
  2. In the Solver Browser, right-click and select Create > *AIRBAG > *AIRBAG_WANG_NEFSKE from the context menu.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_creating_new_airbag.png)


Figure 5.


A new control volume opens in the Entity Editor.
  3. For Name, enter airbag.
  4. Click SID.


The entity selector becomes active.
  5. Set the entity selector to Sets as seen in [Figure 6](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4615_t.htm#task_l1g_c5p_xhb__fig_uxd_xvp_xhb).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_setting_airbag_sid_to_set.png)


Figure 6.
  6. Click Set.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_setting_airbag_sid.png)


Figure 7.
  7. In the Select Set dialog, select
                                airbag_set and then click OK.


Note: The parts in this set define the airbag's geometry.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_select_set_dialog.png)


Figure 8.
  8. For CV (Heat capacity at constant volume), enter
                                1023.0.
  9. For CP (Heat capacity at constant pressure), enter
                                1320.0.
  10. For T (Temperature of input gas), enter
                            780.0.
  11. Click LCMT (Load curve specifying input mass flow
                                    rate) > Curve.
  12. In the Select Curve dialog, select
                                airbag LCMT curve and then click
                                    OK.
  13. For C23 (Vent orifice coefficient), enter
                            1.0.
  14. Click LCA23 (Load curve defining vent orifice area as a
                                    function of pressure) > Curve.
  15. In the Select Curve dialog, select
                                airbag LCA23 curve and then click
                                    OK.
  16. For CP23 (Orifice coefficient for leakage), enter
                                1.0.
  17. For PE (Ambient pressure), enter 1.0E-4.
  18. For RO (Ambient density), enter 1.0E-9.
  19. For GC (Gravitational conversion constant), enter
                                1.0.
3. Define an initial velocity of 3 mm/ms in the negative xdirection for the head
                    with *INITIAL_VELOCITY_GENERATION.


  1. In the Solver Browser, right-click and select Create >  *INITIAL > *INITIAL_VELOCITY_GENERATION from the context menu.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_directional_velocity.png)


Figure 9.


A new load opens in the Entity Editor.
  2. Under Region Type, right-click on ID and select
                                Create/Edit.


The Create Sets dialog opens.
  3. For Entity IDs, click 0 Nodes > Nodes.


Note: The Create Sets dialog will remain open for steps [3.d](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4615_t.htm#task_l1g_c5p_xhb__substep_i1w_wwv_xhb) through [3.g](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4615_t.htm#task_l1g_c5p_xhb__substep_bzk_xwv_xhb). If necessary, move the Create Sets dialog to access the panel area.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_create_sets_dialog_2021_1.png)


Figure 10.
  4. In the panel area, click nodes > by Collector.
  5. Select the Head checkbox as seen in [Figure 11](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4615_t.htm#task_l1g_c5p_xhb__fig_vtk_mzp_xhb).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_selecting_head_checkbox.png)


Figure 11.
  6. Click select.
  7. Click proceed.
  8. In the Create Sets dialog, click
                                Close.
  9. In the Solver Browser, *INITIAL folder,
                            *INITIAL_VELOCITY_GENERATION subfolder, right-click on
                                velocity and select
                                Review from the context menu.


HyperMesh highlights the load and greys out
                            all of the other entities as seen in the following image.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_reviewing_velocity_2021_1.png)


Figure 12.
  10. Right-click on velocity and select
                                Review from the context menu.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Define a Contact Between the Airbag and the Head


In this section, you will define a contact between the airbag and the head with *CONTACT_AUTOMATIC_SURFACE_TO_SURFACE.


1. Create a HyperMesh group with the card image SurfaceToSurface.


  1. In the Solver Browser, right-click and select Create > *CONTACT > *CONTACT_AUTOMATIC_SURFACE_TO_SURFACE >  *CONTACT_AUTOMATIC_SURFACE_TO_SURFACE from the context menu.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_creating_new_contact.png)


Figure 13.


A new group opens in the Entity Editor.
  2. For Name, enter Airbag_Head.
2. Specify the head to be the main surface with a surface type of 3, part
                    ID.


Tip: In this step, the Entity Editor should still be open for the Airbag_Head group.


  1. Click MSID.
  2. Set the entity selector to Components.
  3. Click Components.
  4. In the Select Components dialog, select
                                Head and then click OK.
3. Specify the airbag to be the secondary surface with a surface type of 2, part
                    set ID.


Tip: In this step, the Entity Editor should be open for the Airbag_Head group.


  1. Click SSID.
  2. Set the entity selector to Set.
  3. Click Set.
  4. In the Select Set dialog, select
                                airbag_set and then click OK.


Note: This set contains the components, AirbagFront and AirbagRear.
4. View the main and secondary entities.


Tip: In this step, the Airbag_Head group should be selected in the Solver Browser.


  1. In the Solver Browser, right-click on
                                Airbag_Head and select
                                Review from the context menu.


The main and secondary entities temporarily display in blue and
                            red. The other entities temporarily display grey.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_master_and_slave_entities_displayed_in_red.png)


Figure 14.
  2. Right-click on Airbag_Head and select
                                Review from the context menu.


The entities return to their original display color.
5. Define *CONTACT_AIRBAG_SINGLE_SURFACE for the airbag.


  1. In the Solver Browser, right-click and select Create > *CONTACT > *CONTACT_AIRBAG_SINGLE_SURFACE from the context menu.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_creating_new_contact_airbag_single_surface.png)


Figure 15.


A new group opens in the Entity Editor.
  2. For Name, enter airbag.
6. Define the airbag to be a secondary surface with a secondary set type of 2,
                    part set ID.


Tip: In this step, the Entity Editor should be open for the airbag group.


  1. Click SSID.
  2. Set the entity selector to Set.
  3. Click Set.
  4. In the Select Set dialog, select
                                airbag_set and then click OK.
7. View the secondary entities.


Tip: In this step, the airbag group should be selected in the Solver Browser.


  1. In the Solver Browser, right-click on
                                airbag and select
                                Review from the context menu.


The main and secondary entities temporarily display white and
                            red. The other entities temporarily display grey.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_master_and_slave_entities_displayed_in_red_and_white.png)


Figure 16.
  2. Right-click on airbag and select
                                Review from the context menu.


The entities return to their original display color.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Define a Contact Between the Plate and the Airbag


In this step, you will define a contact between the plate and the airbag with *CONTACT_NODES_TO_SURFACE.


1. Define the AirbagRear component to be the main surface with a main type of 0,
                    set segment ID.


  1. In the Solver Browser, right-click and select Create > *SET > *SET_SEGMENT > *SET_SEGMENT from the context menu.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_creating_new_set_in_solver_browser.png)


Figure 17.


A new contactsurf opens in the Entity Editor.
  2. For Name, enter AirbagRear_main.
  3. Optional: 
Click the Color icon and select a color for the
                            contactsurf.
  4. For Elements, click 0 Elements > Elements.
  5. In the panel area, set the second switch to
                                elems as seen in [Figure 18](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4615_t.htm#task_ijq_sdq_xhb__fig_kfj_p2q_xhb).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_setting_second_panel_to_elems.png)


Figure 18.
  6. Click elems > by collector.
  7. Select the AirbagRear checkbox.
  8. Click select.
  9. Click add.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_defining_the_airbag_rear_component.png)


Figure 19.
2. Reverse the contactsurf’s pyramids so they point out of the airbag.


  1. In the panel area, set the first switch to
                                adjust contact direction as seen in [Figure 20](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4615_t.htm#task_ijq_sdq_xhb__fig_phn_x2q_xhb).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_setting_first_switch_to_adjust_contact_direction.png)


Figure 20.
  2. Select the all elements checkbox.
  3. Click reverse.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_reversing_contactsurfs.png)


Figure 21.
  4. Click return.
3. Create a *CONTACT_NODES_TO_SURFACE card.


  1. In the Solver Browser, right-click and select Create > *CONTACT > *CONTACT_NODES_TO_SURFACE > *CONTACT_NODES_TO_SURFACE from the context menu.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_creating_new_contact_node_to_surface.png)


Figure 22.


A new group opens in the Entity Editor.
  2. For Name, enter Airbag_Plate.
4. Specify the AirbagRear_main contactsurf for the contact’s main surface.


Tip: In this step, the Entity Editor should be open for the Airbag_Plate group.


  1. Click MSID.
  2. Set the entity selector to Contactsurfs.
  3. Click Contactsurfs.
  4. In the Select Contactsurfs dialog, select
                                AirbagRear_main and then click
                                    OK.
5. Define the plate to be the contact’s secondary surface with a secondary type of
                    4, node set ID.


  1. For SSID, click 0 Nodes > Nodes.
  2. In the panel area, set the switch to
                                nodes.
  3. Click nodes > by collector.
  4. Select the RigidPlate component.
  5. Click select as seen in [Figure 23](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4615_t.htm#task_ijq_sdq_xhb__fig_a5q_1gq_xhb).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_setting_ssid.png)


Figure 23.
  6. Click add.


HyperMesh adds the secondary selection to the
                            group Airbag_Plate as seen in [Figure 24](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/tutorials/hm/tut_hm_4615_t.htm#task_ijq_sdq_xhb__fig_yhb_dgq_xhb).


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_adding_the_slave_selection.png)


Figure 24.
  7. Click return.
6. View the main and secondary entities.


  1. In the Solver Browser, *CONTACT folder, *CONTACT
                            NODES TO SURFACE subfolder, right-click on
                                Airbag_Plate and select
                                Review from the context menu.


The main and secondary entities temporarily display blue and
                            red. The other entities temporarily display grey.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_reviewing_airbag_plate.png)


Figure 25.
  2. Right-click on Airbag_Plate and select
                                Review from the context menu.


The entities return to their regular display color.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Review the Created Solver Entities


In this step, you will review the created solver entities using the Solver Browser.


1. In the Solver Browser, *CONTACT folder,
                    *CONTACT_AIRBAG_SINGLE_SURFACE subfolder, right-click on
                        airbag and select Review from
                    the context menu.


Note: Only secondary (red) entities are shown because there are no main entities for this type of contact.


The main and secondary entities temporarily display blue and red. The
                    other entities temporarily display grey.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_reviewing_airbag.png)


Figure 26.
2. Right-click on airbag and select
                        Review from the context menu.


The entities return to their regular display color.
3. In the Solver Browser, *CONTACT  folder, *CONTACT NODES TO
                    SURFACE subfolder, right-click on Airbag_Plate and select
                        Isolate Only from the context menu.


Tip: If main and secondary entities are not visible, make sure the Show/Isolate/IsolateOnly/Attached checkbox is selected in the Options tab of the Browser Configuration dialog. Access the Browser Configuration dialog by right-clicking in the Model Browser and selecting Configure Browser from the context menu.


Only the elements/components that are implicated in this contact display
                    as seen in the following image.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_isolating_only_airbag_plate.png)


Figure 27.
4. In the Solver Browser, *CONTACT folder,
                    *CONTACT_AIRBAG_SINGLE_SURFACE subfolder, right-click on
                        airbag and select Show from
                    the context menu.


The entire airbag displays as seen in the following image.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_showing_airbag.png)


Figure 28.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Export the Model


In this step, you will export the model to an LS-DYNA 971 formatted input file.


1. From the menu bar, click File > Export > Solver Deck.


The Export - Solver Deck tab opens.
2. Set Template to Keyword971.
3. In the File field, navigate to your working directory and save the file as
                        airbag_complete.key.
4. Next to Export options, click 
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/tutorials/hm/hm_4615_export_options_icon.png)
.
5. Set Export to All.
6. Click Export.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Submit the Input File


In this step, you will submit the LS-DYNA input file to LS-DYNA 970.


1. From the Start Menu, open the LS-DYNA Manager program.
2. From the solvers menu, select Start LS-DYNA
                        analysis.
3. Load the airbag_complete.key file.
4. Start the analysis by clicking OK.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### View the Results


In this tutorial, you will view the results in HyperView.


Save your work to a HyperMesh file.
