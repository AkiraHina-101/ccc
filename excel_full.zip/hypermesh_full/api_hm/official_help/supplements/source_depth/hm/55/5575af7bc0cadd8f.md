# Summary Page

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/user_interface/utility_menu_optistruct_summary_page_r.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `19cc384f983045223267093122729c50a3acc2167aeccf2845fcdfd2fdf0775c`. Record: `5575af7bc0cadd8f`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source images linked but not mirrored; textual record is not a complete copy of graphical instructions

## Original topic body (structured)

## Summary Page


The Summary page of the OptiStruct Utility menu lists a short summary using displayed or the entire model for components, loads, elements, center of gravity, moment of inertia, responses and constraints.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/summary_dialog_comps.png)


Figure 1. Summary of Components


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/summary_dialog_elems.png)


Figure 2. Summary of Elements
