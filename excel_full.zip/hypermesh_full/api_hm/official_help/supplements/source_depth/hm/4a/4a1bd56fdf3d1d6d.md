# Manage Penetrations/Intersections

Product/source label: HyperMesh. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/hm/topics/pre_processing/model_setup/penetration_check_tool_1.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `bc15a78e8fc95b372638caed21ab2569cde43d08dbcaf5520c6b282060d42a77`. Record: `4a1bd56fdf3d1d6d`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API
- Source images linked but not mirrored; textual record is not a complete copy of graphical instructions
- Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code

## Original topic body (structured)

## Manage Penetrations/Intersections


Check components or groups for element penetrations and intersections using the Penetration Check tool.


Penetration and intersection can be used individually or collectively. Penetration is defined as the overlap of the material thickness of shell elements, while intersection is defined as elements passing completely through one another.


1. From the menu bar, click Tools > Penetration Check.


Restriction: Only available in the Radioss, LS-DYNA, and PAM-CRASH user profiles.


The Penetrations browser opens.
2. Set up the Penetration Check and check for intersections/penetrations.


  1. In the Penetrations browser, click 
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_invoke_collision_setup_widget.png)

                            to invoke the collision setup widget.
  2. In the Check type field, select the type of collision to check.
  3. In the Entity type field, select the type of entity to be checked for
                            intersections and/or penetrations.
  4. In the Selection field, select contacts (groups), components, or
                            elements to check.


Selecting one of more contacts will perform the penetration check according to the rules enforced by the solver. In any case, the penetrating elements will be found, and the results will display in the Penetration Browser. Results will be listed by pairs of components regardless of the entity type that was used to select penetration candidates.
  5. Use Minimum penetration depth to filter out penetrations with lower
                            penetration depth values.
  6. Select a Thickness option.


Restriction: Only available for Component checks.


- Choose Component/Elements thickness to
                                    apply no adjustments as it uses the thickness value specified in
                                    a component’s property card for each element within that
                                    component.
    - Choose Thickness multiplier to multiply
                                    the selected entities' thickness by the value entered in the
                                    Thickness multiplier field for purposes of the penetration
                                    check. Fractional values are acceptable, but negative values are
                                    not.
    - Choose Uniform thickness to ignore the
                                    existing component's thickness, and instead uses the value
                                    entered in the Uniform Thickness field for all of the components
                                    in the model. 

Note: Use Uniform thickness as a workaround to the lack of thickness information in the default HyperMesh user profile, or when working with models that do not have a thickness specified.
  7. Select a Thickness > size option.


Restriction: Only available for Component checks.


    - Ignore self-penetrations when thickness > elem size
    - Consider self-penetrations when thickenss > elem size
  8. To consider edge penetrations, select the Consider edge
                                penetrations checkbox.
  9. Select a treatment algorithm for the boundary shell edge.


- Choose Flat edges to consider external
                                    borders of the components flat.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/penetrations_flat_edges.png)


Figure 1. Flat Edges
    - Choose Rounded edges to extend external
                                    borders of the component by a cylinder having the diameter of
                                    the component thickness.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/penetrations_rounded_edges.png)


Figure 2. Rounded Edges
  10. Click Check. 


Once the check is complete, the browser
                            populates with detected intersections and/or penetrations.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/collision_detect_widget.png)


Figure 3.
3. Review the penetrations/intersections using the view controls in the browser.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/toolbar_collision_view_controls.png)


Figure 4.
4. Fix the penetrations/intersections.


<table>
<col/><col/><thead><tr><th>To fix</th>
<th>Do this</th></tr></thead>
<tbody><tr>
<th>Manually</th>
<td>
<ol>
<li>Select groups/components to fix in the <span>browser</span>. </li>
<li>Click <img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_manual_fix.png"/> on the collision toolbar. Additional
                                    tools display.<figure>
<br/><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/toolbar_collision_manual_fix.png"/><br/>
<span><span>Figure 5. </span></span></figure>
</li>
<li>Select the elements or nodes to move.</li>
<li>Move and/or translate the selected elements/nodes.</li>
<li>Click <img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_recheck.png"/> to recheck that the
                                    intersection/penetration no longer remains.</li>
</ol>
</td>
</tr>
<tr>
<th>Automatically</th>
<td>
<ol>
<li>Select groups/components to fix in the <span>browser</span>.</li>
<li>Click <img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_automatic_fix.png"/> on the collision toolbar. </li>
</ol>
</td>
</tr>
</tbody></table>
Tip:


  - If a component is intersecting with another, right-click on the
                                component and select Find Matching Penetrating Component
                                    Pair from the context menu
                                to find the same pair of components in the penetrations list. If the
                                pair does not penetrate, a message will display.
  - To keep a specific component from changing when performing
                                de-penetration fixes, right-click on that component and select
                                    Lock Component from the context menu. A red padlock displays on the
                                component name in the browser to indicate that it has been locked.
                                The nodes in a locked component cannot be moved by the Collision
                                tool. To unlock, right-click a locked component and select
                                    Unlock Component from the context menu.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/collision_detection_lock_comp.png)


Figure 6.
  - Sort the columns in the browser by clicking
                                the column headings. For example, clicking the
                                    Violations heading sorts the parent
                                components according to their number of violations. A small
                                triangular arrow in the column heading indicates whether the
                                components are sorted in ascending or descending order; repeated
                                clicks toggle between these two options.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Penetration Check Browser


Overview of the Penetration Check Browser user interface.


#### Collision Toolbar


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Option</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_invoke_collision_setup_widget.png"/></td>
<td>Invokes the collision setup widget, which can be used to setup the
                  Penetration Check and check for intersections/penetrations.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_recheck.png"/></td>
<td>Reruns the collision check. This is recommended when you modify any
                  attributes that control the collision check, or when a mesh modification has
                  occurred.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_automatic_fix.png"/></td>
<td>Automatically attempts to fix the intersections/penetrations you have
                  selected in the browser, based on the settings found in the
                    <span>Options</span> dialog.<p>You can perform a fix on all of the
                    intersections/penetrations listed in the browser, but it is highly recommended
                    that all intersections are resolved before any automatic penetration fix is
                    executed. </p>
</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_manual_fix.png"/></td>
<td>Enables you to manually fix intersections/penetrations. When selected,
                  additional tools display in the browser that can be used to perform manual, rather
                  than automatic, penetration fixes.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_collision_write_results_to_file.png"/></td>
<td>Exports the result of the collision run to a <span><span>.txt</span></span> or <span>.csv</span> file. <p>Nodes
                    and nodes + element pairs are supported. </p>
</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_penetration_selector.png"/></td>
<td>When multiple collisions are displayed in graphics area, click this button to
                  identity the collision pairs in the collision browser after making a seletion in
                  the graphics area.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_node_list_for_selected_penetrations.png"/></td>
<td>Displays a node List for selected penetration that reports penetration depth
                  (thickness minus residual distance), thickness, relative penetration, (penetration
                  divided by thickness) and residual distance for all penetrating nodes.</td>
</tr>
</tbody>
</table>
#### View Controls


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Button</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_collision_highlight_failed_elements.png"/></td>
<td>Highlights all elements that caused penetrations or intersections when you
                  select a component in the <span>browser</span>.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_collision_review_failed_elements.png"/></td>
<td>Makes all elements transparent (wireframe) except for the interacting
                  elements of the component that you selected in the <span>browser</span>, which display in a solid color.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_collision_contour_penetration_depth.png"/></td>
<td>Displays a color gradient of the penetrating elements in the selected
                  component, which indicates the severity (degree) of penetration for the
                  interacting elements.<p>This mode is not available for intersections because their
                    depth cannot be determined.</p>
</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_collision_contour_relative_penetration.png"/></td>
<td>Displays a color gradient of relative penetrating elements.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_collision_penetration_vectors.png"/></td>
<td>Displays individual vectors for each penetrating element in the component
                  that you select in the browser. These vectors indicate the direction and depth of
                  penetration for both the selected component and its interacting components.<p>This
                    mode is not available for intersections because their depth cannot be
                    determined.</p>
</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_collision_fit_view.png"/></td>
<td>Fits the failed elements to the display.<p>In large models, this can be very
                    helpful in finding and viewing small areas of minor penetration. Note that while
                    this option is active, the view automatically fits to the penetrating elements
                    of any component that you click in the browser. Click the option again to
                    deactivate the fit mode.</p>
</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_collision_display_all_elements.png"/></td>
<td>Displays all elements, by unmasking all elements in the model, but not other
                  masked entities such as model geometry.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_collision_display_components_with_failed_elements.png"/></td>
<td>Masks everything in the model except for components with penetrations or
                  intersections. Note that this option only applies to components for which you have
                  run the current penetration check; other components may be interacting, but if you
                  have not run a check on them they do not appear as interacting, and they will be
                  masked.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_collision_display_failed_elements.png"/></td>
<td>Masks everything in the model, including the interacting components, except
                  for the specific elements that penetrate or intersect.</td>
</tr>
<tr>
<td>
<br/><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_mask_except_neighbors.png"/><br/>
</td>
<td>Masks everything in the model, including the interacting components, except
                  for the specific elements and neighbors that penetrate or intersect.</td>
</tr>
</tbody>
</table>
#### Manual Fix Tools


<table><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Button</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_elements_from_tree_selection.png"/></td>
<td>Select Elements By Tree. When enabled, clicking the lowest-level component in
                  the browser selects all of its failed elements.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_elements_selected_manually.png"/></td>
<td>Select Elements Manually. When enabled, you can click each desired element
                  belonging to the lowest-level component in the <span>browser</span>.
                  This includes the ability to select non-failed elements or a sub-set of the failed
                  elements.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_nodes_selected_from_tree_selection.png"/></td>
<td>Select Nodes By Tree. When enabled, clicking the lowest-level component in
                  the <span>browser</span> selects all of the penetrating nodes in its
                  failed elements. This differs from Select Elements By Tree in that individual
                  nodes can be moved to fix a penetration, thus changing the shape of a failed
                  element, instead of moving entire elements.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_nodes_selected_manually.png"/></td>
<td>Select Nodes Manually. When enabled, you can click each desired node
                  belonging to the lowest-level component in the <span>browser</span>.
                  This includes the ability to select individual nodes of non-failed elements, or a
                  sub-set of nodes belonging to the failed elements.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_move_in_normal_direction.png"/></td>
<td>Determines the direction that you wish to manually move the selected nodes or
                  elements. Click the small triangle, in the bottom corner, to select one of the
                    following:<dl>
<dt><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_move_in_normal_direction.png"/></dt>
<dd>Move along the average normal of the selected elements, or related
                        elements in the case of selected nodes.</dd>
<dt><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_move_along_fix_direction.png"/></dt>
<dd>Move along a fixed vector.</dd>
<dt><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_move_x_direction.png"/></dt>
<dd>Move along the X axis.</dd>
<dt><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_move_y_direction.png"/></dt>
<dd>Move along the Y axis.</dd>
<dt><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_move_z_direction.png"/></dt>
<dd>Move along the Z axis.</dd>
<dt><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_move_along_vector.png"/></dt>
<dd>Move along an already-existing vector entity in your model that you
                        select.</dd>
<dt><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_move_direction_defined_by_nodes.png"/></dt>
<dd>Move along nodes in your model that you select to define the direction
                        vector. If you pick two nodes, they define the direction. If you pick three
                        nodes, the direction is the normal of the plane that these three nodes
                        define (picking more than three nodes uses only the last three picked.)</dd>
</dl>
</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_blue_arrow_back.png"/></td>
<td>Moves the selected nodes/elements by the negative amount specified in the
                  numeric text box.</td>
</tr>
<tr>
<td><img alt="" src="https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/icon_blue_arrow_forward.png"/></td>
<td>Moves the selected nodes/elements by the positive amount specified in the
                  numeric text box.</td>
</tr>
</tbody>
</table>
workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Overview


The new Penetration Check tool in HyperMesh is designed to mimic the respective Finite Element solver on hand to the maximum extent possible. This way, identified initial penetrations are almost identical to those detected by the solvers themselves.


Most Finite Element solvers encounter two types of collisions: Penetrations and Intersections.


#### Penetrations


Penetrations themselves are broadly divided into two categories: Node to Segment and Edge to Edge penetrations. Most commercial Finite Element solvers offer interfaces that are Node to Segment only, or Edge to Edge only, or more often than not, a combination of Node to Segment and Edge to Edge.


**Node to Segment Penetrations**


A node to segment penetration is encountered when a secondary node is
                            spatially located within the thickness of a main segment:


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/model_setup_node_to_segment_penetration.png)


Figure 7.


Such penetrations are usually reported by solvers as “node to surface” penetrations. During penetration checks, a secondary node is a sphere with its diameter numerically equal to the maximum thickness of all secondary segments it is attached to.


The "Gap" used for detection of penetration = (Secondary node thickness / 2) + (Main segment thickness / 2)


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/model_setup_math_diagram.png)


Figure 8.


In order to accurately identify nodal penetrations at segment boundaries,
                        like most commercial Finite Element solvers, the Penetration Check tool adds
                        virtual cylinders to the edges of segment boundaries as shown below:


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/model_setup_virtual_cylinders.png)


Figure 9.


Penetrations are also encountered when secondary nodes impact virtual
                        cylindrical edges of main segments:


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/model_setup_slave_nodes_impact.png)


Figure 10.


Some solvers report such penetrations separately as “node to edge,” while others bundle them together with “nodes to surface” penetrations.


Flat boundary shell edges treatment: During nodes to surface penetration checks, some modern contact interfaces provide parameters to disable the addition of virtual cylinders on free/boundary edges of shell elements (along free edges of shell components).


With this, it is possible to identify ‘true’ penetrations at free edges of shell components since the checks are now performed on geometries that accurately represent the physical model.


For such modern interfaces in the Penetration Check tool:

- No virtual cylinders are added to the free/boundary edges of main
                                shell elements.
- For secondary nodes of shell elements, the portion of the secondary node
                                spheres that lie outside the material of the shell elements are
                                    ignored.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/model_setup_slave_node.png)


Figure 11.


Note: A secondary node sphere should not be attached to more than two free/boundary shell edges. If attached to more than two, the secondary node sphere will be retained fully.


**Edge to Edge Penetrations**


Edge to edge penetrations are those that occur when two distinct virtual
                            edge cylinders of segments (that do not share a common node) interfere
                            with each other.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/model_setup_edge_to_edge_penetration.png)


Figure 12.


Most solvers identify and report such penetrations distinctly as "Edge to Edge" penetrations.


**Special Use Case**


Self-penetrations due to extremely thick segments. Some interfaces contain segments with large thicknesses (when compared to segment edge lengths). Depending on the type of penetration check performed, you might encounter penetrations within the same component.


In a node to surface check, the secondary node sphere of one element penetrates
                        the virtual cylinder of the neighboring main segment.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/model_setup_slave_node_sphere.png)


Figure 13.


In an edge to edge check, two virtual cylinders on opposite edges of the
                        same segment penetrate each other.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/model_setup_edge_to_edge_check.png)


Figure 14.


Some solvers offer one or both of the following remedies to deal with the
                        above issues when they are encountered during Node to Surface checks:

- Ignore penetrations within the neighborhood of a secondary node.
                                Penetrations between a secondary node and main segments in its
                                immediate neighborhood within the same component are ignored. In
                                    Radioss, this method can be
                                activated for /INTER/TYPE7 type interfaces by setting 'IREM_GAP =
                                2'. This method, if activated in the Penetration Check tool, will
                                impose significant computation overhead, thereby impacting the
                                performance of the tool.
- Reduce thickness of main segments by a specified factor. This can be
                                seen in LS-DYNA single surface contacts,
                                where the thickness is reduced to 40% of the minimum edge length of
                                the segment.


#### Intersections


Intersections are formed when an edge of an element crosses the mid surfaces/faces of
                other shell elements/solid elements, respectively. 


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/model_setup_intersections.png)


Figure 15.


Intersection checks are not a function of solver parameters and are, therefore, user-profile agnostic.


Intersections are not reported by most solvers. However, their presence will lead to severe issues during analyses, and should therefore be avoided at all costs.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Components and Groups (Contacts) Checks


The Penetration Check tool is useful for checking components for the Radioss, LS-DYNA, and PAM-CRASH user profiles.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

#### Perform a Penetration Check


In this task you will learn how to perform a penetration check using the Penetration Check tool.


Before performing the following steps, make sure you are in HyperMesh Desktop, and that you have a model file open. Note: The Penetration Check tool is only available within the Radioss, LS-DYNA, or PAM-CRASH user profiles.


1. To display the Penetrations Browser, select Tools > Penetration Check from the main menu.


The Penetrations Browser displays. The Entity Editor displays beneath it. If you do not see the Entity Editor, you can display it using the Invoke Penetration Check Setup Widget button ( [Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/penetration_check_setup_widget.png) ).
2. In the Entity Type field, select Components.
3. Set each value in the editor according to the following options:


**Check type**


Can be set to Intersections, Penetrations, or Intersections and penetrations.


**Entity type**


Can be set to Groups (Contacts) or Components, or elements.


**Selection**


Set this to the selection of components to check for collisions.


**Thickness option**


Applicable to penetration checks only. Specifies the gap within
                                which penetrations should be detected. Available options are:

  - Component Thickness: (Main element or component thickness
                                        / 2) + (Secondary element or component thickness / 2)
  - Thickness Multiplier: (User specified multiplication factor)
                                        * ((Main element or component thickness / 2) + (Secondary
                                        element or component thickness / 2))
  - Uniform Thickness: value specified by user


**Thickness > size option**


Applicable to "Node to Surface" penetration checks only. Specifies
                                what should be done with penetrations between secondary nodes and main
                                segments with extremely large thickness values. Available options
                                    are:

  - Ignore self-penetrations when thickness > element size.
                                        Ignores penetrations within the neighborhood of a secondary
                                        node.
  - Consider self-penetrations when thickness > element size.
                                        Reports all detected penetrations including those within the
                                        same component.


**Consider edge penetrations**


Applicable to penetration checks only. If this option is checked, a combined "Node to Surface" and "Edge to Edge" penetration chick is performed. If unchecked (which is the default), only a "Node to Surface" check is performed. Note: Reported results will not distinguish between "Node to Surface" and "Edge to Edge" penetrations. They are reported as one generic penetrating secondary node.


**Boundary shell edge treatment**


Applicable to "Node to Surface" penetration checks only. Specifies
                                whether the free/boundary edges of shell elements must be flattened.
                                Available options are:

  - Flat edges: flattens the free/boundary edges of shell
                                        elements so that the detected penetration results honor the
                                        true geometry of the model.
  - Rounded edges: retains virtual cylinders at the
                                        free/boundary edges of main shell elements, and also retains
                                        fully spherical free/boundary shell edge secondary
                                        nodes.


Note: Reported penetration results match most solver results to a greater degree than when edges are flattened.


**Thickness multiplier**


Applicable to Groups (Contacts) penetrations checks only. This is an optional multiplication factor that can be applied to the contact gap as it is computed.


**Re-check component shared nodes**


Applicable to Components penetrations check only. This option treats the penetrations detected on nodes which are common to multiple components (example: T-connections, ribs on plastic parts…)


When this option is ON (default), the penetrated component pairs having nodes shared by other components will be re-checked, considering for each pair, the thickness of the two components and if the edges are flat or not. This additional check may affect the performances of the tool, but delivers very accurate results.


When the option is OFF, the algorithm considers the maximum thickness of the connected components for the calculation of the penetrations of those common nodes. This may lead to non-valid penetrations for components having such kind of common nodes between components (example: plastic parts). But for sheet metal components, this option may not be needed. Furthermore, this will not impact the performances of the tool.


workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Supported Solver Contacts and Parameters


In this section you will find contact and parameter information for the LS-DYNA, PAM-CRASH, and Radioss solver cards.


#### LS-DYNA Solver Contacts


<table><caption><span><span>Table 1. </span></span></caption><colgroup><col/><col/><col/><col/></colgroup><thead>
<tr>
<th>Group Type</th>
<th>Node to Surface</th>
<th>Edge to Edge</th>
<th>N2S Treatment when thickness &gt; edge length</th>
</tr>
</thead>
<tbody>
<tr>
<td>SINGLE_SURFACE </td>
<td>Yes</td>
<td>No</td>
<td>Optional, 40% of minimum edge length</td>
</tr>
<tr>
<td>AUTOMATIC_GENERAL </td>
<td>Yes</td>
<td>Yes</td>
<td>Optional, 40% of minimum edge length</td>
</tr>
<tr>
<td>NODES_TO_SURFACE </td>
<td>Yes</td>
<td>No</td>
<td>None</td>
</tr>
<tr>
<td>SURFACE_TO_SURFACE </td>
<td>Yes</td>
<td>No</td>
<td>None</td>
</tr>
<tr>
<td>SINGLE_EDGE </td>
<td>No</td>
<td>Yes</td>
<td>N/A</td>
</tr>
</tbody>
</table>
#### PAM-CRASH Solver Contacts


<table><caption><span><span>Table 2. </span></span></caption><colgroup><col/><col/><col/><col/></colgroup><thead>
<tr>
<th>Group Type</th>
<th>Node to Surface</th>
<th>Edge to Edge</th>
<th>N2S Treatment when thickness &gt; edge length</th>
</tr>
</thead>
<tbody>
<tr>
<td>CNTAC Type 33 </td>
<td>Yes</td>
<td>No</td>
<td>Ignore neighborhood penetrations</td>
</tr>
<tr>
<td>CNTAC Type 34 </td>
<td>Yes</td>
<td>No</td>
<td>Ignore neighborhood penetrations</td>
</tr>
<tr>
<td>CNTAC Type 36 </td>
<td>Yes</td>
<td>No</td>
<td>Ignore neighborhood penetrations</td>
</tr>
<tr>
<td>CNTAC Type 37 </td>
<td>Yes</td>
<td>Yes</td>
<td>Ignore neighborhood penetrations</td>
</tr>
<tr>
<td>CNTAC Type 43 </td>
<td>Yes</td>
<td>Yes</td>
<td>Ignore neighborhood penetrations</td>
</tr>
<tr>
<td>CNTAC Type 46 </td>
<td>Yes</td>
<td>Yes</td>
<td>Ignore neighborhood penetrations</td>
</tr>
</tbody>
</table>
#### Radioss Solver Contacts


<table><caption><span><span>Table 3. </span></span></caption><colgroup><col/><col/><col/><col/></colgroup><thead>
<tr>
<th>Group Type</th>
<th>Node to Surface</th>
<th>Edge to Edge</th>
<th>N2S Treatment when thickness &gt; edge length</th>
</tr>
</thead>
<tbody>
<tr>
<td>/INTER/TYPE7 </td>
<td>Yes</td>
<td>No</td>
<td>Optional, ignore neighborhood penetrations</td>
</tr>
<tr>
<td>/INTER/TYPE11 </td>
<td>No</td>
<td>Yes</td>
<td>N/A</td>
</tr>
<tr>
<td>/INTER/TYPE19 </td>
<td>Yes</td>
<td>Yes</td>
<td>N/A</td>
</tr>
<tr>
<td>/INTER/TYPE24 </td>
<td>Yes</td>
<td>Yes</td>
<td>N/A</td>
</tr>
</tbody>
</table>
#### LS-DYNA Solver Parameters


<table><caption><span><span>Table 4. </span></span></caption><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Entity</th>
<th>Solver Parameters</th>
</tr>
</thead>
<tbody>
<tr>
<td>*CONTROL_CONTACT </td>
<td>TH, TH_SF, SSTHK</td>
</tr>
<tr>
<td>*CONTROL_SHELL </td>
<td>CNTCO</td>
</tr>
<tr>
<td>*CONTACT </td>
<td>SST, SFST, MST, SFMT, SLDTHK, SOFT, THKOPT, SHLTHK, SHLEDG,
                                SRNDE, MSTYP, SSTYP</td>
</tr>
<tr>
<td>*PART </td>
<td>OPTT, SFT</td>
</tr>
<tr>
<td>*SECTION_SHELL</td>
<td>T1, NLOC</td>
</tr>
<tr>
<td>*ELEMENT_SHELL </td>
<td>THIC1, THIC2, THIC3, THIC4, OFFSET</td>
</tr>
</tbody>
</table>
#### PAM-CRASH Solver Parameters


<table><caption><span><span>Table 5. </span></span></caption><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Entity</th>
<th>Solver Parameters</th>
</tr>
</thead>
<tbody>
<tr>
<td>CNTAC /</td>
<td>Hcont, ITPRT</td>
</tr>
<tr>
<td>PART /</td>
<td>TCONT, H</td>
</tr>
<tr>
<td>SHELL /</td>
<td>H</td>
</tr>
<tr>
<td>TSHEL /</td>
<td>H</td>
</tr>
</tbody>
</table>
#### Radioss Solver Parameters


<table><caption><span><span>Table 6. </span></span></caption><colgroup><col/><col/></colgroup><thead>
<tr>
<th>Entity</th>
<th>Solver Parameters</th>
</tr>
</thead>
<tbody>
<tr>
<td>/DEFAULT/INTER/TYPE7 </td>
<td>IGap, IRem_Gap</td>
</tr>
<tr>
<td>/DEFAULT/INTER/TYPE11 </td>
<td>IGap</td>
</tr>
<tr>
<td>/DEFAULT/INTER/TYPE19 </td>
<td>IGap</td>
</tr>
<tr>
<td>/DEFAULT/INTER/TYPE24 </td>
<td>IPen0, Inacti</td>
</tr>
<tr>
<td>/INTER/TYPE7</td>
<td>IGap, GapMin, GapMax, FScaleGap, IRem_Gap, %Mesh_Size</td>
</tr>
<tr>
<td>/INTER/TYPE11</td>
<td>IGap, GapMin</td>
</tr>
<tr>
<td>/INTER/TYPE19</td>
<td>IGap, GapMin, GapMax, FScaleGap</td>
</tr>
<tr>
<td>/INTER/TYPE24</td>
<td>IPen0, Grnod_Ids, GapMax_S, GapMax_M, PenMax, Inacti</td>
</tr>
<tr>
<td>/PART</td>
<td>Thick</td>
</tr>
<tr>
<td>/PROP</td>
<td>Thick</td>
</tr>
<tr>
<td>/SHELL</td>
<td>Thick</td>
</tr>
<tr>
<td>/SH3N</td>
<td>Thick</td>
</tr>
</tbody>
</table>
workdir /<SOURCE_PATH> file:/<SOURCE_PATH> ..\..\..\?path2project-uri ../../../?path2rootmap-uri ../../../?

### Node List for Selected Penetrations


After performing penetration checks, detailed information regarding penetrating secondary nodes can be viewed in the node list for selected penetrations.


You can view the node list by clicking Node list for selected
                penetrations on the Penetration Check browser toolbar (
[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/icons/node_list_selected_penetrations.png)
). The node list looks similar to the following image:


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/model_setup_node_list_selected_penetrations.png)


Figure 16.


The list contains information on all penetrating secondary nodes from the Components
            Pair(s)/Group(s) selected in the Penetrations Check browser. The five columns in the
            table contain the following information:

**Node ID**


IDs of the penetrating secondary nodes.


**Pene. Depth**


The maximum penetration depth for each secondary node listed.


**Thickness**


The gap (or thickness) value corresponding to the maximum of all penetration depths for each secondary node listed.


**Rel. Pene**


The relative penetration value for each secondary node listed. Relative Penetration = Penetration Depth / Thickness.


**Res. Dist**


The residual distance (or physical distance) between the mid-plane of the main segment and the center of the secondary node sphere.


If a secondary node impacts multiple segments (from a "Node to Surface" check) and/or belongs
            to an edge that impacts multiple edges (from an "Edge to Edge" check):

- The secondary node is listed only once (despite multiple penetrations of multiple
                    entities)
- The information listed against it corresponds to the maximum of all its
                    penetration depths


If a more comprehensive report of each and every impact of a given secondary node is
            required, such a report can be written out to a plain-text file by clicking
                List of Node-Elem Pairs in TXT Format in the Penetration
            Check browser toolbar.


[Source image: no alternate description](https://2022.help.altair.com/2022.3/hwdesktop/hm/images/model_setup_list_of_node_elem_pairs.png)


Figure 17.


Note that the plain-text report does not distinguish between Node to Surface and Edge to Edge penetrations. In both cases, the report provides pairs of secondary nodes and their impacted main elements. For solid main elements, indices of impacted faces are also included.
