# Tcl/Tk 8.5 routes for tool GUI patterns

This note routes the GUI facts needed by the maintained tools to the **Tcl/Tk 8.5.19** reference manuals and compares only the relevant callback/options semantics already used by their interfaces. It complements [GUI authoring](GUI_TOOL_AUTHORING.md); it does not restate its general layout guidance.

The coordinator reports that the selected Classic 2022 installation contains a Tcl 8.5.9 DLL. That is bundled-install evidence only: it does **not** establish the Tcl interpreter version or Tk package version loaded by the active HyperMesh client. The RevolveTet4 header declares HyperMesh 2022 / Tcl 8.5. Its lowercase `.revolveTet` toplevel path and the dashboard's `.hv2022dash` path are compatible with the guidance already in the 8.6 reference; this note does not revalidate that separate rule. Confirm Tk availability and version in the actual target client before relying on GUI runtime behavior.

## Bounded comparison with the existing Tcl/Tk 8.6 guide

For the options and callbacks used in these tools, the 8.5 manuals support the same relevant behavior described in the published 8.6 GUI reference:

- `ttk::entry -textvariable`, `-validate focusout`, `-validatecommand`, boolean return requirement, `%P` substitution, and no automatic validation merely because the linked variable changes.
- `ttk::combobox -values`, `-state readonly`, `-textvariable`, and `<<ComboboxSelected>>` after a value is chosen from the list.
- `ttk::checkbutton -variable/-onvalue/-offvalue/-command`; radiobutton groups share `-variable`, each supplies `-value`, and an optional `-command` runs when invoked.
- `ttk::button -command` as invocation callback.
- `bind` with `%W` for `<Destroy>`; the widget is half-dead during delivery, so the callback should update Tcl state rather than operate on that widget.
- `wm minsize`, `wm title`, and `wm attributes ... -topmost` forms. Window-manager requests may be platform/window-manager dependent; `-topmost` is listed as available on all platforms, with X11 caveats in the manual.
- `grid` placement and `-sticky`/row-column weight behavior.
- `tk_getOpenFile` returns a full path on selection and an empty string on cancel; `tk_chooseDirectory -mustexist false` permits a not-yet-existing directory and likewise returns an empty string when canceled.

No semantic difference affecting these cited patterns was found in the 8.5.19 manual passages examined relative to the claims in the existing 8.6 GUI reference. This is a bounded documentation comparison, not a complete API diff and not evidence about the installed Classic client's loaded Tk package or theme. The previous guide's citation can therefore be version-routed to the exact 8.5 manual linked below for these patterns.

## Direct 8.5 manual routes

- [ttk::entry](https://www.tcl-lang.org/man/tcl8.5/TkCmd/ttk_entry.htm): linked variable, focus-out validation, validation callback boolean and `%P`; validation differences from classic `entry` are explicitly in this manual.
- [ttk::combobox](https://www.tcl-lang.org/man/tcl8.5/TkCmd/ttk_combobox.htm): `-values`, `-state`, `-textvariable`; `<<ComboboxSelected>>` event semantics.
- [ttk::checkbutton](https://www.tcl-lang.org/man/tcl8.5/TkCmd/ttk_checkbutton.htm): `-command`, `-variable`, `-onvalue`, `-offvalue`.
- [ttk::radiobutton](https://www.tcl-lang.org/man/tcl8.5/TkCmd/ttk_radiobutton.htm): `-command`, `-value`, `-variable` and group selection.
- [ttk::button](https://www.tcl-lang.org/man/tcl8.5/TkCmd/ttk_button.htm): `-command` invoked by the themed button.
- [bind](https://www.tcl-lang.org/man/tcl8.5/TkCmd/bind.htm): virtual events, `%W`, `Destroy` and half-dead widget boundary.
- [wm](https://www.tcl-lang.org/man/tcl8.5/TkCmd/wm.htm): `title`, `minsize`, `attributes -topmost`; see platform support notes for attributes.
- [grid](https://www.tcl-lang.org/man/tcl8.5/TkCmd/grid.htm): row/column placement, `-sticky`, weights.
- [tk_getOpenFile](https://www.tcl-lang.org/man/tcl8.5/TkCmd/getOpenFile.htm): chooser options and empty-string cancellation return.
- [tk_chooseDirectory](https://www.tcl-lang.org/man/tcl8.5/TkCmd/chooseDirectory.htm): `-mustexist` and empty-string cancellation example.

## Evidence boundaries

- Manual identity: Tcl 8.5.19 / Tk 8.5.19 documentation on tcl-lang.org.
- Installed evidence: coordinator reports Tcl 8.5.9 DLL bundled with selected Classic 2022 installation; not independently inspected in this staging task.
- Active-client evidence: Tk package/version loaded by the active client is unknown here.
- Target compatibility: no GUI was launched; visual styling, themed widget availability and window-manager behavior remain unverified.
