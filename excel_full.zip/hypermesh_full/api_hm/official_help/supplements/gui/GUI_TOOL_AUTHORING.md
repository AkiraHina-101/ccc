# Tcl/Tk GUI tool authoring notes

For Tcl/Tk 8.5, use the [version-specific source routes](GUI_TK85_SOURCE_ROUTES.md) for these callback/widget patterns; the comparison is bounded and does not establish the active client package.

**Source baseline:** Tcl/Tk 8.6.18 manuals. This identifies the manuals used; it does not identify the Tcl/Tk version embedded in any Altair release. Example status: derived from these references, `runtime: not_run`.

## Pick the API layer and target first

For the target application, release, client, and GUI/batch context, establish which interface owns each call. Standard Tk/ttk widgets and window-manager commands follow Tcl/Tk. HyperMesh GUI commands are Altair APIs. HWTK provides its own Altair-oriented Tcl/Tk widgets and dialog helpers; HWAT supplies Tcl automation functions/widgets. HWI/HWC and Python `hwx.gui` are separate surfaces. Similar purpose does not make their syntax interchangeable.

Before relying on these Tcl/Tk 8.6 examples, check the target application's supported and loaded Tcl/Tk versions and the relevant widget/theme availability. `info patchlevel` and `package present Tk` are Tcl 8.6 version queries; they only report the current interpreter/packages. The manuals do not establish what Classic 2022, a later Desktop client, or a particular application embeds. Use release-matched Altair sources for native commands and HWTK/HWAT calls.

Start with the existing [HyperMesh GUI scripting routes](../hypermesh/HYPERMESH_GUI_SCRIPTING_2022_3.md) and the GUI/toolkit source map (outside this package; choose another package if needed). The 2022.3 HWTK/HWAT guide (outside this package; choose another package if needed) and HWTK widget reference (outside this package; choose another package if needed) route to Altair toolkit contracts. These references are routing aids: open the exact target-release source before using an Altair command.

## A small themed dialog pattern

Tk widgets use a `pathName`; a widget path is also the Tcl command used to configure or operate that widget. Keep each child under its parent path. For Tk 8.6, a new child window name cannot begin with an uppercase letter; use lowercase path fragments and keep uppercase display labels/values separate. This rule is enforced by [Tk NameWindow](https://github.com/tcltk/tk/blob/core-8-6-branch/generic/tkWindow.c), whose uppercase-name branch returns a Tk error. `grid` places children in a container's row/column cells; `-sticky` controls how a child fills or aligns inside its cell. Give the entry column positive weight when it should receive extra width.

```tcl
namespace eval ::gui {
    variable name ""
    variable mode "mesh"
    variable enabled 1
    variable method "fast"
    variable status "Ready"
    variable closing 0
}

proc ::gui::valid {candidate} {
    return [expr {$candidate ne ""}]
}
proc ::gui::mode_changed {} {
    variable mode
    variable status
    set status "Mode: $mode"
}
proc ::gui::options_changed {} {
    variable status
    set status "Options updated"
}
proc ::gui::on_destroy {expected actual} {
    variable closing
    if {$actual eq $expected} {
        set closing 1
    }
}

toplevel .gui_tool
wm title .gui_tool "Mesh options"
wm attributes .gui_tool -topmost 1

ttk::frame .gui_tool.content -padding 8
grid .gui_tool.content -sticky nsew
grid columnconfigure .gui_tool 0 -weight 1
grid columnconfigure .gui_tool.content 1 -weight 1

ttk::label .gui_tool.content.name_label -text "Name"
ttk::entry .gui_tool.content.name \
    -textvariable ::gui::name \
    -validate focusout \
    -validatecommand [list ::gui::valid %P]
grid .gui_tool.content.name_label -row 0 -column 0 -sticky w -padx 4 -pady 4
grid .gui_tool.content.name       -row 0 -column 1 -sticky ew -padx 4 -pady 4

ttk::label .gui_tool.content.mode_label -text "Mode"
ttk::combobox .gui_tool.content.mode \
    -textvariable ::gui::mode -values {mesh quality} -state readonly
bind .gui_tool.content.mode <<ComboboxSelected>> [list ::gui::mode_changed]
grid .gui_tool.content.mode_label -row 1 -column 0 -sticky w -padx 4 -pady 4
grid .gui_tool.content.mode       -row 1 -column 1 -sticky ew -padx 4 -pady 4

ttk::checkbutton .gui_tool.content.enabled \
    -text "Enabled" -variable ::gui::enabled -onvalue 1 -offvalue 0 \
    -command ::gui::options_changed
grid .gui_tool.content.enabled -row 2 -column 0 -columnspan 2 -sticky w -padx 4 -pady 4

ttk::radiobutton .gui_tool.content.fast \
    -text "Fast" -variable ::gui::method -value fast \
    -command ::gui::options_changed
ttk::radiobutton .gui_tool.content.safe \
    -text "Safe" -variable ::gui::method -value safe \
    -command ::gui::options_changed
grid .gui_tool.content.fast -row 3 -column 0 -sticky w -padx 4 -pady 4
grid .gui_tool.content.safe -row 3 -column 1 -sticky w -padx 4 -pady 4

ttk::style configure Status.TLabel -foreground #a02020
ttk::label .gui_tool.content.status -textvariable ::gui::status -style Status.TLabel
grid .gui_tool.content.status -row 4 -column 0 -columnspan 2 -sticky w -padx 4 -pady 4

bind .gui_tool <Destroy> [list ::gui::on_destroy .gui_tool %W]
```

`ttk::entry -textvariable` links the field and a Tcl variable. The sample uses focus-out validation; a `-validatecommand` must return a boolean. The themed entry manual notes validation is not automatically run just because its linked variable changes. For validation scripts, use `%P` for the proposed value during prevalidation; during focus-out revalidation it is the current entry value; keep validation callbacks small and avoid rebuilding the entry value while prevalidation is running.

A `ttk::combobox` can link to a variable and list its choices with `-values`. `-state readonly` prevents direct text editing; `<<ComboboxSelected>>` handles a selection from the dropdown. Checkbuttons link a variable with `-onvalue`/`-offvalue`; radiobuttons in one group share a variable and each supplies a distinct `-value`. Their `-command` option is an invoked callback, not an entry-style text-change event.

`wm title` sets the window-manager title. In Tcl/Tk 8.6, `wm attributes window -topmost value` is the documented form for requesting a topmost window. Confirm behavior in the target application and window-system context; this manual is not evidence that an embedded Tk build supports the option.

A binding on a toplevel can receive events from descendant widgets. Tk delivers `Destroy` while the widget is already in a half-dead state, so the example checks `%W` and updates Tcl state without calling widget methods. Use a named callback rather than embedding substantial logic in a bind string.

For a themed status label, `ttk::label` lists `-foreground` as a styling option and says it is configurable through `ttk::style`; some styling options depend on the theme. Define a named style and test its appearance on the target theme. Avoid relying on a classic-widget color option for a themed widget.

## Parser and callback boundaries

A Tcl parser can inspect literal command forms, braces, expressions, and callbacks that appear as literal scripts. It does not execute the script or establish API availability. Callback prefixes built from variables, `eval`, `subst`, `source`, or other computed dispatch need separate inspection; command substitution and generated script text are not proven by parsing the surrounding line. Tk validation percent substitutions such as `%P` and binding substitutions such as `%W` are Tcl/Tk callback syntax, not Tcl variable expansion at authoring time. Record parser version, nested-body/callback coverage, unresolved dynamic sites, and target runtime separately.

No GUI was launched and this derived example was not run. Tcl/Tk parse status, target API availability, visual behavior, theme styling, and window-manager behavior remain `not_run`.

## Primary manual sources

- [tcltk86_toplevel](https://www.tcl-lang.org/man/tcl8.6/TkCmd/toplevel.htm) — 8.6.18 manual; window path naming, toplevel event reach
- [tcltk86_wm](https://www.tcl-lang.org/man/tcl8.6/TkCmd/wm.htm) — 8.6.18 manual; title, topmost request
- [tcltk86_grid](https://www.tcl-lang.org/man/tcl8.6/TkCmd/grid.htm) — 8.6.18 manual; grid placement, sticky, row and column weight
- [tcltk86_entry](https://www.tcl-lang.org/man/tcl8.6/TkCmd/ttk_entry.htm) — 8.6.18 manual; entry variable binding, focus-out validation callback, validation boundaries
- [tcltk86_combobox](https://www.tcl-lang.org/man/tcl8.6/TkCmd/ttk_combobox.htm) — 8.6.18 manual; readonly choice list, variable binding, selection callback
- [tcltk86_checkbutton](https://www.tcl-lang.org/man/tcl8.6/TkCmd/ttk_checkbutton.htm) — 8.6.18 manual; on/off variable values, invocation callback
- [tcltk86_radiobutton](https://www.tcl-lang.org/man/tcl8.6/TkCmd/ttk_radiobutton.htm) — 8.6.18 manual; shared variable with distinct values, invocation callback
- [tcltk86_bind](https://www.tcl-lang.org/man/tcl8.6/TkCmd/bind.htm) — 8.6.18 manual; Destroy lifecycle callback, binding script scope and substitutions
- [tcltk86_style](https://www.tcl-lang.org/man/tcl8.6/TkCmd/ttk_style.htm) — 8.6.18 manual; named themed style configuration
- [tcltk86_label](https://www.tcl-lang.org/man/tcl8.6/TkCmd/ttk_label.htm) — 8.6.18 manual; status label foreground via style with theme caveat
- [tcl86_info](https://www.tcl-lang.org/man/tcl8.6/TclCmd/info.htm) — 8.6 manual; report current Tcl interpreter version
- [tcl86_package](https://www.tcl-lang.org/man/tcl8.6/TclCmd/package.htm) — 8.6 manual; report loaded Tk package version where present

## File chooser cancellation

[`tk_getOpenFile`](https://www.tcl-lang.org/man/tcl8.6/TkCmd/getOpenFile.htm) returns the selected pathname or an empty string when cancelled. [`tk_chooseDirectory`](https://www.tcl-lang.org/man/tcl8.6/TkCmd/chooseDirectory.htm) returns the selected directory pathname or an empty string on cancellation. Update the tool's path variable only for a nonempty result; distinguish that cancellation from a CAE operation failure. These are Tcl/Tk 8.6 manual contracts, not an installed Altair runtime availability check. The actual embedded package/version still needs target context.
