# Tcl 8.5/Tk patterns for Altair tools

Use this as a small language/GUI foundation beside the product API package. The language links point to Tcl/Tk 8.5.19 manuals; the installed HyperMesh client may embed another patch level or a different Tk package. Product-command availability and UI behavior must be checked separately. For widget contracts, see [`GUI_TK85_SOURCE_ROUTES.md`](GUI_TK85_SOURCE_ROUTES.md); for broader UI authoring guidance, see [`GUI_TOOL_AUTHORING.md`](GUI_TOOL_AUTHORING.md).

## State, procedures and values

Keep a tool's state in a named namespace and qualify callback procedures. A procedure should receive values as arguments and return a value or error; avoid hidden dependence on whichever namespace happens to invoke a button callback. See the Tcl 8.5 [`namespace`](https://www.tcl-lang.org/man/tcl8.5/TclCmd/namespace.htm), [`proc`](https://www.tcl-lang.org/man/tcl8.5/TclCmd/proc.htm) and [`variable`](https://www.tcl-lang.org/man/tcl8.5/TclCmd/variable.htm) references.

Represent command arguments, selections and callback prefixes as Tcl lists. Use `list`, `lappend`, `lindex`, `llength`, and `lrange` rather than manually concatenating a script string. List construction preserves spaces and special characters as data. Tcl 8.5 supports argument expansion with `{*}`; use it on a list of already-separated arguments. Do not use `eval` as a quoting repair. See the official [`list`](https://www.tcl-lang.org/man/tcl8.5/TclCmd/list.htm), [`lindex`](https://www.tcl-lang.org/man/tcl8.5/TclCmd/lindex.htm) and [`eval`](https://www.tcl-lang.org/man/tcl8.5/TclCmd/eval.htm) references.

```tcl
namespace eval ::tool {
    variable busy 0
    variable status Ready
}

proc ::tool::withSelection {entity ids} {
    # `ids` remains one Tcl list value, even when it contains many IDs.
    return [list $entity {*}$ids]
}

button .run -command [list ::tool::run]
```

The snippet illustrates Tcl value/list construction only. `button` is Tk syntax; `$selection` and any Altair API call need to exist in the chosen client. Do not treat this as a HyperMesh workflow contract.

## Errors and cleanup in Tcl 8.5

Tcl 8.5 has `catch`; do not use Tcl 8.6's `try` in a tool that must run under Tcl 8.5. `catch` captures a completion code and result, and its optional options variable carries the return options. A named handler can restore state and preserve the original error:

```tcl
proc ::tool::run {} {
    variable busy
    if {$busy} { return }
    set busy 1
    set code [catch {::tool::doWork} result options]
    set busy 0
    if {$code != 0} {
        return -options $options $result
    }
    return $result
}
```

This pattern assumes `::tool::doWork` exists. A busy flag prevents a second invocation from starting the same operation; it is not a transaction or model rollback mechanism. Choose cleanup for each resource explicitly, and do not delete model entities as generic error recovery. See [`catch`](https://www.tcl-lang.org/man/tcl8.5/TclCmd/catch.htm), [`return`](https://www.tcl-lang.org/man/tcl8.5/TclCmd/return.htm) and [`error`](https://www.tcl-lang.org/man/tcl8.5/TclCmd/error.htm).

## Callbacks and event-loop safety

Use a list-built callback prefix such as `[list ::tool::select $id]`, not an interpolated script assembled with string concatenation. Keep callbacks short: validate their inputs, update state, and call a named worker procedure. Bind widget variables explicitly. For Tk, see the Tcl 8.5 [`bind`](https://www.tcl-lang.org/man/tcl8.5/TkCmd/bind.htm), [`after`](https://www.tcl-lang.org/man/tcl8.5/TclCmd/after.htm) and [event-loop `update`](https://www.tcl-lang.org/man/tcl8.5/TclCmd/update.htm) references.

`update idletasks` processes idle display/layout work only. `update` processes pending events too; that can run another button callback while the first procedure has partially updated the model or tool state. Avoid using `update` as a generic performance/yield fix. If long work must keep the UI responsive, divide it into bounded callbacks, guard re-entry, and define cancellation/cleanup behavior first. This is a Tcl event-loop design precaution, not an Altair API guarantee.

For delayed work, retain the token returned by `after` and cancel it when the window/tool is destroyed. In a `<Destroy>` callback, identify the destroyed widget and update Tcl state only; Tk widgets are already in teardown. The 8.5 widget routes document `%W` and that lifecycle boundary.

## Tk version and window behavior

Use [Tk 8.5 routes](GUI_TK85_SOURCE_ROUTES.md) for `ttk::entry`, `ttk::combobox`, check/radio buttons, `grid`, `wm`, file choosers, `bind` and themed status labels. Read the 8.5 pages rather than copying a newer online example. `wm attributes ... -topmost` is a window-manager request; it does not prove an embedded Altair window will remain above every application window. Confirm the actual Tk package and target client when that behavior matters.

## Source and validation boundaries

The Tcl manuals establish Tcl 8.5 language behavior; Tk manuals establish widget/window contracts. Neither establishes that HyperMesh/HyperView loads Tk, which Altair commands exist in the active client, what solver/profile is active, or whether a workflow changes the model correctly. Report these independently:

- `PARSE`: Tcl grammar checked by the non-executing Tcl parser, including unparsed/dynamic bodies.
- `CALL_FORM`: product API call matched to an exact local source contract; dynamic argument forms remain manual review.
- `CONTEXT`: target application/client/version/profile availability.
- `BEHAVIOR`: task-specific result in a separate fixture.

See the `altair-tcl-check` skill's checking protocol when it is included in the selected transfer package. API reader Markdown stays independent of maintenance evidence and archive folders.

## Callback correction (2026-10-06)

The previous callback example was `button .run -command [list ::tool::run $selection]`. It passed one argument to the zero-argument `::tool::run` procedure shown below it. The corrected callback passes no argument. For a selection-dependent worker, explicitly add the same parameter to its procedure signature and callback; do not mix the two forms.
