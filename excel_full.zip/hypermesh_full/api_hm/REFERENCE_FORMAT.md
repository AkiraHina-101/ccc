# Source reference format

Preserve exact product, owner, name, source release, official URL and source sections. Include purpose, verbatim syntax and examples, argument positions/options/defaults/types, prerequisites, returns/errors and known source omissions. Unknown is not stated by source; never infer missing syntax or runtime validity. Source facts and runtime observations are separate. New source publication follows MODULE_RULES.md. Do not delete existing evidence without specific user approval. Use relative paths/placeholders, never machine account/install/profile paths.
