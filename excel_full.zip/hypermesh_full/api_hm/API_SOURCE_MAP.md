# Scoped source map

MODULE_INDEX.md is the exact-name source routing authority in this bundle. Product, owner, source release, URL and body pointer stay separate from target availability. No archive or external catalog is required. Ask for another package if outside scope; do not silently search outside the bundle.
