# Other package scopes

This bundle contains only its selected scope. Available package IDs: hypermesh_tcl, hypermesh_gui, hypermesh_batch, hypermesh_solver, hypermesh_native, hypermesh_full, hyperview, hyperview_gui, api_documentation_maintenance, desktop, gui, hvtrans, nastran, hyperview_player, hyperworks_ui, hypergraph, motionview, shared_reference. Ask for the relevant additional bundle if a needed API is outside this scope. Archive is not a dependency.
