# Module routing and portable package maintenance

This is the active documentation organization. Existing `official_help` source bodies are retained in place to preserve provenance and frozen references. `modules` is the product/surface routing layer. Ready independent transfer packages are generated outside the Markdown reader library. Archive is never a tool-authoring dependency or a package input.

## Where to publish source documents

Choose the source software first, then its API surface. Use `modules/<module>/records/<surface>/<source-url-sha256>.md` for new, source-derived records. Do not put builder caches, raw HTML, probes, manifests, scripts, logs or local configuration in api_hm. Those belong in sibling api_hm_evidence. Existing source_depth/web_completion batches retain their frozen denominator; do not silently alter them.

Module IDs: hypermesh, hyperview, desktop, gui, hvtrans, nastran, hyperview_player, hyperworks_ui, hypergraph, motionview, shared_reference.

HyperMesh surfaces: tcl, tcl_gui, environment, hmascii, solver_templates, native_interfaces, reference. Other modules currently use reference; introduce finer surfaces only with explicit source evidence and corresponding classifier/package updates.

Keep original `product`, `owner`, `name`, `title`, `application` and `source_release`. Routing labels do not override source identity. Explicit source families/titles may guide routing; do not infer that every generic HyperWorks Tcl Query/Modify API belongs to HyperMesh. Unknown clients/owners go to shared_reference. New UI is separate from Classic. Nastran covers Altair interface documentation, not every external solver manual.

## Required new-record metadata

Each new source document starts with its normal reader title and includes the following marker and JSON block. Replace example values with exact source facts; unknown fields must say not stated by source. `signature` is empty only when the source does not state syntax. Record original sections, parameters, return values, exceptions, examples and source omissions using REFERENCE_FORMAT.md. Never invent a call form.

<!-- API_RECORD -->
```json
{
  "product": "HyperMesh",
  "owner": "source-stated owner",
  "name": "exact command name",
  "title": "exact source title",
  "application": "HyperMesh Tcl Query Command",
  "source_release": "2022.3",
  "signature": "exact source syntax",
  "url": "https://example.invalid/replace-with-official-source",
  "status": "structured_source_body",
  "source_flags": []
}
```

The marker is used only in actual records under modules/*/records. A canonical reuse may add `reused_body_pointer`, `canonical_source_url` and `same_topic_sha256`, using relative reader paths and exact body identity. Do not merge similar command names or different product owners/releases blindly. Publication must reject conflicting records for the same source URL; append an erratum or review the conflict instead of overwriting evidence.

## Build and acceptance

Read builder STATUS first. Use `api_hm_evidence/tools/build_modular_packages.py` with --docs <DOCS_ROOT>, --output <DOCS_ROOT>/deliverables/packages and --checkpoint <RUNTIME_TESTS_DIR>/<NEW_BATCH>. Use the user-designated Python 3.8+ executable, not PATH; keep its real path in private project configuration.

The builder reads the two retained source LOOKUPs and new module records, classifies every record once, regenerates MODULE_INDEX/modules/PACKAGES, resolves exact alias body dependencies and exports independent bundles. Exported prose links outside scope become their known official source URL or an explicit outside-package label. Code fences and source API syntax are preserved. Cross-scope changes are listed in PACKAGE_MANIFEST.json. Do not silently depend on another bundle, archive or the source workstation.

After publication, verify exact lookup using an extracted bundle, source signatures/code blocks, all local reader/skill links, no path escapes, no archive files, portable placeholders, and record count accounting. Keep package scope limitations explicit. Rebuild every affected package after publication; do not claim ZIPs are current until acceptance passes. Update STATUS and receipt with modules, packages, counts, results, unresolved items and next action. No Altair runtime or workbook update is required for this source-only workflow.

Preserve earlier records/checkpoints. Before deletion of documentation or correction that removes prior evidence, ask the user with exact targets and reasons. No machine account, absolute install/user path, credential or local profile belongs in api_hm or exported shared skills.
