# Source-backed contract standard

A contract tells the AI exactly what the source says about a call and what remains unknown. Keep it compact and faithful. Do not treat a source route or a function-looking signature as proof that the page is callable, available in the target client, or semantically correct.

## Required identity

- Exact product, client/surface, source release, owner/class, command or method, page title, exact official URL and relative source-body pointer.
- Identify the item as a callable command, class method, native function, file format, workflow page or unknown only when the source establishes that category. A reader's module routing is a separate field from the source's product/owner.
- Preserve source heading and every alternative call form. Keep explicit `not stated by source`, missing fields and empty fields distinct.

## Call details

Record source-stated purpose and preconditions, then each ordered argument. Keep type, required/optional, default, allowed values, units, valid entity/profile context and limitations only where the source says. Preserve optional groups and alternatives as alternatives; do not flatten mutually exclusive forms into one signature. If the page has no formal Inputs or Returns heading but explains something in prose, cite that prose and label it as prose-only.

Record source-stated return values, error behavior, side effects/state changes, and examples. Keep source syntax/examples verbatim in fenced text where practical. If adapting an example, show original and adapted forms separately and state why; never turn placeholders, ellipses, typos or machine paths into runnable calls by guessing.

## Evidence and review state

| State | What it means |
|---|---|
| `structured_source_body` | The page was transcribed into a reader body; fields/omissions follow the page. No semantic or runtime approval is implied. |
| `existing_reviewed_transcript` | A direct section transcript in the 133-page focused collection; reviewer caveats may be linked. It is still not an installed-target or behavior certification. |
| `source_contract_summary` | A bounded source-based interpretation with exact source pointer, release and caveats; not a full manual. |
| `source-syntax-not-stated` | The source page provides no syntax/call form. Never invent one. |
| `source-conflict` | The source statements disagree or are malformed; list the statements and cite the original source. Do not select a winner without a separate authoritative basis. |

Track these independently: source identity; syntax stated; argument/result/error detail stated; source conflict/omission; target product/client/version/profile compatibility; Tcl parser result; actual call availability; fixture behavior. Unknown is a valid result. Runtime evidence is dated and limited to the named version/context/fixture. A parser pass proves Tcl grammar only.

The generated `contract_assessment` object in `MODULE_INDEX.md` is an AI routing aid: `source_status` repeats the source-record state; `call_form_state` distinguishes a nonempty signature, source-explicitly-unstated syntax, an absent syntax-heading field, and records needing a body review; `target_compatibility` is `not_checked`; `runtime_behavior` is `not_run`. These fields do not repair source omissions or certify a call. Preserve the original source fields and flags.

## Before calling it ready

A reader should be able to answer: what exact product/client owns the API? What exact source version/form? What are the argument boundaries and alternatives? What must already exist? What can change? What does success/error return? What source contradictions remain? What target behavior is still untested? If the source does not answer, mark the gap and choose a safer documented route or ask for the missing requirement.
