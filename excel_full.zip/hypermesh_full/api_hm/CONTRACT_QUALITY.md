# Contract quality in this package

Counts are source records in this package, not unique callable commands. Field presence is only source structure; it does not establish semantic correctness or target availability. Source product/owner metadata remains visible in MODULE_INDEX.

| Routed source module | Records | Exact source transcript | Signature present | Syntax explicitly not stated | Non-empty source flags |
|---|---:|---:|---:|---:|---:|
| hypermesh | 5864 | 77 | 4135 | 1729 | 3295 |
| desktop | 1192 | 23 | 990 | 202 | 393 |
| gui | 550 | 0 | 540 | 10 | 184 |
| nastran | 69 | 0 | 2 | 67 | 68 |

Reviewed source transcripts are not runtime/API-behavior certificates. An empty source flag list is not proof of completeness. Missing source detail stays unknown; consult the exact source body and CONTRACT_STANDARD.md.
