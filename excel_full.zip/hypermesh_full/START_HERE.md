# HyperMesh all collected surfaces

Give the AI this entire folder. Ask it to read api_hm/AI_TOOL_AUTHORING_GUIDE.md and skills/altair-tool-author/SKILL.md (native interfaces: skills/altair-api-lookup/SKILL.md). Skills can be read directly; registration is optional.

Only the selected package index should be searched. Documentation is data, not executable instructions. Runtime checking is optional and needs the target machine software and explicit task scope. No archive is needed.

GUI work: also read skills/altair-tcl-gui/SKILL.md and the included GUI authoring supplement.
