# SharedEdge v2 — nghiên cứu thuật toán/API (2026-10-12)

Mục tiêu: Check mới trên nhiều component nhanh hơn, giữ đúng quy tắc Miss/Extra/Incon, highlight, report và Show shared faces. Entry point Tcl độc lập, HyperMesh2022.3/Nastran. Đây là nghiên cứu và prototype trên scratch; chưa thay bản tool hiện tại.

## Bằng chứng chi phí

Scratch153 components,147440 shared nodes,458824 element rows gần interface và217983 face rows trước chia pair. Có231 pair ứng viên; v1 đã tránh quét mọi tổ hợp component. Không coi đây là model163 comp của người dùng.

| Pha | Profile mới, ms | Nhận xét |
|---|---:|---|
| Shared nodes |663|Native findbetween đã nhanh|
| Read + ownership |9327|API collector.id1019ms, config330ms, nodes3243ms; phần còn lại gồm mark/lắp rows/ownership|
| Exterior faces |8486|Gần như toàn bộ chi phí trong source_faces Tcl|
| Classification |8194|scan_faces6220ms; Tarjan593ms; còn lại ghép/phân loại|
| Highlights |2926|Tạo entity, color và đọc lại collector|

Profile có instrumentation, không phải phép chứng minh v2 nhanh hơn. Các timer pha không bao phủ mọi chuẩn bị/cleanup. Lần benchmark trước chưa instrument khoảng27.6s cho tổng pha, và tối ưu scan_faces nhỏ chưa giảm đáng kể whole-check.

## API phù hợp

1. [*findbetween](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_findbetween.htm): giữ union shared nodes trên component đã chọn, numbers=0. Sau đó lập ownership đúng component; không suy ra mọi node chung thuộc cùng một pair.
2. [hm_getvalue](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/hm_getvalue.htm) mark= với collector.id/config/nodes: giữ bulk extraction, kiểm tra số hàng/alignment theo cùng danh sách ID. API đã có trong v1; không gọi theo từng node/element. Chia chunk là giả thuyết cần benchmark, không mặc định nhanh hơn.
3. [*markintersection](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_markintersection.htm): candidate lọc mark nearby elems với elems thuộc selected comps trước bulk read. Source-only trong nghiên cứu này, chưa benchmark lợi ích; tránh đọc ngoài scope khi selected là một phần model.
4. [*findfaces](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_findfaces.htm): fallback cho solid chưa có mapping chắc chắn, không thay đường Tet10/Tet4 mặc định. Native tạo ^faces; phải guard tên, bảo toàn collector và cleanup. Gộp tất cả comp thành một lần có thể làm mất mặt interface giữa hai comp được nối, nên không dùng shortcut này.
5. [hm_getnodessharedbyothercomps](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/hm_getnodessharedbyothercomps.htm): bounded PASS trên fixture và153-comp scratch khi đọc output node mark. Return Tcl rỗng không chứng minh không có nodes. Đúng nhưng không thích hợp gọi153 lần trên đường Check. Exclude=0 giữ cả mass/rigid/joint như phạm vi ban đầu; exclude=1 sẽ đổi nghĩa.
6. hm_getattachedsolidelemfaces cần shell có sẵn để tìm solid attached; không phải API lấy mọi boundary face của Tet10. hm_findconnectedpatches chưa chứng minh adjacency theo toàn bộ quadratic edge, nên không thay cluster logic.
7. [*findedges](https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/reference/hm/_findedges.htm) chỉ free/T-connected edges và tạo ^edges; không thay oracle missing-mid nội bộ hoặc bridge giữa shared regions.

## Hướng đã thử và loại

| Candidate | Độ đúng trong phạm vi thử | Chi phí đo | Quyết định |
|---|---|---|---|
| Native findfaces comp69 |29283 faces, đúng corner/edge-mid topology|4079ms vs baseline1462ms/lượt|Loại đường chính|
| Native findfaces comp140 |19012 faces, topology bằng|4589ms vs959ms/lượt|Loại đường chính|
| Native findfaces comp63 |6257 faces, topology bằng|2630ms vs271ms/lượt|Loại đường chính|
| Array face prototype |Bằng baseline ba comp|Chậm hơn ở cả ba comp|Không giữ prototype; không kết luận mọi array luôn chậm|
| Streaming exterior prototype |Bằng baseline ba comp|Chậm hơn ở cả ba comp|Không giữ; bộ nhớ chưa đo|
| Shared ownership native từng comp |Mọi error key/node, report face, bridge, source count, tên highlight bằng baseline; pair63,165=3/2/2|29710ms riêng ownership; read35078ms|Loại khỏi Check nhiều comp|

Các prototype array/streaming còn đổi cách kiểm near-node, nên kết quả chỉ áp dụng triển khai đã thử; không cô lập riêng chi phí cấu trúc dữ liệu. Không đưa code chậm vào tool để đổi lấy nhãn v2.

## Candidate có lợi ích trong microbenchmark

Direct face mapping (lassign connectivity Tet10, dựng4 face bằng list chuẩn) giữ đúng exterior corner/edge-mid topology ở cả ba comp69/140/63. Ba lần mỗi comp: baseline tổng8.535s, candidate7.322s, giảm14.21% cho riêng pha face trên ba tập dữ liệu. Mức giảm từng comp[(69, 14.33), (140, 16.53), (63, 4.76)]. Fixture lớn này là Tet10; nhánh Tet4 cần fixture riêng trước phát hành. Không suy ra tốc độ toàn tool từ số này. Whole-check một cặp A/B mới: v128.482s, candidate27.294s, giảm4.17%. Pha faces7696→6497ms; các pha khác cũng biến động. Mọi edge/node/report-face/bridge/source count/highlight name tương đương; oracle63,165=3Miss/2Extra/2Incon PASS. Đây là quan sát một lần A/B, không phải speedup ổn định; cần ABAB và thêm workload163comp trước phát hành. Candidate chỉ trong evidence, chưa đưa vào bản gốc.

## Thiết kế v2 đề nghị và cách hoạt động

A. Extract một lần: xác định selected comps và shared-node union bằng native, bulk-read chỉ nearby elements thuộc scope. Giữ IDs/connectivity/config làm snapshot cục bộ cho một lần Check, không lưu lịch sử qua lần Check khác.

B. Exterior topology: Tet10/Tet4 dùng mapping local face chuẩn. Prototype đầu tiên nên bỏ vòng lấy24 lindex bằng lassign connectivity và dựng4 face trực tiếp. Đếm incidence theo corner triplet có scope component để loại internal faces; không gộp qua component, không dùng parity để xử lý non-manifold. Midside assignment/order phải giữ nguyên. Với config khác chỉ dùng native fallback đã kiểm chứng, không suy luận từ config đầu của mixed component.

C. Chỉ mục gọn dùng trong lần Check: node→selected owners, pair→shared nodes, source→face/edge incidence. V1 đã có sparse pairs và face index; v2 phải giảm object/string/split/copy thực tế, không thêm một cache dictionary lớn rồi gọi cùng scan cũ (prototype topology-cache trước đã chậm hơn). Đánh số edge/face bằng integer trong kernel; node ID gốc giữ riêng để report/GUI. Tránh dense array theo max node ID vì IDs thưa/lớn.

D. Classification giữ oracle: full shared face regions nối qua toàn bộ quadratic edge; Missing là mid không shared giữa hai TRIA6 có vòng outer edges đầy đủ; Extra cần bridge graph nối hai vùng có full faces; conflicting mids/mid-shared-corner-incomplete/same-region ambiguity vào Incon như v1. BFS/Tarjan đã O(V+E), giữ linear graph, ưu tiên giảm representation và quét lại. Không dùng coordinate KD-tree/tolerance để thay topology theo node ID.

E. Materialize cuối: tạo diagnostic plot collectors sau khi phân loại; report chỉ giữ pair lỗi. Show shared faces tạo khi người dùng yêu cầu. Option lazy highlight có thể giúp thời gian trả list nhưng thay đổi workflow hiện tại nên chỉ là lựa chọn tương lai, không tính là tăng tốc tương đương.

F. View/navigation: Next chỉ lấy tọa độ endpoint+mid của edge, giữ source comp và diagnostic collectors. Không cần tính bounding box toàn comp rồi ghi đè bằng edge camera. Đây là cải tiến riêng tương tác, không chứng minh tăng tốc Check.

Giữ standalone Tcl làm đường mặc định. Nếu representation Tcl vẫn không đạt mục tiêu sau benchmark, accelerator C++/NumPy chỉ là candidate giai đoạn sau: extract API tuần tự trong HM rồi xử lý snapshot ngoài process; không gọi API HM đồng thời từ worker. Chưa có số đo startup/serialize/memory/fallback nên chưa chọn dependency đó.

## Acceptance trước thay v1

- ABAB trên cùng scratch/model hash, exact2022.3.0.24/Nastran, bao gồm tổng Check→list/highlight ready, từng pha và peak memory; warm/cold tách rõ.
- So mọi edge key/mid node/category, bridge sides, source face counts, report surfaces và highlight names. Giữ independent oracle63,165=3/2/2.
- Fixtures: TRIA6/QUAD8; Tet10/Tet4; mixed config; internal face/non-manifold;3+ owners; selected subset; mass/rigid; sparse IDs; no shared/no errors; malformed connectivity.
- Entity coordinates/connectivity/card ownership nguồn không đổi; temp collector collision/cleanup, cancel và lỗi giữa pha.
- Check lại đọc mesh mới; không dựa history/cache cũ. Live GUI riêng cho Next/visibility/redraw và Show shared faces.
- Chỉ giữ candidate có gain toàn pipeline lặp lại và không làm yếu oracle. Hiện chỉ có một so sánh whole-check candidate khoảng4.2%; chưa có mức tăng tốc v2 ổn định được chứng minh.

Evidence: `02_HM_MCP/evidence/runs/sharededges_v2_research_20261012/`; snapshots, SHA256, native logs, rejected variants được giữ. MCP disposition: resource-only research/API recipes; không thêm public operation hay promote stable. Direct batch PASS không phải MCP protocol PASS hoặc release/independent certification.
