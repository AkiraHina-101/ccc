"""Optional durable input inbox. Python 3.9+, standard library, no network.

This stores input; it does not hook a chat app or run an AI automatically.
"""

import argparse
import json
import os
import re
import sys
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path


EVENT_ID = re.compile(r"E-[0-9a-f]{32}\Z")
REQUEST_ID = re.compile(r"R([0-9]+)\Z")


def memory_root(workspace, task=None):
    root = Path(workspace).expanduser().resolve()
    if not root.is_dir():
        raise ValueError("Workspace must be an existing directory")
    memory = root / ".agent"
    if task:
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", task):
            raise ValueError("Invalid task ID")
        memory = memory / "tasks" / task
    return memory


def capture(memory, text):
    """Return only after a complete event has been flushed and installed."""
    if not text.strip():
        raise ValueError("Input is empty")
    event = {
        "schema": 1,
        "event_id": "E-" + uuid.uuid4().hex,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "text": text,
    }
    inbox = memory / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    destination = inbox / (event["event_id"] + ".json")
    descriptor, temporary = tempfile.mkstemp(prefix=".capture-", suffix=".tmp", dir=inbox)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as output:
            json.dump(event, output, ensure_ascii=False, indent=2)
            output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, destination)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return event["event_id"]


def event_path(memory, event_id, folder="inbox"):
    if not EVENT_ID.fullmatch(event_id):
        raise ValueError("Invalid event ID")
    return memory / folder / (event_id + ".json")


def read_event(path):
    event = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(event, dict) or event.get("schema") != 1 or event.get("event_id") != path.stem:
        raise ValueError("Invalid event envelope: " + path.name)
    if not isinstance(event.get("text"), str) or not isinstance(event.get("created_at"), str):
        raise ValueError("Invalid event fields: " + path.name)
    return event


def pending(memory, limit=20):
    if limit < 1:
        raise ValueError("Limit must be positive")
    files = sorted((memory / "inbox").glob("E-*.json"))
    # Metadata only; do not load all raw inputs into a model's context.
    entries = []
    for path in files:
        event = read_event(path)
        entries.append({"event_id": event["event_id"], "created_at": event["created_at"],
                        "characters": len(event["text"])})
    entries.sort(key=lambda item: (item["created_at"], item["event_id"]))
    return {"total": len(entries), "shown": min(limit, len(entries)),
            "remaining": max(0, len(entries) - limit), "events": entries[:limit]}


def acknowledge(memory, event_id, request_id):
    """Archive input only after a complete ledger entry and STATE exist."""
    match = REQUEST_ID.fullmatch(request_id)
    if not match:
        raise ValueError("Invalid request ID")
    source = event_path(memory, event_id)
    destination = event_path(memory, event_id, "processed")
    if not source.is_file():
        if destination.is_file():
            read_event(destination)
            return "already_processed"
        raise ValueError("Event not found")
    read_event(source)
    ledger = (memory / "REQUESTS.md").read_text(encoding="utf-8-sig")
    entry = re.search(
        r"(?ms)^## " + re.escape(request_id) + r"\s*\|[^\n]*\n(.*?)(?=^## R[0-9]+\s*\||\Z)",
        ledger,
    )
    if not entry or not re.search(r"(?m)^Source event: " + re.escape(event_id) + r"\s*$", entry[1]):
        raise ValueError("Completed request must reference this Source event")
    if not re.search(r"<!-- END " + re.escape(request_id) + r" -->\s*\Z", entry[1]):
        raise ValueError("Request entry is incomplete")
    state = (memory / "STATE.md").read_text(encoding="utf-8-sig")
    revision = re.search(r"(?m)^rev:\s*([0-9]+)\s*$", state)
    cursor = re.search(r"(?m)^request_cursor:\s*R([0-9]+)\s*$", state)
    ending = re.search(r"<!-- END STATE rev=([0-9]+) -->\s*\Z", state)
    if not revision or not ending or revision[1] != ending[1]:
        raise ValueError("STATE is not a complete matching revision")
    if not cursor or int(cursor[1]) < int(match[1]):
        raise ValueError("STATE has not incorporated this request")
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise ValueError("Conflicting processed event exists; inspect before retrying")
    os.replace(source, destination)
    return "processed"


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", required=True)
    parser.add_argument("--task", help="Assigned concurrent task ID; otherwise use .agent/")
    commands = parser.add_subparsers(dest="command", required=True)
    save = commands.add_parser("capture")
    save.add_argument("--input-file", required=True, help="UTF-8 text file, or - for UTF-8 stdin")
    listing = commands.add_parser("pending")
    listing.add_argument("--limit", type=int, default=20)
    read = commands.add_parser("read")
    read.add_argument("event_id")
    ack = commands.add_parser("ack")
    ack.add_argument("event_id")
    ack.add_argument("--request-id", required=True)
    args = parser.parse_args(argv)
    try:
        memory = memory_root(args.workspace, args.task)
        if args.command == "capture":
            value = (sys.stdin.buffer.read().decode("utf-8-sig") if args.input_file == "-"
                     else Path(args.input_file).read_text(encoding="utf-8-sig"))
            result = {"event_id": capture(memory, value), "saved": True}
        elif args.command == "pending":
            result = pending(memory, args.limit)
        elif args.command == "read":
            result = read_event(event_path(memory, args.event_id))
        else:
            result = {"status": acknowledge(memory, args.event_id, args.request_id)}
        # Keep Vietnamese readable instead of inflating it into Unicode escapes.
        sys.stdout.reconfigure(encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except (OSError, ValueError) as error:
        sys.stderr.reconfigure(encoding="utf-8")
        print(json.dumps({"error": str(error)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
