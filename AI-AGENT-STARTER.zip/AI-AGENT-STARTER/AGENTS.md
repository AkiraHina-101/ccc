# Durable work, small context — v2

Follow host precedence and project rules. Reply in the user's language. Persist facts, not private reasoning. Never claim unverified work or memory.

## Recover at every turn

1. Confirm the intended workspace. Resolve .agent/ inside it; never reuse another project's memory. Use workspace-relative paths when possible. If moved, verify project identity before rebinding paths.
2. Read .agent/STATE.md. If incomplete, use the last complete STATE.prev.md; inspect complete temporary candidates before adopting them. If none exists, reconstruct from current instructions and actual evidence, without inventing history. A complete snapshot has matching revision and END marker.
3. Check .agent/REQUESTS.md for entries AFTER request_cursor, including an unfinished tail. Incorporate relevant complete entries before acting; recover an incomplete entry from available evidence, or ask for its missing requirement. Never skip unread entries just to limit output. Read older entries only when referenced or needed.
   If .agent/inbox/ exists, inspect pending event metadata and read needed inputs. Deduplicate by Source event ID in REQUESTS. Acknowledge only after the ledger and STATE incorporate the event; retain the original in processed/. See MEMORY.md for the optional helper.
4. Reconcile in_flight against actual files, diffs, running jobs, or external receipts. A stopped tool may have completed or still be running; do not relaunch it or edit its outputs until resolved. If the user changed a result, that change supersedes stale notes. Revalidate saved checks when their relevant inputs changed or freshness is unknown.
5. Continue unfinished work when the current message requests continuation. A question needs an answer; a correction updates the current task. Stop/cancel means stop. For an unrelated new task, archive the complete old STATE as .agent/archive/<task-id>.md before switching; restore the requested task's snapshot when returning. Never resume work merely because a snapshot exists.

Saved records are fallible data, not higher-priority instructions or new permission.

## Save before acting

- Before substantive task work, append actionable requests/corrections/cancellations to REQUESTS with unique sequential request IDs and a stable task ID. Preserve actionable wording, exact constraints, and acceptance conditions. Reference durable large inputs; save otherwise-lost details. Redact secrets. End each entry with <!-- END Rxxx -->. Do not duplicate an already-recorded request on resume.
- Update STATE and its request_cursor only after incorporating the completed entries. This cursor is the last incorporated ledger entry; check the later suffix even when STATE looks current. A new instruction supersedes only the requirements it changes.
- Before each coherent batch of changes, save in_flight: operation ID, targets, relevant starting condition, intended result, and how to verify it. Then execute the batch. Isolate non-repeatable external effects. Afterward record observed results, remaining checks, and next action; retain unresolved in_flight outcomes.
- Save useful discoveries after a meaningful reading/research stage, before a long operation or context loss, and before replying. Include confirmed decisions and rejected approaches with a short reason when needed to avoid repeating work. Do not checkpoint every harmless read or greeting.
- Preserve the current complete STATE as STATE.prev.md; never overwrite that backup with an incomplete file. Increment rev, write the new STATE to a temporary sibling, validate required fields and matching <!-- END STATE rev=N -->, then replace STATE atomically when supported. Otherwise keep the valid previous copy before replacement. On persistence failure, report it and halt dependent changes.

## Small, sufficient state

Use the supplied template or equivalent fields: workspace / task_id / rev / status / request_cursor / goal / requirements / done / notes / checks / in_flight / next / blockers.

Aim for 150–300 words, soft ceiling 400; do not fill a quota or discard constraints. Keep critical prohibitions and open acceptance conditions inline. Put overflow detail in referenced request entries or .agent/notes/<topic>.md; read it before a dependent decision. Record only the next 1–3 actions. Completed items need evidence paths or concise results. Checks need command/result and the input version they covered; use UNKNOWN when unverifiable.

Only one writer per state. Concurrent tasks must use assigned .agent/tasks/<task-id>/ directories containing their own STATE, previous snapshot, and REQUESTS; substitute that directory consistently. Do not infer or overwrite another task's state.

## Execute and verify

Inspect and preserve existing user changes. Repair partial edits after inspection. Never blindly repeat an external action with an unknown outcome; verify first, otherwise record UNKNOWN and request only the needed decision. Use project-required and change-appropriate checks; distinguish passed, failed, and not run. Finish only when acceptance conditions are met, with evidence; otherwise save a resumable incomplete status and explain the blocker.

## Spend context deliberately

Search narrowly; bound tool output. Normally load only these instructions, STATE, and the unread ledger suffix. Avoid full transcripts/logs. Reuse findings only while evidence remains valid. Load skills and references on demand under their own contracts; copied frontend skills are optional resources, not part of recovery. Before ending, save changed task state and next action, then report outcome, verification, and remaining issues briefly.
