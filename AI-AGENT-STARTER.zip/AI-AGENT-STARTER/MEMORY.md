# Bộ nhớ trên ổ đĩa, dùng chung giữa các model

Với ứng dụng riêng của công ty, đặt bộ nhớ cạnh project là cách triển khai cơ bản, không phụ thuộc nhà cung cấp model. Đây là dữ liệu lưu bằng file, không phải phần RAM hay lịch sử chat mà ứng dụng có thể làm mất khi Dừng. Không cần vector database để giữ nhiệm vụ đang làm.

## Ba phần bộ nhớ

| Dữ liệu | File | Cách đọc để hạn chế context |
| --- | --- | --- |
| Đầu vào gốc chưa xác nhận | `.agent/inbox/<event-id>.json` | Liệt kê metadata, đọc các sự kiện cần xử lý |
| Yêu cầu đã tiếp nhận | `.agent/REQUESTS.md` | Đọc phần sau request_cursor và mục được tham chiếu |
| Tình trạng đang làm | `.agent/STATE.md` | Đọc bản ngắn mỗi lượt |

Đầu vào đã được ghi vào ledger và STATE được chuyển sang `.agent/processed/`, không xóa. Việc chuyển này chỉ xác nhận **đã tiếp nhận vào bộ nhớ**, không có nghĩa nhiệm vụ đã làm xong. Model mới có thể đọc cùng những file này sau khi model trước bị dừng. Chỉ cho một model ghi một task tại một thời điểm.

## Luồng cho ứng dụng công ty

```text
Người dùng gửi yêu cầu
  -> ứng dụng ghi inbox và chờ ghi thành công
  -> gọi model, truyền workspace và event_id
  -> model đọc STATE + yêu cầu mới + đối chiếu thao tác bị ngắt
  -> ghi REQUESTS có Source event + STATE đã cập nhật
  -> xác nhận tiếp nhận, chuyển đầu vào sang processed/
  -> model thực hiện việc, lưu checkpoint trước/sau các nhóm thao tác
```

Ứng dụng cần tự lưu cả yêu cầu hủy/sửa và trạng thái job nếu muốn giữ chúng khi Dừng. Có file inbox không tự làm model đọc file; ứng dụng hoặc hướng dẫn khởi động vẫn phải đưa đúng đường dẫn vào lượt chạy được người dùng cho phép. Sự kiện cũ không tự cấp quyền tiếp tục task.

Nếu chỉ dùng AGENTS mà không sửa ứng dụng, AI có thể gọi lệnh capture làm thao tác đầu tiên. Cách đó bảo vệ từ sau lần ghi thành công; vẫn không bảo vệ khoảng trước khi model kịp gọi lệnh. Tích hợp trước lời gọi model mới che được khoảng này đối với lần ghi đã thành công.

## Công cụ có sẵn

Yêu cầu Python 3.9 trở lên, chỉ dùng thư viện chuẩn. Thay `<bundle>` và `<project>` bằng đường dẫn thật. Không truyền nội dung dài qua tham số command line; dùng file UTF-8 hoặc stdin.

```text
python <bundle>/tools/memory.py --workspace <project> capture --input-file <request.txt>
python <bundle>/tools/memory.py --workspace <project> pending --limit 20
python <bundle>/tools/memory.py --workspace <project> read <event-id>
```

Lệnh capture chỉ báo `saved: true` sau khi đã ghi, flush/fsync và thay file tạm bằng file sự kiện hoàn chỉnh. Khi lỗi, trả mã thoát khác 0. Bên gọi phải chờ thành công trước khi gửi cùng đầu vào đó cho model. Mỗi capture tạo ID mới: nếu bên gọi không nhận được kết quả và muốn thử lại, kiểm tra inbox trước, tránh ghi cùng yêu cầu hai lần.

`pending` trả ID, thời gian và độ dài; không trả toàn bộ nội dung. Kết quả có total/shown/remaining để không bỏ qua dữ liệu vượt giới hạn. Nếu remaining còn lớn, xử lý/xác nhận các mục đầu rồi liệt kê tiếp; không xem giới hạn 20 là đã đọc đủ. File `.tmp` đang ghi dở không được coi là sự kiện hoàn chỉnh. Thời gian giúp sắp xếp thông thường; ứng dụng phải giữ thứ tự gửi thật nếu có nhiều nguồn gửi hoặc đồng hồ thay đổi.

Sau khi ghi bản ghi R001 hoàn chỉnh có dòng `Source event: <event-id>`, và cập nhật STATE với request_cursor từ R001 trở đi cùng marker revision khớp, chạy:

```text
python <bundle>/tools/memory.py --workspace <project> ack <event-id> --request-id R001
```

Lệnh ack kiểm tra các bằng chứng cú pháp đó trước khi chuyển file. Nó không đánh giá model đã hiểu đúng yêu cầu hay thực sự hoàn thành công việc. Nếu sự kiện đã được xử lý, gọi lại trả `already_processed`; bản gốc vẫn nằm trong processed/.

Nếu ứng dụng lưu cả câu hỏi tình trạng/ngữ cảnh không tạo yêu cầu mới, có thể ghi một mục ledger ngắn `Type: context` với Source event, cập nhật cursor rồi ack; không biến nội dung đó thành lệnh tiếp tục. Lệnh capture không tự phân loại hay thực thi nội dung.

Task đồng thời có thể thêm `--task T001` sau workspace ở tất cả các lệnh. Khi đó bộ nhớ nằm trong `.agent/tasks/T001/`. Phải dùng cùng một task ID ở mọi lệnh và trong hướng dẫn cho model. Không chạy hai model ghi STATE của cùng task; công cụ này không cung cấp khóa đa tiến trình cho STATE/REQUESTS.

## Những điều đã và chưa làm

Công cụ đã được đóng gói để chạy độc lập; chưa được cài hoặc nối vào ứng dụng riêng của công ty. Nhà phát triển ứng dụng có thể gọi CLI trước model, hoặc dùng module Python nếu ứng dụng phù hợp. Mọi model cần có quyền đọc file hoặc được ứng dụng cung cấp nội dung tương ứng.

File được lưu dạng văn bản rõ; công cụ không tự phát hiện hoặc che bí mật. Bên gọi cần loại thông tin không được phép lưu theo chính sách công ty trước khi capture, và giữ quyền truy cập bộ nhớ như quyền truy cập project. Bộ nhớ file không thay thế bản sao lưu và không bảo đảm chống mất điện/hỏng ổ đĩa ở mọi hệ thống.

Kiểm tra helper từ thư mục bộ hướng dẫn:

```text
python -B -m unittest discover -s tests -p test_memory.py -v
```

Các kiểm tra này kiểm chứng việc lưu/đọc/xác nhận file, không chứng minh model hay ứng dụng máy đích luôn tuân thủ giao thức.

Tại môi trường đóng gói, **10 kiểm tra đã chạy thành công**, gồm giữ nguyên tiếng Việt/tiếng Nhật, đọc giới hạn metadata, bỏ qua file tạm dở, lỗi trước khi cài file, từ chối xác nhận khi checkpoint chưa đủ, xác nhận lặp an toàn và đường lệnh UTF-8. Chưa chạy trong ứng dụng công ty.
