# Active task — rev=1

workspace: <project identity/root; verify if moved>
task_id: T001
rev: 1
status: pending
request_cursor: R000
goal: <current user outcome>

## requirements
- [ ] <open acceptance condition; request ID; critical constraints inline>

## done
- None verified yet. <Later: result plus evidence path/identifier.>

## notes
- <working files, important finding, decision/reason; omit unused lines>

## checks
- Not run: <command/validation>. Input version: unknown.

## in_flight
- None. <Before action: operation ID; targets; starting condition; desired result; verification.>

## next
1. <smallest concrete next action>

## blockers
- None known. <Include unresolved outcome or decision when present.>

<!-- END STATE rev=1 -->
