"""Test durable inbox behavior, not model compliance."""

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

SPEC = importlib.util.spec_from_file_location("agent_memory", Path(__file__).parents[1] / "tools" / "memory.py")
memory = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(memory)


class MemoryTests(unittest.TestCase):
    def setUp(self):
        # Use the test workspace, not a system temp directory with separate ACLs.
        test_root = Path(__file__).resolve().parent
        self.temporary = tempfile.TemporaryDirectory(prefix=".memory-test-", dir=test_root)
        resolved_test = Path(self.temporary.name).resolve()
        resolved_test.relative_to(test_root)
        if resolved_test == test_root:
            raise ValueError("Refuse cleanup of the test root itself")
        self.addCleanup(self.temporary.cleanup)
        self.root = memory.memory_root(self.temporary.name)

    def record_checkpoint(self, event_id, cursor="R001", marker=1, complete_request=True):
        ending = "<!-- END R001 -->" if complete_request else ""
        (self.root / "REQUESTS.md").write_text(
            "## R001 | T001 | test\nSource event: " + event_id + "\nUser requirement: test\n" + ending + "\n",
            encoding="utf-8",
        )
        (self.root / "STATE.md").write_text(
            "rev: 1\nrequest_cursor: " + cursor + "\n<!-- END STATE rev=" + str(marker) + " -->\n",
            encoding="utf-8",
        )

    def test_unicode_and_newlines_survive(self):
        text = "Yêu cầu: sửa giao diện\nGiữ dữ liệu 日本語.\n"
        event_id = memory.capture(self.root, text)
        self.assertEqual(text, memory.read_event(memory.event_path(self.root, event_id))["text"])

    def test_cli_captures_utf8_stdin_and_reads_it_back(self):
        text = "Tiếp tục nhiệm vụ\nGiữ tên 日本語."
        command = [sys.executable, "-B", str(Path(__file__).parents[1] / "tools" / "memory.py"),
                   "--workspace", self.temporary.name]
        saved = subprocess.run(command + ["capture", "--input-file", "-"],
                               input=text.encode("utf-8"), capture_output=True)
        self.assertEqual(0, saved.returncode, saved.stderr)
        event_id = json.loads(saved.stdout.decode("utf-8"))["event_id"]
        fetched = subprocess.run(command + ["read", event_id], capture_output=True)
        self.assertEqual(0, fetched.returncode, fetched.stderr)
        self.assertEqual(text, json.loads(fetched.stdout.decode("utf-8"))["text"])

    def test_pending_is_bounded_and_excludes_raw_text(self):
        for _ in range(3):
            memory.capture(self.root, "private task details")
        result = memory.pending(self.root, 2)
        self.assertEqual((3, 2, 1), (result["total"], result["shown"], result["remaining"]))
        self.assertNotIn("private task details", json.dumps(result))

    def test_interrupted_temporary_file_is_not_pending(self):
        memory.capture(self.root, "complete")
        (self.root / "inbox" / ".capture-interrupted.tmp").write_text('{"text":', encoding="utf-8")
        self.assertEqual(1, memory.pending(self.root)["total"])

    def test_failed_install_does_not_report_event_as_saved(self):
        with mock.patch.object(memory.os, "replace", side_effect=OSError("simulated interrupted install")):
            with self.assertRaises(OSError):
                memory.capture(self.root, "not installed")
        self.assertEqual(0, memory.pending(self.root)["total"])

    def test_ack_requires_checkpoint_and_preserves_input_on_failure(self):
        event_id = memory.capture(self.root, "task")
        self.record_checkpoint(event_id, cursor="R000")
        with self.assertRaises(ValueError):
            memory.acknowledge(self.root, event_id, "R001")
        self.assertTrue(memory.event_path(self.root, event_id).is_file())

    def test_ack_rejects_incomplete_request_or_mismatching_state_marker(self):
        event_id = memory.capture(self.root, "task")
        self.record_checkpoint(event_id, complete_request=False)
        with self.assertRaises(ValueError):
            memory.acknowledge(self.root, event_id, "R001")
        self.record_checkpoint(event_id, marker=2)
        with self.assertRaises(ValueError):
            memory.acknowledge(self.root, event_id, "R001")
        self.assertTrue(memory.event_path(self.root, event_id).is_file())

    def test_ack_archives_and_is_repeatable_after_interruption(self):
        event_id = memory.capture(self.root, "task")
        self.record_checkpoint(event_id)
        self.assertEqual("processed", memory.acknowledge(self.root, event_id, "R001"))
        self.assertEqual("already_processed", memory.acknowledge(self.root, event_id, "R001"))
        self.assertEqual(0, memory.pending(self.root)["total"])
        self.assertEqual("task", memory.read_event(memory.event_path(self.root, event_id, "processed"))["text"])

    def test_event_path_traversal_is_rejected(self):
        with self.assertRaises(ValueError):
            memory.event_path(self.root, "../../other-file")

    def test_concurrent_tasks_have_separate_memory_directories(self):
        first = memory.memory_root(self.temporary.name, "T001")
        second = memory.memory_root(self.temporary.name, "T002")
        memory.capture(first, "first task")
        self.assertEqual(0, memory.pending(second)["total"])
        with self.assertRaises(ValueError):
            memory.memory_root(self.temporary.name, "../outside")


if __name__ == "__main__":
    unittest.main()
