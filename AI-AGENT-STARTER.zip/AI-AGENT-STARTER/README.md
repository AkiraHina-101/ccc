# Bộ hướng dẫn AI dùng chung — v2

Bộ này giúp AI giữ lại yêu cầu, tiến độ và bước sắp làm trên ổ đĩa, để có thể khôi phục sau khi bấm Dừng, mất cửa sổ chat hoặc đổi phiên. Không gắn với ngôn ngữ lập trình, framework hay project cụ thể.

## Các file chính

| File/thư mục | Mục đích |
| --- | --- |
| `AGENTS.md` | Hướng dẫn thực thi chính, viết bằng tiếng Anh ngắn gọn; yêu cầu AI trả lời theo ngôn ngữ người dùng. |
| `Agent.md` | Bản sao cùng nội dung cho công cụ cần tên này. Chỉ cấu hình đọc một bản. |
| `DESIGN-NOTES.md` | Giải thích thiết kế, giới hạn và cách kiểm tra bằng tiếng Việt. Không cần nạp vào mỗi phiên. |
| `REVIEW.md` | Những lỗ hổng phát hiện ở bản đầu, thay đổi trong v2 và phần chưa được kiểm chứng trên AI đích. |
| `BOOTSTRAP.txt` | Lời nhắc để kích hoạt hoặc tiếp tục khi công cụ không tự đọc hướng dẫn. |
| `MEMORY.md` | Cách lưu đầu vào bền vững và nối với ứng dụng riêng dùng nhiều model. |
| `tools/memory.py` | Công cụ inbox tùy chọn, Python chuẩn, không cần mạng hoặc cài thư viện. |
| `templates/` | Mẫu bộ nhớ; chỉ khởi tạo trong project đích khi chưa có file. |
| `skills/frontend-design/` | Skill định hướng thẩm mỹ, sao nguyên thư mục đang cài. |
| `skills/frontend-design-premium/` | Skill UX sản phẩm, kèm đủ references, scripts, assets và agents. |
| `COPY-MANIFEST.json` | Nguồn, phiên bản bundle và SHA-256 các file đã chép. |
| `skills/frontend-design/LICENSE.txt`, `skills/frontend-design-premium/LICENSE`, `THIRD_PARTY_NOTICES.md` | Giấy phép đặt cùng từng skill và ghi nhận nguồn gốc. |

## Mang sang máy khác

1. Chép nguyên thư mục `AI-AGENT-STARTER` sang máy kia.
2. Trong project đích, cho AI đọc nội dung `AGENTS.md` bằng cơ chế hướng dẫn của công cụ. Nếu công cụ hỗ trợ file hướng dẫn trong project, đặt nội dung vào đúng tên/đúng vị trí mà nó hỗ trợ. Nếu project đã có hướng dẫn, ghép phần chính sách này vào, giữ quy tắc sẵn có; không chép đè. Tên `AGENTS.md` hay `Agent.md` không bảo đảm mọi AI tự nhận.
3. Nếu muốn dùng skill frontend, đặt hai thư mục vào `<project>/skills/` hoặc vị trí skills mà công cụ kia hỗ trợ và chỉ rõ nơi tìm. Giữ chúng cạnh nhau để script resolver tìm được skill phụ thuộc. Chép file không tự đăng ký skill với mọi công cụ. Không cần cài skill để dùng cơ chế chống quên.
4. Với project mới, có thể chép `templates/STATE.md` và `templates/REQUESTS.md` sang `<project>/.agent/`, rồi thay các placeholder bằng nhiệm vụ thật. AI cũng có thể tự tạo theo hướng dẫn. Không ghi đè bộ nhớ đã tồn tại.
5. Nếu AI không tự nạp hướng dẫn mỗi phiên, dùng `BOOTSTRAP.txt` và cung cấp đường dẫn thật. Thiết lập hướng dẫn khởi động trong công cụ sẽ bền hơn việc chỉ nhắn một lần trong chat.

Ví dụ cấu trúc sau khi đưa vào một project bất kỳ:

```text
<project>/
  AGENTS.md                    # đã ghép quy tắc của project nếu có
  .agent/
    STATE.md                   # ngắn, đọc đầu mỗi lượt
    STATE.prev.md              # checkpoint hoàn chỉnh trước, tạo khi cập nhật
    REQUESTS.md                # đọc phần sau request_cursor + mục cũ khi cần
    inbox/<event-id>.json       # đầu vào chưa xác nhận; tùy chọn
    processed/<event-id>.json   # đầu vào đã đối chiếu vào STATE; vẫn được giữ
    archive/<task-id>.md        # chỉ tạo khi chuyển nhiệm vụ
  skills/
    frontend-design/
    frontend-design-premium/
```

Nếu nhiều AI chạy đồng thời, dùng `.agent/tasks/<task-id>/STATE.md` và `REQUESTS.md` riêng cho từng nhiệm vụ; cấu hình mỗi AI đúng task trước khi chạy. Không dùng chung file trạng thái đang ghi.

## Dùng hằng ngày

Giao việc bình thường. AI cần lưu yêu cầu trước khi bắt đầu và lưu ý định trước mỗi nhóm thao tác. Sau khi bấm nhầm Dừng, nhắn: **“Tiếp tục theo AGENTS.md: đọc STATE và phần REQUESTS sau request_cursor; đối chiếu in_flight trước khi làm.”** Nếu mở phiên mới mà AI không biết quy tắc, gửi lời nhắc trong `BOOTSTRAP.txt` trước.

Muốn kiểm tra AI có thực hiện cơ chế không, mở `<project>/.agent/STATE.md`: phải thấy mục tiêu, yêu cầu chưa xong, file đã làm, kiểm tra đã/chưa chạy và bước tiếp theo. Nếu không có file này, không nên coi việc “đã đọc hướng dẫn” là đã có bộ nhớ bền vững.

Skill frontend là tài nguyên tùy chọn khi làm UI. Bản Premium đầy đủ có nhiều yêu cầu và tốn context hơn hướng dẫn chống quên; khi chọn dùng thì vẫn phải tuân thủ hợp đồng của skill. Hai SKILL.md cộng khoảng 39 nghìn ký tự, chưa tính references; không đưa chúng vào prompt thường trực cho mọi việc. Hướng dẫn lõi không ép nạp frontend chỉ vì đang khôi phục task.

Trạng thái hướng tới 150–300 từ, tối đa mềm 400, không bắt buộc viết cho đủ độ dài. Chỉ cập nhật khi có thay đổi công việc; không cần viết lại trạng thái vì một lời chào hoặc câu hỏi tình trạng đơn thuần. Các con số này là mục tiêu biên soạn, không phải ngân sách token được bảo đảm.

## Giới hạn thực tế

Có thể dùng bộ nhớ trên ổ đĩa ngay cả khi ứng dụng dùng nhiều model. Phần mới trong `MEMORY.md` có công cụ ghi đầu vào, liệt kê phần chờ và giữ bản gốc sau xử lý. Để bảo vệ trước lúc model bắt đầu chạy, ứng dụng phải gọi bước ghi này trước khi gửi yêu cầu cho model. Chỉ chép file hướng dẫn không tự nối được vào ứng dụng riêng của công ty.

Đây là quy trình lưu trạng thái, không phải cơ chế phục hồi toàn bộ lịch sử chat. Nó cần AI có quyền đọc/ghi và thật sự tuân thủ. Bấm Dừng trước lần ghi đầu tiên vẫn có thể mất yêu cầu; mất ổ đĩa, file bị xóa hoặc công cụ không nạp hướng dẫn cũng không được khắc phục chỉ bằng Markdown.

Không cam kết số token cố định: phụ thuộc model, tokenizer và công cụ. Thiết kế chỉ giữ hướng dẫn lõi và một trạng thái ngắn trong luồng đọc thường xuyên. Không ghi khóa, mật khẩu, token hay dữ liệu nhạy cảm vào bộ nhớ; cân nhắc loại `.agent/` khỏi version control theo chính sách project. `REQUESTS.md` giữ yêu cầu công việc, không thay thế bản sao lưu chat đầy đủ.

Hai skill được chép từ bundle đang cài phiên bản **1.4.0** vào ngày **15/10/2026**; không sửa nội dung và không tuyên bố đây là bản mới nhất trên mạng. Giữ giấy phép/thông báo nguồn khi chuyển tiếp.
