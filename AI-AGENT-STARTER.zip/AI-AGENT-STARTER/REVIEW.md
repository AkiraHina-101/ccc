# Rà soát thiết kế v2 — 15/10/2026

## Kết luận

Bản đầu có cơ chế checkpoint đúng hướng, nhưng chưa đủ để gọi là đã chứng minh hiệu quả. Bản v2 sửa các khoảng trống trong giao thức; đây vẫn là hướng dẫn cho model, chưa phải một hệ thống tự bảo đảm lưu lịch sử.

| Điểm yếu ở bản đầu | Sửa trong v2 | Chi phí thêm |
| --- | --- | --- |
| Đã nối yêu cầu mới vào REQUESTS nhưng bị dừng trước khi ghi STATE: lần sau chỉ đọc ID cũ nên bỏ sót yêu cầu mới | STATE có request_cursor; mỗi lượt kiểm tra phần ledger sau cursor, kể cả bản ghi dở | Một lượt đọc/search phần mới, có thể gộp cùng đọc STATE |
| Chỉ chú trọng checkpoint sửa file, dễ mất phát hiện sau nhiều bước đọc hoặc nghiên cứu | Lưu phát hiện sau một chặng có ý nghĩa; lưu quyết định và lý do loại hướng thử khi cần | Vài dòng, không ghi sau từng lệnh đọc |
| Nói “giữ bản trước” nhưng chưa thống nhất cách phát hiện snapshot dở | Quy ước STATE.prev.md, số revision và dấu kết thúc khớp revision | Một bản sao trên đĩa; không nạp thường xuyên |
| Báo test đã pass nhưng code hoặc đầu vào đã đổi | Ghi phiên bản đầu vào của bằng chứng; khi không rõ thì kiểm tra lại | Thông tin phiên bản/bằng chứng ngắn |
| STATE có thể bị ép dài dù nhiệm vụ nhỏ | Mục tiêu 150–300 từ, tối đa mềm 400; không có mức tối thiểu; giữ điều cấm và nghiệm thu còn mở ngay trong STATE | Giảm phần đọc lặp |
| Hướng dẫn lõi ép nạp hai skill frontend cho mọi việc UI, có thể ngốn context | Tách cơ chế nhớ khỏi lựa chọn skill; skill được chọn vẫn phải theo đầy đủ hợp đồng của nó | Không cần nạp frontend để khôi phục việc |
| Bootstrap vừa bảo tiếp tục vừa bảo chờ nhiệm vụ | Tách rõ kích hoạt lần đầu và lệnh tiếp tục | Không thêm thủ tục cho lượt thông thường |
| Mẫu REQUESTS có sẵn R001 giả, dễ bị coi là yêu cầu đã lưu | Khối ví dụ Rxxx; cursor ban đầu R000 | Không thêm file runtime |

## Lần theo các tình huống dừng

Đây là rà soát logic bằng cách lần theo thứ tự ghi/đọc, không phải kết quả chạy trên AI máy đích:

1. **Dừng trước khi ghi yêu cầu:** Markdown không cứu được phần chưa lưu. Cần lịch sử chat còn lại hoặc cơ chế của ứng dụng ghi input trước khi gọi model.
2. **REQUESTS hoàn chỉnh, STATE cũ:** phần sau cursor được đọc lại; yêu cầu mới không biến mất chỉ vì chưa vào snapshot.
3. **REQUESTS đang ghi dở:** dấu kết thúc thiếu được phát hiện. Đối chiếu thông điệp còn lại để phục hồi; không suy đoán phần bị mất.
4. **Đã checkpoint, chưa sửa:** kiểm tra điều kiện bắt đầu rồi thực hiện bước còn lại.
5. **Đang sửa hoặc sửa xong nhưng chưa checkpoint lại:** in_flight dẫn tới đúng đối tượng cần đối chiếu; done không được suy ra chỉ từ ý định.
6. **STATE bị cắt dở:** đọc bản prev hoàn chỉnh. Phần ledger chưa xử lý vẫn được tìm; cần đối chiếu thao tác có thể đã xảy ra ngoài snapshot.
7. **Test pass rồi code đổi:** bằng chứng không còn được mặc định hợp lệ.
8. **Đọc nhiều tài liệu rồi dừng:** phát hiện đã checkpoint có thể tái sử dụng; phần chưa ghi vẫn có thể mất.
9. **Task khác hoặc project khác:** xác định workspace/task trước khi đọc bộ nhớ; task đồng thời có thư mục ghi riêng.
10. **Kết quả tác dụng bên ngoài chưa rõ:** xác minh receipt/trạng thái; không tự lặp hành động dựa vào sự thiếu kết quả.

## Các giới hạn chưa thể giải quyết bằng lời nhắc

- Model có thể bỏ qua hướng dẫn, hoặc công cụ không tự nạp file. Phải thử trên đúng model và ứng dụng sử dụng thực tế.
- Cursor và marker giúp phát hiện khoảng trống, không tạo giao dịch nguyên tử giữa nhiều file và không chứng minh nội dung không bị hỏng. Model vẫn phải thực hiện đúng việc ghi/đọc; bản prev không thay thế backup.
- Dừng trước lần ghi đầu tiên vẫn là khoảng trống. Muốn bảo vệ cả lúc đó, ứng dụng chạy AI phải tự lưu input/cancellation trước khi model xử lý; cần biết công cụ cụ thể mới thiết kế tích hợp được.
- Giới hạn context/token do công ty áp dụng vẫn còn. Không thể xác nhận mức tiết kiệm cụ thể nếu chưa biết model, tokenizer, chính sách cache và cách công cụ nạp hướng dẫn.
- Hai SKILL.md frontend cộng lại khoảng 39 nghìn ký tự ở bản đóng gói này, chưa gồm references. Vì vậy không đưa toàn bộ bộ skill vào system prompt thường trực. Con số ký tự không phải số token.

## Tiêu chí chứng minh trên máy đích

Chạy các tình huống trong DESIGN-NOTES ít nhất một lần với phiên mới thật, ở project thử. Quan sát file thực tế, không chỉ lời AI báo đã lưu. Ghi nhận: yêu cầu còn đủ hay thiếu, thao tác có bị làm lại, số bước phải lặp và token thực tế nếu công cụ hiển thị. So sánh với cùng nhiệm vụ không dùng hướng dẫn. Chưa có dữ liệu đó thì chỉ có thể kết luận thiết kế đã được rà soát, không thể đưa tỷ lệ thành công hay bảo đảm chống quên.

## Bổ sung bộ nhớ đầu vào tùy chọn

Sau lần rà soát v2, đã bổ sung `tools/memory.py` và MEMORY.md cho ứng dụng riêng dùng nhiều model. Helper lưu mỗi đầu vào thành sự kiện JSON, liệt kê metadata và chỉ chuyển sang processed sau khi ledger/checkpoint có dấu xác nhận tương ứng. Có **10 kiểm tra tự động đã pass** cho helper, bao gồm trường hợp ghi lỗi và checkpoint chưa hoàn chỉnh. Kết quả này bổ sung bằng chứng thực thi cho phần lưu file; các giới hạn tuân thủ model và tích hợp ứng dụng ở trên vẫn còn.
